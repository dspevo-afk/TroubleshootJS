#!/usr/bin/env python3
"""Package audited epoch15 native-full/native-append receipts; never runs gates."""
from __future__ import annotations

import collections
import gzip
import hashlib
import io
import json
import math
import os
import re
import stat
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any


REPO_DEFAULT = Path(
    r"$REPO"
)
EXPECTED_HEAD = "d37c3b3b8581abdeaa9b88b7bfb2349cff958d31"
EXPECTED_SOURCE = "a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51"
EXPECTED_PRIOR_SOURCE = "a3bd150019d00870a08896efd893c99aff120ce11a49f34cca0af07f33d59c31"
EXPECTED_TASK_NAME = "q30-process-pinned-final-qualification-fcffecff8fa444889bce93725495c628"
EXPECTED_INTEGRATION_SHA = "fa238faff209fdbe497c72637b3e49b6e28a482a18d6ea2123e8ad4a8f3fb9e4"
EXPECTED_PLAN_SHA = "69707f4282dd41a394c2eb6723057b32379d0743553940a2b2a11bd5221f8d48"
EXPECTED_ORIGINAL_PLAN_SHA = "1078cb80a13e8fcde2dac6dd1188ee8fa3add3faf6b64a385ed27ed4cc19b749"
INPUT_COUNT = 1354
ROOT_COUNT = 77
SERVICE_ROOT_COUNT = 21
LAYOUT_EPOCH = 15
JOB_MILLIS = 90000
SHARED_WORK = 640
ACTIVE_OPERATION_MILLIS = 5000
FULL_FINAL = "PASS: current contracts; 82 Java suites, independent seed/value/role oracles and report protocol."
APPEND_FINAL = "PASS: focused current contracts; 1 Java suites. Full matrix and independent oracles NOT RUN."
CLEANUP_MARKER = "CLEANUP: current JVM contract classes and task-owned scratch removed."
SIDECAR_SUFFIXES = (
    ".vectors.txt", ".manifest-resistive.txt", ".manifest-controlled.txt",
    ".manifest-controlled-alt.txt", ".seeds.txt", ".roles.txt", ".values.txt",
)
SOURCE_GROUP_COUNTS = {"src": 1132, "tests": 173, "war": 29, "scripts": 20}
OUT_REL = Path("docs/task-evidence/Q30/epoch15-native-full-append-evidence")
ARCHIVE_NAME = "epoch15-native-full-append-evidence.tar.gz"
MAX_MEMBER_BYTES = 16 * 1024 * 1024
MAX_TOTAL_EVIDENCE_BYTES = 64 * 1024 * 1024
MAX_SOURCE_BYTES = 128 * 1024 * 1024
SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
SIGNED_LONG_RE = re.compile(r"(?:0|-?[1-9][0-9]*)\Z")
PERSONAL_WINDOWS_PATH = re.compile(r"(?i)(?:\\\\\?\\)?[A-Z]:[\\/]+Users[\\/]")
PERSONAL_POSIX_PATH = re.compile(r"(?i)/(?:Users|home)/[^/\s\"'<>]+")
ISO_TIMESTAMP_RE = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.(\d+))?(?:Z|[+-]\d{2}:\d{2})\Z"
)
SECRET_ASSIGNMENT = re.compile(
    r"(?i)\b(password|passwd|secret|token|api[_-]?key|access[_-]?key|"
    r"refresh[_-]?token|client[_-]?secret|authorization|cookie|auth)"
    r"(\s*[:=]\s*)(\"[^\"\r\n]*\"|'[^'\r\n]*'|[^\s,;\]\}]+)"
)
UNREDACTED_SECRET = re.compile(
    r"(?i)\b(?:password|passwd|secret|token|api[_-]?key|access[_-]?key|"
    r"refresh[_-]?token|client[_-]?secret|authorization|cookie|auth)"
    r"\s*[:=]\s*(?![\"']?\[REDACTED\])(?:\"[^\"]+\"|'[^']+'|[^\s,;\]\}]+)"
)


class PacketError(RuntimeError):
    pass


def need(condition: bool, message: str) -> None:
    if not condition:
        raise PacketError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normpath(path: Path) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def under(path: Path, root: Path) -> bool:
    try:
        return os.path.commonpath((normpath(path), normpath(root))) == normpath(root)
    except (ValueError, OSError):
        return False


def reject_reparse_chain(path: Path, root: Path) -> None:
    lexical = Path(os.path.abspath(str(path)))
    root_lexical = Path(os.path.abspath(str(root)))
    need(under(lexical, root_lexical), "input path escapes its approved root")
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    cursor = lexical
    while True:
        try:
            info = cursor.lstat()
        except OSError as exc:
            raise PacketError("cannot inspect bounded input path: " + path.name) from exc
        if stat.S_ISLNK(info.st_mode) or (getattr(info, "st_file_attributes", 0) & reparse_flag):
            raise PacketError("reparse/symlink input refused: " + path.name)
        if normpath(cursor) == normpath(root_lexical):
            break
        parent = cursor.parent
        need(parent != cursor, "input root ancestry is invalid")
        cursor = parent
    try:
        resolved = path.resolve(strict=True)
        root_resolved = root.resolve(strict=True)
    except OSError as exc:
        raise PacketError("input path did not resolve: " + path.name) from exc
    need(under(resolved, root_resolved), "resolved input escaped its approved root")


def decode_text(raw: bytes, label: str) -> str:
    try:
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
            return raw.decode("utf-16", errors="strict")
        if raw.startswith(b"\xef\xbb\xbf"):
            return raw.decode("utf-8-sig", errors="strict")
        return raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise PacketError("strict text decode failed for " + label) from exc


def unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        need(key not in result, "duplicate JSON key in retained evidence")
        result[key] = value
    return result


def reject_json_constant(value: str) -> Any:
    raise PacketError("nonstandard JSON constant refused: " + value)


def parse_json(raw: bytes, label: str) -> Any:
    try:
        return json.loads(decode_text(raw, label), object_pairs_hook=unique_pairs,
                          parse_constant=reject_json_constant)
    except PacketError:
        raise
    except Exception as exc:
        raise PacketError("invalid JSON receipt: " + label) from exc


def iso_timestamp(value: Any) -> bool:
    if not isinstance(value, str) or not value:
        return False
    match = ISO_TIMESTAMP_RE.fullmatch(value)
    if match is None:
        return False
    fraction = match.group(1)
    if fraction is not None and len(fraction) > 6:
        value = re.sub(r"\.(\d+)(?=Z|[+-]\d{2}:\d{2})",
                       lambda found: "." + found.group(1)[:6], value)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return parsed.tzinfo is not None


def same_utc_identity(left: Any, right: Any) -> bool:
    """Compare exact UTC ticks while accepting omitted trailing fractional zeros."""
    if not iso_timestamp(left) or not iso_timestamp(right):
        return False
    pattern = re.compile(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(?:Z|\+00:00)\Z')
    a, b = pattern.fullmatch(left), pattern.fullmatch(right)
    return bool(a and b and a.group(1) == b.group(1) and
                (a.group(2) or '').rstrip('0') == (b.group(2) or '').rstrip('0'))


class Inputs:
    """Exact-byte input capture and post-archive recheck; no directory traversal."""
    def __init__(self) -> None:
        self.baselines: dict[str, tuple[Path, Path, int, str]] = {}
        self.payload_cache: dict[str, bytes] = {}

    def capture(self, path: Path, root: Path) -> bytes:
        reject_reparse_chain(path, root)
        key = normpath(path)
        if key in self.payload_cache:
            return self.payload_cache[key]
        try:
            before = path.stat()
            need(stat.S_ISREG(before.st_mode), "input is not a regular file: " + path.name)
            need(before.st_size <= MAX_MEMBER_BYTES, "evidence member exceeds 16 MiB: " + path.name)
            raw = path.read_bytes()
            after = path.stat()
        except OSError as exc:
            raise PacketError("cannot read bounded evidence file: " + path.name) from exc
        need(len(raw) == before.st_size == after.st_size and
             before.st_mtime_ns == after.st_mtime_ns,
             "input changed while being captured: " + path.name)
        digest = sha(raw)
        self.baselines[key] = (path, root, len(raw), digest)
        self.payload_cache[key] = raw
        return raw

    def verify_source(self, path: Path, root: Path, expected_size: int,
                      expected_sha: str) -> None:
        reject_reparse_chain(path, root)
        try:
            before = path.stat()
            need(stat.S_ISREG(before.st_mode), "source input is not a regular file: " + path.name)
            need(before.st_size == expected_size, "source snapshot size mismatch: " + path.name)
            digest = sha_file(path)
            after = path.stat()
        except OSError as exc:
            raise PacketError("cannot hash source snapshot input: " + path.name) from exc
        need(before.st_size == after.st_size == expected_size and
             before.st_mtime_ns == after.st_mtime_ns and digest == expected_sha,
             "current source bytes differ from the frozen 1,354-input snapshot: " + path.name)
        key = normpath(path)
        prior = self.baselines.get(key)
        value = (path, root, expected_size, expected_sha)
        need(prior is None or prior[2:] == value[2:], "source input was captured with conflicting hashes")
        self.baselines[key] = value

    def recheck_all(self) -> None:
        for path, root, size, expected_sha in self.baselines.values():
            reject_reparse_chain(path, root)
            try:
                info = path.stat()
                current_sha = sha_file(path)
                after = path.stat()
            except OSError as exc:
                raise PacketError("input disappeared during archive validation: " + path.name) from exc
            need(info.st_size == after.st_size == size and
                 info.st_mtime_ns == after.st_mtime_ns and current_sha == expected_sha,
                 "input changed before evidence publication: " + path.name)


def safe_relative_source(value: Any) -> str:
    need(isinstance(value, str) and value and "\\" not in value,
         "source snapshot path is malformed")
    rel = PurePosixPath(value)
    need(not rel.is_absolute() and all(part not in ("", ".", "..") for part in rel.parts),
         "source snapshot path escapes repository")
    need(rel.as_posix() == value, "source snapshot path is not canonical")
    need(rel.parts and rel.parts[0] in SOURCE_GROUP_COUNTS,
         "source snapshot has an unexpected source group")
    return rel.as_posix()


def source_rows(snapshot: dict[str, Any]) -> dict[str, tuple[int, str]]:
    rows = snapshot.get("files")
    need(isinstance(rows, list) and len(rows) == INPUT_COUNT,
         "source snapshot must contain exactly 1,354 file rows")
    result: dict[str, tuple[int, str]] = {}
    groups: collections.Counter[str] = collections.Counter()
    for row in rows:
        need(isinstance(row, dict), "source snapshot row is malformed")
        rel = safe_relative_source(row.get("path"))
        size, digest = row.get("size"), row.get("sha256")
        need(type(size) is int and size >= 0 and isinstance(digest, str) and
             SHA256_RE.fullmatch(digest) is not None,
             "source snapshot row has an invalid size/hash")
        need(rel not in result, "source snapshot contains duplicate paths")
        result[rel] = (size, digest)
        groups[rel.split("/", 1)[0]] += 1
    need(dict(groups) == SOURCE_GROUP_COUNTS,
         "source snapshot group counts differ from the reviewed 1,354-file inventory")
    return result


def canonical_long(value: Any) -> bool:
    if not isinstance(value, str) or SIGNED_LONG_RE.fullmatch(value) is None:
        return False
    number = int(value)
    return -(1 << 63) <= number <= (1 << 63) - 1 and str(number) == value


def verify_plan(pointer: dict[str, Any], plan_raw: bytes,
                plan: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str], str]:
    plan_sha = sha(plan_raw)
    need(pointer.get("originalPlanSha256") == EXPECTED_ORIGINAL_PLAN_SHA and
         pointer.get("continuedPlanSha256") == EXPECTED_PLAN_SHA and
         plan_sha == EXPECTED_PLAN_SHA and pointer.get("changedPlanFields") == ["baseHead"],
         "original/continued frozen plan binding changed")
    need(plan.get("schema") == 1 and plan.get("planEpoch") == 4 and
         plan.get("baseHead") == EXPECTED_HEAD,
         "acceptance plan schema, epoch, or base HEAD changed")
    cases = plan.get("cases")
    service = plan.get("serviceAndSensitivitySeeds")
    need(isinstance(cases, list) and len(cases) == ROOT_COUNT,
         "acceptance plan is not the original 77-root cohort")
    need(isinstance(service, list) and len(service) == SERVICE_ROOT_COUNT and
         all(canonical_long(seed) for seed in service) and len(set(service)) == SERVICE_ROOT_COUNT,
         "service/sensitivity cohort is not 21 unique signed-long roots")
    case_seeds: list[str] = []
    for index, case in enumerate(cases):
        need(isinstance(case, dict) and canonical_long(case.get("seed")),
             "frozen root identity malformed at row " + str(index))
        need(type(case.get("packages")) is int and 20 <= case["packages"] <= 40 and
             type(case.get("channels")) is int and case["channels"] in (1, 2) and
             isinstance(case.get("canonical"), str) and case["canonical"],
             "frozen root package/channel/canonical metadata malformed")
        case_seeds.append(case["seed"])
    need(len(set(case_seeds)) == ROOT_COUNT and set(service).issubset(set(case_seeds)),
         "frozen roots are duplicated or lack the 21 service/sensitivity roots")
    return cases, service, plan_sha


def scrub_text(text: str, repo: Path, task: Path, workspace: Path) -> str:
    replacements = [
        (str(task), "$TASK_ROOT"), (str(task).replace("\\", "/"), "$TASK_ROOT"),
        (str(repo), "$REPO"), (str(repo).replace("\\", "/"), "$REPO"),
        (str(workspace), "$TASK_WORKSPACE"),
        (str(workspace).replace("\\", "/"), "$TASK_WORKSPACE"),
        (str(Path(tempfile.gettempdir())), "$OS_TEMP"),
        (str(Path.home()), "$USER_HOME"),
    ]
    # Text logs can contain JSON-escaped Windows paths alongside plain paths.
    replacements += [(source.replace('\\', '\\\\'), target)
                     for source, target in list(replacements) if '\\' in source]
    for source, target in sorted(replacements, key=lambda pair: len(pair[0]), reverse=True):
        text = re.sub(re.escape(source), target, text, flags=re.IGNORECASE)
    text = PERSONAL_WINDOWS_PATH.sub("$USER_HOME", text)
    text = PERSONAL_POSIX_PATH.sub("$USER_HOME", text)
    text = re.sub(r"(?i)\b(Bearer\s+)(?!\[REDACTED\])[A-Za-z0-9._~+/\-=]+",
                  r"\1[REDACTED]", text)
    text = re.sub(r"(?i)\b(Basic\s+)(?!\[REDACTED\])[A-Za-z0-9+/=]{8,}",
                  r"\1[REDACTED]", text)
    text = re.sub(r"(?i)(https?://[^:/\s\"'<>]+:)([^@\s\"'<>]+)(@)",
                  r"\1[REDACTED]\3", text)
    text = re.sub(r"(?i)\bAKIA[0-9A-Z]{16}\b", "[REDACTED]", text)
    text = SECRET_ASSIGNMENT.sub(lambda match: match.group(1) + match.group(2) + "[REDACTED]", text)
    need(PERSONAL_WINDOWS_PATH.search(text) is None and PERSONAL_POSIX_PATH.search(text) is None,
         "personal absolute path remains after sanitization")
    need(UNREDACTED_SECRET.search(text) is None,
         "credential-like assignment remains after sanitization")
    return text


def scrub_value(value: Any, repo: Path, task: Path, workspace: Path) -> Any:
    if isinstance(value, str):
        return scrub_text(value, repo, task, workspace)
    if isinstance(value, list):
        return [scrub_value(item, repo, task, workspace) for item in value]
    if isinstance(value, dict):
        clean: dict[str, Any] = {}
        for key, item in value.items():
            key_text = scrub_text(str(key), repo, task, workspace)
            normalized = re.sub(r"[^a-z0-9]", "", key_text.casefold())
            if any(normalized == part or normalized.endswith(part) for part in
                   ("password", "passwd", "secret", "token", "apikey", "accesskey",
                    "refreshkey", "authorization", "cookie", "auth")):
                clean[key_text] = "[REDACTED]" if item is not None else None
            else:
                clean[key_text] = scrub_value(item, repo, task, workspace)
        return clean
    if value is None or type(value) in (bool, int, float):
        need(not isinstance(value, float) or math.isfinite(value), "non-finite JSON number refused")
        return value
    raise PacketError("unsupported JSON value in evidence")


class Packager:
    def __init__(self, repo: Path, task: Path, workspace: Path,
                 inputs: Inputs | None = None) -> None:
        self.repo, self.task, self.workspace = repo, task, workspace
        self.inputs = inputs if inputs is not None else Inputs()
        self.items: dict[str, dict[str, Any]] = {}
        self.total_raw = 0

    def capture_json(self, path: Path, root: Path, label: str) -> tuple[bytes, Any]:
        raw = self.inputs.capture(path, root)
        return raw, parse_json(raw, label)

    def add_file(self, member: str, path: Path, root: Path, kind: str) -> None:
        posix = PurePosixPath(member)
        need(not posix.is_absolute() and ".." not in posix.parts and "\\" not in member and
             member not in self.items,
             "unsafe or duplicate archive member")
        raw = self.inputs.capture(path, root)
        need(len(raw) <= MAX_MEMBER_BYTES, "raw evidence file exceeds bounded member size")
        self.total_raw += len(raw)
        need(self.total_raw <= MAX_TOTAL_EVIDENCE_BYTES,
             "raw evidence exceeds the 64 MiB packet budget")
        if kind == "json":
            value = parse_json(raw, member)
            safe = scrub_value(value, self.repo, self.task, self.workspace)
            payload = (json.dumps(safe, ensure_ascii=False, allow_nan=False,
                                  indent=2, sort_keys=True) + "\n").encode("utf-8")
        elif kind == "text":
            text = decode_text(raw, member)
            payload = scrub_text(text, self.repo, self.task, self.workspace).replace(
                "\r\n", "\n").encode("utf-8")
        else:
            raise PacketError("unrecognized evidence file kind")
        need(len(payload) <= MAX_MEMBER_BYTES and
             PERSONAL_WINDOWS_PATH.search(payload.decode("utf-8")) is None and
             PERSONAL_POSIX_PATH.search(payload.decode("utf-8")) is None,
             "portable evidence failed privacy/path checks")
        self.items[member] = {
            "rawBytes": len(raw), "rawSha256": sha(raw),
            "payload": payload, "payloadBytes": len(payload),
            "payloadSha256": sha(payload), "kind": kind,
        }


def capture_json(packager: Packager, path: Path, root: Path, label: str) -> tuple[bytes, dict[str, Any]]:
    raw, value = packager.capture_json(path, root, label)
    need(isinstance(value, dict), "expected JSON object: " + label)
    return raw, value


def verify_source_binding(packager: Packager, repo: Path, task: Path,
                          workspace: Path) -> dict[str, Any]:
    pointer_raw, pointer = capture_json(packager, workspace / "epoch15-task-pointer.json",
                                        workspace, "epoch15-task-pointer.json")
    integration_pointer_raw, integration_pointer = capture_json(
        packager, workspace / "integration-pointer.json", workspace, "integration-pointer.json")
    need(pointer.get("schema") == 1 and pointer.get("baseHead") == EXPECTED_HEAD and
         pointer.get("sourceIdentity") == EXPECTED_SOURCE and pointer.get("frozenRoots") == ROOT_COUNT and
         pointer.get("frozenServiceSensitivityRoots") == SERVICE_ROOT_COUNT and
         pointer.get("layoutEpoch") == LAYOUT_EPOCH,
         "epoch15 restart pointer differs from approved source/cohort")
    need(sha(integration_pointer_raw) == EXPECTED_INTEGRATION_SHA and
         pointer.get("integrationPointerSha256") == EXPECTED_INTEGRATION_SHA,
         "integration pointer hash binding changed")
    task_text = pointer.get("taskRoot")
    need(isinstance(task_text, str) and task_text, "epoch15 task root is missing")
    temp_root = Path(tempfile.gettempdir()).resolve(strict=True)
    reject_reparse_chain(Path(task_text), temp_root)
    task_from_pointer = Path(task_text).resolve(strict=True)
    need(task_from_pointer.name == EXPECTED_TASK_NAME and under(task_from_pointer, temp_root) and
         under(task.resolve(strict=True), temp_root) and normpath(task_from_pointer) == normpath(task),
         "task root is not the exact bounded epoch15 OS-temp root")
    need(integration_pointer.get("schema") == 1 and
         integration_pointer.get("status") == "INTEGRATED_PENDING_FRESH_GATES" and
         integration_pointer.get("baseHead") == EXPECTED_HEAD and
         integration_pointer.get("taskRoot") == task_text and
         integration_pointer.get("priorSourceIdentity") == EXPECTED_PRIOR_SOURCE,
         "integrated source pointer differs from the reviewed candidate")
    integration_raw, integration = capture_json(packager, task / "integration.json", task,
                                                 "task/integration.json")
    need(integration.get("status") == "INTEGRATED_PENDING_FRESH_GATES" and
         integration.get("baseHead") == EXPECTED_HEAD and
         integration.get("taskRoot") == task_text and
         integration.get("priorSourceIdentity") == EXPECTED_PRIOR_SOURCE,
         "task-local source integration record differs")
    need(integration.get("changes") == integration_pointer.get("changes"),
         "task-local and workspace source-change inventories disagree")

    plan_raw, plan = capture_json(packager, task / "acceptance-plan.json", task,
                                  "task/acceptance-plan.json")
    cases, service_seeds, plan_sha = verify_plan(pointer, plan_raw, plan)
    maintained_raw, maintained = capture_json(
        packager, task / "source-snapshot-maintained.json", task,
        "task/source-snapshot-maintained.json")
    snapshot_raw, snapshot = capture_json(packager, task / "source-snapshot.json", task,
                                          "task/source-snapshot.json")
    source_audit_raw, source_audit = capture_json(
        packager, task / "source-input-audit.json", task, "task/source-input-audit.json")
    need(source_audit.get("schema") == 1 and source_audit.get("status") == "PASS" and
         source_audit.get("sourceIdentity") == EXPECTED_SOURCE and
         source_audit.get("baseHead") == EXPECTED_HEAD and
         source_audit.get("inputsVerified") == INPUT_COUNT and
         source_audit.get("layoutAlgorithmVersion") == LAYOUT_EPOCH and
         source_audit.get("q30NormalPlayerEnabled") is False and
         source_audit.get("maintainedSnapshotSha256") == sha(maintained_raw),
         "fresh source-input audit is not PASS/disabled/source-bound")
    for label, value in (("maintained source snapshot", maintained), ("runner source snapshot", snapshot)):
        need(value.get("sourceIdentity") == EXPECTED_SOURCE and value.get("baseHead") == EXPECTED_HEAD,
             label + " identity/head mismatch")
    maintained_rows = source_rows(maintained)
    snapshot_rows = source_rows(snapshot)
    need(maintained_rows == snapshot_rows,
         "maintained and runner source snapshots disagree on raw hashes")
    source_total = sum(row[0] for row in snapshot_rows.values())
    need(source_total <= MAX_SOURCE_BYTES, "source hash inventory exceeds bounded size budget")
    for rel, (size, digest) in snapshot_rows.items():
        packager.inputs.verify_source(repo.joinpath(*rel.split("/")), repo, size, digest)

    changed_rows = integration_pointer.get("changes")
    need(isinstance(changed_rows, list) and len(changed_rows) == 5,
         "integration source-change inventory must contain the five reviewed files")
    changed_by_path = {row.get("path"): row.get("candidateSha256")
                       for row in changed_rows if isinstance(row, dict)}
    expected_changes = {
        "src/com/lushprojects/circuitjs1/client/CirSim.java",
        "src/com/lushprojects/circuitjs1/client/QuickPlayDeveloperVerifier.java",
        "tests/browser/compiled_attribute_acceptance.py",
        "tests/qualification/q30-scale-acceptance/normal_screen_host.py",
        "tests/qualification/q30-scale-acceptance/overlay-manifest.json",
    }
    need(set(changed_by_path) == expected_changes and len(changed_by_path) == 5,
         "integration changed-source path set differs")
    for rel, candidate_sha in changed_by_path.items():
        need(snapshot_rows.get(rel, (None, None))[1] == candidate_sha,
             "integrated candidate hash differs from current source snapshot")
    return {
        "pointer": pointer, "pointerSha256": sha(pointer_raw),
        "integrationPointer": integration_pointer,
        "integrationPointerSha256": sha(integration_pointer_raw),
        "integration": integration, "integrationSha256": sha(integration_raw),
        "plan": plan, "planSha256": plan_sha, "cases": cases,
        "serviceSeeds": service_seeds, "maintainedSnapshot": maintained,
        "maintainedSnapshotSha256": sha(maintained_raw), "snapshot": snapshot,
        "snapshotSha256": sha(snapshot_raw), "sourceAudit": source_audit,
        "sourceAuditSha256": sha(source_audit_raw), "sourceRows": snapshot_rows,
        "sourceBytes": source_total,
    }


def expected_preflight(batch: str, cases: list[dict[str, Any]],
                       service_seeds: list[str]) -> list[str]:
    start, end = (0, 51) if batch == "native-full" else (51, 77)
    corpus = [row["seed"] for row in cases[start:end]]
    tail = service_seeds * 2 if batch == "native-full" else []
    return list(dict.fromkeys(corpus + tail))


def parse_plan_receipt(text: str, batch: str, cases: list[dict[str, Any]],
                       service_seeds: list[str]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in text.splitlines():
        if line.startswith("Q30_CASE_PLAN "):
            value = parse_json(line[len("Q30_CASE_PLAN "):].encode("utf-8"),
                               batch + " Q30_CASE_PLAN")
            need(isinstance(value, dict), "case plan receipt row is not an object")
            rows.append(value)
    expected = expected_preflight(batch, cases, service_seeds)
    need([row.get("seed") for row in rows] == expected,
         batch + " plan rows differ from exact frozen seed order")
    by_seed = {row["seed"]: row for row in cases}
    for row in rows:
        case = by_seed.get(row.get("seed"))
        need(case is not None and row.get("schema") == 1 and row.get("planEpoch") == 4 and
             row.get("canonical") == case.get("canonical") and
             row.get("channelCount") == case.get("channels") and
             row.get("packageCount") == case.get("packages"),
             batch + " plan row identity differs from frozen acceptance plan")
        need(row.get("maxJobMillis") == JOB_MILLIS and
             row.get("maxJobSteps") == SHARED_WORK and
             row.get("activeOperationMillis") == ACTIVE_OPERATION_MILLIS,
             batch + " receipt changed a frozen runtime budget")
    return rows


def validate_cleanup(packager: Packager, task: Path, batch: str,
                     owner: dict[str, Any], children: dict[str, Any],
                     cleanup: dict[str, Any]) -> None:
    need(cleanup.get("schema") == 1 and cleanup.get("batch") == batch and
         cleanup.get("status") == "PASS" and cleanup.get("noTerminationPerformed") is True and
         cleanup.get("recordedWrapperPid") == owner.get("pid") and
         same_utc_identity(cleanup.get("recordedWrapperCreationUtc"), owner.get("createdUtc")) and
         cleanup.get("recordedWrapperInstanceGone") is True and
         cleanup.get("pidCurrentlyPresent") is False,
         batch + " independent wrapper cleanup receipt is not PASS")
    rows = children.get("rows")
    need(isinstance(rows, list) and len(rows) > 0,
         batch + " lacks captured live verifier ownership samples")
    seen_pids: set[int] = set()
    scratch_counts: collections.Counter[str] = collections.Counter()
    temp_root = Path(tempfile.gettempdir()).resolve(strict=True)
    for row in rows:
        need(isinstance(row, dict) and type(row.get("ProcessId")) is int and
             row["ProcessId"] > 0 and row["ProcessId"] not in seen_pids and
             row.get("ParentProcessId") == owner.get("pid") and
             isinstance(row.get("ExecutablePath"), str) and row["ExecutablePath"] and
             Path(row["ExecutablePath"]).name.casefold() == "java.exe" and
             isinstance(row.get("CommandLine"), str) and
             isinstance(row.get("createdUtc"), str) and iso_timestamp(row["createdUtc"]),
             batch + " live process sample is malformed or not owned by its wrapper")
        seen_pids.add(row["ProcessId"])
        scratch_text = row.get("scratchPath")
        need(isinstance(scratch_text, str) and scratch_text and Path(scratch_text).is_absolute(),
             batch + " live JVM scratch root is not an absolute path")
        scratch = Path(scratch_text)
        need(under(scratch, temp_root) and
             re.search(r"TroubleshootJS-current-contracts-[0-9a-f]{32}$", scratch.name) is not None and
             "classes" in row["CommandLine"].casefold() and
             scratch_text.casefold() in row["CommandLine"].casefold(),
             batch + " process sample lacks a unique contained verifier scratch binding")
        scratch_counts[normpath(scratch)] += 1
    cleanup_rows = cleanup.get("scratch")
    need(isinstance(cleanup_rows, list), batch + " cleanup scratch receipt is malformed")
    observed_counts: collections.Counter[str] = collections.Counter()
    for item in cleanup_rows:
        need(isinstance(item, dict) and isinstance(item.get("path"), str),
             batch + " cleanup scratch row is malformed")
        scratch = Path(item["path"])
        need(scratch.is_absolute() and under(scratch, temp_root) and item.get("exists") is False and
             item.get("liveJvmCount") == 0 and item.get("liveJvms") == [],
             batch + " captured verifier scratch/JVM cleanup did not pass")
        observed_counts[normpath(scratch)] += 1
    need(observed_counts == scratch_counts,
         batch + " cleanup receipt does not cover each captured task JVM scratch identity")


def validate_batch(packager: Packager, task: Path, batch: str,
                   binding: dict[str, Any]) -> dict[str, Any]:
    result_path = task / (batch + "-result.json")
    audit_path = task / (batch + "-audit.json")
    owner_path = task / (batch + "-ownership.json")
    children_path = task / (batch + "-live-children.json")
    cleanup_path = task / (batch + "-cleanup-review.json")
    log_path = task / (batch + ".log")
    receipt_path = task / (batch + ".txt")
    result_raw, result = capture_json(packager, result_path, task, batch + " result")
    audit_raw, audit = capture_json(packager, audit_path, task, batch + " audit")
    owner_raw, owner = capture_json(packager, owner_path, task, batch + " ownership")
    children_raw, children = capture_json(packager, children_path, task, batch + " live-child sample")
    cleanup_raw, cleanup = capture_json(packager, cleanup_path, task, batch + " cleanup")
    log_raw = packager.inputs.capture(log_path, task)
    receipt_raw = packager.inputs.capture(receipt_path, task)
    log_text = decode_text(log_raw, batch + ".log")
    receipt_text = decode_text(receipt_raw, batch + ".txt")

    need(result.get("schema") == 1 and result.get("batch") == batch and
         result.get("head") == EXPECTED_HEAD and
         result.get("consumedSourceIdentity") == EXPECTED_SOURCE and
         result.get("consumedInputsVerified") == INPUT_COUNT and
         result.get("exitCode") == 0 and
         result.get("status") == "COMMAND_PASS_PENDING_RECEIPT_REVIEW" and
         result.get("complete") is True and
         result.get("acceptancePlanSha256") == binding["planSha256"],
         batch + " wrapper result is not the expected completed terminal receipt")
    expected_suite_count = 82 if batch == "native-full" else 1
    need(result.get("suiteCount") == expected_suite_count and
         result.get("cleanupElapsedSeconds") == "NOT RECORDED separately" and
         type(result.get("elapsedSeconds")) in (int, float) and
         math.isfinite(result.get("elapsedSeconds")) and result["elapsedSeconds"] >= 0 and
         iso_timestamp(result.get("startedUtc")) and iso_timestamp(result.get("finishedUtc")),
         batch + " wrapper timing or suite count differs from maintained runner")
    corpus_start, corpus_end = (0, 51) if batch == "native-full" else (51, 77)
    corpus_seeds = [row["seed"] for row in binding["cases"][corpus_start:corpus_end]]
    service_seeds = binding["serviceSeeds"]
    for key, expected in (("serviceSeeds", service_seeds),
                          ("sensitivitySeeds", service_seeds),
                          ("corpusSeeds", corpus_seeds)):
        need(result.get(key) == expected, batch + " wrapper seed list/order changed: " + key)

    need(owner.get("schema") == 1 and owner.get("batch") == batch and
         type(owner.get("pid")) is int and owner["pid"] > 0 and
         iso_timestamp(owner.get("createdUtc")) and
         isinstance(owner.get("executable"), str) and owner["executable"] and
         isinstance(owner.get("command"), str) and owner["command"] and
             isinstance(owner.get("taskRoot"), str) and
             normpath(Path(owner["taskRoot"])) == normpath(task),
         batch + " wrapper ownership identity is malformed")
    need(children.get("schema") == 1 and children.get("batch") == batch and
         children.get("wrapperPid") == owner["pid"] and
         same_utc_identity(children.get("wrapperCreationUtc"), owner.get("createdUtc")) and
         children.get("sourceIdentity") == EXPECTED_SOURCE and
         children.get("noTerminationPerformed") is True,
         batch + " live-child ownership sample is not bound to its wrapper/source")
    validate_cleanup(packager, task, batch, owner, children, cleanup)

    need(audit.get("schema") == 1 and audit.get("batch") == batch and
         audit.get("auditStatus") == "PASS" and audit.get("issues") == [] and
         isinstance(audit.get("taskRoot"), str) and
         normpath(Path(audit["taskRoot"])) == normpath(task),
         batch + " independent native audit is not PASS")
    source_inputs = audit.get("sourceInputs", {})
    need(source_inputs.get("expected") == INPUT_COUNT and
         source_inputs.get("checked") == INPUT_COUNT and
         source_inputs.get("sourceIdentity") == EXPECTED_SOURCE and
         source_inputs.get("allRawInputsUnchanged") is True and
         source_inputs.get("mismatches") == [],
         batch + " native audit did not verify every frozen raw source input")
    acceptance = audit.get("acceptance", {})
    need(acceptance.get("planSha256") == binding["planSha256"] and
         acceptance.get("baseHead") == EXPECTED_HEAD and
         acceptance.get("layoutEpoch") == LAYOUT_EPOCH and
         acceptance.get("frozenRoots") == ROOT_COUNT and
         acceptance.get("serviceSensitivityRoots") == SERVICE_ROOT_COUNT and
         acceptance.get("expectedSuiteCount") == expected_suite_count and
         acceptance.get("expectedCorpusCount") == len(corpus_seeds),
         batch + " audit acceptance binding/cohort differs")
    audit_wrapper = audit.get("wrapper", {})
    need(audit_wrapper.get("head") == EXPECTED_HEAD and
         audit_wrapper.get("consumedSourceIdentity") == EXPECTED_SOURCE and
         audit_wrapper.get("consumedInputsVerified") == INPUT_COUNT and
         audit_wrapper.get("exitCode") == 0 and
         audit_wrapper.get("status") == result["status"] and
         audit_wrapper.get("complete") is True and
         audit_wrapper.get("cleanupElapsedSeconds") == "NOT RECORDED separately" and
         audit_wrapper.get("suiteCount") == expected_suite_count and
         math.isclose(float(audit_wrapper.get("elapsedSeconds", -1)),
                      float(result["elapsedSeconds"]), rel_tol=0, abs_tol=1e-9),
         batch + " strict audit wrapper summary differs from raw terminal result")
    suite = audit.get("suiteMarkers", {})
    need(suite.get("maintainedDefinitionCount") == 82 and
         suite.get("requiredCount") == expected_suite_count and suite.get("missing") == [],
         batch + " strict suite-marker audit is incomplete")
    artifacts = audit.get("artifacts", {})
    for key, path in (("wrapperResult", result_path), ("nativeLog", log_path),
                      ("receipt", receipt_path)):
        recorded = artifacts.get(key)
        need(isinstance(recorded, str) and normpath(Path(recorded)) == normpath(path),
             batch + " strict audit artifact link differs: " + key)
    logs = audit.get("logs", {})
    final = FULL_FINAL if batch == "native-full" else APPEND_FINAL
    need(log_text.count(final) == 1 and log_text.count(CLEANUP_MARKER) == 1 and
         "CURRENT_CONTRACT_FAILURE:" not in log_text and
         logs.get("finalMarker") == final and logs.get("finalMarkerCount") == 1 and
         logs.get("cleanupMarkerCount") == 1 and logs.get("failureMarkerCount") == 0,
         batch + " raw log lacks exact terminal/cleanup markers or contains failure")
    plan_rows = parse_plan_receipt(receipt_text, batch, binding["cases"], service_seeds)
    corpus = audit.get("cohorts", {}).get("corpus", {})
    need(corpus.get("expectedRows") == len(corpus_seeds) and
         corpus.get("receiptRows") == len(corpus_seeds) and
         corpus.get("acceptedRows", -1) + corpus.get("rejectedRows", -1) == len(corpus_seeds) and
         corpus.get("rowSeedsMatchedInOrder") is True,
         batch + " structural corpus summary does not cover its exact roots")

    service = audit.get("cohorts", {})
    if batch == "native-full":
        need(service.get("serviceExpected") == 105 and service.get("serviceReceipt") == 105 and
             service.get("sensitivityExpected") == 105 and
             service.get("sensitivityReceipt") == 105,
             "native-full lacks exact 105/105 service and sensitivity receipts")
        full_only = audit.get("fullOnly", {})
        oracle_markers = full_only.get("independentOracleMarkers", {})
        protocol_markers = full_only.get("reportAndListenerMarkers", {})
        need(len(oracle_markers) == 4 and all(type(value) is int and value >= 1
                                              for value in oracle_markers.values()) and
             len(protocol_markers) == 2 and all(type(value) is int and value >= 1
                                                for value in protocol_markers.values()),
             "native-full independent oracle or report/listener receipts are missing")
        sidecars = full_only.get("sidecars", [])
        need(isinstance(sidecars, list) and len(sidecars) == len(SIDECAR_SUFFIXES) and
             all(item.get("nonempty") is True and type(item.get("bytes")) is int and
                 item["bytes"] > 0 for item in sidecars),
             "native-full parity/seed/role/value sidecars are incomplete")
        for suffix in SIDECAR_SUFFIXES:
            path = Path(str(receipt_path) + suffix)
            packager.inputs.capture(path, task)
            matching = [row for row in sidecars if isinstance(row, dict) and
                        isinstance(row.get("path"), str) and
                        normpath(Path(row["path"])) == normpath(path)]
            need(len(matching) == 1 and matching[0]["bytes"] == path.stat().st_size,
                 "native-full sidecar audit path/size mismatch")
            packager.add_file("native-full/" + path.name, path, task, "text")
    else:
        need(service.get("serviceExpected") == 0 and service.get("serviceReceipt") == 0 and
             service.get("sensitivityExpected") == 0 and service.get("sensitivityReceipt") == 0,
             "native-append unexpectedly claims service/sensitivity work")
        need(audit.get("fullOnly") == {}, "native-append claims full-only independent oracles")

    # Exact, bounded allow-list; no directories, profiles, caches, .git, or screenshots.
    packager.add_file("native-" + batch + "/result.json", result_path, task, "json")
    packager.add_file("native-" + batch + "/audit.json", audit_path, task, "json")
    packager.add_file("native-" + batch + "/ownership.json", owner_path, task, "json")
    packager.add_file("native-" + batch + "/live-children.json", children_path, task, "json")
    packager.add_file("native-" + batch + "/cleanup-review.json", cleanup_path, task, "json")
    packager.add_file("native-" + batch + "/native.log", log_path, task, "text")
    packager.add_file("native-" + batch + "/receipt.txt", receipt_path, task, "text")
    return {
        "batch": batch, "wrapperStatus": result["status"], "exitCode": result["exitCode"],
        "auditStatus": audit["auditStatus"], "cleanupStatus": cleanup["status"],
        "suiteCount": expected_suite_count,
        "corpus": {"rows": len(corpus_seeds), "acceptedRows": corpus["acceptedRows"],
                   "rejectedRows": corpus["rejectedRows"], "seedOrderMatched": True},
        "serviceCases": service.get("serviceReceipt", 0),
        "sensitivityCases": service.get("sensitivityReceipt", 0),
        "operationElapsedSeconds": float(result["elapsedSeconds"]),
        "cleanupElapsedSeconds": "NOT RECORDED separately",
        "ownershipSamples": len(children["rows"]), "casePlanRows": len(plan_rows),
    }


def sanitize_member(raw: bytes, logical: str, kind: str,
                    repo: Path, task: Path, workspace: Path) -> bytes:
    if kind == "json":
        value = parse_json(raw, logical)
        clean = scrub_value(value, repo, task, workspace)
        payload = (json.dumps(clean, ensure_ascii=False, allow_nan=False,
                              indent=2, sort_keys=True) + "\n").encode("utf-8")
    else:
        payload = scrub_text(decode_text(raw, logical), repo, task, workspace).replace(
            "\r\n", "\n").encode("utf-8")
    text = payload.decode("utf-8", errors="strict")
    need(PERSONAL_WINDOWS_PATH.search(text) is None and PERSONAL_POSIX_PATH.search(text) is None,
         "portable member contains a personal absolute path")
    need(UNREDACTED_SECRET.search(text) is None,
         "portable member contains a credential-like assignment")
    need(len(payload) <= MAX_MEMBER_BYTES, "portable member exceeds bounded size")
    return payload


def tar_add(tar: tarfile.TarFile, name: str, data: bytes) -> None:
    safe = PurePosixPath(name)
    need(not safe.is_absolute() and ".." not in safe.parts and "\\" not in name,
         "unsafe tar member name")
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o600
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    tar.addfile(info, io.BytesIO(data))


def verify_archive(archive: bytes, expected: dict[str, bytes], inner_manifest_name: str,
                   inner_manifest: dict[str, Any]) -> None:
    try:
        tar_raw = gzip.decompress(archive)
        with tarfile.open(fileobj=io.BytesIO(tar_raw), mode="r:") as tar:
            members = tar.getmembers()
            names = [member.name for member in members]
            need(len(names) == len(set(names)) and set(names) == set(expected),
                 "archive member inventory differs from the prevalidated manifest")
            for member in members:
                need(member.isfile() and member.size <= MAX_MEMBER_BYTES,
                     "archive contains a non-file or oversized member")
                stream = tar.extractfile(member)
                need(stream is not None, "archive member could not be read")
                data = stream.read(MAX_MEMBER_BYTES + 1)
                need(len(data) == member.size and len(data) <= MAX_MEMBER_BYTES and
                     sha(data) == sha(expected[member.name]),
                     "archive member bytes/hash differ from prevalidated payload")
                text = data.decode("utf-8", errors="strict")
                need(PERSONAL_WINDOWS_PATH.search(text) is None and
                     PERSONAL_POSIX_PATH.search(text) is None,
                     "archive member contains an unredacted personal path")
            embedded = tar.extractfile(inner_manifest_name)
            need(embedded is not None, "archive manifest is missing")
            parsed = parse_json(embedded.read(MAX_MEMBER_BYTES + 1), inner_manifest_name)
            need(parsed == inner_manifest, "embedded archive manifest changed")
    except PacketError:
        raise
    except Exception as exc:
        raise PacketError("archive failed internal validation") from exc


def write_exclusive(path: Path, data: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def main() -> int:
    workspace = Path(__file__).resolve(strict=True).parent
    repo = REPO_DEFAULT.resolve(strict=True)
    need((repo / ".git").exists() and (repo / "docs" / "task-evidence" / "Q30").is_dir(),
         "expected TroubleshootJS repository/evidence root not found")
    output = repo / OUT_REL
    reject_reparse_chain(output.parent, repo)
    parent = output.parent.resolve(strict=True)
    need(under(parent, repo) and not output.exists() and not output.is_symlink(),
         "refusing to overwrite or escape the new native evidence destination")

    shared_inputs = Inputs()
    pointer_path = workspace / "epoch15-task-pointer.json"
    pointer_raw = shared_inputs.capture(pointer_path, workspace)
    pointer = parse_json(pointer_raw, "epoch15-task-pointer.json")
    need(isinstance(pointer, dict), "epoch15 restart pointer is malformed")
    task = Path(pointer.get("taskRoot", "")).resolve(strict=True)
    packager = Packager(repo, task, workspace, shared_inputs)
    # Capture helper/pointers through the same immutable-input ledger as receipts.
    helper_raw = packager.inputs.capture(Path(__file__).resolve(strict=True), workspace)
    bindings = verify_source_binding(packager, repo, task, workspace)
    need(sha(pointer_raw) == bindings["pointerSha256"],
         "restart pointer changed between initial and bound reads")
    full = validate_batch(packager, task, "native-full", bindings)
    append = validate_batch(packager, task, "native-append", bindings)

    # Explicit allow-list of source and qualification records needed to replay this audit.
    for member, path, root, kind in (
        ("workspace/epoch15-task-pointer.json", workspace / "epoch15-task-pointer.json", workspace, "json"),
        ("workspace/integration-pointer.json", workspace / "integration-pointer.json", workspace, "json"),
        ("workspace/save_process_final_native.py", Path(__file__).resolve(strict=True), workspace, "text"),
        ("task/integration.json", task / "integration.json", task, "json"),
        ("task/acceptance-plan.json", task / "acceptance-plan.json", task, "json"),
        ("task/source-input-audit.json", task / "source-input-audit.json", task, "json"),
        ("task/source-snapshot.json", task / "source-snapshot.json", task, "json"),
        ("task/source-snapshot-maintained.json", task / "source-snapshot-maintained.json", task, "json"),
    ):
        packager.add_file(member, path, root, kind)
    # Preserve task-session identities only when the exact fixed receipt exists.
    for batch in ("native-full", "native-append"):
        session_path = task / (batch + "-tool-session.json")
        if session_path.exists():
            packager.add_file("task/" + session_path.name, session_path, task, "json")

    need(full["corpus"]["rows"] + append["corpus"]["rows"] == ROOT_COUNT and
         full["corpus"]["rows"] == 51 and append["corpus"]["rows"] == 26,
         "native corpus batches do not partition the exact 77 structural roots")
    need(full["serviceCases"] == 105 and full["sensitivityCases"] == 105,
         "native-full service/sensitivity cohorts are incomplete")
    helper_sha = sha(helper_raw)
    readme = (
        "# Q30 epoch 15 native full and append evidence\n\n"
        "This is a scoped evidence packet for the audited native-full and native-append contract batches. "
        "It does not establish overall Q30 acceptance or authorize enabling/publishing Q30.\n\n"
        f"- Base HEAD: `{EXPECTED_HEAD}`.\n"
        f"- Candidate source identity: `{EXPECTED_SOURCE}`; layout epoch {LAYOUT_EPOCH}.\n"
        f"- Frozen source inventory: {INPUT_COUNT} raw files; all hashes were checked before and after archive creation.\n"
        "- Normal-player Q30 catalog: disabled according to the bound source audit.\n"
        f"- Frozen plan: {ROOT_COUNT} unique structural roots (native-full {full['corpus']['rows']} + "
        f"native-append {append['corpus']['rows']}); {SERVICE_ROOT_COUNT} service/sensitivity roots.\n"
        f"- Limits audited from the per-root receipts: {JOB_MILLIS} ms/job, {SHARED_WORK} shared work units, "
        f"{ACTIVE_OPERATION_MILLIS} ms/active operation.\n\n"
        "## Terminal batches\n\n"
        "| Batch | Suites | Structural rows | Native audit | Independent cleanup | Wrapper elapsed | Cleanup elapsed |\n"
        "| --- | ---: | ---: | --- | --- | ---: | --- |\n"
        f"| native-full | {full['suiteCount']} | 51 ({full['corpus']['acceptedRows']} accepted, "
        f"{full['corpus']['rejectedRows']} explicit rejects) | PASS | PASS | "
        f"{full['operationElapsedSeconds']:.3f} s | NOT RECORDED separately |\n"
        f"| native-append | {append['suiteCount']} | 26 ({append['corpus']['acceptedRows']} accepted, "
        f"{append['corpus']['rejectedRows']} explicit rejects) | PASS | PASS | "
        f"{append['operationElapsedSeconds']:.3f} s | NOT RECORDED separately |\n\n"
        f"Native-full also audited {full['serviceCases']}/{full['serviceCases']} service and "
        f"{full['sensitivityCases']}/{full['sensitivityCases']} sensitivity cases and the independent "
        "seed/value/role, report, and listener receipts. Seven parity/seed/role/value sidecars are retained.\n\n"
        "The 77 structural cases are reported once as the 51+26 partition; this packet does not multiply that "
        "count into 308 or label these native contract batches as cold qualification timing. Wrapper elapsed "
        "is the recorded batch duration; the maintained wrapper reports cleanup elapsed as NOT RECORDED separately, "
        "and no cleanup duration is inferred from timestamps.\n\n"
        "The archive contains sanitized terminal result JSON, logs, complete receipts, independent native audits, "
        "wrapper and live-child ownership samples, cleanup reviews, the exact plan, both 1,354-row source-hash "
        "inventories, source audit, and audited parity sidecars. Each member records raw and portable SHA-256; "
        "the whole tar.gz hash is in the adjacent manifest. Source file bodies, `.git`, caches, screenshots, "
        "profiles, and global process inventories are excluded. Personal absolute paths and credential-like "
        "values are scrubbed; raw evidence remains in the task root.\n\n"
        "Cold77, compiled31, menu/replay, archive/visible QA, and independent parent acceptance are separate "
        "gates. This packet claims none of them and makes no publication claim.\n"
    ).encode("utf-8")
    readme = scrub_text(readme.decode("utf-8"), repo, task, workspace).encode("utf-8")
    need(len(readme) <= MAX_MEMBER_BYTES, "generated README exceeds bounded size")

    archive_members: dict[str, bytes] = {}
    file_records: list[dict[str, Any]] = []
    for logical, item in sorted(packager.items.items()):
        member = "evidence/" + logical
        payload = item["payload"]
        archive_members[member] = payload
        file_records.append({
            "member": member, "sourceAlias": logical, "rawBytes": item["rawBytes"],
            "rawSha256": item["rawSha256"], "portableBytes": len(payload),
            "portableSha256": sha(payload), "archiveMemberSha256": sha(payload),
            "kind": item["kind"],
        })
    archive_members["evidence/README.md"] = readme
    file_records.append({"member": "evidence/README.md", "sourceAlias": "generated/README.md",
                         "rawBytes": len(readme), "rawSha256": sha(readme),
                         "portableBytes": len(readme), "portableSha256": sha(readme),
                         "archiveMemberSha256": sha(readme), "kind": "generated-text"})
    inner_manifest = {
        "schema": 1, "packetStatus": "EPOCH15_NATIVE_EVIDENCE_ONLY",
        "q30Acceptance": "NOT_ESTABLISHED_BY_THIS_PACKET",
        "baseHead": EXPECTED_HEAD, "sourceIdentity": EXPECTED_SOURCE,
        "layoutEpoch": LAYOUT_EPOCH, "normalPlayerQ30Enabled": False,
        "structuralRoots": {"total": ROOT_COUNT, "nativeFull": full["corpus"]["rows"],
                             "nativeAppend": append["corpus"]["rows"]},
        "limits": {"maxJobMillis": JOB_MILLIS, "maxSharedWork": SHARED_WORK,
                   "maxActiveOperationMillis": ACTIVE_OPERATION_MILLIS},
        "batches": [full, append], "sourceInputCount": INPUT_COUNT,
        "sourceBytes": bindings["sourceBytes"], "files": file_records,
    }
    inner_manifest_bytes = (json.dumps(inner_manifest, ensure_ascii=False,
                                       allow_nan=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    need(len(inner_manifest_bytes) <= MAX_MEMBER_BYTES, "embedded archive manifest exceeds bounded size")
    archive_members["evidence/ARCHIVE-MANIFEST.json"] = inner_manifest_bytes
    tar_raw = io.BytesIO()
    with tarfile.open(fileobj=tar_raw, mode="w", format=tarfile.PAX_FORMAT) as tar:
        for member, data in sorted(archive_members.items()):
            tar_add(tar, member, data)
    archive = gzip.compress(tar_raw.getvalue(), compresslevel=9, mtime=0)
    verify_archive(archive, archive_members, "evidence/ARCHIVE-MANIFEST.json", inner_manifest)

    # Confirm every evidence byte and all 1,354 source files are unchanged after archive verification.
    packager.inputs.recheck_all()
    reject_reparse_chain(output.parent, repo)
    final_parent = output.parent.resolve(strict=True)
    need(not output.exists() and not output.is_symlink() and under(parent, repo),
         "native evidence destination appeared or escaped before publication")
    need(normpath(final_parent) == normpath(parent),
         "native evidence destination parent changed before publication")
    manifest = dict(inner_manifest)
    manifest.update({
        "createdUtc": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "helperSha256": helper_sha,
        "archiveName": ARCHIVE_NAME, "archiveBytes": len(archive),
        "archiveSha256": sha(archive),
        "embeddedManifestSha256": sha(inner_manifest_bytes),
        "embeddedManifestArchiveMemberSha256": sha(inner_manifest_bytes),
        "embeddedManifestArchiveMemberBytes": len(inner_manifest_bytes),
        "cleanupTiming": "NOT RECORDED separately by maintained native wrapper; no duration inferred",
        "coldTiming": "NOT CLAIMED by native-full/native-append packet",
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, allow_nan=False,
                                 indent=2, sort_keys=True) + "\n").encode("utf-8")
    need(PERSONAL_WINDOWS_PATH.search(manifest_bytes.decode("utf-8")) is None and
         PERSONAL_POSIX_PATH.search(manifest_bytes.decode("utf-8")) is None,
         "external manifest contains personal absolute path")

    # No output path is created until all source, receipt, privacy, and archive checks pass.
    output.mkdir(parents=False, exist_ok=False)
    reject_reparse_chain(output, repo)
    need(under(output.resolve(strict=True), repo),
         "created native evidence destination escaped repository containment")
    write_exclusive(output / ARCHIVE_NAME, archive)
    write_exclusive(output / "manifest.json", manifest_bytes)
    write_exclusive(output / "README.md", readme)
    print(json.dumps({
        "status": "SAVED_EPOCH15_NATIVE_EVIDENCE",
        "output": OUT_REL.as_posix(), "archiveSha256": sha(archive),
        "manifestSha256": sha(manifest_bytes), "helperSha256": helper_sha,
        "nativeFullAudit": full["auditStatus"], "nativeAppendAudit": append["auditStatus"],
        "structuralRoots": ROOT_COUNT, "sourceInputs": INPUT_COUNT,
        "q30Acceptance": "NOT_ESTABLISHED_BY_THIS_PACKET",
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PacketError as exc:
        print("ERROR: native evidence packet not written: " + str(exc), file=sys.stderr)
        raise SystemExit(2)
    except Exception:
        # Avoid printing exception paths/command strings from private task receipts.
        print("ERROR: native evidence packet not written; inspect the local traceback privately.",
              file=sys.stderr)
        raise SystemExit(2)
