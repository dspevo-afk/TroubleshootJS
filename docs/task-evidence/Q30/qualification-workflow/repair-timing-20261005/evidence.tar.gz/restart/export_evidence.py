"""Bounded evidence export, not a qualification or source-archive gate."""
import hashlib, io, json, re, shutil, tarfile
from pathlib import Path, PurePosixPath
N=Path(__file__).resolve().parent; W=N.parent
R=Path(r'$REPO')
E=R/'docs/task-evidence/Q30/qualification-workflow/repair-timing-20261005'
U=Path((N/'headed-ui-root.txt').read_text(encoding='utf-8-sig').strip())
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
flow=read(N/'visible-flow-audit.json')
assert flow['status']=='PASS_TARGETED_30_40_REPAIR_AND_REAL_METERS_ONLY'
assert not E.exists(), 'Preserve preceding evidence export'
members={}; derivations=[]
roots=[(str(R),'$REPO'),(str(W),'$TASK_WORKSPACE'),(r'$TASK_TEMP','$TASK_TEMP'),(r'$WINDOWSAPPS','$WINDOWSAPPS'),(r'$USER_HOME','$USER_HOME')]
def portable(raw):
    if raw.startswith(b'\x89PNG'):return raw
    text=raw.decode('utf-8-sig')
    for old,new in roots:
        text=text.replace(old,new).replace(old.replace('\\','\\\\'),new).replace(old.replace('\\','/'),new)
    assert not re.search(r'(?i)[A-Z]:[\\/]+Users[\\/]+david|[A-Z]:[\\/]+Program Files[\\/]+WindowsApps',text)
    assert not re.search(r'(?i)(Bearer\s+[A-Za-z0-9_-]{12}|gh[pousr]_[A-Za-z0-9]{20}|AKIA[A-Z0-9]{16})',text)
    return text.encode('utf-8')
def add(path,label):
    assert path.is_file() and path.stat().st_size<=20*1024*1024, str(path)
    assert label not in members and not PurePosixPath(label).is_absolute() and '..' not in PurePosixPath(label).parts
    raw=path.read_bytes(); b=portable(raw);members[label]=b
    derivations.append({'member':label,'rawSha256':sha(raw),'portableSha256':sha(b),'portableBytes':len(b)})
for name in ['result.json','result-progress.json','controller-identity.json','bounded-controller-identity.json','preview-process-identity.json','preview-serving-identity.json','owned-processes.json','independent-release-audit.json','preview.log','executed-headed_q30_ui.py']:
    add(U/name,'visible/'+name)
for sub in ['commands','responses','screenshots']:
    paths=sorted((U/sub).iterdir());assert len(paths)<=180
    for p in paths:
        assert p.is_file() and p.suffix in ['.json','.png'];add(p,'visible/'+sub+'/'+p.name)
for p in sorted(N.iterdir()):
    if p.is_file() and p.suffix in ['.json','.py','.ps1','.txt'] and p.name!='export_evidence.py':add(p,'restart/'+p.name)
# Timing evidence is consumed only after the independent root review writes this pointer.
timing=read(N/'timing-review.json')
add(N/'export_evidence.py','restart/export_evidence.py')
for row in timing.get('packetFiles',[]):add(Path(row['path']),'timing/'+row['member'])
baseline=read(R/'docs/task-evidence/Q30/qualification-workflow/targeted-discharge-20261005/preservation-audit.json')
for row in baseline['untracked']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
assert len(members)<=600 and sum(map(len,members.values()))<=96*1024*1024
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for name,b in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(b))
payload=buffer.getvalue();assert len(payload)<=24*1024*1024
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    actual={}
    for m in archive.getmembers():
        assert m.isfile() and m.name in members and m.size==len(members[m.name]); actual[m.name]=archive.extractfile(m).read()
    assert actual==members
E.mkdir()
(E/'evidence.tar.gz').write_bytes(payload)
for name in flow['screenshotsSelectedAndInspected']:shutil.copyfile(U/'screenshots'/name,E/name)
for name in ['visible-flow-audit.json','timing-review.json']: (E/name).write_bytes(portable((N/name).read_bytes()))
(E/'preservation-audit.json').write_text(json.dumps({'status':'PASS','unchangedPreexistingUntrackedFiles':8,'untracked':baseline['untracked']},indent=2)+'\n',encoding='utf-8')
audit={'status':'PASS_PORTABLE_PACKET_ROUNDTRIP_ONLY','archiveSha256':sha(payload),'archiveBytes':len(payload),'regularMembers':len(members),'uncompressedBytes':sum(map(len,members.values())),'derivations':derivations,'privacy':'Known personal roots normalized and listed credential-pattern scan; not a comprehensive privacy certification','boundary':'Evidence packet only; maintained final-source source-archive/qualification gate NOT RUN'}
(E/'packet-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:audit[k] for k in ['status','archiveSha256','archiveBytes','regularMembers']}))
