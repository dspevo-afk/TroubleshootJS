$ErrorActionPreference='Stop'
$workspace=$PSScriptRoot
$pin=Get-Content -LiteralPath (Join-Path $workspace 'fixed-source-pointer.json') -Raw|ConvertFrom-Json
$private=Join-Path $pin.taskRoot 'private-instrument-diagnostic'
$build=Get-Content -LiteralPath (Join-Path $private 'result.json') -Raw|ConvertFrom-Json
if($build.status -ne 'PASS_PRIVATE_INSTRUMENT_BUILD_ONLY' -or $build.acceptanceStatus -ne 'NOT_ASSESSED' -or $build.sourceIdentity -ne $pin.sourceIdentity){throw 'Current private instrument build is not verified'}
$taskRoot=Join-Path ([IO.Path]::GetTempPath()) ('q30-headed-repair-readiness-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $taskRoot|Out-Null
$pointer=Join-Path $workspace 'headed-ui-root.txt'
if(Test-Path -LiteralPath $pointer){throw 'Preserve prior headed launch pointer'}
$taskRoot|Set-Content -LiteralPath $pointer
$driver=Join-Path $workspace 'headed_q30_ui.py'
Copy-Item -LiteralPath $driver -Destination (Join-Path $taskRoot 'executed-headed_q30_ui.py')
if((Get-FileHash -LiteralPath $driver -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $taskRoot 'executed-headed_q30_ui.py') -Algorithm SHA256).Hash){throw 'Preserved UI driver copy differs from executed workspace source'}
$controller=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID)
@{pid=$PID;created=$controller.CreationDate.ToUniversalTime().ToString('o');executable=$controller.ExecutablePath;commandLine=$controller.CommandLine;driverSha256=(Get-FileHash -LiteralPath $driver -Algorithm SHA256).Hash.ToLowerInvariant();headed=$true;sourceIdentity=$pin.sourceIdentity;userScope='Final-source30/40 visible repair-to-readiness;20-success preserved through actual ordinary UI; cold77 remains FAIL; acceptance NOT_ASSESSED'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $taskRoot 'bounded-controller-identity.json')
$env:PYTHONDONTWRITEBYTECODE='1';$env:PYTHONIOENCODING='utf-8';$env:PYTHONPATH='$TASK_TEMP\q30-finish-0fa2512465\deps'
Import-Module '$REPO\scripts\VerifierIsolation.psm1' -Force
$started=[DateTime]::UtcNow
$result=Invoke-VerifierBoundedProcess '$WINDOWSAPPS\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe' @('-B','-u',$driver,$taskRoot,$private) 2500000
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $taskRoot 'bounded-process-result.json')
@{startedUtc=$started.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$result.ExitCode;terminationProven=$result.TerminationProven;scope='Driver operation only; independent post-exit resource release and visible-flow review still required'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $taskRoot 'bounded-command-result.json')
Write-Output $taskRoot
Write-Output $result.Stdout
if($result.ExitCode -ne 0 -or -not $result.TerminationProven){throw 'Headed current meter operation/outer termination not verified'}
