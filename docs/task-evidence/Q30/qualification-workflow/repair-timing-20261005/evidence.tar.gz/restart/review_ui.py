import hashlib, json, re
from collections import Counter
from pathlib import Path
N=Path(__file__).resolve().parent
R=Path(r'$REPO')
U=Path((N/'headed-ui-root.txt').read_text(encoding='utf-8-sig').strip())
read=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
pin=read(N/'fixed-source-pointer.json'); T=Path(pin['taskRoot'])
ui=read(U/'result.json'); a={x['sequence']:x for x in ui['actions']}
assert list(a)==list(range(1,167)) and ui['outcome']=='UI_SESSION_CLOSED_PENDING_FLOW_REVIEW'
assert not ui['errors'] and ui['inputsBefore']==ui['inputsAfter']
assert ui['inputsAfter']=={'status':'PASS','rawInputs':1355,'compiledFiles':357,'permutations':5,'deploymentFiles':6,'pinnedJars':9}
snap=read(T/'source-snapshot.json')
assert len(snap['files'])==1355 and snap['sourceIdentity']==pin['sourceIdentity']
for row in snap['files']:
    b=(R/row['path']).read_bytes()
    assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'], row['path']
assert b'registerStagedFamily(new Rb30PlayerFamilyCapability(), false);' in (R/'src/com/lushprojects/circuitjs1/client/PlayerFamilyCatalog.java').read_bytes()
def body(seq,text): assert text in a[seq]['body'], (seq,text)
def observed(seq,seed,state,isolated):
    v=a[seq]['solverSnapshot']
    assert v['seed']==seed and v['readiness']==state and v['isolated']==isolated
    return v
body(14,'Customer retest did not pass.'); body(65,'FUNCTION VERIFIED')
before=observed(52,'10226','DISCHARGE',True); assert before['FUSED12']>11.9
assert a[53]['command']=={'op':'click','name':'Install as 12 V entry / DREV'}
ready30=observed(76,'10226','READY',True)
body(80,'\n180 Ohm\n'); body(85,'\n457.626 mV\n')
observed(86,'10226','READY',True)
body(123,'Customer retest did not pass.')
observed(126,'10014','DISCHARGE',True)
assert a[143]['command']=={'op':'click','name':'Install as 5 V regulation / REN'}
observed(150,'10014','DISCHARGE',True)
ready40=observed(154,'10014','READY',True)
body(155,'\n180 Ohm\n'); body(158,'\n457.625 mV\n')
observed(159,'10014','READY',True);body(163,'FUNCTION VERIFIED')
assert a[166]['command']=={'op':'close'} and a[166]['status']=='PASS'
release=read(U/'independent-release-audit.json')
assert release['status']=='PASS_EXACT_INSTANCES_AND_PORT_RELEASED' and release['listenerCount']==0
failures=[x for x in ui['actions'] if x['status']!='PASS']
report={
 'status':'PASS_TARGETED_30_40_REPAIR_AND_REAL_METERS_ONLY',
 'sourceIdentity':pin['sourceIdentity'], 'recordedBuildBaseHead':pin['head'],
 'acceptedLocalHead':'ca079d4f70a7509f3ceda95cd2b7799a288c9db0',
 'consumedSourceBytesVerified':1355,
 'actions':len(a),'actionCounts':dict(Counter(x['status'] for x in ui['actions'])),
 'failedActions':failures,
 'case30':{'seed':'10226','packages':30,'part':'Distinct catalog Part31 Generic silicon diode, narrow lead spacing','service':'Original DREV removed, normal compatible replacement installed','originalRemovalRetainedCharge':before,'postInstallNegativeSample':a[54]['solverSnapshot'],'functionalRetest':'Unrepaired FAIL; repaired FUNCTION VERIFIED','actualReady':ready30,'ohm':'180 Ohm','diode':'457.626 mV','recoveryBoundary':'Two115s OHM waits failed; completion/settlement cleared earlier mode. GenuineREADY and numeric readings proved after ordinary mode/probe re-selection. No automatic retry timing certification.'},
 'case40':{'seed':'10014','packages':40,'part':'Distinct catalog Part41 10000 Ohm +/-5%, wide lead spacing','service':'Original REN removed, normal compatible replacement installed','afterRepairStoredEnergy':a[144]['solverSnapshot'],'actualReady':ready40,'ohm':'180 Ohm','diode':'457.625 mV','functionalRetest':'Unrepaired FAIL; repaired FUNCTION VERIFIED','recoveryBoundary':'Initial115s OHM wait failed. LaterREADY/180Ohm with pending same probes; no successful gameplay mutation/probe/power/mode action between150 and154. Transition time not observed; elapsed wall time is not a performance PASS.'},
 'observationBoundary':'Actual headed Edge production preview; all gameplay ordinary visible SDK input. Private read-only page.evaluate getter labels actual CircuitJS time/node voltages/readiness only. No controller/solver calls or injected stepping. Built-in Browser unavailable; not CDP wrapper/blind-diagnosis proof.',
 'driverOutcome':ui['outcome'],'pageErrors':ui['errors'],'inputInventories':ui['inputsAfter'],
 'cleanup':ui['cleanup'],'independentRelease':release,
 'outerLauncher':'Missing bounded-process-result.json and bounded-command-result.json; no outer exit/deadline/termination PASS claimed',
 'negativeIntermediateLimit':'30 upstream -9.264V after normal install is retained. Static owner review found no capacitor clear/restore mutation and no demonstrated persistent defect; intermediate sign/magnitude attribution remains unresolved.',
 'screenshotsSelectedAndInspected':['001-30-unrepaired-discharge.png','007-30-repaired-isolated-meter.png','013-40-unrepaired-off-discharge.png','015-40-repaired-current-state.png','016-40-repaired-function-verified.png'],
 'qualification':'Q30 DISABLED / NOT ACCEPTED; no fullcohort/fullmatrix/current canaries/sourcearchive gates'
}
(N/'visible-flow-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['status','actions','actionCounts','consumedSourceBytesVerified']}))
