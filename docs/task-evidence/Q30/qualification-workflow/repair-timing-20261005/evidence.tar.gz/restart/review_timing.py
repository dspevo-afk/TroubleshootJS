"""Review completed original-host diagnostics; never replaces qualification."""
import hashlib,json
from pathlib import Path
N=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
T=Path(read(N/'current-source-pointer.json')['taskRoot'])
D=Path(read(N/'timing-root-pointer.json')['taskRoot'])
Q=D/'root10014-matched-diagnostic'
run=read(Q/'run.json');owned=read(D/'result.json')
assert run['status']=='DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION' and run['caseCount']==4
assert run['sourceBindingUnchangedBeforeAfter'] and not run['qualification']
assert owned['status']=='COMPLETED_DIAGNOSTIC_NOT_QUALIFICATION' and not owned['errors']
op=owned['operation'];assert op['exitCode']==0 and op['reason'] is None and op['cleanup']['cleanupVerified'] and op['cleanup']['jobActiveProcesses']==0 and op['cleanup']['drainsComplete']
limits={'jobMillis':90000,'sharedWork':640,'activeOperationMillis':5000}
assert run['limits']==limits and run['caseOrder']==['current','old','old','current']
build=read(T/'isolated-build-result.json');assert build['status']=='PASS' and build['exitCode']==0 and build['permutations']==5
canary=read(T/'compiled-canaries-controller/result.json');stage=canary['stage']
assert canary['status']=='PASS' and not canary['errors'] and stage['status']=='PASS' and stage['original77And308CanonicalsUnchanged']
assert canary['operation']['cleanup']['cleanupVerified'] and canary['operation']['cleanup']['jobActiveProcesses']==0
reports=[];cases=[];packet=[]
def add(p,label):
    assert p.is_file();packet.append({'path':str(p),'member':label,'sha256':sha(p),'size':p.stat().st_size})
for row in run['cases']:
    i=row['index']; variant=row['variant'];root=Q/('%02d-%s-seed10014'%(i,variant))
    raw=root/'host/cases/001-cold-10014.report.json';report=read(raw)
    assert sha(raw)==row['reportSha256'] and row['status']=='APP_PASS_DIAGNOSTIC'
    assert row['readerExitCode']==0 and row['reader']['appStatus']=='APP_PASS' and row['reader']['hostStatus']=='HOST_PASS' and row['reader']['synthetic'] is False
    assert not row['reader']['hostErrors'] and not row['reader']['appErrors']
    assert report['classification']==report['applicationOutcome']=='PASS' and report['rootSeed']=='10014'
    assert report['workUnits']==440 and report['generationElapsedMs']<90000 and report['maxActiveOperationMs']<=5000
    assert report['maxJobMillis']==90000 and report['maxWorkUnits']==640 and report['maxActiveOperationMillis']==5000
    hyp=next(x for x in report['stages'] if x['stage']=='HYPOTHESES');assert hyp['workUnits']==390
    cases.append({'index':i,'variant':variant,'applicationMillis':report['generationElapsedMs'],'headroomMillis':report['headroomMs'],'workUnits':440,'hypothesesMillis':hyp['elapsedMs'],'hypothesesUnits':390,'maxActiveOperationMillis':report['maxActiveOperationMs'],'matrixObservations':report['matrixObservations'],'reportSha256':sha(raw),'readerStatus':'APP_PASS/HOST_PASS','hostSeconds':row['elapsedSeconds']})
    reports.append(report)
    for rel in ['case-result.json','case-spec.json','host.stdout.bin','reader.stdout.bin','reader.stderr.bin','host/result.json','host/cases/001-cold-10014.report.json']:
        add(root/rel,'case-%02d-%s/'%(i,variant)+rel)
    # Preserve bounded host-owned process/port receipts, never profiles/caches.
    for name in ['identity.json','owned-processes-before.json','owned-processes-before-close.json','input-manifest-before.json','input-manifest-after.json','runner-before.json','runner-after.json']:
        p=root/'host'/name
        if p.is_file():add(p,'case-%02d-%s/host/'%(i,variant)+name)
release=read(N/'new-resource-release-audit.json')
assert release['status']=='PASS_RECORDED_INSTANCES_AND_PORTS_RELEASED'
assert not any(x['exactInstancePresent'] for x in release['records']) and all(x['released'] for x in release['ports'])
for name in ['identity.json','owned-processes-before.json','owned-processes-before-close.json','input-manifest-before.json','input-manifest-after.json','runner-before.json','runner-after.json','spec.json']:
    add(T/'compiled-canaries-py313'/name,'compiled-host/'+name)
for p in sorted((T/'compiled-canaries-py313/cases').iterdir()):
    assert p.is_file() and p.suffix in ['.json','.png']
    add(p,'compiled-host/cases/'+p.name)
semantic=['program','partition','explicitCompletion','evidence','warmReuse']
same={k:all(x['proof'][k]==reports[0]['proof'][k] for x in reports) for k in semantic}
assert all(same.values()),same
assert all(x['candidates']==reports[0]['candidates'] for x in reports)
contexts=[x['proof']['context'] for x in reports]
current=[x for x in cases if x['variant']=='current'];old=[x for x in cases if x['variant']=='old']
mean=lambda rows,k:sum(x[k] for x in rows)/len(rows)
for p,label in [(D/'result.json','owned-result.json'),(D/'controller-identity.json','controller-identity.json'),(D/'launch.json','launch.json'),(D/'stdout.log','owned.stdout.log'),(D/'stderr.log','owned.stderr.log'),(Q/'run.json','run.json'),(Q/'hashes-before.json','hashes-before.json'),(Q/'hashes-after.json','hashes-after.json'),(T/'source-snapshot.json','current-source-snapshot.json'),(T/'isolated/prepare-receipt.json','current-prepare-receipt.json'),(T/'acceptance-plan.json','current-acceptance-plan.json'),(T/'scale-plan.json','current-scale-plan.json'),(T/'preparation-result.json','current-preparation-result.json'),(T/'isolated-build-result.json','current-build-result.json'),(T/'isolated-build-ownership.json','current-build-ownership.json'),(T/'isolated-build.log','current-build.log'),(T/'compiled-canaries-controller/result.json','compiled-owner-result.json'),(T/'compiled-canaries-controller/controller-identity.json','compiled-owner-identity.json'),(T/'compiled-canaries-py313-stage-result.json','compiled-stage-result.json'),(T/'compiled-canaries-py313/result.json','compiled-host-result.json')]:add(p,label)
review={'status':'PASS_FOUR_BOUNDED_DIAGNOSTICS_NOT_QUALIFICATION','sourceHead':run['bindings']['current']['baseHead'],'currentSourceIdentity':run['bindings']['current']['sourceIdentity'],'oldSourceHead':run['bindings']['old']['baseHead'],'oldSourceIdentity':run['bindings']['old']['sourceIdentity'],'cases':cases,'limits':limits,'commonHostSha256':run['commonHostSha256'],'sourceAppBindingUnchanged':True,'equalPublishedCandidateAndDifficulty':True,'semanticProofFieldsEqual':same,'contextCanonicalCharacters':[len(x) if isinstance(x,str) else len(json.dumps(x)) for x in contexts],'currentMeanApplicationMillis':mean(current,'applicationMillis'),'oldMeanApplicationMillis':mean(old,'applicationMillis'),'currentMinusOldMeanMillis':mean(current,'applicationMillis')-mean(old,'applicationMillis'),'currentMeanHypothesesMillis':mean(current,'hypothesesMillis'),'oldMeanHypothesesMillis':mean(old,'hypothesesMillis'),'oldSameCodeRangeMillis':max(x['applicationMillis'] for x in old)-min(x['applicationMillis'] for x in old),'currentMinimumHeadroomMillis':min(x['headroomMillis'] for x in current),'matrixBoundary':'Observed solver matrix counts vary within identical-source repeats; work units and semantic proof equality do not assert identical adaptive solver cost','build':{'status':'PASS','operationSeconds':build['elapsedSeconds'],'permutations':5},'compiledCanaries':{'status':'PASS','stageSeconds':stage['elapsedSeconds'],'hostCleanupSeconds':stage['cleanupSeconds'],'rootsFrozen':77,'candidateDeclarations':308},'ownedOperation':op,'cpu':'NOT SAMPLED; no contemporaneous system/process CPU attribution','conclusion':'Current77.167/75.904s overlaps old79.999/73.799s; same nominal440/390units and semantic program/partition/evidence. Current mean is363.5ms lower. This diagnostic does not reproduce current-source slowdown or justify a production performance fix. Static50x internal-proof supplemental-time path remains a nonblocking scheduling question, not a measured cause. Prior89.195/90.621s failure cause remains unattributed; new paired passes do not replace the failed qualification cohort.','readiness':'Targeted gates complete; ready for parent-coordinated fresh qualification attempt, not Q30 acceptance','remaining':'Fresh full77/full native matrix/warm distribution/qualified menu-replay/final-source archive/independent acceptance; Q30 remains disabled','packetFiles':packet}
(N/'timing-review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:review[k] for k in ['status','currentMeanApplicationMillis','oldMeanApplicationMillis','currentMinusOldMeanMillis','currentMinimumHeadroomMillis','semanticProofFieldsEqual']}))
