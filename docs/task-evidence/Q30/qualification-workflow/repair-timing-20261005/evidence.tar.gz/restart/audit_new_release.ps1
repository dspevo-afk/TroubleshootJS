$ErrorActionPreference='Stop'
function ReadReceipt($path) { Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -DateKind String }
$taskRoot=(ReadReceipt (Join-Path $PSScriptRoot 'current-source-pointer.json')).taskRoot
$diagnosticRoot=(ReadReceipt (Join-Path $PSScriptRoot 'timing-root-pointer.json')).taskRoot
$caseRoot=Join-Path $diagnosticRoot 'root10014-matched-diagnostic'
$records=@(); $ports=@()
function CheckOwner($recordedPid,$birth,$image,$source) {
 if(-not $recordedPid -or -not $birth -or -not $image){throw ('Incomplete recorded identity '+$source)}
 $live=Get-CimInstance Win32_Process -Filter ('ProcessId='+$recordedPid)
 $same=$null -ne $live -and $live.ExecutablePath -eq $image -and $live.CreationDate.ToUniversalTime() -eq $birth.ToUniversalTime()
 $script:records+=@{pid=$recordedPid;birthUtc=$birth.ToUniversalTime().ToString('o');executable=$image;source=$source;exactInstancePresent=$same;pidPresent=$null -ne $live}
}
function TickOwner($identity,$source) {
 CheckOwner $identity.pid ([DateTime]::FromFileTimeUtc([long]$identity.creationFileTimeTicks)) $identity.executable $source
}
function DateOwner($identity,$source) {
 $birth=if($identity.createdUtc){$identity.createdUtc}else{$identity.created}
 $image=if($identity.executable){$identity.executable}else{$identity.ExecutablePath}
 CheckOwner $identity.pid ([DateTime]::Parse($birth)) $image $source
}
$path=Join-Path $taskRoot 'preparation-result.json'
TickOwner (ReadReceipt $path).controller $path
$path=Join-Path $taskRoot 'isolated-build-ownership.json'
DateOwner (ReadReceipt $path) $path
foreach($root in @((Join-Path $taskRoot 'compiled-canaries-controller'),$diagnosticRoot)){
 $path=Join-Path $root 'controller-identity.json'; TickOwner (ReadReceipt $path) $path
 $path=Join-Path $root 'result.json'; TickOwner (ReadReceipt $path).process $path
}
$path=Join-Path $caseRoot 'run.json'; DateOwner (ReadReceipt $path).controllerIdentity $path
$hosts=@((Join-Path $taskRoot 'compiled-canaries-py313'))
foreach($name in @('01-current-seed10014','02-old-seed10014','03-old-seed10014','04-current-seed10014')){
 $path=Join-Path $caseRoot ($name+'\case-result.json'); DateOwner (ReadReceipt $path).hostProcess $path
 $hosts+=Join-Path $caseRoot ($name+'\host')
}
foreach($root in $hosts){
 $path=Join-Path $root 'result.json'; $receipt=ReadReceipt $path
 if($receipt.cleanup.status -ne 'PASS' -or $receipt.cleanup.ownedSurvivors.Count -ne 0 -or $receipt.cleanup.errors.Count -ne 0){throw ('Host cleanup nonpass '+$path)}
 DateOwner $receipt.identity.runner $path
 foreach($owner in $receipt.identity.edgeProcessesBeforeCases){DateOwner $owner ($path+'#before-cases')}
 foreach($name in @('owned-processes-before.json','owned-processes-before-close.json')){
  $path=Join-Path $root $name
  foreach($owner in (ReadReceipt $path)){DateOwner $owner $path}
 }
 $port=[int]$receipt.identity.port
 $listeners=@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
 $ports+=@{port=$port;source=$root;listeners=$listeners.Count;released=$listeners.Count -eq 0}
}
$survivors=@($records|Where-Object exactInstancePresent)
$openPorts=@($ports|Where-Object { -not $_.released })
$result=@{status=if($survivors.Count -eq 0 -and $openPorts.Count -eq 0){'PASS_RECORDED_INSTANCES_AND_PORTS_RELEASED'}else{'BLOCKED'};observedUtc=[DateTime]::UtcNow.ToString('o');records=$records;ports=$ports;terminationAttempted=$false;scope='Exact recorded preparation/build launchers, native canary/diagnostic controllers and children, original-host runners and Edge inventories, five host ports. Repeated observations retained; build child job cleanup is maintained owner evidence. Headed player UI audited separately; no global process scan or termination.'}
$result|ConvertTo-Json -Depth 9|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'new-resource-release-audit.json')
@{status=$result.status;observations=$records.Count;ports=$ports.Count;pidPresent=@($records|Where-Object pidPresent).Count}|ConvertTo-Json
if($survivors.Count -ne 0 -or $openPorts.Count -ne 0){exit 2}
