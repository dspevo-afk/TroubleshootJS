#!/usr/bin/env python3
"""Prepare a current-HEAD Q30 scale app and source-bound frozen-plan inputs.

This preparation stops before build, browser launch, root execution, or cohort
execution. Run the copied maintained build and compiled-canary owners separately.
"""
from __future__ import annotations

import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import serial_runner as owner

WORKSPACE = Path(__file__).resolve().parent
REPOSITORY = Path(r"$REPO")
EXPECTED_HEAD = "ca079d4f70a7509f3ceda95cd2b7799a288c9db0"
EXPECTED_BRANCH = "codex/q30-multirail-qualification"
HOST_PYTHON = Path(r"$WINDOWSAPPS\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe")
DEFAULT_GWT_JARS = Path(r"$TASK_TEMP\q30-targeted-public-c7f1875bcb354d6c801470625756917b\.tools\gwt-2.7.0")
PREPARE = REPOSITORY / "tests/qualification/q30-scale-acceptance/prepare.py"
ACCEPTANCE = REPOSITORY / "tests/qualification/q30-scale-acceptance/acceptance-plan.json"
MANIFEST = REPOSITORY / "docs/task-evidence/Q30/scale-plan-4/manifest-proposal.json"
OWNER_HASHES = {
    "run_epoch15_build.ps1": "74d5c4d54b9eefdd2d994b50cb9a29523c62320fee7d0d50594ec47ba3569e8f",
    "run_epoch15_canaries.py": "0890337a5f938ff46e59118555969aec7ca8a6b0a5dfff2282fc00656a4ab2cb",
    "run_compiled_canaries_owned.py": "b58e1810f338c3e7b29430ab57796c49a996aff5ec796a758a4814b64ced39d3",
    "serial_runner.py": "19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6",
    "receipts.py": "5d0865564e39a33a679a7fe5adda0e3ba2c539ce5740034e0a495135619ab0a8",
}
LIMITS = {"jobMillis": 90000, "sharedWork": 640, "activeOperationMillis": 5000}


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path, label: str):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise RuntimeError(f"{label} is unavailable or invalid: {error}") from error
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must be a JSON object")
    return value


def write_exclusive(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def canonical(value) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def git(*args: str) -> str:
    return subprocess.check_output(
        ["git", "-C", str(REPOSITORY), *args],
        text=True, encoding="utf-8", errors="strict",
    ).strip()


def verify_owner_copies(plan: dict) -> None:
    expected = plan.get("ownerCopies")
    if expected != OWNER_HASHES:
        raise RuntimeError("preparation-plan.json owner pins differ from this driver")
    for name, digest in OWNER_HASHES.items():
        path = WORKSPACE / name
        if not path.is_file() or path.is_symlink() or sha256_file(path) != digest:
            raise RuntimeError("maintained owner copy missing or changed: " + name)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gwt-jar-directory", type=Path, default=DEFAULT_GWT_JARS)
    args = parser.parse_args()

    plan_path = WORKSPACE / "preparation-plan.json"
    plan = load_json(plan_path, "preparation plan")
    if plan.get("schema") != 1 or plan.get("expectedHead") != EXPECTED_HEAD:
        raise RuntimeError("preparation plan does not pin the current HEAD")
    if plan.get("expectedBranch") != EXPECTED_BRANCH:
        raise RuntimeError("preparation plan branch pin changed")
    verify_owner_copies(plan)

    for output in (
        WORKSPACE / "current-source-pointer.json",
        WORKSPACE / "epoch15-task-pointer.json",
        WORKSPACE / "integration-pointer.json",
    ):
        if output.exists() or output.is_symlink():
            raise RuntimeError("preserving existing pointer/output: " + str(output))

    if not HOST_PYTHON.is_file():
        raise RuntimeError("pinned physical CPython 3.13 host executable is missing")
    # Windows app aliases can change sys.executable while the native image is
    # the requested physical interpreter. Use the maintained native owner.
    native=owner._api();native.GetCurrentProcess.restype=ctypes.c_void_p
    image,birth=owner._identity(native,native.GetCurrentProcess(),HOST_PYTHON.resolve(strict=True))
    controller={'pid':os.getpid(),'executable':image,'creationFileTimeTicks':birth,'reportedExecutable':sys.executable}
    if not REPOSITORY.is_dir() or REPOSITORY.is_symlink():
        raise RuntimeError("repository root is missing or unsafe")
    if not PREPARE.is_file() or not ACCEPTANCE.is_file() or not MANIFEST.is_file():
        raise RuntimeError("maintained scale-acceptance preparation inputs are missing")
    gwt_jars = args.gwt_jar_directory.resolve(strict=True)
    if not gwt_jars.is_dir() or gwt_jars.is_symlink():
        raise RuntimeError("pinned GWT jar directory is missing or unsafe")

    head = git("rev-parse", "HEAD")
    branch = git("branch", "--show-current")
    if (head, branch) != (EXPECTED_HEAD, EXPECTED_BRANCH):
        raise RuntimeError(f"checkout moved: expected {EXPECTED_BRANCH}@{EXPECTED_HEAD}, found {branch}@{head}")
    if git("diff", "--name-only", "--", "src", "war", "scripts", "tests"):
        raise RuntimeError("tracked source inputs have unstaged worktree changes")
    if git("diff", "--cached", "--name-only", "--", "src", "war", "scripts", "tests"):
        raise RuntimeError("tracked source inputs have staged changes")

    original_raw = ACCEPTANCE.read_bytes()
    original_sha = sha256(original_raw)
    manifest_sha = sha256_file(MANIFEST)
    if original_sha != plan.get("originalAcceptancePlanSha256"):
        raise RuntimeError("bundled acceptance plan bytes changed")
    if manifest_sha != plan.get("manifestSha256"):
        raise RuntimeError("frozen plan-4 manifest bytes changed")

    original = load_json(ACCEPTANCE, "bundled acceptance plan")
    if (original.get("planEpoch") != 4 or original.get("manifestSha256") != manifest_sha
            or original.get("limits") != LIMITS
            or len(original.get("cases", [])) != 77
            or len(original.get("coldOrder", [])) != 77
            or len(original.get("serviceAndSensitivitySeeds", [])) != 21):
        raise RuntimeError("bundled 77-root/308-candidate acceptance contract changed")
    continued = dict(original)
    continued["baseHead"] = head
    if ({key: value for key, value in continued.items() if key != "baseHead"}
            != {key: value for key, value in original.items() if key != "baseHead"}):
        raise RuntimeError("continued acceptance plan changed more than baseHead")
    continued_raw = (
        json.dumps(continued, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")
    continued_sha = sha256(continued_raw)

    temp_root = Path(tempfile.gettempdir()).resolve(strict=True)
    task_root = Path(tempfile.mkdtemp(prefix="q30-seed10014-current-timing-ca079-")).resolve(strict=True)
    if not task_root.is_relative_to(temp_root) or task_root.is_relative_to(REPOSITORY):
        raise RuntimeError("task root is not a new OS-temp directory outside the repository")
    isolated = task_root / "isolated"
    acceptance_copy = task_root / "acceptance-plan.json"
    write_exclusive(acceptance_copy, continued_raw)

    child_env = dict(os.environ)
    child_env["PYTHONDONTWRITEBYTECODE"] = "1"
    child_env["PYTHONIOENCODING"] = "utf-8"
    command = [
        str(HOST_PYTHON), "-B", str(PREPARE), str(REPOSITORY), str(isolated),
        str(gwt_jars), "--plan", str(acceptance_copy),
    ]
    started_utc = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    print(json.dumps({
        "status": "PREPARING_CURRENT_SOURCE_ONLY",
        "baseHead": head,
        "taskRoot": str(task_root),
        "command": command,
        "cold77Execution": "NOT_STARTED",
    }), flush=True)

    result = subprocess.run(
        command, cwd=REPOSITORY, env=child_env,
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
    )
    elapsed = time.monotonic() - timer
    log_raw = (result.stdout + result.stderr).encode("utf-8")
    write_exclusive(task_root / "prepare.log", log_raw)
    if result.returncode != 0:
        raise RuntimeError(
            f"maintained prepare.py failed with exit {result.returncode}; "
            f"preserved log: {task_root / 'prepare.log'}"
        )

    prepared = load_json(isolated / "prepare-receipt.json", "maintained prepare receipt")
    snapshot_raw = (isolated / "source-snapshot.json").read_bytes()
    snapshot = json.loads(snapshot_raw.decode("utf-8"))
    if not isinstance(snapshot, dict):
        raise RuntimeError("maintained source snapshot is not a JSON object")
    if prepared.get("status") != "PREPARED" or prepared.get("baseHead") != head:
        raise RuntimeError("maintained preparation is not bound to the selected HEAD")
    if prepared.get("sourceFileCount") != plan.get("expectedSourceFileCount"):
        raise RuntimeError("maintained source file count differs from the frozen expected count")
    if prepared.get("sourceIdentity") != snapshot.get("sourceIdentity"):
        raise RuntimeError("prepare receipt and source snapshot identity disagree")
    if snapshot.get("baseHead") != head or not isinstance(snapshot.get("files"), list):
        raise RuntimeError("maintained source snapshot HEAD/files are malformed")
    if len(snapshot["files"]) != prepared["sourceFileCount"]:
        raise RuntimeError("maintained source snapshot row count differs from its receipt")
    identity = sha256(canonical({
        "schema": 1, "baseHead": head, "files": snapshot["files"],
    }))
    if identity != snapshot["sourceIdentity"]:
        raise RuntimeError("source snapshot canonical identity check failed")
    if sha256(snapshot_raw) != prepared.get("sourceSnapshotSha256"):
        raise RuntimeError("source snapshot bytes differ from preparation receipt")
    if prepared.get("acceptancePlanSha256") != continued_sha:
        raise RuntimeError("prepare receipt does not bind the continued acceptance plan")
    if prepared.get("manifestSha256") != manifest_sha or prepared.get("limits") != LIMITS:
        raise RuntimeError("prepare receipt does not retain the frozen manifest and limits")
    if prepared.get("rootCount") != 77 or prepared.get("coldOrder") != continued.get("coldOrder"):
        raise RuntimeError("prepare receipt does not retain the frozen 77-root order")

    root_snapshot = task_root / "source-snapshot.json"
    write_exclusive(root_snapshot, snapshot_raw)
    if sha256_file(root_snapshot) != prepared["sourceSnapshotSha256"]:
        raise RuntimeError("build-owner source snapshot copy changed")

    pointer = {
        "schema": 1,
        "status": "PREPARED_CURRENT_SOURCE_UNBUILT",
        "baseHead": head,
        "sourceIdentity": identity,
        "taskRoot": str(task_root),
        "sourceInputCount": prepared["sourceFileCount"],
        "continuedPlanSha256": continued_sha,
        "originalAcceptancePlanSha256": original_sha,
        "sourceSnapshotSha256": prepared["sourceSnapshotSha256"],
        "manifestSha256": manifest_sha,
        "acceptancePlanPath": str(acceptance_copy),
        "preparedDirectory": str(isolated),
        "appPath": str(isolated / "app"),
        "sourceSnapshotPath": str(isolated / "source-snapshot.json"),
        "buildOwnerSourceSnapshotPath": str(root_snapshot),
        "prepareReceiptPath": str(isolated / "prepare-receipt.json"),
        "scalePlanPath": str(task_root / "scale-plan.json"),
        "sourceFileCount": prepared["sourceFileCount"],
        "coldRootCount": 77,
        "candidateManifestCountAfterCompiledExport": 308,
    }
    pointer_raw = (
        json.dumps(pointer, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")
    write_exclusive(WORKSPACE / "current-source-pointer.json", pointer_raw)
    write_exclusive(WORKSPACE / "epoch15-task-pointer.json", pointer_raw)

    integration = {
        "schema": 1,
        "status": "PREPARED_CURRENT_SOURCE_UNBUILT",
        "baseHead": head,
        "sourceIdentity": identity,
        "taskRoot": str(task_root),
        "continuedPlanSha256": continued_sha,
    }
    integration_raw = (
        json.dumps(integration, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")
    write_exclusive(WORKSPACE / "integration-pointer.json", integration_raw)

    summary = {
        "controller": controller,
        "schema": 1,
        "status": "PREPARED_CURRENT_SOURCE_UNBUILT",
        "startedUtc": started_utc,
        "finishedUtc": datetime.now(timezone.utc).isoformat(),
        "prepareElapsedSeconds": elapsed,
        "baseHead": head,
        "branch": branch,
        "sourceIdentity": identity,
        "sourceInputCount": prepared["sourceFileCount"],
        "continuedPlanSha256": continued_sha,
        "originalAcceptancePlanSha256": original_sha,
        "changedAcceptancePlanFields": ["baseHead"],
        "taskRoot": str(task_root),
        "normalScreenApp": str(isolated / "app"),
        "prepareReceipt": str(isolated / "prepare-receipt.json"),
        "sourceSnapshot": str(isolated / "source-snapshot.json"),
        "acceptancePlan": str(acceptance_copy),
        "scalePlanAfterCompiledCanaries": str(task_root / "scale-plan.json"),
        "buildOrHostLaunchPerformedByThisDriver": False,
        "full77Execution": "NOT_STARTED",
        "qualificationAcceptance": "NOT_ASSESSED",
    }
    summary_raw = (
        json.dumps(summary, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")
    write_exclusive(task_root / "preparation-result.json", summary_raw)
    print(json.dumps({
        "status": "PASS_PREPARED_CURRENT_SOURCE_UNBUILT",
        "baseHead": head,
        "sourceIdentity": identity,
        "sourceInputCount": prepared["sourceFileCount"],
        "continuedPlanSha256": continued_sha,
        "taskRoot": str(task_root),
        "appPath": str(isolated / "app"),
        "acceptancePlan": str(acceptance_copy),
        "nextOwner": "run_epoch15_build.ps1 -Tag isolated, then run_compiled_canaries_owned.py",
        "cold77Execution": "NOT_STARTED",
    }), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, subprocess.SubprocessError, ValueError) as error:
        print("BLOCKED_PREPARATION: " + str(error), file=sys.stderr, flush=True)
        raise SystemExit(2)
