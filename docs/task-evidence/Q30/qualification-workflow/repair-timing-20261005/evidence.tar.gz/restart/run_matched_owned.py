"""Task caller of the existing owned-job runner for four bounded diagnostics."""
import ctypes, hashlib, json, os, tempfile, uuid
from datetime import datetime, timezone
from pathlib import Path
import serial_runner as owner
from receipts import write_exclusive
N=Path(__file__).resolve().parent
physical=Path(r'$WINDOWSAPPS\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe').resolve(strict=True)
assert hashlib.sha256((N/'serial_runner.py').read_bytes()).hexdigest()=='19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6'
T=Path(tempfile.gettempdir())/('q30-root10014-matched-'+uuid.uuid4().hex);T.mkdir(exist_ok=False)
write_exclusive(N/'timing-root-pointer.json',{'taskRoot':str(T),'scope':'Four bounded seed10014 diagnostics, no qualification'})
k=owner._api();k.GetCurrentProcess.restype=ctypes.c_void_p
image,birth=owner._identity(k,k.GetCurrentProcess(),physical)
write_exclusive(T/'controller-identity.json',{'pid':os.getpid(),'executable':image,'creationFileTimeTicks':birth,'taskRoot':str(T),'scope':'Native owned-job envelope for existing paired diagnostic; no global process control'})
driver=N/'run_root10014_matched_diagnostic.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='87e24ecd2d651dd9232b347e573f2afbab78798fe03379c28be1d770969f804c'
argv=[str(physical),'-B','-u',str(driver),'--task-root',str(T),'--current-pointer',str(N/'current-source-pointer.json'),'--old-pointer',str(N.parent/'epoch15-task-pointer.json')]
child=None;waited=None
result={'status':'FAIL','startedUtc':datetime.now(timezone.utc).isoformat(),'operationLimitMilliseconds':1050000,'cleanupLimitMilliseconds':15000,'argv':argv,'driverSha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'errors':[]}
try:
    child=owner._spawn(k,{'executable':physical},argv,T)
    result['process']={key:child[value] for key,value in [('pid','pid'),('creationFileTimeTicks','creationTicks'),('executable','image'),('commandSha256','commandSha256')]}
    write_exclusive(T/'launch.json',{**result,'status':'RUNNING'})
    waited=owner._wait(k,child,1050000);result['operation']=waited
    stagePath=T/'root10014-matched-diagnostic/run.json'
    result['diagnostic']=json.loads(stagePath.read_text()) if stagePath.exists() else None
    completed=waited['reason'] is None and waited['cleanup']['cleanupVerified'] and result['diagnostic'] and result['diagnostic'].get('sourceBindingUnchangedBeforeAfter') is True
    if completed and waited['exitCode']==0 and result['diagnostic']['status']=='DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION':
        result['status']='COMPLETED_DIAGNOSTIC_NOT_QUALIFICATION'
    elif completed and waited['exitCode']==1 and result['diagnostic']['status']=='DIAGNOSTIC_COMPLETE_WITH_TIMEOUT_NONPASS_NOT_QUALIFICATION':
        result['status']='COMPLETED_APP_NONPASS_DIAGNOSTIC'
    else:result['status']='FAIL_OR_INCOMPLETE_DIAGNOSTIC'
except BaseException as error:
    result['errors'].append(type(error).__name__+': '+str(error))
    if child is not None and waited is None:result['emergencyCleanup']=owner._wait(k,child,0)
finally:
    if child is not None:
        for key in ['job','thread','proc']:
            if child.get(key) and not k.CloseHandle(child[key]):result['errors'].append('CloseHandle failed '+key)
            child[key]=None
    if result['errors']:result['status']='FAIL_OR_INCOMPLETE_DIAGNOSTIC'
    result['finishedUtc']=datetime.now(timezone.utc).isoformat();write_exclusive(T/'result.json',result)
print(json.dumps({'status':result['status'],'root':str(T),'errors':result['errors']}),flush=True)
raise SystemExit(0 if result['status']=='COMPLETED_DIAGNOSTIC_NOT_QUALIFICATION' else 1)
