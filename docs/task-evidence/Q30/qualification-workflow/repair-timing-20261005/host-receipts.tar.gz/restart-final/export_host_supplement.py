"""Preserve the first packet; add actual original-host inventories and canary reports."""
import hashlib,io,json,re,tarfile
from pathlib import Path,PurePosixPath
N=Path(__file__).resolve().parent;W=N.parent
R=Path(r'$REPO')
E=R/'docs/task-evidence/Q30/qualification-workflow/repair-timing-20261005'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
review=read(N/'timing-review.json')
assert review['status']=='PASS_FOUR_BOUNDED_DIAGNOSTICS_NOT_QUALIFICATION'
assert not (E/'host-receipts.tar.gz').exists()
roots=[(str(R),'$REPO'),(str(W),'$TASK_WORKSPACE'),(r'$TASK_TEMP','$TASK_TEMP'),(r'$WINDOWSAPPS','$WINDOWSAPPS'),(r'$USER_HOME','$USER_HOME')]
def portable(raw):
    if raw.startswith(b'\x89PNG'):return raw
    text=raw.decode('utf-8-sig')
    for old,new in roots:text=text.replace(old,new).replace(old.replace('\\','\\\\'),new).replace(old.replace('\\','/'),new)
    assert not re.search(r'(?i)[A-Z]:[\\/]+Users[\\/]+david|[A-Z]:[\\/]+Program Files[\\/]+WindowsApps',text)
    assert not re.search(r'(?i)(Bearer\s+[A-Za-z0-9_-]{12}|gh[pousr]_[A-Za-z0-9]{20}|AKIA[A-Z0-9]{16})',text)
    return text.encode('utf-8')
base=read(E/'packet-audit.json');existing={x['member']:x for x in base['derivations']}
members={};derivations=[]
def add(p,label):
    assert p.is_file() and p.stat().st_size<=20*1024*1024
    assert label not in members and not PurePosixPath(label).is_absolute() and '..' not in PurePosixPath(label).parts
    raw=p.read_bytes();data=portable(raw);members[label]=data
    derivations.append({'member':label,'rawSha256':sha(raw),'portableSha256':sha(data),'portableBytes':len(data)})
for row in review['packetFiles']:
    label='timing/'+row['member'];p=Path(row['path'])
    if label in existing:
        assert sha(p.read_bytes())==existing[label]['rawSha256']
    else:add(p,label)
for name in ['review_timing.py','timing-review.json','export_host_supplement.py','new-resource-release-audit.json','packaging-failure.json']:
    add(N/name,'restart-final/'+name)
assert len(members)<100 and sum(map(len,members.values()))<20*1024*1024
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for name,data in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
payload=buffer.getvalue();assert len(payload)<5*1024*1024
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    assert {m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}==members
(E/'host-receipts.tar.gz').write_bytes(payload)
(E/'timing-review-with-host-receipts.json').write_bytes(portable((N/'timing-review.json').read_bytes()))
audit={'status':'PASS_PORTABLE_PACKET_ROUNDTRIP_ONLY','archiveSha256':sha(payload),'archiveBytes':len(payload),'regularMembers':len(members),'uncompressedBytes':sum(map(len,members.values())),'derivations':derivations,'baseArchiveSha256':base['archiveSha256'],'firstPacketPreserved':True,'reason':'The added host-receipt review first rejected maintained .state.txt files. Corrected bounded suffix set includes them; no live gates rerun. First packet remains unchanged.','boundary':'Evidence only; final-source qualification/source archive NOT RUN'}
(E/'host-receipts-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:audit[k] for k in ['status','archiveSha256','archiveBytes','regularMembers']}))
