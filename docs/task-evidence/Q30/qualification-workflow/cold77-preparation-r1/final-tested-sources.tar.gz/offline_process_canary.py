"""Real selected Windows launcher, synthetic receipts only; no app or browser.

Tests the additive controller's positive, missing-receipt and timeout paths.
This cannot establish qualification-host support or electrical qualification.
"""
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace

import cold77_batch as batch
from receipts import write_exclusive

HERE = Path(__file__).resolve().parent
roles = json.loads((HERE / 'test-roles.json').read_text())
args = SimpleNamespace(**{key: Path(value) for key, value in roles.items()})
fixtures = json.loads((HERE / 'retained-fixtures.json').read_bytes())
binding = fixtures['binding']
plan = json.loads((Path(json.loads(args.pointer.read_text())['taskRoot']) / 'scale-plan.json').read_bytes())
from cold77_case_worker import receipt_from_records
passed = fixtures['pass']
receipt = receipt_from_records(passed['rootSeed'], binding, passed['report'], passed['host'],
                              passed['checked'], 0, 100, True, [])
fixture_root = Path(tempfile.mkdtemp(prefix='q30-cold77-offline-process-fixtures-'))
batch.HERE = fixture_root
for name in ('serial_runner.py', 'receipts.py'):
    (fixture_root / name).write_bytes((HERE / name).read_bytes())
write_exclusive(fixture_root / 'fixture.json', {'receipt': receipt, 'plan': plan, 'binding': binding})
# Keep the child tiny and auditable. It performs no host imports, network,
# browser launch, build or solver work.
child_source = '''import argparse,copy,json,time
from pathlib import Path
from receipts import write_exclusive,summarize_cases
p=argparse.ArgumentParser();p.add_argument('--batch-root',type=Path,required=True)
a,_=p.parse_known_args();here=Path(__file__).resolve().parent
data=json.loads((here/'fixture.json').read_bytes());mode=(here/'mode.txt').read_text()
if mode=='timeout': time.sleep(5)
if mode!='missing':
 receipts=[];seeds=data['plan']['coldOrder']
 for index,seed in enumerate(seeds,1):
  receipt=copy.deepcopy(data['receipt']);receipt['rootSeed']=seed
  receipt['provenance']['publishedPackages']=20+(index-1)%21
  target=a.batch_root/'sequence/cases'/(f'{index:03d}-seed-'+seed.replace('-','minus-'))
  target.mkdir(parents=True);write_exclusive(target/'normalized-receipt.json',receipt);receipts.append(receipt)
 summary=summarize_cases(seeds,receipts)
 result={'status':'PASS_COLD77','qualified':True,'rows':summary['rows'],
  'publishedPackageSizes':list(range(20,41)),'complete':True,
  'qualificationScope':'Cold77 only; Q30 acceptance and normal-play enablement remain pending.'}
else:
 result={'status':'PASS_COLD77','qualified':True}
write_exclusive(a.batch_root/'input-audit-after.json',data['binding'])
write_exclusive(a.batch_root/'batch-result.json',result)
'''
(fixture_root / 'cold77_batch.py').write_text(child_source, encoding='utf-8', newline='')
# Unused argv target must remain a regular path for the actual spec builder.
(fixture_root / 'cold77_case_worker.py').write_text('# NEVER EXECUTED\n', encoding='utf-8')
results = []
normal_validation = batch.validate_grant
for mode in ('positive', 'missing', 'timeout'):
    (fixture_root / 'mode.txt').write_text(mode)
    now = datetime.now(timezone.utc)
    grant = {'schema': 1, 'kind': 'Q30_COLD77_SERIAL_QUALIFICATION',
        'parentReference': 'OFFLINE_PROCESS_FIXTURE_ONLY_NO_APP_' + mode,
        'candidateManifestSha256': 'a' * 64, 'sourceIdentity': binding['sourceIdentity'],
        'planSha256': binding['planSha256'], 'limits': dict(batch.LIMITS), 'rootCount': 77,
        'notBeforeUtc': now.isoformat().replace('+00:00', 'Z'),
        'windowEndUtc': (now + timedelta(milliseconds=batch.WINDOW_MS)).isoformat().replace('+00:00', 'Z')}
    args.grant_json = fixture_root / (mode + '-fixture-grant.json')
    write_exclusive(args.grant_json, grant)
    def short_fixture_grant(value, manifest_sha, binding_value, clock):
        normal_validation(value, manifest_sha, binding_value, clock)
        return (200 if mode == 'timeout' else 10000) + batch.CONTROLLER_RECORD_MS
    batch.validate_grant = short_fixture_grant
    code = batch.controlled_launch(args, 'a' * 64, binding, {'plan': plan})
    expected = 0 if mode == 'positive' else 1
    assert code == expected, (mode, code, expected)
    results.append({'mode': mode, 'exitCode': code, 'expected': expected})
batch.validate_grant = normal_validation
result_path = HERE / 'offline-process-canary-result.json'
index = 2
while result_path.exists():
    result_path = HERE / ('offline-process-canary-result-' + str(index) + '.json')
    index += 1
write_exclusive(result_path,
    {'status': 'PASS_OFFLINE_PROCESS_CANARIES_ONLY', 'appCases': 0, 'browserLaunched': False,
     'fixtureRoot': str(fixture_root), 'rows': results,
     'limits': 'Synthetic receipts and shortened outer timeouts; no qualification or host proof.'})
print(json.dumps({'status': 'PASS_OFFLINE_PROCESS_CANARIES_ONLY', 'rows': results, 'fixtureRoot': str(fixture_root)}))
