package com.lushprojects.circuitjs1.client;

import com.google.gwt.json.client.*;
import com.google.gwt.user.client.Timer;
import java.util.Vector;

/** Isolated-export entry point only. Never compiled into the shipping module. */
public final class Q30NormalScreenHarness extends circuitjs1 {
    private static final String SOURCE_HEAD = "d37c3b3b8581abdeaa9b88b7bfb2349cff958d31";
    private static final String SOURCE_IDENTITY = "a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51";
    private static final String MANIFEST_SHA256 = "70bb3c32fc6d13416c8c7b47dd996a155440d8948b9d472118679d893e2571a8";
    // Filled by prepare.py from the frozen 77-row plan; newline separates seed|canonical.
    private static final String FROZEN_ROOTS = "0|rb30-plan@4;seed=0;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_BJT;support=C12:true,S5:false,S12:false,filters:2,outputIndicators:1,bleeder5:true;layout=-5811592868239938363;routing=6323369344316473384;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=35;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n1|rb30-plan@4;seed=1;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_BJT;support=C12:false,S5:false,S12:false,filters:3,outputIndicators:2,bleeder5:false;layout=1799317865416717022;routing=8574451956206511489;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n15|rb30-plan@4;seed=15;topology=RB30_CH1_SHARED_HYSTERETIC_A_BJT;support=C12:true,S5:false,S12:true,filters:1,outputIndicators:0,bleeder5:true;layout=-4102781316482433804;routing=3125582050554378627;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=26;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n14|rb30-plan@4;seed=14;topology=RB30_CH1_SEPARATE_DIRECT_A_NMOS;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:1,bleeder5:true;layout=-4066299183252158013;routing=8455461874929798594;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=24;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n44|rb30-plan@4;seed=44;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_BJT;support=C12:false,S5:true,S12:true,filters:0,outputIndicators:1,bleeder5:true;layout=-5418343777379898806;routing=9221105868543393541;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=37;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n8|rb30-plan@4;seed=8;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:1,bleeder5:false;layout=1789953187444160285;routing=-8500271482997274880;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=32;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10|rb30-plan@4;seed=10;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_NMOS;support=C12:false,S5:false,S12:false,filters:3,outputIndicators:1,bleeder5:false;layout=-5437028946546985473;routing=6161596101315970262;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n12|rb30-plan@4;seed=12;topology=RB30_CH1_SHARED_HYSTERETIC_A_NMOS;support=C12:true,S5:true,S12:false,filters:1,outputIndicators:1,bleeder5:true;layout=6046541773753211669;routing=-6554665895955772872;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=28;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n48|rb30-plan@4;seed=48;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:false,S5:true,S12:true,filters:1,outputIndicators:0,bleeder5:false;layout=53484932549578302;routing=4547458730190472417;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n35|rb30-plan@4;seed=35;topology=RB30_CH1_SHARED_DIRECT_A_NMOS;support=C12:true,S5:true,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=274218021066538630;routing=6495378868313983241;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=29;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n6|rb30-plan@4;seed=6;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_NMOS;support=C12:true,S5:true,S12:false,filters:0,outputIndicators:1,bleeder5:false;layout=4908328448798023347;routing=6716285875351407986;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=37;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n18|rb30-plan@4;seed=18;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_NMOS;support=C12:true,S5:false,S12:true,filters:2,outputIndicators:3,bleeder5:false;layout=7980265023153347415;routing=-2193322311656395346;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=38;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n43|rb30-plan@4;seed=43;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_BJT;support=C12:true,S5:false,S12:false,filters:3,outputIndicators:3,bleeder5:false;layout=-1512077175122950681;routing=-7965146064256394114;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n93|rb30-plan@4;seed=93;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:true,S12:false,filters:3,outputIndicators:3,bleeder5:true;layout=-985482431507298186;routing=6628695670293430585;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20|rb30-plan@4;seed=20;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_NMOS;support=C12:false,S5:false,S12:true,filters:1,outputIndicators:3,bleeder5:false;layout=-5479991671754943044;routing=-5126670298154170197;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n64|rb30-plan@4;seed=64;topology=RB30_CH1_SHARED_DIRECT_A_NMOS;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:1,bleeder5:false;layout=-7619673160888504460;routing=-2032842263090610941;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=22;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n56|rb30-plan@4;seed=56;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_BJT;support=C12:false,S5:false,S12:true,filters:1,outputIndicators:2,bleeder5:true;layout=-5211896398607998619;routing=3213407112027802824;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n13|rb30-plan@4;seed=13;topology=RB30_CH1_SEPARATE_DIRECT_A_NMOS;support=C12:false,S5:false,S12:true,filters:1,outputIndicators:0,bleeder5:false;layout=-8526998057890890386;routing=7912193663056532433;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=23;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n4|rb30-plan@4;seed=4;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_NMOS;support=C12:true,S5:false,S12:false,filters:1,outputIndicators:2,bleeder5:false;layout=-7967780441668740599;routing=4321422998255155060;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=34;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n11|rb30-plan@4;seed=11;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_NMOS;support=C12:false,S5:false,S12:true,filters:0,outputIndicators:2,bleeder5:false;layout=1059241135697365744;routing=-6884625828109004681;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n2|rb30-plan@4;seed=2;topology=RB30_CH1_SHARED_HYSTERETIC_A_BJT;support=C12:false,S5:true,S12:true,filters:0,outputIndicators:1,bleeder5:true;layout=2546006604234761519;routing=2893653270581892614;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=28;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n3|rb30-plan@4;seed=3;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:3,bleeder5:true;layout=7415793985178074592;routing=-6737138315424505881;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=38;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n19|rb30-plan@4;seed=19;topology=RB30_CH1_SHARED_HYSTERETIC_A_BJT;support=C12:false,S5:false,S12:true,filters:0,outputIndicators:1,bleeder5:true;layout=5662094857471849512;routing=-5130833588164138129;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=26;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n9|rb30-plan@4;seed=9;topology=RB30_CH1_SEPARATE_DIRECT_A_NMOS;support=C12:true,S5:true,S12:true,filters:1,outputIndicators:0,bleeder5:false;layout=-8978433393770098794;routing=3741625010610597337;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=26;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n7|rb30-plan@4;seed=7;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_BJT;support=C12:true,S5:false,S12:false,filters:3,outputIndicators:1,bleeder5:false;layout=-1194938301906846876;routing=8563653456340676275;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=37;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n42|rb30-plan@4;seed=42;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_BJT;support=C12:true,S5:false,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=8214649964397189944;routing=-1053291048239537729;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n24|rb30-plan@4;seed=24;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:true,S5:true,S12:false,filters:0,outputIndicators:1,bleeder5:true;layout=7383636897588197784;routing=-7307251309157613025;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=26;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n21|rb30-plan@4;seed=21;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_NMOS;support=C12:true,S5:true,S12:false,filters:1,outputIndicators:0,bleeder5:false;layout=-2024216170428135701;routing=-1576339877345421814;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=34;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n75|rb30-plan@4;seed=75;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_BJT;support=C12:false,S5:true,S12:false,filters:1,outputIndicators:3,bleeder5:false;layout=6626451485285559634;routing=4130765676055363405;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n22|rb30-plan@4;seed=22;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_BJT;support=C12:true,S5:false,S12:true,filters:3,outputIndicators:2,bleeder5:true;layout=-5405813596696424534;routing=-1869640971445039899;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=40;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n105|rb30-plan@4;seed=105;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:true,S5:false,S12:true,filters:0,outputIndicators:1,bleeder5:false;layout=609710105076971411;routing=-4153643006712800686;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n27|rb30-plan@4;seed=27;topology=RB30_CH1_SHARED_DIRECT_A_NMOS;support=C12:true,S5:true,S12:false,filters:1,outputIndicators:0,bleeder5:true;layout=7181867712567016669;routing=-5149770747598021696;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n53|rb30-plan@4;seed=53;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_BJT;support=C12:true,S5:false,S12:false,filters:1,outputIndicators:3,bleeder5:true;layout=7115854511337141938;routing=7382537408061392045;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n50|rb30-plan@4;seed=50;topology=RB30_CH1_SEPARATE_DIRECT_A_NMOS;support=C12:true,S5:false,S12:false,filters:1,outputIndicators:1,bleeder5:false;layout=-8901581436382159789;routing=5298496642915075858;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=24;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n16|rb30-plan@4;seed=16;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:false,S5:true,S12:true,filters:0,outputIndicators:0,bleeder5:true;layout=-7965344397602894695;routing=-9085004239563195708;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n25|rb30-plan@4;seed=25;topology=RB30_CH1_SHARED_HYSTERETIC_A_NMOS;support=C12:false,S5:false,S12:true,filters:1,outputIndicators:0,bleeder5:false;layout=-5653937787444795065;routing=2774127172421115486;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=24;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n60|rb30-plan@4;seed=60;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:true,S5:false,S12:true,filters:0,outputIndicators:1,bleeder5:false;layout=-2457650708708704912;routing=6403693931955557367;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n100|rb30-plan@4;seed=100;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_BJT;support=C12:true,S5:true,S12:false,filters:2,outputIndicators:0,bleeder5:false;layout=1746523992209718592;routing=-2746755630293671225;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=34;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n59|rb30-plan@4;seed=59;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_NMOS;support=C12:true,S5:false,S12:true,filters:2,outputIndicators:2,bleeder5:true;layout=3637568334448835740;routing=3934344778036482699;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n84|rb30-plan@4;seed=84;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_NMOS;support=C12:true,S5:true,S12:false,filters:3,outputIndicators:2,bleeder5:true;layout=-3242673823339532026;routing=1336954554668993673;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=40;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n70|rb30-plan@4;seed=70;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:false,S5:false,S12:true,filters:0,outputIndicators:0,bleeder5:true;layout=1781146716209768197;routing=2544927411207093608;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=23;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n41|rb30-plan@4;seed=41;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:true,S12:true,filters:3,outputIndicators:1,bleeder5:false;layout=-4826655946790102787;routing=-7904962308046568992;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=40;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n45|rb30-plan@4;seed=45;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:false,S5:false,S12:true,filters:0,outputIndicators:0,bleeder5:false;layout=9192899733629551201;routing=-4387679830588408564;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=22;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n23|rb30-plan@4;seed=23;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_NMOS;support=C12:true,S5:false,S12:true,filters:2,outputIndicators:0,bleeder5:true;layout=618616678036401345;routing=-7410276840993130516;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=37;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n5|rb30-plan@4;seed=5;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_BJT;support=C12:true,S5:true,S12:true,filters:1,outputIndicators:0,bleeder5:true;layout=4144048873421939986;routing=2013810180461903117;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n38|rb30-plan@4;seed=38;topology=RB30_CH1_SHARED_HYSTERETIC_A_NMOS;support=C12:false,S5:true,S12:false,filters:0,outputIndicators:1,bleeder5:false;layout=-3535978731510237511;routing=9035685029422851812;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n40|rb30-plan@4;seed=40;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:true,S5:false,S12:false,filters:1,outputIndicators:1,bleeder5:false;layout=2531409412898772470;routing=-6659624089771131463;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=24;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n26|rb30-plan@4;seed=26;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_NMOS;support=C12:true,S5:false,S12:true,filters:3,outputIndicators:1,bleeder5:false;layout=-5544984293667468202;routing=-4513041428443066471;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n-9223372036854775808|rb30-plan@4;seed=-9223372036854775808;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_BJT;support=C12:true,S5:false,S12:true,filters:3,outputIndicators:1,bleeder5:false;layout=-9148433352076385288;routing=4476781566495134847;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n9223372036854775807|rb30-plan@4;seed=9223372036854775807;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:0,bleeder5:true;layout=-5182076709963905222;routing=-4425426508039394635;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=21;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n9007199254740993|rb30-plan@4;seed=9007199254740993;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:false,S5:true,S12:false,filters:1,outputIndicators:0,bleeder5:false;layout=-7793972108954435269;routing=745089071391012698;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=23;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n10006|rb30-plan@4;seed=10006;topology=RB30_CH1_SHARED_DIRECT_A_NMOS;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:0,bleeder5:false;layout=1218254286965064840;routing=8113131611356216655;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=21;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n10008|rb30-plan@4;seed=10008;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_BJT;support=C12:false,S5:false,S12:false,filters:2,outputIndicators:0,bleeder5:false;layout=-7159585819865794430;routing=6394230140853700157;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=33;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10014|rb30-plan@4;seed=10014;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_NMOS;support=C12:false,S5:true,S12:false,filters:1,outputIndicators:3,bleeder5:true;layout=-3262450690658810933;routing=-5851812364560090390;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=40;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10028|rb30-plan@4;seed=10028;topology=RB30_CH1_SHARED_DIRECT_A_NMOS;support=C12:true,S5:false,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=4903623016800586716;routing=6241105062844798923;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=27;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n10226|rb30-plan@4;seed=10226;topology=RB30_CH1_SHARED_HYSTERETIC_A_BJT;support=C12:true,S5:true,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=-1380815054569158496;routing=5063181356558970279;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=30;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n10272|rb30-plan@4;seed=10272;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_BJT;support=C12:true,S5:false,S12:false,filters:0,outputIndicators:0,bleeder5:false;layout=-223924317456944311;routing=-2898798926231524172;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=31;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10387|rb30-plan@4;seed=10387;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:0,bleeder5:false;layout=-3255522771404521770;routing=-6535911948543126759;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=20;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n20001|rb30-plan@4;seed=20001;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:false,S12:false,filters:3,outputIndicators:0,bleeder5:true;layout=-1264992836607534820;routing=2758649750281290763;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=33;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20003|rb30-plan@4;seed=20003;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:false,S12:false,filters:3,outputIndicators:0,bleeder5:true;layout=-7479444175884212598;routing=1162685305019923781;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=35;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20005|rb30-plan@4;seed=20005;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_NMOS;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:0,bleeder5:false;layout=-1073113834562743688;routing=-6906997107415602177;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=32;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20009|rb30-plan@4;seed=20009;topology=RB30_CH2_SEPARATE_DIRECT_A_NMOS_B_NMOS;support=C12:true,S5:false,S12:true,filters:2,outputIndicators:1,bleeder5:false;layout=2042398917295880964;routing=-7486988576274378797;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=38;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20013|rb30-plan@4;seed=20013;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_BJT;support=C12:true,S5:false,S12:false,filters:3,outputIndicators:0,bleeder5:true;layout=-4925011151268098209;routing=4643193263884229942;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20019|rb30-plan@4;seed=20019;topology=RB30_CH1_SEPARATE_DIRECT_A_NMOS;support=C12:true,S5:true,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=7615518387674235341;routing=3689716304905894384;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=29;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n20022|rb30-plan@4;seed=20022;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:false,S5:true,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=4373353270802315335;routing=-3559992168979066018;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=28;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n20026|rb30-plan@4;seed=20026;topology=RB30_CH1_SHARED_DIRECT_A_NMOS;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:0,bleeder5:false;layout=8003074887818974699;routing=-7910459218745603318;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=21;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n20028|rb30-plan@4;seed=20028;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:true,S5:false,S12:true,filters:1,outputIndicators:1,bleeder5:true;layout=-3121414454846602363;routing=1369232383451901672;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_A_COIL_OPEN;packages=27;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n20254|rb30-plan@4;seed=20254;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_NMOS;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:0,bleeder5:false;layout=-2984021027130767404;routing=-4811982420017575325;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=30;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20364|rb30-plan@4;seed=20364;topology=RB30_CH1_SHARED_DIRECT_A_BJT;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:0,bleeder5:false;layout=-4299743742600706268;routing=-724539781568242061;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=20;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n20392|rb30-plan@4;seed=20392;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_NMOS;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:0,bleeder5:false;layout=-5542663641102345427;routing=-6105401913822036144;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=31;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10000|rb30-plan@4;seed=10000;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_NMOS;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:1,bleeder5:true;layout=-5582834733033270822;routing=-7232503086477951915;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10009|rb30-plan@4;seed=10009;topology=RB30_CH2_SHARED_HYSTERETIC_A_BJT_B_NMOS;support=C12:false,S5:false,S12:true,filters:3,outputIndicators:0,bleeder5:true;layout=5676716728902091513;routing=4035296932330885924;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=37;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n10016|rb30-plan@4;seed=10016;topology=RB30_CH1_SEPARATE_DIRECT_A_BJT;support=C12:false,S5:false,S12:true,filters:0,outputIndicators:0,bleeder5:true;layout=-6356389506153994079;routing=-3717458644511788724;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=23;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated\n10017|rb30-plan@4;seed=10017;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_BJT;support=C12:true,S5:true,S12:false,filters:0,outputIndicators:3,bleeder5:true;layout=-6808783541809440886;routing=-2871378041971292091;physicalPolicy=MEDIUM_BOARD@1;fault=REN_OPEN;packages=40;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20007|rb30-plan@4;seed=20007;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_NMOS;support=C12:false,S5:true,S12:true,filters:3,outputIndicators:0,bleeder5:true;layout=-5882437397857524426;routing=-8566637954451418631;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=39;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20017|rb30-plan@4;seed=20017;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_BJT;support=C12:false,S5:false,S12:false,filters:3,outputIndicators:3,bleeder5:true;layout=-8744413051427585757;routing=-6563625346560632798;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=37;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated\n20037|rb30-plan@4;seed=20037;topology=RB30_CH1_SHARED_HYSTERETIC_A_BJT;support=C12:false,S5:true,S12:false,filters:0,outputIndicators:1,bleeder5:false;layout=-5031417642310200239;routing=8335217990737571388;physicalPolicy=MEDIUM_BOARD@1;fault=DRIVE_A_OPEN;packages=25;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=1;sensors=1-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN);loadReference=isolated";
    private final JSONObject report = new JSONObject();
    private CirSim sim;
    private GenerationCoordinator coordinator;
    private GenerationRequest request;
    private GenerationJob ownJob;
    private IsolatedGenerationQualification authority;
    private Task41SimulationSnapshot snapshot;
    private GeneratedBoardInstance predecessor;
    private GeneratedChallengeController predecessorController;
    private Vector<CircuitElm> predecessorGraph;
    private Timer observer;
    private String mode, seed;
    private boolean done, intervention;
    private long began;
    private int observedMatrixOrderMax, matrixObservations;
    private Throwable startupFailure;

    @Override public void loadSimulator() {
        super.loadSimulator();
        sim = mysim;
        final long boot = System.currentTimeMillis();
        new Timer() { public void run() {
            if (sim.isGeneratedRuntimeSettled() && !sim.generatedBoardVerificationPending) {
                cancel();
                try { begin(); } catch (Throwable failure) { failBeforeStart(failure); }
            } else if (System.currentTimeMillis() - boot > 15000) {
                cancel(); failBeforeStart(new IllegalStateException("Initial runtime did not settle"));
            }
        }}.scheduleRepeating(50);
    }

    private void begin() {
        QueryParameters query = new QueryParameters();
        mode = query.getValue("tsjNormalMode");
        seed = query.getValue("tsjNormalSeed");
        require(loopbackVisible(), "Isolated screen requires a visible loopback document");
        require(!sim.troubleshootDebug && !sim.developerVerifierRunning,
            "Screen cannot use debug/verifier execution");
        require("manifest-export".equals(mode) || "cold".equals(mode) || "unauthorized".equals(mode) ||
            "cancel".equals(mode) || "scope-loss".equals(mode), "Unknown isolated screen mode");
        require(!PlayerFamilyCatalog.isNormalPlayerEnabled("RB30_CONTROL"), "Shipping Q30 enabled");
        coordinator = sim.generationCoordinator;
        require(coordinator != null && coordinator.getJob() == null, "Not a fresh simulator");
        require(cachesEmpty(), "Not a cold ordinary/private cache");
        if ("manifest-export".equals(mode)) {
            exportPlanManifests();
            finish();
            return;
        }
        require(isFrozenRoot(seed), "Seed is not a canonical signed-long root in the frozen plan");
        request = PlayerLaunchRequest.random("RB30_CONTROL", seed, "MEDIUM").generation();
        require(!request.isPrivateDiagnosticQualification() && request.isCandidateSearch() &&
            !request.isQuickPlay() && request.candidateCount() == 4 &&
            request.getDifficulty() == DifficultyProfile.MEDIUM && request.requiresExplicitCompletion(),
            "Normal request semantics changed");
        Rb30Plan plan = Rb30Plan.resolve(Long.parseLong(seed));
        int expected = frozenPackageCount(seed);
        int channels = frozenChannelCount(seed);
        require(plan.physicalPackageCount() == expected && expected >= 20 && expected <= 40 &&
            plan.channelCount == channels && (channels == 1 || channels == 2) &&
            plan.board().getComponentIds().size() == expected &&
            plan.canonical().equals(frozenCanonical(seed)) && plan.canonical().startsWith("rb30-plan@4;"),
            "Frozen plan changed");
        put(report, "schema", 1); put(report, "sourceCommit", SOURCE_HEAD);
        put(report, "sourceIdentity", SOURCE_IDENTITY); put(report, "manifestSha256", MANIFEST_SHA256);
        put(report, "mode", mode); put(report, "rootSeed", seed);
        put(report, "planVersion", 4); put(report, "planCanonical", plan.canonical());
        put(report, "plannedPackages", expected); put(report, "channels", channels);
        put(report, "requestCanonical", request.canonical());
        put(report, "requestPrivate", false); put(report, "candidateSearch", true);
        put(report, "quickPlay", false); put(report, "explicitCompletion", true);
        put(report, "maxJobMillis", 90000); put(report, "maxWorkUnits", 640);
        put(report, "maxActiveOperationMillis", 5000); put(report, "candidateLimit", 4);
        put(report, "executionPolicy", request.getExecutionPolicy().canonical());
        put(report, "cache", "fresh ordinary instance-owned; reuse enabled");
        put(report, "scheduler", "GenerationCoordinator.start(request, completion, true); standard Timer/watchdog");
        put(report, "clock", "normal foreground; debug=false");
        put(report, "initialCachesEmpty", true);
        JSONArray manifests = new JSONArray();
        JSONArray plannedCandidates = new JSONArray();
        for (int i=0; i<4; i++) {
            manifests.set(i, new JSONString(request.candidateManifest(i)));
            GenerationRequest candidate = request.candidate(i);
            Rb30Plan candidatePlan = Rb30Plan.resolve(candidate.getDescriptor().getRootSeed());
            JSONObject row = new JSONObject();
            put(row, "ordinal", i);
            put(row, "seed", Long.toString(candidate.getDescriptor().getRootSeed()));
            put(row, "packages", candidatePlan.physicalPackageCount());
            put(row, "channels", candidatePlan.channelCount);
            put(row, "planCanonical", candidatePlan.canonical());
            put(row, "manifest", request.candidateManifest(i));
            plannedCandidates.set(i, row);
        }
        report.put("plannedManifests", manifests);
        report.put("plannedCandidates", plannedCandidates);
        predecessor = sim.generatedBoardInstance;
        predecessorController = sim.generatedChallengeController;
        predecessorGraph = sim.elmList;
        snapshot = Task41SimulationSnapshot.captureForFreshInstallation(sim);
        if ("unauthorized".equals(mode)) {
            boolean rejected = false;
            try { coordinator.start(request, null, true); }
            catch (IllegalArgumentException expectedFailure) { rejected = true; }
            finally { ownJob=coordinator.getJob(); }
            require(rejected && coordinator.getJob() == null && cachesEmpty(),
                "Unauthorized normal Q30 entry was not rejected before mutation");
            snapshot.assertRestored(sim);
            put(report, "classification", "CANARY_PASS"); put(report, "cleanupComplete", true);
            finish(); return;
        }
        authority = IsolatedGenerationQualification.attach(sim, coordinator, request);
        began = System.currentTimeMillis();
        setState("RUNNING", "Normal Q30 " + mode + " seed " + seed);
        try {
            coordinator.start(request, new GenerationCoordinator.Completion() {
                public void complete(GenerationJob job, GeneratedBoardInstance owner) { completed(job, owner); }
            }, true);
        } finally { ownJob = coordinator.getJob(); }
        require(authority.getBoundJob()==ownJob, "Normal start did not bind its exact job");
        require(coordinator.usesForegroundClockForIsolatedQualification(), "Wrong scheduler clock");
        installVisibilityAudit();
        observer = new Timer() { public void run() {
            GenerationJob job = coordinator.getJob();
            if (done || job == null || !job.isRunning()) { cancel(); return; }
            observeMatrix();
            setState("RUNNING", "Normal Q30 " + mode + " seed " + seed + " / " +
                job.getStage().name() + " / work " + job.getStepCount());
            if (!"cold".equals(mode) && !intervention &&
                    job.getCandidateStageWorkCount(GenerationJob.Stage.HYPOTHESES) > 0) {
                intervention = true;
                put(report,"interventionStage",job.getStage().name());
                put(report,"interventionProofUnits",job.getCandidateStageWorkCount(GenerationJob.Stage.HYPOTHESES));
                if ("cancel".equals(mode)) coordinator.cancel();
                else authority.close();
            }
        }};
        observer.scheduleRepeating(25); // Observe/cancel only; never advances generation.
    }

    /** Emits pre-evaluation candidate manifests computed by the production Java path. */
    private void exportPlanManifests() {
        JSONArray rows = new JSONArray();
        String[] roots = FROZEN_ROOTS.split("\\n");
        require(roots.length == 77, "Frozen plan must retain all 77 roots");
        for (int rowIndex = 0; rowIndex < roots.length; rowIndex++) {
            String[] fields = roots[rowIndex].split("\\|", 2);
            require(fields.length == 2, "Malformed frozen root row");
            String rootSeed = fields[0];
            long parsed = parseCanonicalSeed(rootSeed);
            Rb30Plan plan = Rb30Plan.resolve(parsed);
            require(plan.canonical().equals(fields[1]), "Java plan differs from frozen manifest row");
            int packages = plan.physicalPackageCount();
            require(packages >= 20 && packages <= 40 &&
                (plan.channelCount == 1 || plan.channelCount == 2),
                "Plan-4 row is outside the frozen package/channel envelope");
            GenerationRequest request = PlayerLaunchRequest.random(
                "RB30_CONTROL", rootSeed, "MEDIUM").generation();
            require(!request.isPrivateDiagnosticQualification() && request.isCandidateSearch() &&
                !request.isQuickPlay() && request.candidateCount() == 4 &&
                request.getDifficulty() == DifficultyProfile.MEDIUM && request.requiresExplicitCompletion(),
                "Manifest export did not use the ordinary MEDIUM candidate-search request");
            JSONObject row = new JSONObject();
            put(row, "manifestOrder", rowIndex);
            put(row, "seed", rootSeed);
            put(row, "planCanonical", plan.canonical());
            put(row, "packages", packages);
            put(row, "channels", plan.channelCount);
            put(row, "requestCanonical", request.canonical());
            JSONArray candidates = new JSONArray();
            for (int ordinal = 0; ordinal < 4; ordinal++) {
                GenerationRequest candidate = request.candidate(ordinal);
                long candidateSeed = candidate.getDescriptor().getRootSeed();
                Rb30Plan candidatePlan = Rb30Plan.resolve(candidateSeed);
                JSONObject candidateRow = new JSONObject();
                put(candidateRow, "ordinal", ordinal);
                put(candidateRow, "seed", Long.toString(candidateSeed));
                put(candidateRow, "packages", candidatePlan.physicalPackageCount());
                put(candidateRow, "channels", candidatePlan.channelCount);
                put(candidateRow, "planCanonical", candidatePlan.canonical());
                put(candidateRow, "manifest", request.candidateManifest(ordinal));
                candidates.set(ordinal, candidateRow);
            }
            row.put("candidates", candidates);
            rows.set(rowIndex, row);
        }
        put(report, "schema", 1);
        put(report, "kind", "Q30_PLAN4_MANIFEST_EXPORT");
        put(report, "sourceCommit", SOURCE_HEAD);
        put(report, "sourceIdentity", SOURCE_IDENTITY);
        put(report, "manifestSha256", MANIFEST_SHA256);
        put(report, "planVersion", 4);
        put(report, "rootCount", rows.size());
        report.put("rows", rows);
    }

    private static boolean isFrozenRoot(String seed) {
        try { parseCanonicalSeed(seed); } catch (RuntimeException invalid) { return false; }
        for (String line : FROZEN_ROOTS.split("\\n")) {
            int separator = line.indexOf('|');
            if (separator > 0 && line.substring(0, separator).equals(seed)) return true;
        }
        return false;
    }

    private static String frozenCanonical(String seed) {
        for (String line : FROZEN_ROOTS.split("\\n")) {
            int separator = line.indexOf('|');
            if (separator > 0 && line.substring(0, separator).equals(seed))
                return line.substring(separator + 1);
        }
        throw new IllegalArgumentException("Seed is not in the frozen plan");
    }

    private static int frozenPackageCount(String seed) {
        String canonical = frozenCanonical(seed);
        int start = canonical.indexOf(";packages=");
        int end = canonical.indexOf(';', start + 10);
        if (start < 0) throw new IllegalArgumentException("Frozen plan has no package count");
        return Integer.parseInt(end < 0 ? canonical.substring(start + 10) : canonical.substring(start + 10, end));
    }

    private static int frozenChannelCount(String seed) {
        String canonical = frozenCanonical(seed);
        int start = canonical.indexOf(";channels=");
        int end = canonical.indexOf(';', start + 10);
        if (start < 0) throw new IllegalArgumentException("Frozen plan has no channel count");
        return Integer.parseInt(end < 0 ? canonical.substring(start + 10) : canonical.substring(start + 10, end));
    }

    private static long parseCanonicalSeed(String seed) {
        if (seed == null || seed.length() == 0 || seed.length() > 20)
            throw new IllegalArgumentException("Seed is not canonical signed-long text");
        long parsed;
        try { parsed = Long.parseLong(seed); }
        catch (NumberFormatException invalid) { throw new IllegalArgumentException("Seed is not a signed long"); }
        if (!Long.toString(parsed).equals(seed))
            throw new IllegalArgumentException("Seed is not canonical signed-long text");
        return parsed;
    }

    private void observeMatrix() {
        if (sim.circuitMatrix != null) {
            matrixObservations++;
            observedMatrixOrderMax = Math.max(observedMatrixOrderMax, sim.circuitMatrixSize);
        }
    }

    private void completed(GenerationJob job, GeneratedBoardInstance owner) {
        if (done) return;
        if (observer != null) observer.cancel();
        if (job.getOutcome() == GenerationJob.Outcome.PASS) observeMatrix();
        put(report, "observedMatrixOrderMax", observedMatrixOrderMax);
        put(report, "matrixObservations", matrixObservations);
        put(report, "matrixObservationScope", "Existing 25 ms observer plus successful publication; sampled live reduced matrix order, not an exhaustive trial maximum");
        put(report, "applicationOutcome", job.getOutcome().name());
        put(report, "terminalStage", job.getStage().name());
        put(report, "generationElapsedMs", job.getElapsedMillis());
        put(report, "startToCallbackWallMs", System.currentTimeMillis() - began);
        put(report, "workUnits", job.getStepCount());
        put(report, "maxActiveOperationMs", job.getMaxActiveOperationMillis());
        put(report, "maxCoordinatorAdvanceMs", coordinator.getMaxAdvanceMillis());
        put(report, "headroomMs", 90000 - job.getElapsedMillis());
        put(report, "yields", coordinator.getYieldCount());
        put(report, "foregroundClock", coordinator.usesForegroundClockForIsolatedQualification());
        put(report, "hiddenEvents", hiddenEvents());
        put(report, "ordinaryCacheHits", coordinator.getDiagnosticProofCacheHits());
        put(report, "ordinaryCacheMisses", coordinator.getDiagnosticProofCacheMisses());
        put(report, "ordinaryCacheSizeBeforeCleanup", coordinator.getDiagnosticProofCacheSize());
        if(job.getOutcome()==GenerationJob.Outcome.PASS) {
            put(report, "routingElapsedMsNested", coordinator.getLastRoutingElapsedMillisForDeveloperVerification());
            put(report, "proofElapsedMsNested", coordinator.getLastProofElapsedMillisForDeveloperVerification());
        } else {
            // Abort releases these owners; zero would falsely imply no work.
            report.put("routingElapsedMsNested",JSONNull.getInstance());
            report.put("proofElapsedMsNested",JSONNull.getInstance());
        }
        JSONArray stages = new JSONArray();
        for (GenerationJob.Stage stage : GenerationJob.Stage.values()) {
            JSONObject row = new JSONObject(); put(row,"stage",stage.name());
            put(row,"elapsedMs",job.getStageElapsedMillis(stage));
            put(row,"workUnits",job.getStageWorkCount(stage)); stages.set(stages.size(),row);
        }
        report.put("stages", stages);
        JSONArray attempts = new JSONArray();
        for (GenerationJob.Attempt attempt : job.getAttempts()) {
            JSONObject row = new JSONObject(); put(row,"ordinal",attempt.ordinal);
            put(row,"manifest",attempt.manifest); put(row,"stage",attempt.stage.name());
            put(row,"outcome",attempt.outcome.name()); put(row,"workUnits",attempt.workUnits);
            put(row,"proofUnits",attempt.proofUnits); put(row,"failureType",attempt.failureType);
            put(row,"failureMessage",attempt.failureMessage); attempts.set(attempts.size(),row);
        }
        report.put("attempts",attempts);
        JSONArray candidates = new JSONArray();
        for (IsolatedGenerationQualification.CandidateEvidence item : authority.getCandidates()) {
            JSONObject row = new JSONObject(); put(row,"ordinal",item.ordinal); put(row,"seed",item.seed);
            put(row,"actualPackages",item.packages); put(row,"physical",item.physical);
            put(row,"diagnostic",item.diagnostic); put(row,"difficulty",item.difficulty);
            put(row,"published",item.published); put(row,"aborted",item.aborted);
            candidates.set(candidates.size(),row);
        }
        report.put("candidates",candidates);
        put(report,"startScopeChecks",authority.getStartChecks());
        put(report,"publicationScopeChecks",authority.getPublicationChecks());
        if (job.getFailure()!=null) put(report,"failure",describe(job.getFailure()));
        String classification = job.getOutcome()==GenerationJob.Outcome.PASS ? "PASS" :
            job.getOutcome()==GenerationJob.Outcome.TIMEOUT ? "TIMEOUT" :
            job.getOutcome()==GenerationJob.Outcome.EXPECTED_REJECTION ||
            job.getOutcome()==GenerationJob.Outcome.WORK_EXHAUSTED ? "ADMISSION_REJECTED" : "INFRASTRUCTURE_FAILURE";
        try {
            require(startupFailure==null,"Startup invariant failed: "+(startupFailure==null?"":describe(startupFailure)));
            require(coordinator.getJob()==job && ownJob==job &&
                (authority.getBoundJob()==job || ("scope-loss".equals(mode) && authority.isClosed())),
                "Completion belongs to a successor or foreign job");
            require(!coordinator.retainsSavedOwnersForDeveloperVerification() &&
                !coordinator.retainsObservationForDeveloperVerification(), "Coordinator retained temporary proof state");
            require(hiddenEvents()==0 && loopbackVisible(), "Screen lost foreground visibility");
            require(privateCacheUntouched() && coordinator.getDiagnosticProofCacheHits()==0,
                "Screen used private or warm proof cache");
            if (job.getOutcome()==GenerationJob.Outcome.PASS) {
                require(coordinator.getDiagnosticProofCacheMisses()>0,"Cold publication did not perform an ordinary cache lookup");
                require(owner!=null && owner==sim.generatedBoardInstance, "Missing published owner");
                owner.requireNormalPhysicalAdmission();
                GeneratedDiagnosticProofReceipt proof = sim.generatedChallengeController.getDiagnosticProofReceipt();
                require(proof!=null && !proof.isWarmReuseForDeveloperVerification(), "Missing cold proof");
                DifficultyAssessment assessment = DifficultyAssessment.assess(owner,proof);
                assessment.require(DifficultyProfile.MEDIUM);
                put(report,"difficultyAssessment",assessment.canonical());
                report.put("proof",proofJson(proof,owner));
                put(report,"generationReceiptManifest",job.getReceipt().getManifest());
            }
            if (!"cold".equals(mode)) {
                require(intervention && owner==null &&
                    ("cancel".equals(mode) ? job.getOutcome()==GenerationJob.Outcome.CANCELLED :
                        job.getOutcome()==GenerationJob.Outcome.STALE), "Lifecycle canary did not reach expected terminal outcome");
                classification="CANARY_PASS";
            }
        } catch(Throwable failure) {
            classification="INFRASTRUCTURE_FAILURE"; put(report,"harnessFailure",describe(failure));
        }
        long cleanupBegan=System.currentTimeMillis();
        try {
            cleanup(job,owner);
            authority.close();
            coordinator.clearDiagnosticProofCacheForDeveloperVerification();
            require(privateCacheUntouched() && coordinator.getDiagnosticProofCacheSize()==0 && authority.isClosed() &&
                !PlayerFamilyCatalog.isNormalPlayerEnabled("RB30_CONTROL"), "Scope/cache/catalog leaked");
            put(report,"cleanupComplete",true);
        } catch(Throwable failure) {
            classification="INFRASTRUCTURE_FAILURE"; put(report,"cleanupComplete",false);
            put(report,"cleanupFailure",describe(failure));
            authority.close();
        }
        put(report,"cleanupElapsedMs",System.currentTimeMillis()-cleanupBegan);
        put(report,"privateCacheUntouched",privateCacheUntouched());
        put(report,"classification",classification); finish();
    }

    private void cleanup(GenerationJob job, GeneratedBoardInstance owner) {
        require(coordinator.getJob()==job && !coordinator.isRunning() && !coordinator.isAdvancing(),
            "Refusing cleanup across a running/successor job");
        if (owner!=null) {
            Vector<CircuitElm> graph=sim.elmList;
            require(sim.generatedBoardInstance==owner,"Refusing retirement of noncurrent owner");
            owner.getExternalPowerBindings().setConnected(false);
            require(owner.getExternalPowerBindings().areAllDisconnected(),"External power remained connected");
            sim.setSimRunning(false);
            for (CircuitElm element:owner.getSimulationElements()) {
                require(coordinator.getJob()==job && sim.generatedBoardInstance==owner && sim.elmList==graph &&
                    !predecessorGraph.contains(element),"Retirement lost graph ownership");
                element.delete();
            }
            snapshot.restore(sim);
            require(owner.getExternalPowerBindings().areAllDisconnected(),"Retired source reconnected");
            for (CircuitElm element:owner.getSimulationElements())
                require(!sim.elmList.contains(element),"Retired element survived restore");
        } else {
            require(sim.generatedBoardInstance==predecessor && sim.generatedChallengeController==predecessorController &&
                sim.elmList==predecessorGraph,"Abort failed to restore predecessor");
            // The normal renderer can run between our capture and installation's
            // own capture. Restore our exact still-current predecessor snapshot.
            snapshot.restore(sim);
        }
        snapshot.assertRestored(sim);
    }

    private static JSONObject proofJson(GeneratedDiagnosticProofReceipt proof, GeneratedBoardInstance owner) {
        proof.requireAssessmentOwner(owner);
        require(proof.getContextKey()!=null && proof.getContextKey().isTrustedCapture(),"Untrusted proof context");
        JSONObject result=new JSONObject(); put(result,"warmReuse",proof.isWarmReuseForDeveloperVerification());
        put(result,"context",proof.getContextKey().canonical()); put(result,"program",proof.getProgramIdentity());
        put(result,"partition",proof.getPartitionPlan().canonical()); put(result,"explicitCompletion",true);
        JSONArray rows=new JSONArray();
        for (GeneratedDiagnosticSolvabilityEvidence item:proof.getEvidence()) {
            require(item.isRepairReachable() && item.isCustomerRetestPassed() && item.isStateIsolated(),"Incomplete repair/retest proof");
            JSONObject row=new JSONObject(); put(row,"hypothesis",item.getHypothesisKey());
            put(row,"repairReachable",item.isRepairReachable()); put(row,"customerRetestPassed",item.isCustomerRetestPassed());
            put(row,"stateIsolated",item.isStateIsolated()); put(row,"deterministicResult",item.getDeterministicResult());
            JSONArray samples=new JSONArray();
            for (GeneratedDiagnosticSample sample:item.getSolverSamples()) {
                JSONObject value=new JSONObject(); put(value,"id",sample.getSampleId()); put(value,"outcome",sample.getOutcome().name());
                if (!sample.isOverRange()) { put(value,"value",sample.getValue()); put(value,"tolerance",sample.getComparisonTolerance()); }
                samples.set(samples.size(),value);
            }
            row.put("samples",samples); rows.set(rows.size(),row);
        }
        result.put("evidence",rows); return result;
    }
    private boolean privateCacheUntouched() {
        return coordinator.getDiagnosticMeasurementProofCacheSize()==0 && coordinator.getDiagnosticMeasurementProofCacheHits()==0 &&
            coordinator.getDiagnosticMeasurementProofCacheMisses()==0;
    }
    private boolean cachesEmpty() {
        return privateCacheUntouched() && coordinator.getDiagnosticProofCacheSize()==0 &&
            coordinator.getDiagnosticProofCacheHits()==0 && coordinator.getDiagnosticProofCacheMisses()==0;
    }
    private void failBeforeStart(Throwable failure) {
        if (done) return;
        startupFailure=failure;
        put(report,"classification","INFRASTRUCTURE_FAILURE"); put(report,"harnessFailure",describe(failure));
        put(report,"cleanupComplete",false);
        try {
            if (ownJob!=null) {
                require(coordinator!=null && coordinator.getJob()==ownJob && !coordinator.isAdvancing(),
                    "Startup failure cannot cancel a successor or active job");
                if (ownJob.isRunning()) coordinator.cancel();
                if (done) return; // The exact normal completion callback already checked cleanup.
                GeneratedBoardInstance published=ownJob.getOutcome()==GenerationJob.Outcome.PASS ?
                    sim.generatedBoardInstance : null;
                if(published!=null) require(published!=predecessor && ownJob.getReceipt()!=null &&
                    request.candidateManifest(ownJob.getCandidateIndex()).equals(ownJob.getReceipt().getManifest()) &&
                    published.getSeed()==request.candidate(ownJob.getCandidateIndex()).getDescriptor().getRootSeed(),
                    "Unexpected publication does not belong to this exact request/job");
                cleanup(ownJob,published);
            } else if(snapshot!=null) {
                require(coordinator==null || coordinator.getJob()==null,"Unknown generation owner after startup failure");
                snapshot.assertRestored(sim);
            }
            if(snapshot!=null) put(report,"cleanupComplete",true);
        } catch(Throwable cleanupFailure) { put(report,"cleanupFailure",describe(cleanupFailure)); }
        if (authority!=null) authority.close();
        finish();
    }
    private void finish() {
        done=true; if(observer!=null) observer.cancel();
        publish(report.toString());
    }
    private static void require(boolean value,String message) { if(!value) throw new IllegalStateException(message); }
    private static String describe(Throwable failure) { return failure.getClass().getName()+": "+failure.getMessage(); }
    private static void put(JSONObject o,String k,String v) { o.put(k,v==null?JSONNull.getInstance():new JSONString(v)); }
    private static void put(JSONObject o,String k,double v) { o.put(k,new JSONNumber(v)); }
    private static void put(JSONObject o,String k,boolean v) { o.put(k,JSONBoolean.getInstance(v)); }
    private static native boolean loopbackVisible() /*-{
        return ($wnd.location.hostname==='127.0.0.1'||$wnd.location.hostname==='localhost') && !$doc.hidden;
    }-*/;
    private static native void installVisibilityAudit() /*-{
        $wnd.__q30HiddenEvents=0;
        $doc.addEventListener('visibilitychange',function(){if($doc.hidden)$wnd.__q30HiddenEvents++;});
    }-*/;
    private static native int hiddenEvents() /*-{ return $wnd.__q30HiddenEvents||0; }-*/;
    private static native void setState(String state,String message) /*-{
        $doc.documentElement.setAttribute('data-tsj-q30-normal-state',state);
        var node=$doc.getElementById('q30-normal-status');
        if(!node){node=$doc.createElement('pre');node.id='q30-normal-status';
            node.style.cssText='position:fixed;left:10px;top:10px;z-index:99999;background:white;color:black;padding:14px;border:2px solid #345';
            $doc.body.appendChild(node);}
        node.textContent=message;
    }-*/;
    private static native void publish(String json) /*-{
        $doc.documentElement.setAttribute('data-tsj-q30-normal-report',json);
        $doc.documentElement.setAttribute('data-tsj-q30-normal-state','SCREEN_DONE');
        var node=$doc.getElementById('q30-normal-status');
        if(node)node.textContent='Q30 normal screen: '+JSON.parse(json).classification;
    }-*/;
}
