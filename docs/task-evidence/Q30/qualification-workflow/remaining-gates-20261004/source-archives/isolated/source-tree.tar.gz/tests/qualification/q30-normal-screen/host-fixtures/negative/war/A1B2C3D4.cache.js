window.fixtureCacheAsset = true;
