final class Fixture {}
