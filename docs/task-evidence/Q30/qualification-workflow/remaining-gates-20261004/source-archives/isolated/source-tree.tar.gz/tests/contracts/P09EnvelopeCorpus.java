package com.lushprojects.circuitjs1.client;

import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

/** Predeclared calibration, then held-out physical-only qualification. */
public final class P09EnvelopeCorpus {
    static final long[] REGRESSION={0,1,2,3,17,42,101,-1,9007199254740993L,Long.MIN_VALUE,Long.MAX_VALUE};
    static final long[] HELD_OUT={11,23,37,59,83,127,251,509,-11,-23,-127,-509};
    public static void main(String[] args) {
        CirSim sim=new CirSim(); sim.gridSize=16; sim.gridMask=~15; sim.gridRound=7; CircuitElm.sim=sim;
        for(String family:p09CalibrationFamilies()) {
            long start=System.nanoTime();
            GeneratedBoardInstance owner=new PlayerLaunchRequest(family,"0",
                PlayerFamilyCatalog.candidateProfile(family).name()).generation()
                .resolve(new GenerationRequest.PlanCache()).construct().instance;
            row("calibration",family,0,owner.getBoard(),owner.getPcbLayout(),start);
        }
        int regressionPass=0,regressionReject=0;
        for(long seed:REGRESSION) {
            long start=System.nanoTime(); Rb15Plan plan=Rb15Plan.resolve(seed);
            TroubleshootBoard board=plan.board();
            PcbBoardLayout attempted=null;
            try {
                attempted=new SeededPcbLayoutGenerator().generate(board,plan.layoutSeed,plan.routingSeed);
                row("regression",Rb15Plan.FAMILY_ID,seed,board,attempted,start); regressionPass++;
            } catch(PcbRoutingRejectedException rejected) {
                rejected("regression",seed,"ROUTING_"+rejected.getKind(),start); regressionReject++;
            } catch(SupportedEnvelope.Rejected rejected) {
                rejected("regression",seed,"ENVELOPE_"+rejected.reason,start); regressionReject++;
                rejectMetrics(seed,board,attempted);
            }
        }
        if(regressionPass+regressionReject!=REGRESSION.length || regressionPass<9)
            throw new AssertionError("Regression candidate population collapsed");
        int heldPass=0,heldReject=0;
        for(long seed:HELD_OUT) {
            long start=System.nanoTime(); Rb15Plan plan=Rb15Plan.resolve(seed);
            TroubleshootBoard board=plan.board();
            PcbBoardLayout attempted=null;
            try {
                PcbBoardLayout layout=new SeededPcbLayoutGenerator().generate(board,plan.layoutSeed,plan.routingSeed);
                attempted=layout;
                SupportedEnvelope.current().requireBounds(board,layout);
                layout.validateGeometry(board);
                PcbBoardLayout repeat=new SeededPcbLayoutGenerator().generate(board,plan.layoutSeed,plan.routingSeed);
                if(!layout.geometryFingerprint().equals(repeat.geometryFingerprint())) throw new AssertionError("Held-out replay changed");
                row("held-out",Rb15Plan.FAMILY_ID,seed,board,layout,start); heldPass++;
            } catch(PcbRoutingRejectedException rejected) {
                rejected("held-out",seed,"ROUTING_"+rejected.getKind(),start); heldReject++;
            } catch(SupportedEnvelope.Rejected rejected) {
                rejected("held-out",seed,"ENVELOPE_"+rejected.reason,start); heldReject++;
                rejectMetrics(seed,board,attempted);
            }
        }
        if(heldPass+heldReject!=HELD_OUT.length) throw new AssertionError("Missing held-out rows");
        System.out.println("PASS: P09 physical envelope corpus rows=32 regressionPass="+regressionPass+
            " regressionReject="+regressionReject+" heldPass="+heldPass+" heldReject="+heldReject);
    }
    /**
     * This corpus is specifically the existing P09 single-face contract.
     * Q30 uses MEDIUM_BOARD_NORMAL@1 and is covered by Q30NormalCorpusContractTest
     * plus the full-catalog physical matrix; it must not be reclassified here.
     */
    private static Vector<String> p09CalibrationFamilies() {
        Vector<String> result=QuickPlayFamilyRegistry.getNormalPlayerFamilyIds();
        result.add(ControlledIndicatorBlockContributions.FAMILY_ID);
        return result;
    }
    private static void rejected(String cohort,long seed,String reason,long start) {
        System.out.println("P09_ROW {\"cohort\":\""+cohort+"\",\"seed\":\""+seed+"\",\"outcome\":\""+reason+
            "\",\"elapsedMs\":"+((System.nanoTime()-start)/1000000.0)+"}");
    }
    private static void rejectMetrics(long seed,TroubleshootBoard board,PcbBoardLayout attempted) {
        if(attempted==null)return;
        Rectangle r=attempted.getBoardOutline(); PcbRouteMetrics m=PcbRouteMetrics.measure(attempted.getTraces());
        System.out.println("P09_REJECT_METRICS {\"seed\":\""+seed+"\",\"width\":"+r.width+",\"height\":"+r.height+
            ",\"uniqueLength\":"+m.uniqueLength+",\"score\":"+attempted.getRouteQualityScore(board)+"}");
    }
    static void row(String cohort,String family,long seed,TroubleshootBoard board,PcbBoardLayout layout,long start) {
        SupportedEnvelope.current().requireBounds(board,layout);
        long checkStart=System.nanoTime(); layout.validateGeometry(board); long validationNs=System.nanoTime()-checkStart;
        Rectangle r=layout.getBoardOutline();
        int degree=0,padFloor=Integer.MAX_VALUE,probeFloor=Integer.MAX_VALUE;
        TreeSet<String> domains=new TreeSet<String>(); TreeMap<String,Integer> packages=new TreeMap<String,Integer>();
        for(String net:board.getNetIds()) degree=Math.max(degree,board.getNet(net).getPadIds().size());
        for(PcbPlacementConstraints.Part p:board.getPlacementConstraints().getParts()) domains.add(p.domainId);
        for(PcbComponentPlacement p:layout.getComponents()) {
            String key=p.getPhysicalPackage().getId()+"/"+p.getMountingSide()+"/"+p.getRotation();
            Integer old=packages.get(key); packages.put(key,old==null?1:old+1);
        }
        for(PcbPadPlacement p:layout.getPads()) {
            padFloor=Math.min(padFloor,Math.min(p.getPadBounds().width,p.getPadBounds().height));
            probeFloor=Math.min(probeFloor,Math.min(p.getProbeBounds().width,p.getProbeBounds().height));
            if(!PcbCopperAccess.canProbe(p,PcbBoardSide.BOTTOM)) throw new AssertionError("Inaccessible solder pad "+p.getPadId());
        }
        PcbRouteMetrics m=PcbRouteMetrics.measure(layout.getTraces());
        System.out.println("P09_ROW {\"cohort\":\""+cohort+"\",\"family\":\""+family+"\",\"seed\":\""+seed+
            "\",\"outcome\":\"BOUNDS_GEOMETRY_PASS\",\"validationNs\":"+validationNs+",\"heapUsedBytes\":"+(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())+",\"parts\":"+board.getComponentIds().size()+",\"pads\":"+board.getPadIds().size()+",\"nets\":"+board.getNetIds().size()+
            ",\"layer\":\""+board.getPlacementConstraints().routingLayer+"\",\"width\":"+r.width+",\"height\":"+r.height+",\"area\":"+((long)r.width*r.height)+
            ",\"degree\":"+degree+",\"domains\":"+domains.size()+",\"barriers\":"+board.getPlacementConstraints().getBarriers().size()+
            ",\"padFloor\":"+padFloor+",\"probeFloor\":"+probeFloor+",\"segments\":"+m.segments+",\"uniqueLength\":"+m.uniqueLength+
            ",\"score\":"+layout.getRouteQualityScore(board)+",\"placements\":"+layout.getGenerationPlacementAttempts()+
            ",\"routes\":"+layout.getGenerationRoutingAttempts()+",\"expansions\":"+layout.getGenerationRoutingExpansions()+
            ",\"elapsedMs\":"+((System.nanoTime()-start)/1000000.0)+",\"packages\":\""+packages+"\"}");
    }
}
