package com.lushprojects.circuitjs1.client;

import java.util.Vector;

/**
 * Family-agnostic production diagnostic admission boundary.
 * This runs before a normal generated challenge can become READY.
 */
final class GeneratedDiagnosticSolvabilityAdmission {
    private static int internalProofDepth;

    private GeneratedDiagnosticSolvabilityAdmission() { }

    static boolean isInternalProofRunning() { return internalProofDepth != 0; }

    static void beginInternalProof() { internalProofDepth++; }

    static void endInternalProof() {
        if (internalProofDepth <= 0)
            throw new IllegalStateException("Task 41 diagnostic proof guard underflow");
        internalProofDepth--;
    }

    static void validateLive(CirSim sim, GeneratedBoardInstance instance,
            GeneratedChallengeController ownerController) {
        validate(sim, instance);
        if (instance.isDeveloperOnlyFaultRoute() || isInternalProofRunning()) return;
        instance.requireNormalPhysicalAdmission();
        GeneratedDiagnosticProofService.prove(sim, instance, ownerController);
    }

    static void validate(GeneratedBoardInstance instance) {
        if (instance == null)
            throw new IllegalArgumentException("Missing diagnostic solvability board");
        GeneratedDiagnosticSolvabilityContract contract =
            instance.getDiagnosticSolvabilityContract();
        if (contract == null)
            throw new IllegalArgumentException("Generated challenge has no solvability contract");
        contract.validate(instance);
        for (GeneratedDiagnosticPlan plan : contract.getPlans()) {
            for (String targetId : plan.getProbeTargetIds())
                if (instance.getBoard().getPad(targetId) == null ||
                        instance.getSimulationBindings().getEndpoint(targetId) == null)
                    throw new IllegalArgumentException("Diagnostic plan has no board probe target: " +
                        targetId);
    }
    }

    /**
     * Validates the provider and the complete global serviceability population
     * without touching the rendered workbench.  This is the common admission
     * predicate used before serial proof and before D01 cache reuse.
     */
    static void validateStructural(GeneratedBoardInstance instance) {
        validate(instance);
        GeneratedDiagnosticProvider provider = instance.getDiagnosticProvider();
        if (provider == null || provider.getProviderId() == null ||
                provider.getProviderId().length() == 0)
            throw new IllegalArgumentException("Generated challenge has no identified diagnostic provider");
        GeneratedDiagnosticPlan providerPlan = provider.getDiagnosticPlan();
        GeneratedDiagnosticProgram providerProgram = provider.getObservationProgram();
        if (providerPlan == null || providerProgram == null)
            throw new IllegalArgumentException("Diagnostic provider has incomplete structural contract");
        validatePlan(providerPlan);
        providerProgram.validatePlan(providerPlan);
        GeneratedDiagnosticSolvabilityContract contract =
            instance.getDiagnosticSolvabilityContract();
        if (contract.getPlans().size() != 1 ||
                !GeneratedDiagnosticProgram.describePlan(providerPlan).equals(
                    GeneratedDiagnosticProgram.describePlan(contract.getPlans().firstElement())))
            throw new IllegalArgumentException("Provider plan differs from global diagnostic contract");

        Vector<GeneratedFaultCandidate> admitted =
            GeneratedFaultServiceabilityAdmission.getAdmittedCandidates(instance.getFaultCandidates());
        if (admitted.isEmpty())
            throw new IllegalArgumentException("Generated challenge has no structurally serviceable hypotheses");
        GeneratedFaultServiceabilityAdmission.validateHypothesisPopulation(
            instance.getFaultCandidates(), contract.getHypothesisKeys());
        GeneratedFaultBinding selectedBinding = instance.getFaultBinding();
        boolean selectedAdmitted = false;
        for (GeneratedFaultCandidate candidate : admitted) {
            GeneratedFaultServiceabilityAdmission.validateCandidate(candidate);
            if (candidate.getBinding() == selectedBinding) selectedAdmitted = true;
            GeneratedFaultServiceability serviceability = candidate.getServiceability();
            GeneratedFaultLocus locus = serviceability.getLocus();
            if (locus.getType() == GeneratedFaultLocusType.TRACE_SEGMENT)
                throw new IllegalArgumentException("Diagnostic hypothesis has no installed physical owner: " +
                    locus.getOwnerId());
            BoardComponent component = instance.getBoard().getComponent(locus.getComponentId());
            PhysicalBoardSlot slot = instance.getPhysicalBoardRuntime().getSlot(locus.getComponentId());
            if (component == null || slot == null || slot.getInstalledPart() == null)
                throw new IllegalArgumentException("Diagnostic hypothesis owner is not installed: " +
                    locus.getOwnerId());
            if (serviceability.getFaultClearingRepairActionIds().contains(
                    WorkbenchOperation.CATALOG_INSTALL)) {
                String catalogId = provider.getCorrectCatalogId(instance, locus.getComponentId());
                if (catalogId == null || catalogId.length() == 0)
                    throw new IllegalArgumentException("Diagnostic provider has no legal replacement for: " +
                        locus.getComponentId());
            }
        }
        if (!selectedAdmitted)
            throw new IllegalArgumentException("Selected diagnostic fault is outside the admitted population");
        // Runtime capability/renderer checks remain at the installed executor
        // boundary (`validateExecutableRuntime`); this structural predicate
        // intentionally remains usable on a detached generated owner.
    }

    static void validate(CirSim sim, GeneratedBoardInstance instance) {
        validate(instance);
        if (sim == null)
            throw new IllegalArgumentException("Diagnostic plan has no simulation owner");
        if (sim.getGeneratedBoardInstance() != instance) {
            GeneratedBoardInstance current = sim.getGeneratedBoardInstance();
            throw new IllegalArgumentException("Diagnostic plan has no current board owner: expected=" +
                instance.getCircuitFamilyId() + "/" + instance.getSeed() + ", actual=" +
                (current == null ? "null" : current.getCircuitFamilyId() + "/" + current.getSeed()));
        }
        if (sim.pcbWorkbenchController == null)
            throw new IllegalArgumentException("Diagnostic plan has no rendered workbench");
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        for (GeneratedDiagnosticPlan plan : instance.getDiagnosticSolvabilityContract().getPlans())
            for (String targetId : plan.getProbeTargetIds()) {
                if (!renderer.hasPad(targetId))
                    throw new IllegalArgumentException("Diagnostic plan target is not rendered: " +
                        targetId);
                if (!renderer.canInspectPad(sim, targetId))
                    throw new IllegalArgumentException("Diagnostic plan target is not player probeable: " +
                        targetId);
            }
    }

    static void validatePlan(GeneratedDiagnosticPlan plan) {
        if (plan == null)
            throw new IllegalArgumentException("Missing diagnostic plan");
        validateAllowed(plan.getMeterModeIds(), new String[] { "DC_VOLTAGE", "RESISTANCE",
            "CONTINUITY", "DIODE" }, "meter mode");
        for (String transition : plan.getInputPowerTransitions())
            validatePublicSemanticId(transition, "input/power transition");
        validateIsolationActions(plan.getIsolationActionIds());
        validateFaultClearingRepairActions(plan.getRepairActionIds());
        validateWorkflowActions(plan.getWorkflowActionIds());
        for (String operation : plan.getPlayerOperationIds())
            validatePublicSemanticId(operation, "player operation");
        for (String sampleId : plan.getTemporalWaitSampleIds())
            validatePublicSemanticId(sampleId, "temporal wait/sample");
        if (!plan.getPlayerOperationIds().contains(GeneratedBoardOperationIds.CUSTOMER_RETEST))
            throw new IllegalArgumentException("Diagnostic plan omits CUSTOMER_RETEST");
        for (String targetId : plan.getProbeTargetIds())
            validatePublicSemanticId(targetId, "probe target");
        for (String domainId : plan.getRailDomainIds())
            validatePublicSemanticId(domainId, "rail/domain");
    }

    private static void validateAllowed(Vector<String> actual, String[] allowed, String category) {
        for (String value : actual) {
            boolean known = false;
            for (String candidate : allowed)
                if (candidate.equals(value)) { known = true; break; }
            if (!known)
                throw new IllegalArgumentException("Diagnostic plan contains unsupported " +
                    category + ": " + value);
        }
    }

    private static void validateIsolationActions(Vector<String> actionIds) {
        for (String actionId : actionIds)
            if (!GeneratedActionVocabulary.isExecutableIsolation(actionId))
                throw new IllegalArgumentException("Diagnostic plan contains unsupported or reserved " +
                    "isolation action: " + actionId);
    }

    private static void validateFaultClearingRepairActions(Vector<String> actionIds) {
        for (String actionId : actionIds)
            if (!GeneratedActionVocabulary.isFaultClearingRepair(actionId))
                throw new IllegalArgumentException("Diagnostic plan repair action is not an executable " +
                    "fault-clearing repair: " + actionId);
    }

    private static void validateWorkflowActions(Vector<String> actionIds) {
        for (String actionId : actionIds)
            if (!GeneratedActionVocabulary.isExecutableWorkflow(actionId))
                throw new IllegalArgumentException("Diagnostic plan contains unsupported or reserved " +
                    "workflow action: " + actionId);
    }

    private static void validatePublicSemanticId(String value, String category) {
        if (value == null || value.length() == 0)
            throw new IllegalArgumentException("Diagnostic plan has empty " + category);
        String upper = value.toUpperCase();
        String[] forbidden = { "DEVELOPER", "PRIVATE", "SOLVER", "FAULT", "ANSWER", "HINT",
            "CANDIDATE", "NODE_NUMBER", "COORD", "INDEX", "UUID" };
        for (String token : forbidden)
            if (upper.indexOf(token) >= 0)
                throw new IllegalArgumentException("Diagnostic plan contains hidden " + category);
    }

    static int getAdmittedCandidateCount(Vector<GeneratedFaultCandidate> candidates) {
        return getAdmittedCandidates(candidates).size();
    }

    static boolean isAdmitted(GeneratedFaultCandidate candidate) {
        return GeneratedFaultServiceabilityAdmission.isAdmitted(candidate);
    }

    static Vector<GeneratedFaultCandidate> getAdmittedCandidates(
            Vector<GeneratedFaultCandidate> candidates) {
        return GeneratedFaultServiceabilityAdmission.getAdmittedCandidates(candidates);
    }

    static Vector<String> getHypothesisKeys(Vector<GeneratedFaultCandidate> candidates) {
        return GeneratedFaultServiceabilityAdmission.getHypothesisKeys(candidates);
    }

    static int getPhysicalOwnerCount(Vector<GeneratedFaultCandidate> candidates) {
        return GeneratedFaultServiceabilityAdmission.getPhysicalOwnerCount(candidates);
    }

    static GeneratedDiagnosticOwnerDiversity getOwnerDiversity(
            Vector<GeneratedFaultCandidate> candidates) {
        return getPhysicalOwnerCount(candidates) > 1 ?
            GeneratedDiagnosticOwnerDiversity.MULTI_OWNER_DIAGNOSTIC :
            GeneratedDiagnosticOwnerDiversity.GUIDED_EASY_SINGLE_OWNER;
    }
}
