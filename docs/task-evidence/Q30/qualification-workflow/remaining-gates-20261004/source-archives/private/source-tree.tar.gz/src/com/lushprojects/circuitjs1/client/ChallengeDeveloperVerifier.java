package com.lushprojects.circuitjs1.client;

import java.util.Vector;

class ChallengeDeveloperVerifier {
    static void verify(CirSim sim) {
        GeneratedChallengeController challenge = sim.getGeneratedChallengeController();
        GeneratedBoardInstance instance = sim.getGeneratedBoardInstance();
        require(challenge != null && challenge.isReady(), "Challenge did not become ready");
        verifyLifecycleEvidence(challenge);
        verifyDeterministicMetadata(instance, challenge);
        verifyFaultConstructionInvariants(instance);
        GeneratedFaultController faults = challenge.getFaultController();
        BoardModificationController modifications = sim.getBoardModificationController();
        require(faults.isApplied(), "Challenge fault was not applied");
        require(modifications.getComponentState("R1") == ComponentPhysicalState.INSTALLED,
            "Faulted R1 is not physically installed");
        verifyFaultedPowered(sim, instance);
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-faulted-unpowered");
        verifyFaultedUnpowered(sim, instance);
        verifyPhysicalPersistence(sim, instance, modifications, faults);
        verifyDeveloperClearAndReapply(sim, instance, faults);
        sim.setCircuitTitle("Challenge verification passed");
    }

    private static void verifyFaultedPowered(CirSim sim, GeneratedBoardInstance instance) {
        require(sim.getBoardPowerController().getState() == BoardPowerState.POWERED,
            "Faulted challenge is not powered");
        CircuitPostProbeTarget vin = getProbe(sim, instance, "J1.1");
        CircuitPostProbeTarget ground = getProbe(sim, instance, "J1.2");
        double expected = instance.getPhysicalSpecifications().getPowerInputNameplate("VIN_INPUT")
            .getNominalVoltage();
        requireApproximately(expected, sim.instrumentController
            .getDcVoltageDifferenceForDeveloperVerification(vin, ground), .1,
            "Faulted VIN differs from nameplate");
        sim.getGeneratedChallengeController().getDefinition().getBehaviorContract().verifyFaulted(instance,
            sim.getBoardModificationController(), BoardPowerState.POWERED);
    }

    private static void verifyFaultedUnpowered(CirSim sim, GeneratedBoardInstance instance) {
        GeneratedFaultType type = instance.getFaultBinding().getFault().getType();
        if (type == GeneratedFaultType.RESISTOR_OPEN) {
            CircuitPostProbeTarget r11 = getProbe(sim, instance, "R1.1");
            CircuitPostProbeTarget r12 = getProbe(sim, instance, "R1.2");
            sim.instrumentController.setResistanceProbesForDeveloperVerification(r11, r12);
            require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
                "Faulted R1 PCB pads did not measure OL: " +
                sim.getLastResistanceMeasurementDiagnosticsForDeveloperVerification());
        }
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        verifyLedPolarity(sim, instance);
    }

    private static void verifyLedPolarity(CirSim sim, GeneratedBoardInstance instance) {
        if (instance.getFaultBinding().getFault().getType() == GeneratedFaultType.LED_OPEN) {
            verifyLedOpenPolarity(sim, instance);
            return;
        }
        CircuitPostProbeTarget anode = getProbe(sim, instance, "LED1.A");
        CircuitPostProbeTarget cathode = getProbe(sim, instance, "LED1.K");
        CircuitPostProbeTarget vin = getProbe(sim, instance, "J1.1");
        CircuitPostProbeTarget r11 = getProbe(sim, instance, "R1.1");
        Vector<CircuitElm> elements = new Vector<CircuitElm>(sim.elmList);
        String export = sim.dumpCircuit();
        int undo = sim.undoStack.size();
        int redo = sim.redoStack.size();
        boolean unsaved = sim.unsavedChanges;
        sim.instrumentController.setResistanceProbesForDeveloperVerification(anode, cathode);
        double forwardResistance = sim.instrumentController.getLatestResistanceReadingForDeveloperVerification();
        require(!Double.isNaN(forwardResistance) && !Double.isInfinite(forwardResistance) &&
            forwardResistance < 10000000, "LED forward OHM was not finite: " + forwardResistance);
		verifyNeutralResistanceReference(sim, "forward LED OHM");
        verifyMeasurementRestoration(sim, instance, elements, export, undo, redo, unsaved,
            "forward LED OHM");
        sim.instrumentController.setResistanceProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED reverse OHM was not OL");
		verifyNeutralResistanceReference(sim, "reverse LED OHM");
        verifyMeasurementRestoration(sim, instance, elements, export, undo, redo, unsaved,
            "reverse LED OHM");
        sim.instrumentController.setContinuityProbesForDeveloperVerification(anode, cathode);
        require(!Double.isNaN(sim.instrumentController.getLatestResistanceReadingForDeveloperVerification()) &&
            !sim.instrumentController.isContinuityDetectedForDeveloperVerification() &&
            !sim.instrumentController.isContinuityIndicatorVisibleForDeveloperVerification() &&
            !sim.instrumentController.isContinuityFeedbackRequestedForDeveloperVerification(),
            "LED forward CONT produced false continuity");
        verifyMeasurementRestoration(sim, instance, elements, export, undo, redo, unsaved,
            "forward LED CONT");
        sim.instrumentController.setContinuityProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()) &&
            !sim.instrumentController.isContinuityDetectedForDeveloperVerification(),
            "LED reverse CONT was not OL without continuity");
		verifyNeutralResistanceReference(sim, "reverse LED CONT");
        verifyMeasurementRestoration(sim, instance, elements, export, undo, redo, unsaved,
            "reverse LED CONT");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(anode, cathode);
        require(!"OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED forward diode reading was OL");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED reverse diode reading was not OL");
        sim.instrumentController.setContinuityProbesForDeveloperVerification(vin, r11);
        require(sim.instrumentController.isContinuityDetectedForDeveloperVerification(),
            "Same-net continuity did not activate");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
    }

    private static void verifyLedOpenPolarity(CirSim sim, GeneratedBoardInstance instance) {
        CircuitPostProbeTarget anode = getProbe(sim, instance, "LED1.A");
        CircuitPostProbeTarget cathode = getProbe(sim, instance, "LED1.K");
        sim.instrumentController.setResistanceProbesForDeveloperVerification(anode, cathode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED_OPEN forward resistance did not remain OL");
        sim.instrumentController.setResistanceProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED_OPEN reverse resistance did not remain OL");
        sim.instrumentController.setContinuityProbesForDeveloperVerification(anode, cathode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()) &&
                !sim.instrumentController.isContinuityDetectedForDeveloperVerification(),
            "LED_OPEN forward continuity was not open");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(anode, cathode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED_OPEN forward diode test was not open");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "LED_OPEN reverse diode test was not open");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
    }

    private static void verifyMeasurementRestoration(CirSim sim, GeneratedBoardInstance instance,
            Vector<CircuitElm> elements, String export, int undo, int redo, boolean unsaved,
            String mode) {
        require(!sim.activeMeasurementOverlay && sim.elmList.equals(elements) &&
            export.equals(sim.dumpCircuit()) && undo == sim.undoStack.size() &&
            redo == sim.redoStack.size() && unsaved == sim.unsavedChanges &&
            sim.getBoardPowerController().isElectricallyUnpowered() &&
            instance.getFaultBinding().isApplied(), "Measurement did not restore " + mode);
    }

    private static void verifyNeutralResistanceReference(CirSim sim, String mode) {
        require(sim.hasElectricallyNeutralResistanceReferenceForDeveloperVerification(),
            "Resistance reference was not neutral during " + mode + ": " +
            sim.getLastResistanceMeasurementDiagnosticsForDeveloperVerification());
    }

    private static void verifyLifecycleEvidence(GeneratedChallengeController challenge) {
        GeneratedChallengeLifecycleEvidence evidence = challenge.getLifecycleEvidence();
        require(evidence.healthyGenerationInstalled && evidence.healthyGraphAnalyzedAfterTimeAdvance &&
            evidence.healthyFamilyValidated && evidence.selectedFaultApplied &&
            evidence.faultedGraphAnalyzedAfterTimeAdvance && evidence.selectedFaultValidated &&
            evidence.scenarioCompatibilityValidated && challenge.getScenario() != null &&
            evidence.readyAfterValidation, "Challenge lifecycle evidence is incomplete");
    }

    private static void verifyDeterministicMetadata(GeneratedBoardInstance instance,
            GeneratedChallengeController challenge) {
        GeneratedChallengeDefinition definition = challenge.getDefinition();
        GeneratedScenario<GeneratedObservedBehavior> scenario = challenge.getScenario();
        require("LED_INDICATOR_NO_LIGHT".equals(definition.getId()) &&
            "INDICATOR_DOES_NOT_LIGHT".equals(scenario.getComplaintId()) &&
            "Indicator does not light.".equals(scenario.getComplaintText()) &&
            scenario.getObservedBehavior() == GeneratedObservedBehavior.DARK_INDICATOR &&
            scenario.isCompatible(instance, null, BoardPowerState.POWERED) &&
            definition.getFault() == instance.getFaultBinding().getFault(),
            "Selected challenge metadata disagrees with binding");
        GeneratedScenario<GeneratedObservedBehavior> repeat = GeneratedScenarioLibrary.ledIndicator()
            .select(definition.getSelectionSeed(), instance, null, BoardPowerState.POWERED);
        require(scenario.getScenarioId().equals(repeat.getScenarioId()) &&
            scenario.getComplaintText().equals(repeat.getComplaintText()),
            "Scenario selection was not reproducible for the seed");
        verifySeed(0, 5, 330, GeneratedFaultType.RESISTOR_OPEN, "LED_R1_OPEN");
        verifySeed(2, 9, 680, GeneratedFaultType.RESISTOR_OPEN, "LED_R1_OPEN");
        verifySeed(3, 12, 1000, GeneratedFaultType.RESISTOR_INCORRECT_VALUE,
            "LED_R1_INCORRECT_VALUE");
        require(new LedIndicatorGenerator().generate(0).getChallengeDefinition().getFault().getType() !=
            new LedIndicatorGenerator().generate(3).getChallengeDefinition().getFault().getType(),
            "LED fault selection did not produce multiple deterministic fault types");
    }

    private static void verifyFaultConstructionInvariants(GeneratedBoardInstance instance) {
        ResistorElm resistor = (ResistorElm) instance.getComponentBindings()
            .getSingleElement("R1");
        double healthy = resistor.getResistance();
        try {
            GeneratedFaultEngine.resistorIncorrectValue("TEST_EQUAL_VALUE", "LED_INDICATOR", 0,
                "R1", resistor, healthy, healthy);
            throw new IllegalStateException("Equal healthy/effective resistor values were accepted");
        } catch (IllegalArgumentException expected) {
            // Defensive effective-value rejection is intentional.
        }

        GeneratedFault unrelatedFault = new GeneratedFault("TEST_UNRELATED_VALUE",
            GeneratedFaultType.RESISTOR_INCORRECT_VALUE, "LED1", "LED_INDICATOR", 0,
            healthy, healthy * 100);
        GeneratedFaultBinding unrelatedBinding = new GeneratedFaultBinding(unrelatedFault,
            new ResistorIncorrectValueFaultEffect(resistor, healthy, healthy * 100));
        try {
            GeneratedChallengeController.validateFaultEffectOwnership(instance, unrelatedFault,
                unrelatedBinding);
            throw new IllegalStateException("Unrelated value-mutating fault ownership was accepted");
        } catch (IllegalArgumentException expected) {
            // The private-element list is empty, so this specifically covers
            // the real value mutation target ownership check.
        }
    }

    private static void verifySeed(long seed, double voltage, double resistance,
            GeneratedFaultType expectedType, String expectedId) {
        GeneratedBoardInstance variant = new LedIndicatorGenerator().generate(seed);
        GeneratedChallengeDefinition definition = variant.getChallengeDefinition();
        requireApproximately(voltage, variant.getPhysicalSpecifications()
            .getPowerInputNameplate("VIN_INPUT").getNominalVoltage(), .001,
            "Unexpected deterministic VIN for seed " + seed);
        requireApproximately(resistance, StandardPhysicalDefinitionProviders.RESISTOR.require(
            variant.getPhysicalSpecifications(), "R1").getNominalResistanceOhms(), .001,
            "Unexpected deterministic R1 for seed " + seed);
        require(expectedId.equals(definition.getFault().getId()) &&
            expectedType == definition.getFault().getType() &&
            "R1".equals(definition.getFault().getTargetComponentId()) &&
            definition.getSelectionSeed() == seed, "Unexpected deterministic challenge metadata");
        GeneratedBoardInstance repeat = new LedIndicatorGenerator().generate(seed);
        require(definition.getFault().getType() == repeat.getChallengeDefinition().getFault().getType() &&
            definition.getFault().getId().equals(repeat.getChallengeDefinition().getFault().getId()),
            "LED fault selection was not reproducible for seed " + seed);
        if (expectedType == GeneratedFaultType.RESISTOR_INCORRECT_VALUE)
            require(definition.getFault().getEffectiveValue() == resistance * 100,
                "Incorrect resistor fault metadata lost its effective value");
    }

    private static void verifyPhysicalPersistence(CirSim sim, GeneratedBoardInstance instance,
            BoardModificationController modifications, GeneratedFaultController faults) {
        if (instance.getFaultBinding().getFault().getType() == GeneratedFaultType.LED_OPEN) {
            verifyFailedOriginalLedPersistence(sim, instance, modifications, faults);
            return;
        }
        if (instance.getFaultBinding().getFault().getType() == GeneratedFaultType.RESISTOR_OPEN)
            verifyFailedOriginalLiftedLeadVoltage(sim, instance, modifications, faults);
        else
            verifyIncorrectOriginalLiftedLead(sim, instance, modifications, faults);
        require(modifications.liftLead("R1", "R1.1"),
            "Failed R1 lead 1 did not lift");
        require(modifications.getComponentState("R1") == ComponentPhysicalState.LEAD_LIFTED &&
            faults.isApplied(), "Lead lift cleared the internal fault");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-r1-lead-lift");
        require(modifications.removeComponent("R1"),
            "Failed R1 did not remove after lead lift");
        require(modifications.getComponentState("R1") == ComponentPhysicalState.REMOVED &&
            faults.isApplied(), "Removal cleared the internal fault");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-r1-remove");
        CircuitPostProbeTarget componentLead1 = getProbe(sim,
            instance.getConnectionBindings().get("R1", "R1.1").getComponentEndpoint());
        CircuitPostProbeTarget componentLead2 = getProbe(sim,
            instance.getConnectionBindings().get("R1", "R1.2").getComponentEndpoint());
        sim.instrumentController.setResistanceProbesForDeveloperVerification(componentLead1,
            componentLead2);
        String reading = sim.instrumentController.getReadingForDeveloperVerification();
        if (instance.getFaultBinding().getFault().getType() == GeneratedFaultType.RESISTOR_OPEN)
            require("OL".equals(reading), "Removed failed R1 did not measure OL in tray");
        else {
            double actual = sim.instrumentController.getLatestResistanceReadingForDeveloperVerification();
            double expected = instance.getFaultBinding().getFault().getEffectiveValue();
            require(!"OL".equals(reading) && Math.abs(actual - expected) <= expected * .05,
                "Removed incorrect-value R1 did not measure its effective faulty value: " + actual);
        }
        require(modifications.restoreComponent("R1"),
            "Failed R1 did not restore after tray measurement");
        require(modifications.getComponentState("R1") == ComponentPhysicalState.INSTALLED &&
            faults.isApplied(), "Restoration cleared the internal fault");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-r1-restore");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
    }

    private static void verifyIncorrectOriginalLiftedLead(CirSim sim,
            GeneratedBoardInstance instance, BoardModificationController modifications,
            GeneratedFaultController faults) {
        require(instance.getFaultBinding().getFault().getType() ==
            GeneratedFaultType.RESISTOR_INCORRECT_VALUE,
            "Unexpected non-open fault in incorrect-value persistence path");
        require(modifications.liftLead("R1", "R1.2") && faults.isApplied(),
            "Incorrect-value R1 lead lift changed fault state");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-incorrect-r1-lift");
        sim.setBoardPowerState(BoardPowerState.POWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-incorrect-r1-powered");
        require(Math.abs(((LEDElm) instance.getComponentBindings().getSingleElement("LED1"))
            .getCurrent()) < .000001 &&
            !instance.getOperationalStates().isIlluminated("LED1"),
            "Lifted incorrect-value R1 still drove the LED");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-incorrect-r1-unpowered");
        require(modifications.reconnectLead("R1", "R1.2"),
            "Incorrect-value R1 lead did not reconnect");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-incorrect-r1-reconnect");
        sim.setBoardPowerState(BoardPowerState.POWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-incorrect-r1-repowered");
        instance.getChallengeDefinition().getBehaviorContract().verifyFaulted(instance,
            modifications, BoardPowerState.POWERED);
        require(faults.isApplied(), "Reconnecting incorrect-value R1 cleared the fault");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-incorrect-r1-final-unpowered");
    }

    private static void verifyFailedOriginalLedPersistence(CirSim sim,
            GeneratedBoardInstance instance, BoardModificationController modifications,
            GeneratedFaultController faults) {
        GeneratedComponentConnectionBinding lead = instance.getConnectionBindings()
            .get("LED1", "LED1.A");
        require(modifications.liftLead("LED1", "LED1.A") && faults.isApplied(),
            "LED_OPEN lead lift changed the internal fault");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-led-lift");
        sim.setBoardPowerState(BoardPowerState.POWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-led-powered");
        require(Math.abs(((LEDElm) instance.getComponentBindings().getSingleElement("LED1"))
                .getCurrent()) < .000001 &&
                !instance.getOperationalStates().isIlluminated("LED1"),
            "LED_OPEN lifted lead unexpectedly restored the LED");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-led-unpowered");
        require(modifications.reconnectLead("LED1", "LED1.A") && faults.isApplied(),
            "LED_OPEN lead did not reconnect with the fault applied");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-led-reconnect");
        require(modifications.removeComponent("LED1"),
            "LED_OPEN original did not remove after reconnect");
        require(modifications.getComponentState("LED1") == ComponentPhysicalState.REMOVED &&
                faults.isApplied(), "LED_OPEN removal changed the internal fault");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-led-remove");
        CircuitPostProbeTarget anode = getProbe(sim, lead.getComponentEndpoint());
        CircuitPostProbeTarget cathode = getProbe(sim,
            instance.getConnectionBindings().get("LED1", "LED1.K").getComponentEndpoint());
        sim.instrumentController.setDiodeProbesForDeveloperVerification(anode, cathode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "Removed LED_OPEN original did not measure open in the tray");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        require(modifications.restoreComponent("LED1"),
            "LED_OPEN original did not restore");
        require(modifications.getComponentState("LED1") == ComponentPhysicalState.INSTALLED &&
                faults.isApplied(), "LED_OPEN restoration cleared the internal fault");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-led-restore");
    }

    private static void verifyFailedOriginalLiftedLeadVoltage(CirSim sim,
            GeneratedBoardInstance instance, BoardModificationController modifications,
            GeneratedFaultController faults) {
        GeneratedComponentConnectionBinding lead2 = instance.getConnectionBindings().get("R1", "R1.2");
        CircuitPostProbeTarget liftedLead2 = getProbe(sim, lead2.getComponentEndpoint());
        CircuitPostProbeTarget boardPad2 = getProbe(sim, instance, "R1.2");
        CircuitPostProbeTarget ground = getProbe(sim, instance, "J1.2");
        require(modifications.getComponentState("R1") == ComponentPhysicalState.INSTALLED &&
            faults.isApplied(), "Failed original was not installed before lifted-lead voltage check");
        require(modifications.liftLead("R1", "R1.2"), "Failed original lead 2 did not lift");
        require(!sim.elmList.contains(lead2.getConnectionElement()),
            "Lifted failed-original lead 2 remained attached to its PCB pad");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-failed-r1-lift");
        sim.setBoardPowerState(BoardPowerState.POWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-failed-r1-powered");
        requireApproximately(0, sim.instrumentController.getDcVoltageDifferenceForDeveloperVerification(
            liftedLead2, ground), .01,
            "Failed original lifted public lead 2 incorrectly measured VIN");
        requireApproximately(0, sim.instrumentController.getDcVoltageDifferenceForDeveloperVerification(
            boardPad2, ground), .01, "Failed-original R1.2 board pad was not isolated");
        require(Math.abs(((LEDElm) instance.getComponentBindings().getSingleElement("LED1")).getCurrent()) < .000001 &&
            !instance.getOperationalStates().isIlluminated("LED1"),
            "Lifted failed original allowed LED current");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-failed-r1-unpowered");
        sim.instrumentController.setResistanceProbesForDeveloperVerification(
            getProbe(sim, instance.getConnectionBindings().get("R1", "R1.1").getComponentEndpoint()),
            liftedLead2);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "Lifted failed original did not remain OL across public leads");
        require(modifications.reconnectLead("R1", "R1.2"),
            "Failed original lead 2 did not reconnect");
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-failed-r1-reconnect");
        sim.setBoardPowerState(BoardPowerState.POWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-failed-r1-repowered");
        instance.getChallengeDefinition().getBehaviorContract().verifyFaulted(instance, modifications,
            BoardPowerState.POWERED);
        require(faults.isApplied(), "Reconnecting failed original lead 2 bypassed its internal fault");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
            "challenge-failed-r1-final-unpowered");
    }

    private static void verifyDeveloperClearAndReapply(CirSim sim, GeneratedBoardInstance instance,
            GeneratedFaultController faults) {
        GeneratedChallengeController challenge = sim.getGeneratedChallengeController();
        challenge.beginDeveloperVerificationScope();
        try {
            require(faults.clearForDeveloperVerification(), "Developer fault clear was ignored");
            GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
                "challenge-developer-fault-cleared");
            sim.setBoardPowerState(BoardPowerState.POWERED);
            GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
                "challenge-developer-healthy");
            instance.getBehaviorContract().verifyHealthy(instance, BoardPowerState.POWERED);
            require(instance.getOperationalStates().isIlluminated("LED1"),
                "Developer-cleared LED did not illuminate");
            if (faults.getFault().getType() == GeneratedFaultType.RESISTOR_INCORRECT_VALUE)
                require(((ResistorElm) instance.getComponentBindings().getSingleElement("R1"))
                    .getResistance() == StandardPhysicalDefinitionProviders.RESISTOR.require(
                        instance.getPhysicalSpecifications(), "R1").getNominalResistanceOhms(),
                    "Clearing incorrect resistor fault did not restore nominal resistance");
            require(!faults.clearForDeveloperVerification(), "Repeated developer clear was not idempotent");
            require(faults.apply(), "Developer fault reapply was ignored");
            require(!faults.apply(), "Repeated fault apply was not idempotent");
            if (faults.getFault().getType() == GeneratedFaultType.RESISTOR_INCORRECT_VALUE)
                require(((ResistorElm) instance.getComponentBindings().getSingleElement("R1"))
                    .getResistance() == faults.getFault().getEffectiveValue(),
                    "Reapplying incorrect resistor fault did not restore effective resistance");
            GeneratedRuntimeDeveloperSettlement.settle(sim, instance,
                "challenge-developer-fault-reapplied");
            challenge.getDefinition().getBehaviorContract().verifyFaulted(instance,
                sim.getBoardModificationController(), BoardPowerState.POWERED);
        } finally {
            challenge.endDeveloperVerificationScope();
        }
    }

    private static CircuitPostProbeTarget getProbe(CirSim sim, GeneratedBoardInstance instance,
            String padId) {
        return getProbe(sim, instance.getSimulationBindings().getEndpoint(padId));
    }

    private static CircuitPostProbeTarget getProbe(CirSim sim, CircuitMeasurementEndpoint endpoint) {
        CircuitPostMeasurementEndpoint post = (CircuitPostMeasurementEndpoint) endpoint;
        return new CircuitPostProbeTarget(sim, post.getElement(), post.getPostIndex());
    }

    private static void requireApproximately(double expected, double actual, double tolerance,
            String message) {
        require(Math.abs(expected - actual) <= tolerance, message + ": " + actual);
    }

    private static void require(boolean condition, String message) {
        if (!condition)
            throw new IllegalStateException(message);
    }
}
