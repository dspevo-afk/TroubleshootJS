package com.lushprojects.circuitjs1.client;

import java.util.Vector;

/** Actual installed five-terminal transactions, fault owners and functional retests. */
final class E03RelayMutationChecks {
    private static int assertions;
    static int verify(CirSim sim, long seed) {
        assertions=0;
        {
            CirSim.console("E03 installed relay: seed="+seed);
            Task41SimulationSnapshot protectedOwner=Task41SimulationSnapshot.capture(sim);
            try {
                final GeneratedBoardInstance owner=new RelayOutputGenerator().generate(seed);
                FreshGeneratedRuntimeInstallation.install(sim,owner,false);
                sim.getGeneratedChallengeController().beginDeveloperVerificationScope();
                settle(sim,owner);
                if(seed==0) {
                    sim.changeBenchSource(owner,"COIL_INPUT",false,.01); settle(sim,owner);
                    E01SourceDeveloperVerifier.verify(sim,false);
                    require(!owner.getExternalPowerBindings().getBinding("COIL_INPUT").isConnected() &&
                        owner.getExternalPowerBindings().getBinding("COIL_INPUT").getLimitedSupply().getLimitAmps()==.01 &&
                        sim.getBoardPowerController().getState()==BoardPowerState.POWERED,
                        "private proof restores partial isolation and current setting");
                    sim.changeBenchSource(owner,"COIL_INPUT",true,.25); settle(sim,owner);
                }
                CircuitPostMeasurementEndpoint load=(CircuitPostMeasurementEndpoint)owner.getSimulationBindings().getEndpoint("J4.1");
                CircuitPostMeasurementEndpoint controlReturn=(CircuitPostMeasurementEndpoint)owner.getSimulationBindings().getEndpoint("J1.2");
                int elementsBeforeRejectedVoltage = sim.elmList.size();
                VoltageMeasurementResult rejectedDc = sim.measureDcVoltageResult(load,controlReturn);
                VoltageMeasurementResult rejectedAc = sim.measureAcVoltage(load,controlReturn);
                require(sim.assessMeasurementReference(load,controlReturn).getDecision()==MeasurementReferencePolicy.Decision.REJECTED &&
                    rejectedDc.getStatus()==VoltageMeasurementResult.Status.REFERENCE_REJECTED &&
                    rejectedAc.getStatus()==VoltageMeasurementResult.Status.REFERENCE_REJECTED &&
                    Double.isNaN(sim.measureDcVoltage(load,controlReturn)) &&
                    !sim.activeMeasurementOverlay && sim.elmList.size()==elementsBeforeRejectedVoltage,
                    "isolated domains reject DC and AC before any DMM load can bridge them");
                sim.instrumentController.clearTargets();
                sim.instrumentController.activateScopeModeForDeveloperVerification();
                sim.instrumentController.handlePointerInput(com.google.gwt.dom.client.NativeEvent.BUTTON_LEFT,
                    new CircuitPostProbeTarget(sim, load.getElement(), load.getPostIndex()));
                sim.instrumentController.handlePointerInput(com.google.gwt.dom.client.NativeEvent.BUTTON_RIGHT,
                    new CircuitPostProbeTarget(sim, controlReturn.getElement(), controlReturn.getPostIndex()));
                require("SCOPE: REF?".equals(sim.instrumentController.getReadingForDeveloperVerification()) &&
                    sim.instrumentController.getScopeSubscriptionForDeveloperVerification()==null &&
                    sim.elmList.size()==elementsBeforeRejectedVoltage,
                    "scope preserves selected cross-reference probes as REF? without subscribing or bridging");
                sim.instrumentController.exitInstrumentModeForDeveloperVerification();
                require(!sim.getGeneratedChallengeController().performCustomerRetest().isPassed(),"unrepaired retest seed="+seed);
                String id=owner.getFaultBinding().getFault().getTargetComponentId();
                PhysicalPart<?> original=owner.getPhysicalBoardRuntime().getInstalledPart(id);
                final PhysicalSlotMutationProvider controller=owner.getPhysicalBoardRuntime().getMutationProvider(id);
                boolean refused=false;
                try {controller.removeInstalledPart();}catch(BoardModificationRejectedException expected){refused=true;}
                require(refused&&original.isInstalled(),"powered removal rejected");
                sim.setBoardPowerState(BoardPowerState.UNPOWERED); sim.advanceGeneratedTemporalProfile(.025); settle(sim,owner);
                require(RelayOutputBehavior.isDischarged(owner),"actual coil discharge before mutation");
                require(controller.removeInstalledPart(),"remove original"); settle(sim,owner);
                require(!original.isInstalled()&&original.isFaulted(),"removed original owns its fault");
                if("K1".equals(id)) {
                    final ReplaceableRelayCapability capability=(ReplaceableRelayCapability)owner.getPhysicalBoardRuntime().getCapability(ReplaceableRelayCapability.ID);
                    final int beforeElements=owner.getSimulationElements().size();
                    for(int failAt=1;failAt<=5;failAt++) {
                        final int occurrence=failAt; final int[] writes={0};
                        PhysicalMutationScope.setFailureHookForDeveloperVerification(new PhysicalMutationScope.FailureHook(){
                            public void afterStage(PhysicalMutationScope.FailureStage stage) {
                                if(stage==PhysicalMutationScope.FailureStage.AFTER_ATTACHMENT&&++writes[0]==occurrence)
                                    throw new IllegalStateException("e03-attachment-"+occurrence);
                            }
                        });
                        boolean failed=false;
                        try{controller.installNewFromCatalog(ReplaceableRelayCapability.COIL_5V);}
                        catch(IllegalStateException expected){failed=expected.getMessage().contains("e03-attachment-");}
                        finally{PhysicalMutationScope.clearFailureHookForDeveloperVerification();}
                        require(failed&&writes[0]==occurrence,"injected attachment failure observed");
                        require(capability.getMutationSlot().isEmpty()&&capability.getLooseParts().size()==1&&
                            owner.getSimulationElements().size()==beforeElements,"five-terminal rollback restores inventory/graph/mount");
                        GeneratedRuntimeInvariant.verify(sim,owner,sim.getBoardModificationController(),sim.elmList);
                        settle(sim,owner);
                    }
                    require(controller.installNewFromCatalog(ReplaceableRelayCapability.COIL_12V),"wrong relay is mechanically compatible");
                    settle(sim,owner); sim.setBoardPowerState(BoardPowerState.POWERED); settle(sim,owner);
                    require(!sim.getGeneratedChallengeController().performCustomerRetest().isPassed(),"12 V replacement fails on 5 V");
                    sim.setBoardPowerState(BoardPowerState.UNPOWERED); sim.advanceGeneratedTemporalProfile(.025); settle(sim,owner);
                    require(controller.removeInstalledPart(),"remove wrong relay"); settle(sim,owner);
                }
                require(controller.installNewFromCatalog(owner.getDiagnosticProvider().getCorrectCatalogId(owner,id)),"install specified replacement");
                settle(sim,owner);
                // Exercise healthy service while the ticket is still READY.
                // A successful customer retest deliberately latches COMPLETED
                // and rejects later power/mutation attempts. Retest comes last.
                GeneratedRuntimeInvariant.verify(sim,owner,sim.getBoardModificationController(),sim.elmList);
                // Healthy flyback protection is a real serviceable diode too.
                PhysicalBoardRuntime runtime=owner.getPhysicalBoardRuntime();
                PhysicalPart<?> flyback=runtime.getInstalledPart("D1");
                PhysicalPartProvenance provenance=flyback.getProvenance();
                PhysicalSlotMutationProvider flybackController=runtime.getMutationProvider("D1");
                require(flybackController!=null && !flyback.isFaulted(),"healthy flyback has a physical service owner");
                sim.setBoardPowerState(BoardPowerState.UNPOWERED); sim.advanceGeneratedTemporalProfile(.025); settle(sim,owner);
                require(sim.getBoardPowerController().isElectricallyUnpowered() && RelayOutputBehavior.isDischarged(owner),
                    "healthy flyback service follows real power isolation and coil discharge");
                require(flybackController.removeInstalledPart(),"remove healthy flyback after actual coil discharge"); settle(sim,owner);
                require(!flyback.isInstalled() && runtime.getInstalledPart("D1")==null &&
                    runtime.getPart(flyback.getId())==flyback && flyback.getProvenance()==provenance,
                    "removed flyback retains its exact physical identity and provenance");
                for(GeneratedComponentConnectionBinding lead:owner.getConnectionBindings().getForComponent("D1"))
                    require(!sim.elmList.contains(lead.getConnectionElement()),"removed flyback loses its real solder connections");
                require(flybackController.install(flyback.getId()),"same healthy flyback reinstalls"); settle(sim,owner);
                require(runtime.getInstalledPart("D1")==flyback,"reinstalled flyback is the original physical part");
                sim.setBoardPowerState(BoardPowerState.POWERED); settle(sim,owner);
                require(sim.getGeneratedChallengeController().performCustomerRetest().isPassed(),
                    "restored flyback preserves the repaired HIGH/LOW behavior");
                require(original.isFaulted()&&!original.isInstalled(),"successful repair does not heal tray original");
                GeneratedRuntimeInvariant.verify(sim,owner,sim.getBoardModificationController(),sim.elmList);
            } finally {
                PhysicalMutationScope.clearFailureHookForDeveloperVerification();
                protectedOwner.restore(sim); protectedOwner.assertRestored(sim);
            }
        }
        return assertions;
    }
    private static void settle(CirSim sim,GeneratedBoardInstance owner) { GeneratedRuntimeDeveloperSettlement.settle(sim,owner,"E03 relay mutation"); }
    private static void require(boolean condition,String message) { assertions++; if(!condition)throw new AssertionError("E03 mutation: "+message); }
}
