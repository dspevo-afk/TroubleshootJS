package com.lushprojects.circuitjs1.client;

import java.util.Vector;
import java.util.Collections;

class GeneratedBoardInstance {
    private final TroubleshootBoard board;
    private final Vector<CircuitElm> simulationElements;
    private final long seed;
    private final String circuitFamilyId;
    private final String topologyVariantId;
    private final String description;
    private final GeneratedComponentBindings componentBindings;
    private final GeneratedExternalPowerBindings externalPowerBindings;
    private final GeneratedComponentConnectionBindings connectionBindings;
    private final GeneratedBoardEndpointOracle developerBoardEndpointOracle;
    private final GeneratedChallengeBehaviorContract behaviorContract;
    private final PcbBoardLayout pcbLayout;
    private final PcbConductorState conductorState;
    private final BoardPhysicalSpecifications physicalSpecifications;
    private final PhysicalBoardRuntime physicalRuntime;
    private final GeneratedFaultBinding faultBinding;
    private final Vector<GeneratedFaultCandidate> faultCandidates;
    private final GeneratedComponentOperationalStates operationalStates;
    private final GeneratedChallengeDefinition challengeDefinition;
    private final GeneratedBoardFamilyState familyState;
    private final GeneratedTemporalBehavior temporalBehavior;
    private final boolean developerOnlyFaultRoute;
    private final GeneratedDiagnosticSolvabilityContract diagnosticSolvabilityContract;
    private final GeneratedDiagnosticProvider diagnosticProvider;
    private final GeneratedPhysicalAdmission physicalAdmission;

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime) {
        this(board, simulationElements, seed, circuitFamilyId, topologyVariantId, description,
            componentBindings, externalPowerBindings, connectionBindings, behaviorContract,
            pcbLayout, physicalSpecifications, faultBinding, operationalStates,
            challengeDefinition, familyState, physicalRuntime, null, false);
    }

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime, GeneratedTemporalBehavior temporalBehavior) {
        this(board, simulationElements, seed, circuitFamilyId, topologyVariantId, description,
            componentBindings, externalPowerBindings, connectionBindings, behaviorContract,
            pcbLayout, physicalSpecifications, faultBinding, operationalStates,
            challengeDefinition, familyState, physicalRuntime, temporalBehavior, false);
    }

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime, GeneratedTemporalBehavior temporalBehavior,
            boolean developerOnlyFaultRoute) {
        this(board, simulationElements, seed, circuitFamilyId, topologyVariantId, description,
            componentBindings, externalPowerBindings, connectionBindings, behaviorContract,
            pcbLayout, physicalSpecifications, faultBinding, operationalStates,
            challengeDefinition, familyState, physicalRuntime, temporalBehavior,
            developerOnlyFaultRoute, null);
    }

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime, GeneratedTemporalBehavior temporalBehavior,
            boolean developerOnlyFaultRoute, Vector<GeneratedFaultCandidate> faultCandidates) {
        this(board, simulationElements, seed, circuitFamilyId, topologyVariantId, description,
            componentBindings, externalPowerBindings, connectionBindings, behaviorContract,
            pcbLayout, physicalSpecifications, faultBinding, operationalStates,
            challengeDefinition, familyState, physicalRuntime, temporalBehavior,
            developerOnlyFaultRoute, faultCandidates, null);
    }

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime, GeneratedTemporalBehavior temporalBehavior,
            boolean developerOnlyFaultRoute, Vector<GeneratedFaultCandidate> faultCandidates,
            GeneratedDiagnosticSolvabilityContract suppliedDiagnosticSolvabilityContract) {
        this(board, simulationElements, seed, circuitFamilyId, topologyVariantId, description,
            componentBindings, externalPowerBindings, connectionBindings, behaviorContract,
            pcbLayout, physicalSpecifications, faultBinding, operationalStates,
            challengeDefinition, familyState, physicalRuntime, temporalBehavior,
            developerOnlyFaultRoute, faultCandidates, suppliedDiagnosticSolvabilityContract,
            behaviorContract instanceof GeneratedDiagnosticProvider ?
                (GeneratedDiagnosticProvider)behaviorContract : null);
    }

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime, GeneratedTemporalBehavior temporalBehavior,
            boolean developerOnlyFaultRoute, Vector<GeneratedFaultCandidate> faultCandidates,
            GeneratedDiagnosticSolvabilityContract suppliedDiagnosticSolvabilityContract,
            GeneratedDiagnosticProvider diagnosticProvider) {
        this(board, simulationElements, seed, circuitFamilyId, topologyVariantId, description,
            componentBindings, externalPowerBindings, connectionBindings, behaviorContract,
            pcbLayout, physicalSpecifications, faultBinding, operationalStates,
            challengeDefinition, familyState, physicalRuntime, temporalBehavior,
            developerOnlyFaultRoute, faultCandidates, suppliedDiagnosticSolvabilityContract,
            diagnosticProvider, null);
    }

    GeneratedBoardInstance(TroubleshootBoard board, Vector<CircuitElm> simulationElements,
            long seed, String circuitFamilyId, String topologyVariantId, String description,
            GeneratedComponentBindings componentBindings,
            GeneratedExternalPowerBindings externalPowerBindings,
            GeneratedComponentConnectionBindings connectionBindings,
            GeneratedChallengeBehaviorContract behaviorContract, PcbBoardLayout pcbLayout,
            BoardPhysicalSpecifications physicalSpecifications, GeneratedFaultBinding faultBinding,
            GeneratedComponentOperationalStates operationalStates,
            GeneratedChallengeDefinition challengeDefinition, GeneratedBoardFamilyState familyState,
            PhysicalBoardRuntime physicalRuntime, GeneratedTemporalBehavior temporalBehavior,
            boolean developerOnlyFaultRoute, Vector<GeneratedFaultCandidate> faultCandidates,
            GeneratedDiagnosticSolvabilityContract suppliedDiagnosticSolvabilityContract,
            GeneratedDiagnosticProvider diagnosticProvider,
            GeneratedPhysicalAdmission physicalAdmission) {
        if (suppliedDiagnosticSolvabilityContract != null &&
                (!developerOnlyFaultRoute ||
                 !suppliedDiagnosticSolvabilityContract.isDeveloperFixture()))
            throw new IllegalArgumentException(
                "Supplied diagnostic contract must be an explicit developer fixture");
        if (physicalAdmission == null) {
            PcbTwoLayerRules.requireDeveloperAdmission(pcbLayout,developerOnlyFaultRoute);
        } else {
            if (developerOnlyFaultRoute)
                throw new IllegalArgumentException("Normal physical admission cannot be developer-only");
            physicalAdmission.requireConstruction(board, pcbLayout);
        }
        PcbFactoryLinkPolicy.validateConstruction(board, pcbLayout, physicalSpecifications,
            componentBindings, developerOnlyFaultRoute);
        ServiceableBoardConstruction.complete(board, simulationElements, componentBindings,
            connectionBindings, physicalSpecifications, physicalRuntime);
        operationalStates.completePhysicalBindings(physicalRuntime);
        this.board = board;
        this.developerBoardEndpointOracle = board.getSimulationBindings()
            .captureGeneratedBoardEndpointOracle();
        this.simulationElements = new Vector<CircuitElm>(simulationElements);
        this.seed = seed;
        this.circuitFamilyId = circuitFamilyId;
        this.topologyVariantId = topologyVariantId;
        this.description = description;
        this.componentBindings = componentBindings;
        this.externalPowerBindings = externalPowerBindings;
        this.connectionBindings = connectionBindings;
        if (behaviorContract == null)
            throw new IllegalArgumentException("Missing generated challenge behavior contract");
        this.behaviorContract = behaviorContract;
        this.pcbLayout = pcbLayout;
        // Current gameplay has no copper-cut action. Refuse metadata-only live edits until
        // its consuming capability supplies the transactional solver projection adapter.
        this.conductorState = pcbLayout == null ? null : new PcbConductorState(
            pcbLayout.captureConductorGraph(board), null);
        if (physicalSpecifications == null)
            throw new IllegalArgumentException("Missing generated physical specifications");
        this.physicalSpecifications = physicalSpecifications;
        physicalSpecifications.seal();
        if (physicalRuntime == null)
            throw new IllegalArgumentException("Missing generated physical board runtime");
        this.physicalRuntime = physicalRuntime;
        if (pcbLayout != null)
            physicalRuntime.bindGeometryRealizations(pcbLayout);
        physicalRuntime.validate();
        physicalRuntime.finishConstruction();
        this.faultBinding = faultBinding;
        this.faultCandidates = faultCandidates == null ?
            new Vector<GeneratedFaultCandidate>() :
            new Vector<GeneratedFaultCandidate>(faultCandidates);
        this.operationalStates = operationalStates;
        this.challengeDefinition = challengeDefinition;
        this.familyState = familyState;
        this.temporalBehavior = temporalBehavior;
        this.developerOnlyFaultRoute = developerOnlyFaultRoute;
        this.diagnosticProvider = diagnosticProvider;
        this.physicalAdmission = physicalAdmission;
        this.diagnosticSolvabilityContract = suppliedDiagnosticSolvabilityContract == null ?
            GeneratedDiagnosticSolvabilityContract.forGeneratedBoard(
                circuitFamilyId, topologyVariantId, seed, this.faultCandidates,
                diagnosticProvider) :
            suppliedDiagnosticSolvabilityContract;
        connectionBindings.validateAgainst(board, this.simulationElements, componentBindings,
            externalPowerBindings, faultBinding);
        if (suppliedDiagnosticSolvabilityContract != null)
            suppliedDiagnosticSolvabilityContract.validateDeveloperFixture(this);
        if (pcbLayout != null) pcbLayout.seal();
        if (physicalAdmission != null)
            physicalAdmission.requireNormal(this);
        board.getSimulationBindings().markDeveloperVerificationReady();
    }

    GeneratedDiagnosticProvider getDiagnosticProvider() { return diagnosticProvider; }
    GeneratedPhysicalAdmission getPhysicalAdmission() { return physicalAdmission; }

    /** Uses the attached versioned seam, or the unchanged P09 envelope for legacy owners. */
    void requireNormalPhysicalAdmission() {
        if (developerOnlyFaultRoute)
            throw new IllegalArgumentException("Developer-only boards are not normal physical admission");
        if (physicalAdmission == null)
            SupportedEnvelope.current().requireNormal(this);
        else
            physicalAdmission.requireNormal(this);
    }

    TroubleshootBoard getBoard() {
        return board;
    }

    Vector<CircuitElm> getSimulationElements() {
        return new Vector<CircuitElm>(simulationElements);
    }

    void registerRuntimeSimulationElement(CircuitElm element) {
        if (element == null || simulationElements.contains(element))
            throw new IllegalArgumentException("Invalid runtime generated element");
        simulationElements.add(element);
    }

    /** Removes only the most recently appended runtime element during abort. */
    void unregisterRuntimeSimulationElement(CircuitElm element) {
        if (element == null || simulationElements.isEmpty() ||
                simulationElements.lastElement() != element)
            throw new IllegalStateException("Runtime generated element registration is not append-only");
        simulationElements.remove(simulationElements.size() - 1);
    }

    boolean ownsRuntimeSimulationElement(CircuitElm element) {
        return element != null && simulationElements.contains(element);
    }

    BoardSimulationBindings getSimulationBindings() {
        return board.getSimulationBindings();
    }

    /** Developer-only retained board endpoint truth; never a live binding lookup. */
    GeneratedBoardEndpointOracle getDeveloperBoardEndpointOracle() {
        return developerBoardEndpointOracle;
    }

    long getSeed() {
        return seed;
    }

    String getCircuitFamilyId() {
        return circuitFamilyId;
    }

    String getTopologyVariantId() {
        return topologyVariantId;
    }

    String getDescription() {
        return description;
    }

    GeneratedComponentBindings getComponentBindings() {
        return componentBindings;
    }

    GeneratedExternalPowerBindings getExternalPowerBindings() {
        return externalPowerBindings;
    }

    GeneratedComponentConnectionBindings getConnectionBindings() {
        return connectionBindings;
    }

    GeneratedChallengeBehaviorContract getBehaviorContract() {
        return behaviorContract;
    }

    BoardPhysicalSpecifications getPhysicalSpecifications() {
        return physicalSpecifications;
    }

    PhysicalBoardRuntime getPhysicalBoardRuntime() {
        return physicalRuntime;
    }

    GeneratedFaultBinding getFaultBinding() { return faultBinding; }
    Vector<GeneratedFaultCandidate> getFaultCandidates() {
        return new Vector<GeneratedFaultCandidate>(faultCandidates);
    }
    Vector<String> getAdmittedFaultPhysicalOwnerIds() {
        return GeneratedFaultServiceabilityAdmission.getPhysicalOwnerIds(faultCandidates);
    }
    int getAdmittedFaultPhysicalOwnerCount() {
        return getAdmittedFaultPhysicalOwnerIds().size();
    }
    GeneratedFaultServiceability getFaultServiceability() {
        return faultBinding == null ? null : faultBinding.getServiceability();
    }
    GeneratedFaultLocus getFaultLocus() {
        return faultBinding == null ? null : faultBinding.getFaultLocus();
    }
    Vector<String> getFaultPhysicalOwnerIds() {
        Vector<String> result = new Vector<String>();
        GeneratedFaultLocus locus = getFaultLocus();
        if (locus != null && getFaultServiceability() != null &&
                getFaultServiceability().isAdmissible())
            result.add(locus.getOwnerId());
        Collections.sort(result);
        return result;
    }
    int getFaultPhysicalOwnerCount() { return getFaultPhysicalOwnerIds().size(); }
    boolean isDeveloperOnlyFaultRoute() { return developerOnlyFaultRoute; }
    GeneratedDiagnosticSolvabilityContract getDiagnosticSolvabilityContract() {
        return diagnosticSolvabilityContract;
    }
    GeneratedComponentOperationalStates getOperationalStates() { return operationalStates; }
    GeneratedChallengeDefinition getChallengeDefinition() { return challengeDefinition; }
    GeneratedBoardFamilyState getFamilyState() { return familyState; }
    GeneratedTemporalBehavior getTemporalBehavior() { return temporalBehavior; }

    GeneratedBoardOperationCatalog getOperationCatalog() {
        return familyState.getOperationCatalog();
    }

    GeneratedCustomerRetestProfile getCustomerRetestProfile() {
        return familyState.getCustomerRetestProfile();
    }

    GeneratedCustomerRetestResult invokeOperation(String stableId, CirSim sim) {
        return getOperationCatalog().invoke(stableId, sim, this);
    }

    PcbBoardLayout getPcbLayout() {
        return pcbLayout;
    }
    PcbConductorGraph getPristineConductorGraph() {
        return conductorState == null ? null : conductorState.getPristine();
    }
    PcbConductorGraph.Snapshot getCurrentConductorSnapshot() {
        return conductorState == null ? null : conductorState.getCurrent();
    }
}
