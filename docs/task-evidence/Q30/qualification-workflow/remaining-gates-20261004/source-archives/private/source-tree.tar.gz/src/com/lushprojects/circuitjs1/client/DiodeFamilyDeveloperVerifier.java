package com.lushprojects.circuitjs1.client;

import java.util.Vector;

class DiodeFamilyDeveloperVerifier {
    static void verify(CirSim sim) {
        GeneratedBoardInstance instance = sim.getGeneratedBoardInstance();
        GeneratedChallengeController challenge = sim.getGeneratedChallengeController();
        require(instance != null && DiodeProtectedIndicatorGenerator.FAMILY_ID.equals(
            instance.getCircuitFamilyId()) && challenge != null && challenge.isReady(),
            "Diode verification requires a ready diode challenge");
        WorkbenchCapabilityDeveloperVerifier.verifyRegisteredProviders(sim);
        verifyScenario(sim, instance, challenge);
        ReplaceableDiodeBoardCapability state =
            ReplaceableDiodeBoardCapability.require(instance);
        require(instance.getBoard().getPad("D1.A") != null &&
            instance.getBoard().getPad("D1.K") != null &&
            StandardPhysicalDefinitionProviders.DIODE.find(
                instance.getPhysicalSpecifications(), "D1") != null,
            "D1 logical identity or nameplate is missing");
        require(state.getCatalog().getEntries().size() == 2,
            "Diode catalog choices changed unexpectedly");
        verifyDeterministicFaultMetadata(sim);
        PhysicalDiodePart original = state.getInventory().get("D1_ORIGINAL");
        require(original.isFaulted() && original.getLocation() == DiodePartLocation.INSTALLED,
            "Faulted original D1 is not installed");

        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settleAfterMutation(sim);
        sim.updateCircuit();
        if (isOpen(instance))
            verifyOpen(sim, boardProbe(sim, instance, "D1.A"), boardProbe(sim, instance, "D1.K"),
                "installed faulted D1");
        else
            verifyShort(sim, boardProbe(sim, instance, "D1.A"), boardProbe(sim, instance, "D1.K"),
                "installed faulted D1");
        require(sim.getDiodeSlotController().removeInstalledPart(), "Could not remove original D1");
        settleAfterMutation(sim);
        verifyTopology(sim, instance);
        if (isOpen(instance))
            verifyOpen(sim, looseProbe(sim, instance, original, 0),
                looseProbe(sim, instance, original, 1), "loose faulted original D1");
        else
            verifyShort(sim, looseProbe(sim, instance, original, 0),
                looseProbe(sim, instance, original, 1), "loose faulted original D1");

        DiodeCatalogEntry reversedCatalog = state.getCatalog().get(DiodeReplacementCatalog.REVERSED);
        require(sim.getDiodeSlotController().installNewFromCatalog(reversedCatalog.getId()),
            "Could not install reversed diode");
        settleAfterMutation(sim);
        PhysicalDiodePart reversed = state.getSlot().getInstalledPart();
        verifyCatalogAcquisition(reversed, reversedCatalog);
        require(reversed.isReversedInstallation(), "Reversed catalog diode lost orientation");
        verifyReversedInstalledComponentTargets(sim, instance);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        require(Math.abs(current(instance, "D1")) < .000001 &&
            !instance.getOperationalStates().isIlluminated("LED1") && !challenge.isCompleted() &&
            !challenge.getDefinition().getBehaviorContract().isFunctionallyRepaired(instance,
                sim.getBoardModificationController(), BoardPowerState.POWERED, false),
            "Reversed diode conducted or completed the challenge");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settleAfterMutation(sim);
        require(sim.getDiodeSlotController().removeInstalledPart(), "Could not remove reversed diode");
        settleAfterMutation(sim);
        settleAfterMutation(sim);
        verifyHealthy(sim, instance, reversed);

        DiodeCatalogEntry correctCatalog = state.getCatalog().get(DiodeReplacementCatalog.CORRECT);
        require(sim.getDiodeSlotController().installNewFromCatalog(correctCatalog.getId()),
            "Could not install healthy diode");
        settleAfterMutation(sim);
        PhysicalDiodePart healthy = state.getSlot().getInstalledPart();
        verifyCatalogAcquisition(healthy, correctCatalog);
        require(healthy != original && healthy != reversed &&
            !healthy.getId().equals(original.getId()) && !healthy.getId().equals(reversed.getId()),
            "Repeated diode acquisition did not create distinct physical parts");
        verifyLiftedHealthy(sim, instance, healthy);
        require(sim.getDiodeSlotController().removeInstalledPart(),
            "Could not isolate healthy diode for meter test");
        settleAfterMutation(sim);
        settleAfterMutation(sim);
        verifyHealthy(sim, instance, healthy);
        if (isOpen(instance))
            verifyOpen(sim, looseProbe(sim, instance, original, 0),
                looseProbe(sim, instance, original, 1), "original after healthy acquisition");
        else
            verifyShort(sim, looseProbe(sim, instance, original, 0),
                looseProbe(sim, instance, original, 1), "original after healthy acquisition");
        require(sim.getDiodeSlotController().install(healthy.getId()),
            "Could not reinstall measured healthy diode");
        settleAfterMutation(sim);
        verifyCatalogAcquisition(healthy, correctCatalog);
        require(sim.getDiodeSlotController().removeInstalledPart(),
            "Could not remove healthy diode before repeated catalog acquisition");
        settleAfterMutation(sim);
        require(sim.getDiodeSlotController().installNewFromCatalog(correctCatalog.getId()),
            "Could not acquire the healthy diode catalog entry twice");
        settleAfterMutation(sim);
        PhysicalDiodePart secondHealthy = state.getSlot().getInstalledPart();
        verifyCatalogAcquisition(secondHealthy, correctCatalog);
        PhysicalCatalogAcquisitionDeveloperVerifier.verifySameSpecification(healthy, secondHealthy);
        require(sim.getDiodeSlotController().removeInstalledPart(),
            "Could not remove second healthy diode acquisition");
        settleAfterMutation(sim);
        settleAfterMutation(sim);
        verifyHealthy(sim, instance, secondHealthy);
        require(sim.getDiodeSlotController().install(secondHealthy.getId()),
            "Could not reinstall second healthy diode acquisition");
        settleAfterMutation(sim);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        double diodeCurrent = Math.abs(current(instance, "D1"));
        double resistorCurrent = Math.abs(current(instance, "R1"));
        double ledCurrent = Math.abs(current(instance, "LED1"));
        require(diodeCurrent >= .005 && diodeCurrent <= .015 &&
            Math.abs(diodeCurrent - resistorCurrent) <= .0001 &&
            Math.abs(diodeCurrent - ledCurrent) <= .0001 &&
            instance.getOperationalStates().isIlluminated("LED1") &&
            challenge.getDefinition().getBehaviorContract().isFunctionallyRepaired(instance,
                sim.getBoardModificationController(), BoardPowerState.POWERED, false),
            "Healthy diode did not produce solver-backed functional repair");
        require(challenge.performCustomerRetest().isPassed(),
            "Healthy diode did not pass the public customer retest");
        sim.verifyGeneratedBoard();
        require(challenge.isCompleted(),
            "Healthy diode did not complete after the customer retest");
        require(original.getLocation() == DiodePartLocation.LOOSE && original.isFaulted() &&
            reversed.getLocation() == DiodePartLocation.LOOSE &&
            healthy.getLocation() == DiodePartLocation.LOOSE,
            "Repair changed loose diode identities or original fault");
        verifyTopology(sim, instance);
        sim.setCircuitTitle("Diode family verification passed");
    }

    private static void verifyLiftedHealthy(CirSim sim, GeneratedBoardInstance instance,
            PhysicalDiodePart part) {
        require("default".equals(part.getElement().modelName),
            "Healthy replacement does not use the declared default silicon model");
        require(sim.getBoardModificationController().liftLead("D1", "D1.K"),
            "Could not lift healthy D1 cathode");
        settleAfterMutation(sim);
        settleAfterMutation(sim);
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        ProbeTarget anode = boardProbe(sim, instance, "D1.A");
        ProbeTarget cathode = new ComponentLeadProbeTarget(sim, instance, "D1", "D1.K", renderer);
        requireDiodeMeasurementReady(sim, anode, cathode, "Lifted healthy D1 forward");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(anode, cathode);
        double voltage = sim.instrumentController.getLatestDiodeVoltageForDeveloperVerification();
        require(voltage >= .45 && voltage <= .95,
            "Lifted healthy D1 did not retain its forward diode response: " + voltage);
        requireDiodeMeasurementReady(sim, cathode, anode, "Lifted healthy D1 reverse");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "Lifted healthy D1 reverse response was not OL");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        settleAfterMutation(sim);
        require(sim.getBoardModificationController().reconnectLead("D1", "D1.K"),
            "Could not reconnect healthy D1 cathode");
        settleAfterMutation(sim);
    }

    private static void verifyReversedInstalledComponentTargets(CirSim sim,
            GeneratedBoardInstance instance) {
        require(sim.getBoardModificationController().liftLead("D1", "D1.A"),
            "Could not lift reversed D1 anode lead");
        settleAfterMutation(sim);
        require(sim.getBoardModificationController().liftLead("D1", "D1.K"),
            "Could not lift reversed D1 cathode lead");
        settleAfterMutation(sim);
        settleAfterMutation(sim);
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        ProbeTarget boardAnode = new ComponentLeadProbeTarget(sim, instance, "D1", "D1.A",
            renderer);
        ProbeTarget boardCathode = new ComponentLeadProbeTarget(sim, instance, "D1", "D1.K",
            renderer);
        require(boardAnode.isValid() && boardCathode.isValid(),
            "Reversed D1 installed component-side targets were not valid");
        verifyHealthy(sim, boardCathode, boardAnode,
            "reversed installed component-side D1");
        require(sim.getBoardModificationController().reconnectLead("D1", "D1.A"),
            "Could not reconnect reversed D1 anode lead");
        settleAfterMutation(sim);
        require(sim.getBoardModificationController().reconnectLead("D1", "D1.K"),
            "Could not reconnect reversed D1 cathode lead");
        settleAfterMutation(sim);
    }

    private static void verifyHealthy(CirSim sim, GeneratedBoardInstance instance,
            PhysicalDiodePart part) {
        verifyHealthy(sim, looseProbe(sim, instance, part, 0),
            looseProbe(sim, instance, part, 1), "Healthy loose diode");
    }

    private static void verifyHealthy(CirSim sim, ProbeTarget anode, ProbeTarget cathode,
            String label) {
        requireDiodeMeasurementReady(sim, anode, cathode, label + " forward");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(anode, cathode);
        double voltage = sim.instrumentController.getLatestDiodeVoltageForDeveloperVerification();
        double current = sim.instrumentController.getLatestDiodeCurrentForDeveloperVerification();
        require(!"OL".equals(sim.instrumentController.getReadingForDeveloperVerification()) &&
            voltage >= .45 && voltage <= .95 && current >= InstrumentController.DIODE_MINIMUM_CURRENT,
            label + " forward test was not solver-backed: " + voltage + " V, " + current + " A");
        requireDiodeMeasurementReady(sim, cathode, anode, label + " reverse");
        sim.instrumentController.setDiodeProbesForDeveloperVerification(cathode, anode);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            label + " reverse test was not OL");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        settleAfterMutation(sim);
    }

    private static void requireDiodeMeasurementReady(CirSim sim, ProbeTarget red,
            ProbeTarget black, String label) {
        require(red != null && black != null && red.isValid() && black.isValid(),
            label + " diode targets were not valid before measurement");
        CircuitMeasurementEndpoint redEndpoint = red.getMeasurementEndpoint();
        CircuitMeasurementEndpoint blackEndpoint = black.getMeasurementEndpoint();
        require(redEndpoint instanceof CircuitPostMeasurementEndpoint &&
            blackEndpoint instanceof CircuitPostMeasurementEndpoint,
            label + " diode targets did not expose CircuitJS posts");
        require(sim.getActiveMeasurementReadiness((CircuitPostMeasurementEndpoint) redEndpoint,
            (CircuitPostMeasurementEndpoint) blackEndpoint) == ActiveMeasurementReadiness.READY,
            label + " diode measurement was not ready");
    }

    private static void verifyCatalogAcquisition(PhysicalDiodePart part,
            DiodeCatalogEntry entry) {
        PhysicalCatalogAcquisitionDeveloperVerifier.verify(part, entry, "D1");
        require(part.getNameplate() == entry.getSpecification() &&
                "default".equals(part.getNameplate().getModelName()),
            "Diode acquisition discarded selected technical specification identity");
    }

    private static void verifyOpen(CirSim sim, ProbeTarget first, ProbeTarget second, String label) {
        sim.instrumentController.setDiodeProbesForDeveloperVerification(first, second);
        String forward = sim.instrumentController.getReadingForDeveloperVerification();
        sim.instrumentController.setDiodeProbesForDeveloperVerification(second, first);
        String reverse = sim.instrumentController.getReadingForDeveloperVerification();
        require("OL".equals(forward) && "OL".equals(reverse), label + " was not OL both ways: " + forward + " / " + reverse);
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        settleAfterMutation(sim);
    }

    private static void verifyShort(CirSim sim, ProbeTarget first, ProbeTarget second, String label) {
        sim.instrumentController.setDiodeProbesForDeveloperVerification(first, second);
        String forward = sim.instrumentController.getReadingForDeveloperVerification();
        double forwardVoltage = sim.instrumentController.getLatestDiodeVoltageForDeveloperVerification();
        sim.instrumentController.setDiodeProbesForDeveloperVerification(second, first);
        String reverse = sim.instrumentController.getReadingForDeveloperVerification();
        double reverseVoltage = sim.instrumentController.getLatestDiodeVoltageForDeveloperVerification();
        require(!"OL".equals(forward) && !"OL".equals(reverse) &&
            forwardVoltage <= .05 && reverseVoltage <= .05,
            label + " was not a solver-backed short in both directions: " + forward + " / " + reverse +
                "; " + forwardVoltage + " V / " + reverseVoltage + " V");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        settleAfterMutation(sim);
    }

    private static boolean isOpen(GeneratedBoardInstance instance) {
        return instance.getFaultBinding().getFault().getType() == GeneratedFaultType.DIODE_OPEN;
    }

    private static void verifyDeterministicFaultMetadata(CirSim sim) {
        verifyFaultSeed(0, GeneratedFaultType.DIODE_OPEN, "DIODE_D1_OPEN", false);
        verifyFaultSeed(2, GeneratedFaultType.DIODE_OPEN, "DIODE_D1_OPEN", false);
        verifyFaultSeed(3, GeneratedFaultType.DIODE_OPEN, "DIODE_D1_OPEN", false);
        verifyFaultSeed(0, GeneratedFaultType.DIODE_SHORT, "DIODE_D1_SHORT", true);
        verifyFaultSeed(2, GeneratedFaultType.DIODE_SHORT, "DIODE_D1_SHORT", true);
        verifyFaultSeed(3, GeneratedFaultType.DIODE_SHORT, "DIODE_D1_SHORT", true);
        require(new DiodeProtectedIndicatorGenerator().generate(0).getChallengeDefinition().getFault()
            .getType() == GeneratedFaultType.DIODE_OPEN &&
            new DiodeProtectedIndicatorGenerator().generateForDeveloperVerification(0)
                .getChallengeDefinition().getFault().getType() == GeneratedFaultType.DIODE_SHORT,
            "Diode short was not isolated to the explicit developer route");
        require(sim.troubleshootDiodeShort ==
            (sim.getGeneratedBoardInstance().getFaultBinding().getFault().getType() ==
                GeneratedFaultType.DIODE_SHORT),
            "Diode short route selection disagrees with the selected fault");
    }

    private static void verifyFaultSeed(long seed, GeneratedFaultType type, String id,
            boolean developerShort) {
        GeneratedBoardInstance board = developerShort ?
            new DiodeProtectedIndicatorGenerator().generateForDeveloperVerification(seed) :
            new DiodeProtectedIndicatorGenerator().generate(seed);
        GeneratedChallengeDefinition definition = board.getChallengeDefinition();
        require(type == definition.getFault().getType() && id.equals(definition.getFault().getId()) &&
            definition.getFault().getSelectionSeed() == seed,
            "Unexpected deterministic diode fault metadata for seed " + seed);
        GeneratedChallengeDefinition repeat = (developerShort ?
            new DiodeProtectedIndicatorGenerator().generateForDeveloperVerification(seed) :
            new DiodeProtectedIndicatorGenerator().generate(seed)).getChallengeDefinition();
        require(type == repeat.getFault().getType() && id.equals(repeat.getFault().getId()),
            "Diode fault selection was not reproducible for seed " + seed);
    }

    private static void verifyScenario(CirSim sim, GeneratedBoardInstance instance,
            GeneratedChallengeController challenge) {
        GeneratedScenario<GeneratedObservedBehavior> scenario = challenge.getScenario();
        boolean shortRoute = instance.getFaultBinding().getFault().getType() ==
            GeneratedFaultType.DIODE_SHORT;
        require(scenario != null && scenario.getObservedBehavior() == (shortRoute ?
            GeneratedObservedBehavior.DIODE_SHORT_HIGH_CURRENT : GeneratedObservedBehavior.DARK_INDICATOR) &&
            scenario.isCompatible(instance, null, BoardPowerState.POWERED),
            "Diode complaint does not match the solved behavior");
        if (shortRoute)
            require("The indicator is brighter than expected.".equals(scenario.getComplaintText()) &&
                !scenario.getComplaintText().contains("does not light"),
                "Diode short exposed the dark-indicator complaint");
        else
            require("Indicator does not light.".equals(scenario.getComplaintText()),
                "Diode open did not expose the dark-indicator complaint");
        GeneratedScenario<GeneratedObservedBehavior> repeat =
            GeneratedScenarioLibrary.diodeIndicator(sim.troubleshootDiodeShort).select(
                instance.getSeed(), instance, null, BoardPowerState.POWERED);
        require(scenario.getScenarioId().equals(repeat.getScenarioId()) &&
            scenario.getComplaintText().equals(repeat.getComplaintText()),
            "Diode scenario selection was not reproducible");
    }

    private static ProbeTarget looseProbe(CirSim sim, GeneratedBoardInstance instance,
            PhysicalDiodePart part, int terminal) {
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        selectLoosePartPage(instance, part.getId(), renderer);
        return new PhysicalDiodePartProbeTarget(sim, instance, part.getId(), terminal, renderer);
    }

    private static void selectLoosePartPage(GeneratedBoardInstance instance, String partId,
            PcbWorkbenchRenderer renderer) {
        int index = 0;
        for (WorkbenchPartsProvider provider : instance.getPhysicalBoardRuntime()
                .getWorkbenchPartsProviders())
            for (PhysicalPart<?> part : provider.getLooseParts()) {
                if (partId.equals(part.getId())) {
                    renderer.setTrayPage(index / renderer.getPartsPerTrayPage());
                    return;
                }
                index++;
            }
        throw new IllegalStateException("Requested loose diode part was not in the workbench: " +
            partId);
    }

    private static ProbeTarget boardProbe(CirSim sim, GeneratedBoardInstance instance, String padId) {
        CircuitPostMeasurementEndpoint endpoint = (CircuitPostMeasurementEndpoint)
            instance.getSimulationBindings().getEndpoint(padId);
        return new CircuitPostProbeTarget(sim, endpoint.getElement(), endpoint.getPostIndex());
    }

    private static double current(GeneratedBoardInstance instance, String componentId) {
        return instance.getComponentBindings().getSingleElement(componentId).getCurrent();
    }

    private static void verifyTopology(CirSim sim, GeneratedBoardInstance instance) {
        ReplaceableDiodeBoardCapability state =
            ReplaceableDiodeBoardCapability.require(instance);
        int installed = 0;
        for (PhysicalDiodePart part : state.getInventory().getAll()) {
            if (part.getLocation() == DiodePartLocation.INSTALLED)
                installed++;
            for (CircuitElm element : part.getElectricalBacking().getCircuitElements())
                require(count(sim.elmList, element) == 1,
                    "Diode backing missing or duplicated: " + part.getId());
        }
        require((state.getSlot().isEmpty() && installed == 0) ||
            (!state.getSlot().isEmpty() && installed == 1),
            "Diode slot and physical locations disagree");
    }

    private static int count(Vector<CircuitElm> elements, CircuitElm target) {
        int count = 0;
        for (CircuitElm element : elements)
            if (element == target)
                count++;
        return count;
    }

    private static void settle(CirSim sim) {
        // Follow the same readiness boundary as a player's next input. Merely
        // solving a matrix does not clear pending verification or publish readiness.
        sim.setSimRunning(true);
        for (int attempt = 0; attempt < 20; attempt++) {
            sim.updateCircuit();
            if (sim.isGeneratedRuntimeSettled()) return;
        }
        throw new IllegalStateException("Diode lifecycle did not settle through the production update path");
    }

    private static void settleAfterMutation(CirSim sim) { settle(sim); }

    private static void require(boolean condition, String message) {
        if (!condition)
            throw new IllegalStateException(message);
    }
}
