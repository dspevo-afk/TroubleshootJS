package com.lushprojects.circuitjs1.client;

import com.google.gwt.dom.client.NativeEvent;

class MeterLifecycleDeveloperVerifier {
    static void verify(CirSim sim) {
        GeneratedBoardInstance instance = sim.getGeneratedBoardInstance();
        require(instance != null && sim.getGeneratedChallengeController() != null &&
            sim.getGeneratedChallengeController().isReady(), "Meter verification requires ready challenge");
        installCorrectReplacement(sim, instance);
        verifyStableLedDc(sim);
        verifyLiftedLeadResistance(sim, instance, "R1.2");
        verifyLiftedLeadResistance(sim, instance, "R1.1");
        verifyRetainedLiftedLeadVoltage(sim, instance);
        verifyHighSourceImpedanceDmmBurden(sim, instance);
        verifyPhysicalTargetInvalidation(sim, instance);
        sim.setCircuitTitle("Meter lifecycle verification passed");
    }

    private static void installCorrectReplacement(CirSim sim, GeneratedBoardInstance instance) {
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        ResistorSlotController slots = sim.getResistorSlotController();
        if (!resistorSlot(instance).isEmpty()) {
            require(slots.removeInstalledPart(), "Could not remove original R1");
            settle(sim);
        }
        require(slots.installNewFromCatalog(catalogId(instance)), "Could not install correct R1 replacement");
        settle(sim);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        require(instance.getOperationalStates().isIlluminated("LED1"),
            "Correct replacement did not illuminate LED before meter tests");
    }

    private static void verifyLiftedLeadResistance(CirSim sim, GeneratedBoardInstance instance,
            String liftedPadId) {
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        String attachedPadId = "R1.1".equals(liftedPadId) ? "R1.2" : "R1.1";
        double expected = resistorSlot(instance).getInstalledPart().getNameplate()
            .getNominalResistanceOhms();
        double tolerance = expected * resistorSlot(instance).getInstalledPart().getNameplate()
            .getTolerancePercent() / 100.0;
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        ProbeTarget installedFirst = hitPad(sim, renderer, "R1.1");
        ProbeTarget installedSecond = hitPad(sim, renderer, "R1.2");
        sim.instrumentController.activateResistanceModeForDeveloperVerification();
        placeProbes(sim, installedFirst, installedSecond);
        require(!"OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "Installed healthy R1 unexpectedly measured OL");
        require(sim.getBoardModificationController().liftLead("R1", liftedPadId),
            "Could not lift " + liftedPadId);
        settle(sim);
        ProbeTarget liftedComponentLead = hitLead(sim, renderer, liftedPadId);
        ProbeTarget boardLiftedPad = hitPad(sim, renderer, liftedPadId);
        ProbeTarget boardAttachedPad = hitPad(sim, renderer, attachedPadId);
        require(!liftedComponentLead.isSameTarget(boardLiftedPad) &&
            !liftedComponentLead.isSameTarget(boardAttachedPad) &&
            !boardLiftedPad.isSameTarget(boardAttachedPad),
            "Lifted component lead and PCB pad were not distinct physical targets");
        // The attached terminal is intentionally represented by its board pad.
        // Measuring the resistor through that pad keeps the physical connection
        // assertion while respecting connected-lead surface suppression.
        placeProbes(sim, liftedComponentLead, boardAttachedPad);
		requireLiftedResistance(sim, instance, liftedComponentLead, boardAttachedPad, expected, tolerance,
		    "forward " + liftedPadId + " through attached board pad");
        placeProbes(sim, boardAttachedPad, liftedComponentLead);
		requireLiftedResistance(sim, instance, boardAttachedPad, liftedComponentLead, expected, tolerance,
		    "reverse " + liftedPadId + " through attached board pad");
        placeProbes(sim, liftedComponentLead, boardLiftedPad);
        require("OL".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "Lifted lead gap did not measure OL");
        require(sim.getBoardModificationController().reconnectLead("R1", liftedPadId),
            "Could not reconnect " + liftedPadId);
        settle(sim);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        require(instance.getOperationalStates().isIlluminated("LED1"),
            "Reconnecting " + liftedPadId + " did not restore LED operation");
        require(sim.isActiveMeasurementSolverRestoredForDeveloperVerification(),
            "Resistance overlay did not restore after lifting " + liftedPadId);
    }

    private static void verifyRetainedLiftedLeadVoltage(CirSim sim, GeneratedBoardInstance instance) {
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        double resistance = resistorSlot(instance).getInstalledPart().getNameplate()
            .getNominalResistanceOhms();
        double vin = instance.getPhysicalSpecifications().getPowerInputNameplate("VIN_INPUT")
            .getNominalVoltage();
        double expected = vin * DcVoltageMeasurementStimulus.INPUT_RESISTANCE /
            (DcVoltageMeasurementStimulus.INPUT_RESISTANCE + resistance);
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(sim.getBoardModificationController().liftLead("R1", "R1.2"),
            "Could not lift downstream R1 lead for DC test");
        settle(sim);
        ProbeTarget liftedLead = hitLead(sim, renderer, "R1.2");
        ProbeTarget ground = hitPad(sim, renderer, "J1.2");
        ProbeTarget boardPad = hitPad(sim, renderer, "R1.2");
        sim.instrumentController.activateDcVoltageModeForDeveloperVerification();
        int beforePlacement = sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification();
        placeProbes(sim, liftedLead, ground);
        require(beforePlacement + 2 == sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification(),
            "DC probe placement did not consume exactly one refresh per changed probe");
        int beforePowerOn = sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification();
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        require(beforePowerOn + 1 == sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification(),
            "DC power-on refresh was not consumed exactly once");
        requireDisplayVoltage(sim, expected, .02, "Retained lifted-lead DC reading");
        requireApproximately(0, measureDisplayedDc(sim, boardPad, ground), .02,
            "Separate lifted R1.2 PCB pad did not remain near ground");
		placeProbes(sim, liftedLead, ground);
		requireDisplayVoltage(sim, expected, .02,
		    "Restored retained lifted-lead DC reading after PCB-pad comparison");
        require(Math.abs(getLedCurrent(instance)) < .000001 &&
            !instance.getOperationalStates().isIlluminated("LED1"),
            "Lifted downstream R1 lead allowed LED current");
        int afterMeasurement = sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification();
        sim.updateCircuit();
        sim.updateCircuit();
        require(afterMeasurement == sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification(),
            "Canvas repaint caused recurring DC transactions");
        int beforePowerOff = sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification();
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(beforePowerOff + 1 == sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification(),
            "DC power-off refresh was not consumed exactly once");
        requireDisplayVoltage(sim, 0, .001, "Retained lifted-lead DC power-off reading");
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        requireDisplayVoltage(sim, expected, .02, "Retained lifted-lead DC repower reading");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(sim.getBoardModificationController().reconnectLead("R1", "R1.2"),
            "Could not reconnect downstream R1 lead after DC test");
        settle(sim);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        require(instance.getOperationalStates().isIlluminated("LED1"),
            "Reconnecting downstream R1 lead did not restore LED");
    }

    /**
     * Uses an installed 10 Mohm source resistance and a lifted physical lead
     * so the player-facing voltage read must solve a real 10 Mohm/10 Mohm
     * divider.  The unloaded lead is intentionally near VIN; accepting that
     * value would expose an ideal-voltmeter bypass.
     */
    private static void verifyHighSourceImpedanceDmmBurden(CirSim sim,
            GeneratedBoardInstance instance) {
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        ResistorSlotController slots = sim.getResistorSlotController();
        double vin = instance.getPhysicalSpecifications().getPowerInputNameplate("VIN_INPUT")
            .getNominalVoltage();
        double expectedVoltage = vin * DcVoltageMeasurementStimulus.INPUT_RESISTANCE /
            (10000000 + DcVoltageMeasurementStimulus.INPUT_RESISTANCE);
        double expectedCurrent = vin / (10000000 + DcVoltageMeasurementStimulus.INPUT_RESISTANCE);

        sim.instrumentController.clearTargets();
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(slots.removeInstalledPart(), "Could not remove correct R1 for DMM burden proof");
        settle(sim);
        require(slots.installNewFromCatalog("R_CATALOG_10000000"),
            "Could not install 10 Mohm source resistance for DMM burden proof");
        settle(sim);
        require(sim.getBoardModificationController().liftLead("R1", "R1.2"),
            "Could not lift high-impedance R1 lead for DMM burden proof");
        settle(sim);
        ProbeTarget liftedLead = hitLead(sim, renderer, "R1.2");
        ProbeTarget ground = hitPad(sim, renderer, "J1.2");
        CircuitPostMeasurementEndpoint leadEndpoint = endpoint(liftedLead);
        CircuitPostMeasurementEndpoint groundEndpoint = endpoint(ground);

        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        double unloadedVoltage = leadEndpoint.getElement().getPostVoltage(
            leadEndpoint.getPostIndex()) - groundEndpoint.getElement().getPostVoltage(
            groundEndpoint.getPostIndex());
        requireFinite(unloadedVoltage, "High-impedance unloaded lead was not solver-readable");
        require(unloadedVoltage > expectedVoltage + vin * .20,
            "High-impedance fixture did not distinguish unloaded voltage from DMM load: " +
            unloadedVoltage + " vs " + expectedVoltage);

        int elementsBefore = sim.elmList.size();
        sim.instrumentController.activateDcVoltageModeForDeveloperVerification();
        placeProbes(sim, liftedLead, ground);
        double displayedDc = sim.instrumentController.getLatestDcVoltageForDeveloperVerification();
        requireApproximately(expectedVoltage, displayedDc, .02,
            "Player DC reading did not equal the loaded 10 Mohm divider solution");
        require(Math.abs(displayedDc - unloadedVoltage) > vin * .20,
            "Player DC reading bypassed the finite DMM burden");
        requireApproximately(expectedCurrent,
            Math.abs(sim.getLastVoltageMeasurementBurdenCurrentForDeveloperVerification()), 1e-9,
            "DC DMM burden current did not equal the solved divider current");
        require(!sim.activeMeasurementOverlay && sim.elmList.size() == elementsBefore &&
            sim.isActiveMeasurementSolverRestoredForDeveloperVerification(),
            "DC DMM burden proof left a temporary element or solver overlay");

        /* AC mode sees a DC input as 0 RMS, but it must still connect the
         * same finite input resistor during its solver-time capture. */
        sim.instrumentController.clearTargets();
        sim.instrumentController.activateAcVoltageModeForDeveloperVerification();
        placeProbes(sim, liftedLead, ground);
        requireApproximately(0, sim.instrumentController.getLatestAcVoltageForDeveloperVerification(),
            .001, "Player AC reading did not retain the explicit AC-coupled DC convention");
        requireApproximately(expectedCurrent,
            Math.abs(sim.getLastVoltageMeasurementBurdenCurrentForDeveloperVerification()), 1e-9,
            "AC DMM burden current did not equal the solved divider current");
        require(!sim.activeMeasurementOverlay && sim.elmList.size() == elementsBefore &&
            sim.isActiveMeasurementSolverRestoredForDeveloperVerification(),
            "AC DMM burden proof left a temporary element or solver overlay");

        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(sim.getBoardModificationController().reconnectLead("R1", "R1.2"),
            "Could not reconnect high-impedance R1 after DMM burden proof");
        settle(sim);
        require(slots.removeInstalledPart(), "Could not remove high-impedance R1 after DMM burden proof");
        settle(sim);
        require(slots.installNewFromCatalog(catalogId(instance)),
            "Could not restore correct R1 after DMM burden proof");
        settle(sim);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
        require(instance.getOperationalStates().isIlluminated("LED1"),
            "Restoring correct R1 after DMM burden proof did not restore LED");
    }

    private static void verifyPhysicalTargetInvalidation(CirSim sim, GeneratedBoardInstance instance) {
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(sim.getBoardModificationController().liftLead("R1", "R1.2"),
            "Could not lift R1 before target identity test");
        settle(sim);
        ProbeTarget previousPartLead = hitLead(sim, renderer, "R1.2");
        require(previousPartLead.isValid(), "Lifted lead target was not valid for selected part");
        require(sim.getBoardModificationController().reconnectLead("R1", "R1.2"),
            "Could not reconnect R1 during target identity test");
        settle(sim);
        require(!previousPartLead.isValid(), "Reconnected internal lead remained exposed as a probe target");
        require(sim.getResistorSlotController().removeInstalledPart(),
            "Could not remove selected physical resistor");
        settle(sim);
        require(!previousPartLead.isValid(), "Removed physical part retained an installed-lead probe target");
        require(sim.getResistorSlotController().installNewFromCatalog(catalogId(instance)),
            "Could not install alternate physical resistor");
        settle(sim);
        require(sim.getBoardModificationController().liftLead("R1", "R1.2"),
            "Could not lift alternate physical resistor");
        settle(sim);
        ProbeTarget replacementLead = hitLead(sim, renderer, "R1.2");
        require(!previousPartLead.isSameTarget(replacementLead) && previousPartLead != replacementLead,
            "Probe identity followed the R1 slot to another physical resistor");
        sim.instrumentController.activateDcVoltageModeForDeveloperVerification();
        placeProbes(sim, previousPartLead, replacementLead);
        require("--- V".equals(sim.instrumentController.getReadingForDeveloperVerification()),
            "Invalid physical probe was not cleared before another DC measurement");
        sim.setBoardPowerState(BoardPowerState.UNPOWERED);
        settle(sim);
        require(sim.getResistorSlotController().removeInstalledPart(),
            "Could not remove alternate physical resistor");
        settle(sim);
        require(sim.getResistorSlotController().installNewFromCatalog(catalogId(instance)),
            "Could not reinstall correct physical resistor");
        settle(sim);
        sim.setBoardPowerState(BoardPowerState.POWERED);
        settle(sim);
    }

    private static double measureDisplayedDc(CirSim sim, ProbeTarget red, ProbeTarget black) {
        sim.instrumentController.activateDcVoltageModeForDeveloperVerification();
        placeProbes(sim, red, black);
        return sim.instrumentController.getLatestDcVoltageForDeveloperVerification();
    }

    private static CircuitPostMeasurementEndpoint endpoint(ProbeTarget target) {
        CircuitMeasurementEndpoint result = target == null ? null : target.getMeasurementEndpoint();
        require(result instanceof CircuitPostMeasurementEndpoint,
            "Physical DMM burden target did not resolve to a CircuitJS post");
        return (CircuitPostMeasurementEndpoint) result;
    }

    private static void placeProbes(CirSim sim, ProbeTarget red, ProbeTarget black) {
        sim.instrumentController.handlePointerInput(NativeEvent.BUTTON_LEFT, red);
        sim.instrumentController.handlePointerInput(NativeEvent.BUTTON_RIGHT, black);
    }

    private static ProbeTarget hitPad(CirSim sim, PcbWorkbenchRenderer renderer, String padId) {
        Point point = renderer.getPadPoint(padId);
        ProbeTarget target = sim.pcbWorkbenchController.findProbeTarget(point.x, point.y);
        require(target instanceof BoardPadProbeTarget, "PCB pad hit did not resolve: " + padId);
        return target;
    }

    private static ProbeTarget hitLead(CirSim sim, PcbWorkbenchRenderer renderer, String padId) {
        Point point = renderer.getComponentLeadPoint("R1", padId);
        ProbeTarget target = sim.pcbWorkbenchController.findProbeTarget(point.x, point.y);
        require(target instanceof ComponentLeadProbeTarget, "PCB lead hit did not resolve: " + padId);
        return target;
    }

    private static void requireDisplayVoltage(CirSim sim, double expected, double tolerance,
            String message) {
        requireApproximately(expected, sim.instrumentController.getLatestDcVoltageForDeveloperVerification(),
            tolerance, message);
        String reading = sim.instrumentController.getReadingForDeveloperVerification();
        require(!"--- V".equals(reading) && reading.endsWith("V"),
            message + " did not update the visible DC reading: " + reading);
        require(sim.isActiveMeasurementSolverRestoredForDeveloperVerification(),
            message + " left temporary meter elements in the solver");
    }

    private static void requireLiftedResistance(CirSim sim, GeneratedBoardInstance instance,
            ProbeTarget red, ProbeTarget black, double expected, double tolerance, String phase) {
        double actual = sim.instrumentController.getLatestResistanceReadingForDeveloperVerification();
        if (Double.isNaN(actual) || Math.abs(expected - actual) > tolerance)
            throw new IllegalStateException("Lifted resistance " + phase + " expected=" + expected +
                " actual=" + actual + " label=" +
                sim.instrumentController.getReadingForDeveloperVerification() + " installed=" +
                resistorSlot(instance).getInstalledPart().getId() + " state=" +
                sim.getBoardModificationController().getComponentState("R1") + " red=" +
                describeTarget(sim, instance, red) + " black=" +
                describeTarget(sim, instance, black) + " mode=" +
                sim.instrumentController.getActiveModeForDeveloperVerification() + " pending=" +
                sim.instrumentController.isResistanceRefreshPendingForDeveloperVerification() +
                " powered=" + sim.getBoardPowerController().getState() + " overlay=" +
                sim.activeMeasurementOverlay + " attachments=" +
                sim.elmList.contains(instance.getConnectionBindings().get("R1", "R1.1")
                    .getConnectionElement()) + "/" + sim.elmList.contains(instance.getConnectionBindings()
                    .get("R1", "R1.2").getConnectionElement()));
    }

    private static String describeTarget(CirSim sim, GeneratedBoardInstance instance,
            ProbeTarget target) {
        String description = target == null ? "null" : target.getClass().getName() +
            " valid=" + target.isValid() + " marker=" + target.getMarkerPoint();
        if (target instanceof ComponentLeadProbeTarget) {
            ComponentLeadProbeTarget lead = (ComponentLeadProbeTarget) target;
            description += " part=" + lead.getPhysicalPartIdForDeveloperVerification() +
                " component=" + lead.getComponentIdForDeveloperVerification() + " pad=" +
                lead.getPadIdForDeveloperVerification();
        }
        CircuitMeasurementEndpoint endpoint = target == null ? null : target.getMeasurementEndpoint();
        description += " endpoint=" + endpoint;
        if (endpoint instanceof CircuitPostMeasurementEndpoint) {
            CircuitPostMeasurementEndpoint post = (CircuitPostMeasurementEndpoint) endpoint;
            CircuitElm element = post.getElement();
            description += " elm=" + element.getClass().getName() + "@" +
                System.identityHashCode(element) + " post=" + post.getPostIndex() +
                " installedTerminal=" + belongsToInstalledPart(instance, element);
        }
        return description;
    }

    private static boolean belongsToInstalledPart(GeneratedBoardInstance instance, CircuitElm element) {
        if (resistorSlot(instance).isEmpty())
            return false;
        PhysicalResistorPart part = resistorSlot(instance).getInstalledPart();
		CircuitMeasurementEndpoint first = part.getPublicTerminal(0);
		CircuitMeasurementEndpoint second = part.getPublicTerminal(1);
		return (first instanceof CircuitPostMeasurementEndpoint &&
			((CircuitPostMeasurementEndpoint) first).getElement() == element) ||
			(second instanceof CircuitPostMeasurementEndpoint &&
			((CircuitPostMeasurementEndpoint) second).getElement() == element);
    }

    private static String catalogId(GeneratedBoardInstance instance) {
        return "R_CATALOG_" + (long) StandardPhysicalDefinitionProviders.RESISTOR.require(
            instance.getPhysicalSpecifications(), "R1").getNominalResistanceOhms();
    }

    private static void verifyStableLedDc(CirSim sim) {
        PcbWorkbenchRenderer renderer = sim.pcbWorkbenchController.getRenderer();
        ProbeTarget vin = hitPad(sim, renderer, "J1.1");
        ProbeTarget ground = hitPad(sim, renderer, "J1.2");
        sim.instrumentController.setDcVoltageProbesForDeveloperVerification(vin, ground);
        String initialText = sim.instrumentController.getReadingForDeveloperVerification();
        double initialVoltage = sim.instrumentController.getLatestDcVoltageForDeveloperVerification();
        require(!"--- V".equals(initialText) && finite(initialVoltage),
            "LED stable DC path did not produce a real initial display");
        int placeholders = sim.instrumentController
            .getDcVoltagePlaceholderDisplayCountForDeveloperVerification();
        int measurements = sim.instrumentController
            .getDcVoltageMeasurementCountForDeveloperVerification();
        for (int cycle = 0; cycle < 12; cycle++) {
            sim.updateCircuit();
            require(!"--- V".equals(sim.instrumentController.getReadingForDeveloperVerification()) &&
                    finite(sim.instrumentController.getLatestDcVoltageForDeveloperVerification()) &&
                    Math.abs(sim.instrumentController.getLatestDcVoltageForDeveloperVerification() -
                        initialVoltage) < .0001,
                "LED stable DC display changed without a real voltage change at cycle " + cycle);
        }
        require(sim.instrumentController.getDcVoltagePlaceholderDisplayCountForDeveloperVerification() ==
                placeholders && sim.instrumentController.getDcVoltageMeasurementCountForDeveloperVerification() ==
                    measurements,
            "LED stable DC path flickered or stopped receiving ordinary measurements");
        sim.instrumentController.exitInstrumentModeForDeveloperVerification();
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    private static ReplaceableComponentSlot resistorSlot(GeneratedBoardInstance instance) {
        return ReplaceableResistorBoardCapability.require(instance).getSlot();
    }

    private static void settle(CirSim sim) {
        GeneratedRuntimeDeveloperSettlement.settle(sim, sim.getGeneratedBoardInstance(),
            "meter-lifecycle-verifier");
    }

    private static double getLedCurrent(GeneratedBoardInstance instance) {
        return Math.abs(((LEDElm) instance.getComponentBindings().getSingleElement("LED1")).getCurrent());
    }

    private static void requireApproximately(double expected, double actual, double tolerance,
            String message) {
        require(!Double.isNaN(actual) && !Double.isInfinite(actual) &&
            Math.abs(expected - actual) <= tolerance, message + ": " + actual);
    }

    private static void requireFinite(double value, String message) {
        require(!Double.isNaN(value) && !Double.isInfinite(value), message);
    }

    private static void require(boolean condition, String message) {
        if (!condition)
            throw new IllegalStateException(message);
    }
}
