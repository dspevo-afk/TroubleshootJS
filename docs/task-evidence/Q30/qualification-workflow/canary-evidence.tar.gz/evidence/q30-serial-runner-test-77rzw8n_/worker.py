import json, pathlib, subprocess, sys, time

receipt_path = pathlib.Path(sys.argv[1])
seed, source, head, plan, mode, timeline, child_pid = sys.argv[2:]

def event(label):
    if timeline != "-":
        with open(timeline, "a", encoding="ascii") as stream:
            stream.write(f"{seed} {label} {time.perf_counter_ns()}\n")
            stream.flush()

def receipt(app_elapsed=80000):
    value = {
        "schema": 1, "rootSeed": seed, "sourceIdentity": source,
        "baseHead": head, "planSha256": plan,
        "limits": {"jobMillis": 90000, "sharedWork": 640, "activeOperationMillis": 5000},
        "application": {"status": "PASS", "elapsedMs": app_elapsed, "workUnits": 600,
            "maxActiveOperationMs": 4000, "maxCoordinatorAdvanceMs": 4500},
        "host": {"status": "PASS", "observationElapsedMs": 12, "deadlineMs": 120000,
            "exitCode": 0, "terminal": True},
        "cleanup": {"status": "PASS", "elapsedMs": 250, "elapsedLimitations": None,
            "serverStopped": True, "ownedSurvivors": []},
        "operation": {"elapsedMs": app_elapsed, "elapsedLimitations": None},
        "sourceInputsUnchanged": True,
    }
    receipt_path.write_text(json.dumps(value), encoding="utf-8")

if mode == "missing":
    sys.exit(0)
if mode == "flood":
    sys.stderr.write("x" * (2 * 1024 * 1024))
    sys.stderr.flush()
    time.sleep(30)
    sys.exit(0)

receipt(90221 if mode == "over-cap" else 80000)
event("start")
if mode in ("spawn-child", "orphan-child"):
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
    pathlib.Path(child_pid).write_text(str(child.pid), encoding="ascii")
    if mode == "spawn-child":
        time.sleep(60)
    else:
        event("finish")
        sys.exit(0)
elif mode == "slow":
    time.sleep(30)
else:
    time.sleep(0.12)
event("finish")
