"""Record this active source qualification in the requested repository report."""
from pathlib import Path
import json
R=Path(r'$REPO')
N=Path(__file__).resolve().parent
b=json.loads((N/'epoch15-task-pointer.json').read_text())
T=Path(b['taskRoot'])
p=R/'docs/CODEX_TASK_REPORT.md'
raw=p.read_bytes()
assert raw.startswith(b'# Current checkpoint: Q30 residual-exposure fix verified locally; acceptance blocked')
history=raw.replace(b'# Current checkpoint: Q30 residual-exposure fix verified locally; acceptance blocked',b'# Historical checkpoint: Q30 residual-exposure fix verified locally; acceptance blocked',1)
text='''# Current checkpoint: current-source Q30 cold77 failed; final regression running

2026-10-04. Candidate `abbc614e9456d9fae56274da583175f8721a84c2`, branch
`codex/q30-multirail-qualification`. Maintained source identity
`49bff7525b019d321a821eeafb7bb15ccc0fa5d101442820dabccded5126a45c`:
1,355 raw inputs. Q30 DISABLED / NOT ACCEPTED. Parent authorized fresh final-source
acceptance, with foreground Windows allocated and other projects on background
work. No public enablement, push, publication, email or evidence deletion.
U06/U07/Q60 remain unstarted; limits/save/replay/model epoch unchanged.

Fresh maintained isolated preparation PASS; actual JDK8/GWT OBF build PASS,
106.059 s/five permutations. Compiled manifest-export/unauthorized/cancel/
scope-loss canaries PASS, 18.423 s stage, cleanup 1.109 s. Frozen 77 roots/308
candidate declarations, order and original criteria rechecked. Current binding
negatives reject stale pointer and changed loader bytes before execution.

Fresh full cold77 FAIL: first roots 10387/10226 PASS (23,564/36,128 ms); third
root 10014 TIMEOUT at 90,621 ms/435 units. Remaining 74 NOT RUN. Hypothesis
proof consumed 77,908 ms; original 90,000 ms/640 shared/5,000 ms limits retained.
Host completed without browser errors; task job cleanup/readers complete.
Independent post-exit release PASS: 32 recorded instances absent/three ports
closed. A separate single-root diagnostic PASS at 89,195 ms/440 units, with
only 805 ms headroom. It does not replace the failed cohort. Diagnostic release
PASS: 18 recorded observations absent/owned port closed. Slowdown cause UNKNOWN;
source review comparing this proof path is in progress. Failures retained.

Fresh full83 native matrix/independent oracles RUNNING via maintained verifier;
append26 structural cohort NOT RUN. No parallel build/browser/test matrix.
Current private build/menu/replay and visible charged-to-DISCHARGE-to-numeric
meter recovery have not run; prior private source binding is stale. Private
admission gates that require cold77 PASS remain BLOCKED. Original warm-population
distribution outstanding; existing normal-menu runner can collect cache-eligible
paired replay timings, but public telemetry does not attest hits/final proof work.
No new Java qualification framework proposed. Source archive reconstruction and
parent acceptance pending. Old source-bound results remain historical.

Raw receipts, failed preparation and both cold runs, source snapshots and task
callers retained in task-owned OS-temp/workspace. Full-native launcher ownership
recorded at launch. Eight pre-existing untracked files and Desktop sibling
preserved. No wide machine changes, termination or cleanup of evidence.
Next: finish native83/append, investigate the deadline miss, then resume dependent
gates only with their preconditions satisfied. Parent owns final acceptance.

---

'''
newline=b'\r\n' if b'\r\n' in raw else b'\n'
p.write_bytes(text.encode().replace(b'\n',newline)+history)
road=R/'docs/ROADMAP.md'
r=road.read_bytes()
old=b'**Current task:** **Q30 NOT ACCEPTED - headed 20/30/40 repair/retest recorded; parent acceptance pending**'
assert r.count(old)==1
new=b'**Current task:** **Q30 NOT ACCEPTED - current-source cold77 failed; final regression running**'
note='''
**Current-source qualification (2026-10-04):** Candidate `abbc614e`, 1,355 inputs;
fresh maintained preparation, JDK8/GWT five-permutation build and compiled
canaries PASS. Full cold77 FAIL: two PASS, root10014 TIMEOUT90,621ms, 74 NOT RUN.
Separate single-root PASS89,195ms is diagnostic only; unchanged90s/640units/5s.
Failed cohort and cleanup/release receipts retained. Full83 native RUNNING;
dependent private admission/current visible meter recovery and warm distribution
pending. Q30 remains disabled; parent acceptance required. No publication or
next milestone. See current checkpoint in [task report](CODEX_TASK_REPORT.md).
'''.encode().replace(b'\n',newline)
road.write_bytes(r.replace(old,new+note,1))
print(json.dumps({'status':'CHECKPOINT_RECORDED','paths':['docs/CODEX_TASK_REPORT.md','docs/ROADMAP.md'],'candidate':b['baseHead']}))
