$ErrorActionPreference='Stop'
$workspace=$PSScriptRoot
$binding=Get-Content -LiteralPath (Join-Path $workspace 'epoch15-task-pointer.json') -Raw | ConvertFrom-Json -DateKind String
$taskRoot=$binding.taskRoot
$launchRoot=Join-Path $taskRoot 'cold77-normal-launch'
if(Test-Path -LiteralPath $launchRoot){throw 'Preserve previous launch attempt'}
New-Item -ItemType Directory -Path $launchRoot | Out-Null
$python='C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe'
$repo='$REPO'
$deps='$OS_TEMP\q30-finish-0fa2512465\deps'
$manifestPath=Join-Path $workspace 'cold77-candidate-manifest.json'
$manifestHash=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
if($manifestHash -ne '62341fcf943d35685455953f917bbf15c324ceacae1fc610be8bec80e135f93a'){throw 'Reviewed manifest changed'}
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json -DateKind String
$argsBase=@('-B',(Join-Path $workspace 'cold77_batch.py'),'--repo',$repo,'--pointer',(Join-Path $workspace 'epoch15-task-pointer.json'),'--matched-helper',(Join-Path $workspace 'run_root75_matched_diagnostic.py'),'--host-python',$python,'--deps',$deps)
$env:PYTHONDONTWRITEBYTECODE='1';$env:PYTHONIOENCODING='utf-8'
$preflightFile=Join-Path $launchRoot 'preflight.json'
& $python @argsBase 1> $preflightFile 2> (Join-Path $launchRoot 'preflight.stderr.txt')
if($LASTEXITCODE -ne 0){throw 'Preflight failed; preserve attempt'}
$preflight=Get-Content -LiteralPath $preflightFile -Raw | ConvertFrom-Json -DateKind String
if($preflight.status -ne 'PASS_OFFLINE_INPUT_AUDIT' -or $preflight.candidateManifestSha256 -ne $manifestHash){throw 'Preflight not current reviewed candidate'}
$canary=Get-Content -LiteralPath (Join-Path $taskRoot 'compiled-canaries-controller\result.json') -Raw | ConvertFrom-Json -DateKind String
if($canary.status -ne 'PASS' -or -not $canary.operation.cleanup.cleanupVerified -or $canary.operation.cleanup.jobActiveProcesses -ne 0 -or -not $canary.operation.cleanup.drainsComplete){throw 'Canary owner cleanup incomplete'}
$canaryHost=Get-Content -LiteralPath (Join-Path $taskRoot 'compiled-canaries-py313\identity.json') -Raw | ConvertFrom-Json -DateKind String
$canaryRows=@($canaryHost.runner)+@($canaryHost.edgeProcessesBeforeCases)
$present=@()
foreach($row in $canaryRows){
 $live=Get-CimInstance Win32_Process -Filter "ProcessId=$($row.pid)"
 $exe=if($row.executable){$row.executable}else{$row.ExecutablePath}
 if($null -ne $live -and $live.CreationDate.ToUniversalTime().ToString('o') -eq $row.created -and $live.ExecutablePath -eq $exe){$present+=@{pid=$row.pid;created=$row.created}}
}
$portListeners=@(Get-NetTCPConnection -LocalPort $canaryHost.port -State Listen -ErrorAction SilentlyContinue)
@{status=if($present.Count -eq 0 -and $portListeners.Count -eq 0){'PASS_RELEASED'}else{'FAIL_PRESENT'};observedUtc=[DateTime]::UtcNow.ToString('o');recordedInstances=$canaryRows.Count;exactInstancesPresent=$present;port=$canaryHost.port;listeners=$portListeners.Count;terminationAttempted=$false} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $launchRoot 'canary-release-audit.json')
if($present.Count -gt 0 -or $portListeners.Count -gt 0){throw 'Current canary resources not released'}
$self=Get-CimInstance Win32_Process -Filter "ProcessId=$PID"
@{pid=$PID;createdUtc=$self.CreationDate.ToUniversalTime().ToString('o');executable=$self.ExecutablePath;commandLine=$self.CommandLine;taskRoot=$taskRoot;launchRoot=$launchRoot} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $launchRoot 'launcher-identity.json')
$start=[DateTime]::UtcNow
$grant=@{schema=1;kind='Q30_COLD77_SERIAL_QUALIFICATION';parentReference=$binding.parentReference;candidateManifestSha256=$manifestHash;sourceIdentity=$binding.sourceIdentity;planSha256=$manifest.inputBinding.planSha256;limits=@{jobMillis=90000;sharedWork=640;activeOperationMillis=5000};rootCount=77;notBeforeUtc=$start.ToString('o');windowEndUtc=$start.AddMilliseconds(15120000).ToString('o');foregroundWindowsAllocated=$true;otherTasks='Core and Strata server/background-only, as instructed by parent';criteriaUnchanged=$true}
$grantPath=Join-Path $launchRoot 'quiet-window-grant.json'
$grant | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $grantPath
$argv=$argsBase+@('--launch','--grant-json',$grantPath)
$quoted=@($argv | ForEach-Object {'"'+$_+'"'})
$stdout=Join-Path $launchRoot 'normal.stdout.log';$stderr=Join-Path $launchRoot 'normal.stderr.log'
$process=Start-Process -FilePath $python -ArgumentList $quoted -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
$birth=$process.StartTime.ToUniversalTime();$native=Get-CimInstance Win32_Process -Filter "ProcessId=$($process.Id)"
$identity=@{pid=$process.Id;createdUtc=$birth.ToString('o');creationFileTimeTicks=$birth.ToFileTimeUtc();executable=$python;commandLine=$native.CommandLine;argv=$argv;sourceIdentity=$binding.sourceIdentity;manifestSha256=$manifestHash;windowStartUtc=$grant.notBeforeUtc;windowEndUtc=$grant.windowEndUtc;stdout=$stdout;stderr=$stderr;launchRoot=$launchRoot}
$identity | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $launchRoot 'normal-owner.json')
@{status='CURRENT_SOURCE_COLD77_RUNNING';pid=$process.Id;createdUtc=$identity.createdUtc;launchRoot=$launchRoot;windowEndUtc=$grant.windowEndUtc;sourceIdentity=$binding.sourceIdentity} | ConvertTo-Json
$clock=[Diagnostics.Stopwatch]::StartNew();$watchdog=$false
while(-not $process.HasExited){
 if($clock.Elapsed.TotalSeconds -ge 15110){
  $watchdog=$true
  $live=Get-Process -Id $process.Id -ErrorAction SilentlyContinue
  if($null -ne $live -and $live.StartTime.ToUniversalTime().ToFileTimeUtc() -eq $identity.creationFileTimeTicks){$live.Kill()}
  break
 }
 Start-Sleep -Seconds 1;$process.Refresh()
}
if(-not $watchdog){$process.WaitForExit()}
@{status=if($watchdog){'WATCHDOG_EXPIRED'}else{'NORMAL_CONTROLLER_EXITED'};pid=$process.Id;exitCode=if($watchdog){$null}else{$process.ExitCode};elapsedSeconds=$clock.Elapsed.TotalSeconds;finishedUtc=[DateTime]::UtcNow.ToString('o');windowEndUtc=$grant.windowEndUtc;watchdogExpired=$watchdog;independentPostExitRelease='PENDING; do not count this live launcher as leaked before it exits'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $launchRoot 'normal-exit.json')
if($watchdog){exit 2}
exit $process.ExitCode
