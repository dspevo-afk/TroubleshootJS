#!/usr/bin/env python3
"""Fail-closed receipt audit for the epoch15 Q30 native qualification batches."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO = Path(r"$REPO")
WORKSPACE = Path(__file__).resolve().parent
POINTER = WORKSPACE / "epoch15-task-pointer.json"
INTEGRATION = WORKSPACE / "integration-pointer.json"
SUITE_RE = re.compile(r"@\{ Name = '([^']+)'; Marker = '([^']+)'")
SIGNED_LONG_RE = re.compile(r"(?:0|-?[1-9][0-9]*)\Z")
SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
FULL_FINAL = "PASS: current contracts; 83 Java suites, independent seed/value/role oracles and report protocol."
APPEND_FINAL = "PASS: focused current contracts; 1 Java suites. Full matrix and independent oracles NOT RUN."
CLEANUP = "CLEANUP: current JVM contract classes and task-owned scratch removed."
ORACLES = ("Task46 independent seed oracle ", "A11 provider boundaries/report ",
           "A09 independent diagnostic contracts ", "current value synthesis oracle ")
PROTOCOL = ("PASS: A04 report contracts assertions=", "PASS: preview listener identity contracts assertions=")
SIDECARS = (".vectors.txt", ".manifest-resistive.txt", ".manifest-controlled.txt",
            ".manifest-controlled-alt.txt", ".seeds.txt", ".roles.txt", ".values.txt")
FIXED_FAULTS = (("DREV_OPEN", "DREV"), ("REN_OPEN", "REN"),
                ("SENSOR_A_OPEN", "RSA"), ("DRIVE_A_OPEN", "RDA"))


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_native_log(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16")
    return raw.decode("utf-8-sig")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_long(value: Any) -> bool:
    if not isinstance(value, str) or not SIGNED_LONG_RE.fullmatch(value):
        return False
    n = int(value)
    return -(1 << 63) <= n <= (1 << 63) - 1 and str(n) == value


def lines_with(text: str, prefix: str) -> list[str]:
    return [line for line in text.splitlines() if line.startswith(prefix)]


def case_support(case: dict[str, Any]) -> tuple[str | None, str | None]:
    canonical = case.get("canonical")
    if not isinstance(canonical, str):
        return None, None
    match = re.match(
        r"^rb30-plan@4;seed=(0|-?[1-9][0-9]*);topology=(RB30_CH[12]_(?:SEPARATE_DIRECT|SHARED_DIRECT|SHARED_HYSTERETIC)_A_(?:BJT|NMOS)(?:_B_(?:BJT|NMOS))?);support=(C12:(?:true|false),S5:(?:true|false),S12:(?:true|false),filters:[0-3],outputIndicators:[0-3],bleeder5:(?:true|false));layout=",
        canonical,
    )
    if not match:
        return None, None
    seed, axis, support = match.groups()
    return (support, axis) if seed == case.get("seed") and axis == case.get("axis") else (None, None)


def support_object(support: str) -> dict[str, Any] | None:
    match = re.fullmatch(
        r"C12:(true|false),S5:(true|false),S12:(true|false),filters:([0-3]),outputIndicators:([0-3]),bleeder5:(true|false)",
        support,
    )
    if not match:
        return None
    return {"C12": match[1] == "true", "S5": match[2] == "true",
            "S12": match[3] == "true", "filters": int(match[4]),
            "outputIndicators": int(match[5]), "bleeder5": match[6] == "true"}


def topology_identity(axis: str, support: str) -> str | None:
    obj = support_object(support)
    if obj is None:
        return None
    flag = lambda key: "Y" if obj[key] else "N"
    return (axis + "_C12_" + flag("C12") + "_S5_" + flag("S5") +
            "_S12_" + flag("S12") + "_F" + str(obj["filters"]) +
            "_O" + str(obj["outputIndicators"]) + "_B5_" + flag("bleeder5"))


def validate_plan_row(row: dict[str, Any], case: dict[str, Any], seed: str,
                      issues: list[str]) -> None:
    support, axis = case_support(case)
    if support is None or axis is None:
        issues.append(f"Q30_CASE_PLAN: frozen case identity invalid for {seed}")
        return
    if row.get("schema") != 1 or row.get("seed") != seed or row.get("planEpoch") != 4:
        issues.append(f"Q30_CASE_PLAN: schema/seed/epoch mismatch for {seed}")
    if row.get("canonical") != case.get("canonical") or row.get("topology") != topology_identity(axis, support):
        issues.append(f"Q30_CASE_PLAN: canonical/topology mismatch for {seed}")
    channels, packages = case.get("channels"), case.get("packages")
    if row.get("channelCount") != channels or row.get("packageCount") != packages:
        issues.append(f"Q30_CASE_PLAN: channel/package mismatch for {seed}")
    expected_channels = ["A"] if channels == 1 else ["A", "B"] if channels == 2 else None
    if row.get("activeChannels") != expected_channels:
        issues.append(f"Q30_CASE_PLAN: active channel order mismatch for {seed}")
    axis_match = re.match(r"^RB30_CH[12]_(SEPARATE_DIRECT|SHARED_DIRECT|SHARED_HYSTERETIC)_A_", axis)
    if not axis_match or row.get("referenceArrangement") != (axis_match.group(1) if axis_match else None):
        issues.append(f"Q30_CASE_PLAN: reference arrangement mismatch for {seed}")
    if row.get("support") != support_object(support):
        issues.append(f"Q30_CASE_PLAN: support metadata mismatch for {seed}")
    count = channels if channels in (1, 2) else 0
    states = 1 << count if count else 0
    relay = "A" if count == 1 else "B"
    faults = [{"id": fault, "owner": owner} for fault, owner in FIXED_FAULTS]
    faults.append({"id": f"RELAY_{relay}_COIL_OPEN", "owner": f"K{relay}"})
    if row.get("faults") != faults:
        issues.append(f"Q30_CASE_PLAN: fault IDs/owners/order mismatch for {seed}")
    budgets = {
        "diagnosticProviderDeveloper": "rb30-control-diagnostic@2",
        "diagnosticProviderNormal": "rb30-control-diagnostic@4",
        "diagnosticTemplate": "RB30_CHANNEL_INPUT_SWEEP_V1",
        "diagnosticSamplesPerHypothesis": (7 + count) * states + 1,
        "temporalContract": "RB30_CHANNEL_FUNCTION@3", "sampleSeconds": 0.03,
        "profileWorkUnits": states + 1, "customerRetestWorkUnits": states + 1,
        "maxJobMillis": 90000, "maxJobSteps": 640, "activeOperationMillis": 5000,
    }
    for key, expected in budgets.items():
        if row.get(key) != expected:
            issues.append(f"Q30_CASE_PLAN: {key} mismatch for {seed}")


def section(lines: list[str], start: int, stops: tuple[str, ...]) -> str:
    end = len(lines)
    for index in range(start + 1, len(lines)):
        if lines[index].startswith(stops):
            end = index
            break
    return "\n".join(lines[start:end])


def validate_corpus(receipt: str, expected: list[dict[str, Any]], batch: str,
                    issues: list[str]) -> dict[str, Any]:
    lines = receipt.splitlines()
    entries = [(i, line) for i, line in enumerate(lines) if line.startswith("Q30_CORPUS_CASE ")]
    expected_seeds = [case.get("seed") for case in expected]
    actual_seeds: list[str] = []
    accepted = rejected = 0
    for ordinal, (index, header) in enumerate(entries):
        match = re.fullmatch(r"Q30_CORPUS_CASE seed=(0|-?[1-9][0-9]*) exit=(-?[0-9]+) termination=(True|False) rowContract=(True|False)", header)
        if not match:
            issues.append(f"{batch}: malformed corpus header at row {ordinal}")
            continue
        seed, exit_code, terminated, contract = match.groups()
        actual_seeds.append(seed)
        if ordinal >= len(expected):
            issues.append(f"{batch}: unexpected corpus seed {seed}")
            continue
        case = expected[ordinal]
        if (seed != case.get("seed") or exit_code != "0" or terminated != "True" or contract != "True"):
            issues.append(f"{batch}: corpus process/seed/rowContract failure at row {ordinal}")
        block = section(lines, index, ("Q30_CORPUS_CASE ", "Q30_CORPUS_CENSUS "))
        payloads = [line[len("Q30_CORPUS_JSON:"):] for line in block.splitlines() if line.startswith("Q30_CORPUS_JSON:")]
        if len(payloads) != 1:
            issues.append(f"{batch}: corpus row {seed} has {len(payloads)} JSON rows")
            continue
        try:
            row = json.loads(payloads[0])
        except Exception as exc:
            issues.append(f"{batch}: invalid corpus JSON for {seed}: {exc}")
            continue
        support, _axis = case_support(case)
        support_obj = support_object(support) if support else None
        expected_row_support = None if support_obj is None else (
            f"C12:{str(support_obj['C12']).lower()},S5:{str(support_obj['S5']).lower()},"
            f"S12:{str(support_obj['S12']).lower()},F:{support_obj['filters']},"
            f"O:{support_obj['outputIndicators']},B5:{str(support_obj['bleeder5']).lower()}"
        )
        if (row.get("schema") != 1 or row.get("planEpoch") != 4 or row.get("seed") != seed or
            row.get("topologyAxis") != case.get("axis") or row.get("partCount") != case.get("packages") or
            row.get("support") != expected_row_support or row.get("cleanup") is not True or
            row.get("contractValidated") is not True or row.get("validationFailure") not in (None, "")):
            issues.append(f"{batch}: corpus canonical/epoch/package/cleanup metadata mismatch for {seed}")
        cold, warm = row.get("coldRouteCanonical"), row.get("warmRouteCanonical")
        stats = re.match(r"[^;]+;outcome=([^;]+);selected=([^;]+);", cold) if isinstance(cold, str) else None
        route_status = stats.group(1) if stats else None
        selected = stats.group(2) if stats else None
        if not cold or cold != warm:
            issues.append(f"{batch}: cold/warm route receipt differs for {seed}")
        if row.get("coldRouteOutcomes") != row.get("warmRouteOutcomes") or not isinstance(row.get("coldRouteOutcomes"), list):
            issues.append(f"{batch}: cold/warm route-outcome list mismatch for {seed}")
        route, outcome, admission = row.get("routeOutcome"), row.get("outcome"), row.get("normalAdmissionOutcome")
        reason = row.get("normalAdmissionReason")
        if route_status == "REJECTED":
            valid = (route == "REJECTED" and outcome == "REJECTED" and admission == "REJECTED_ROUTE" and bool(row.get("routeRejection")))
        elif route_status == "SUCCESS" and selected == "P05_ONE_FACE":
            valid = (route == "SUCCESS" and outcome == "REJECTED" and admission == "REJECTED_POLICY" and reason == "P05_ONLY_NORMAL_ADMISSION_REQUIRES_P07")
        elif route_status == "SUCCESS" and selected == "P07_FULLER_TWO_LAYER":
            channels = case.get("channels")
            valid = (route == "SUCCESS" and outcome == "ACCEPTED" and admission == "ACCEPTED" and
                     reason in (None, "") and bool(row.get("physicalFingerprintHash")) and
                     bool(row.get("layoutFingerprintHash")) and row.get("hypothesisCount") == 5 and
                     channels in (1, 2) and row.get("observationCount") == (7 + channels) * (1 << channels) + 1)
        else:
            valid = False
        if not valid or route != route_status:
            issues.append(f"{batch}: route/admission outcome inconsistent for {seed}: {route_status}/{selected}/{outcome}/{admission}")
        if outcome == "ACCEPTED":
            accepted += 1
        elif outcome == "REJECTED":
            rejected += 1
        else:
            issues.append(f"{batch}: unknown normal outcome for {seed}")
        markers = [line for line in block.splitlines() if line.startswith("PASS: Q30 normal corpus contracts ")]
        if len(markers) != 1 or not markers[0].endswith(" seed=" + seed):
            issues.append(f"{batch}: normal corpus PASS detail missing/ambiguous for {seed}")
        elif (f"outcome={outcome}" not in markers[0] or f"routeOutcome={route}" not in markers[0] or
              f"normalAdmission={admission}" not in markers[0] or "cleanup=true" not in markers[0]):
            issues.append(f"{batch}: normal corpus PASS detail disagrees with row for {seed}")
    if actual_seeds != expected_seeds:
        issues.append(f"{batch}: corpus seed order differs from frozen plan")
    if len(entries) != len(expected):
        issues.append(f"{batch}: expected {len(expected)} corpus rows, found {len(entries)}")
    censuses = lines_with(receipt, "Q30_CORPUS_CENSUS ")
    if len(censuses) != 1:
        issues.append(f"{batch}: expected exactly one corpus census")
    else:
        match = re.fullmatch(r"Q30_CORPUS_CENSUS attempted=(\d+) accepted=(\d+) rejected=(\d+) failed=(\d+) childBudgetMs=(\d+)", censuses[0])
        expected_counts = (len(expected), accepted, rejected, 0, 60000)
        if not match or tuple(map(int, match.groups())) != expected_counts or accepted + rejected != len(expected):
            issues.append(f"{batch}: corpus census totals or child budget mismatch")
    return {"expectedRows": len(expected), "receiptRows": len(entries),
            "acceptedRows": accepted, "rejectedRows": rejected,
            "rowSeedsMatchedInOrder": actual_seeds == expected_seeds}


def audit(batch: str) -> tuple[dict[str, Any], list[str], Path]:
    issues: list[str] = []
    started = now()
    pointer = read_json(POINTER)
    integration = read_json(INTEGRATION)
    task_root = Path(pointer.get("taskRoot", ""))
    if not task_root.is_absolute():
        raise RuntimeError("epoch15 pointer taskRoot must be absolute")
    task_root = task_root.resolve()
    temp_root = Path(tempfile.gettempdir()).resolve()
    try:
        task_root.relative_to(temp_root)
    except ValueError as error:
        raise RuntimeError("epoch15 pointer taskRoot is outside the OS temp root") from error
    if task_root != Path(integration.get("taskRoot", "")).resolve():
        raise RuntimeError("epoch15 task pointer differs from the integrated task root")
    if pointer.get("baseHead") != integration.get("baseHead"):
        issues.append("epoch15 pointer baseHead differs from the integrated candidate")
    batch_prefix = "native-full" if batch == "native-full" else "native-append"
    log_path, result_path = task_root / f"{batch_prefix}.log", task_root / f"{batch_prefix}-result.json"
    receipt_path, output_path = task_root / f"{batch_prefix}.txt", task_root / f"{batch_prefix}-audit.json"
    if not result_path.is_file():
        raise RuntimeError("native wrapper result is absent; batch is unfinished or not started")
    if not log_path.is_file() or not receipt_path.is_file():
        raise RuntimeError("native log or receipt is absent; batch artifacts are incomplete")
    snapshot = read_json(task_root / "source-snapshot.json")
    plan_path = task_root / "acceptance-plan.json"
    plan, wrapper = read_json(plan_path), read_json(result_path)
    log_text = read_native_log(log_path)
    receipt = receipt_path.read_bytes().decode("utf-8-sig")

    expected_binding = {"schema": 1, "baseHead": integration.get("baseHead"),
                        "frozenRoots": 77, "frozenServiceSensitivityRoots": 21, "layoutEpoch": 15}
    for key, value in expected_binding.items():
        if pointer.get(key) != value:
            issues.append(f"epoch15 pointer {key} mismatch")
    if snapshot.get("baseHead") != pointer.get("baseHead") or snapshot.get("sourceIdentity") != pointer.get("sourceIdentity"):
        issues.append("source snapshot identity differs from epoch15 pointer")
    plan_sha = sha256_file(plan_path)
    if plan_sha != pointer.get("continuedPlanSha256") or plan.get("baseHead") != pointer.get("baseHead"):
        issues.append("continued acceptance plan hash/head differs from pointer")
    cases = plan.get("cases", [])
    seeds = plan.get("serviceAndSensitivitySeeds", [])
    if plan.get("schema") != 1 or not isinstance(cases, list) or len(cases) != 77:
        issues.append("frozen acceptance plan is not the exact 77-root schema")
        cases = cases if isinstance(cases, list) else []
    if not isinstance(seeds, list) or len(seeds) != 21 or any(not canonical_long(seed) for seed in seeds) or len(set(seeds)) != len(seeds):
        issues.append("frozen service/sensitivity seed cohort is not 21 unique canonical signed-long roots")
        seeds = seeds if isinstance(seeds, list) else []

    source_rows = snapshot.get("files", [])
    if not isinstance(source_rows, list) or len(source_rows) != 1355:
        issues.append("source snapshot does not contain exactly 1,355 raw inputs")
        source_rows = source_rows if isinstance(source_rows, list) else []
    source_result: dict[str, Any] = {"expected": 1355, "checked": 0, "mismatches": []}
    seen: set[str] = set()
    repo_resolved = REPO.resolve()
    for row in source_rows:
        rel = row.get("path") if isinstance(row, dict) else None
        digest = row.get("sha256") if isinstance(row, dict) else None
        size = row.get("size") if isinstance(row, dict) else None
        if (not isinstance(rel, str) or not rel or Path(rel).is_absolute() or "\\" in rel or
            any(part in ("", ".", "..") for part in rel.split("/")) or rel in seen or
            not isinstance(digest, str) or not SHA256_RE.fullmatch(digest) or type(size) is not int):
            issues.append("source snapshot contains malformed, duplicate, or path-escaping row")
            continue
        seen.add(rel)
        target = (REPO / Path(*rel.split("/"))).resolve()
        try:
            target.relative_to(repo_resolved)
        except ValueError:
            issues.append(f"source input escapes repository: {rel}")
            continue
        source_result["checked"] += 1
        if not target.is_file():
            source_result["mismatches"].append({"path": rel, "reason": "missing"})
        elif target.stat().st_size != size or sha256_file(target) != digest:
            source_result["mismatches"].append({"path": rel, "reason": "raw-bytes-changed"})
    if source_result["mismatches"]:
        issues.append(f"{len(source_result['mismatches'])} raw source snapshot input(s) changed")
    source_result.update({"sourceIdentity": snapshot.get("sourceIdentity"),
                          "allRawInputsUnchanged": len(source_rows) == source_result["checked"] == 1355 and not source_result["mismatches"]})

    case_by_seed: dict[str, dict[str, Any]] = {}
    for index, case in enumerate(cases):
        if not isinstance(case, dict):
            issues.append(f"frozen case {index} is malformed")
            continue
        seed = case.get("seed")
        support, axis = case_support(case)
        if (not canonical_long(seed) or support is None or axis is None or type(case.get("packages")) is not int or
            type(case.get("channels")) is not int or case.get("channels") not in (1, 2) or
            not 20 <= case.get("packages", 0) <= 40):
            issues.append(f"frozen case {index} has invalid epoch4 canonical/package/channel metadata")
        elif seed in case_by_seed:
            issues.append(f"duplicate frozen root seed {seed}")
        else:
            case_by_seed[seed] = case
    for seed in seeds:
        if seed not in case_by_seed:
            issues.append(f"service/sensitivity root {seed} has no frozen case metadata")

    start, end = (0, 51) if batch == "native-full" else (51, 77)
    corpus_cases = cases[start:end]
    corpus_seeds = [row.get("seed") for row in corpus_cases if isinstance(row, dict)]
    expected_preflight = list(dict.fromkeys(corpus_seeds + (list(seeds) * 2 if batch == "native-full" else [])))
    suite_definitions = SUITE_RE.findall((REPO / "scripts/verify-current-contracts.ps1").read_text(encoding="utf-8"))
    if len(suite_definitions) != 83:
        issues.append(f"maintained verifier suite definition count is {len(suite_definitions)}, expected 83")
    expected_suite_count = 83 if batch == "native-full" else 1
    expected_corpus_count = 51 if batch == "native-full" else 26
    expected_wrapper = {"schema": 1, "batch": batch, "head": pointer.get("baseHead"),
        "consumedSourceIdentity": snapshot.get("sourceIdentity"), "consumedInputsVerified": 1355,
        "exitCode": 0, "status": "COMMAND_PASS_PENDING_RECEIPT_REVIEW", "complete": True,
        "acceptancePlanSha256": pointer.get("continuedPlanSha256"), "suiteCount": expected_suite_count}
    for key, expected in expected_wrapper.items():
        if wrapper.get(key) != expected:
            issues.append(f"wrapper result {key} mismatch")
    for key, expected in (("serviceSeeds", seeds), ("sensitivitySeeds", seeds), ("corpusSeeds", corpus_seeds)):
        actual = wrapper.get(key)
        if not isinstance(actual, list) or [str(value) for value in actual] != expected:
            issues.append(f"wrapper result {key} differs from frozen ordered cohort")
    if wrapper.get("cleanupElapsedSeconds") != "NOT RECORDED separately":
        issues.append("wrapper cleanup timing does not match maintained result format")
    if not isinstance(wrapper.get("elapsedSeconds"), (int, float)) or wrapper.get("elapsedSeconds", -1) < 0:
        issues.append("wrapper elapsed time missing or invalid")
    if not wrapper.get("startedUtc") or not wrapper.get("finishedUtc"):
        issues.append("wrapper start/finish timestamps missing")

    final_marker = FULL_FINAL if batch == "native-full" else APPEND_FINAL
    if len(lines_with(log_text, final_marker)) != 1:
        issues.append("native log lacks exactly one exact final PASS marker")
    if len(lines_with(log_text, CLEANUP)) != 1:
        issues.append("native log lacks exactly one exact cleanup marker")
    if "CURRENT_CONTRACT_FAILURE:" in log_text:
        issues.append("native log contains CURRENT_CONTRACT_FAILURE")

    marker_counts = Counter(marker for _name, marker in suite_definitions)
    marker_lines = {marker: len(lines_with(receipt, "PASS: " + marker)) for marker in marker_counts}
    definitions = suite_definitions if batch == "native-full" else [
        item for item in suite_definitions if item[0] == "Q30NormalCorpusContractTest"]
    missing_markers = []
    for name, marker in definitions:
        needed = marker_counts[marker] if batch == "native-full" else 1
        if marker_lines.get(marker, 0) < needed:
            missing_markers.append({"suite": name, "marker": marker,
                                    "requiredAtLeast": needed, "found": marker_lines.get(marker, 0)})
    if missing_markers:
        issues.append(f"{len(missing_markers)} maintained suite PASS marker(s) missing")
    if batch == "native-full" and len(definitions) != 83:
        issues.append("full batch suite-marker audit is not bound to all 83 definitions")

    plan_records = []
    for line in receipt.splitlines():
        if line.startswith("Q30_CASE_PLAN "):
            try:
                plan_records.append(json.loads(line[len("Q30_CASE_PLAN "):]))
            except Exception as exc:
                issues.append(f"malformed Q30_CASE_PLAN metadata: {exc}")
    preflight_seeds = [row.get("seed") for row in plan_records if isinstance(row, dict)]
    if preflight_seeds != expected_preflight or len(plan_records) != len(expected_preflight):
        issues.append("case-plan preflight seeds/order/count differ from selected exact cohort")
    for index, seed in enumerate(expected_preflight):
        if index < len(plan_records) and isinstance(plan_records[index], dict) and seed in case_by_seed:
            validate_plan_row(plan_records[index], case_by_seed[seed], seed, issues)
        elif index < len(expected_preflight):
            issues.append(f"missing frozen case or preflight metadata for {seed}")

    corpus_result = validate_corpus(receipt, corpus_cases, batch, issues)
    cohort: dict[str, Any] = {"corpus": corpus_result, "preflightExpectedSeeds": expected_preflight,
        "preflightReceiptSeeds": preflight_seeds, "serviceExpected": 0, "serviceReceipt": 0,
        "sensitivityExpected": 0, "sensitivityReceipt": 0}
    if batch == "native-full":
        expected_service: list[tuple[str, str]] = []
        expected_sensitivity: list[tuple[str, str]] = []
        for seed in seeds:
            channels = case_by_seed.get(seed, {}).get("channels")
            relay = "A" if channels == 1 else "B"
            faults = [f"RELAY_{relay}_COIL_OPEN"] + [fault for fault, _owner in FIXED_FAULTS]
            expected_service.extend((seed, fault) for fault in faults)
            expected_sensitivity.extend((seed, fault) for fault in faults)
        service_headers = []
        receipt_lines = receipt.splitlines()
        for index, line in enumerate(receipt_lines):
            match = re.fullmatch(r"Q30_CASE\|((?:0|-?[1-9][0-9]*))\|([^|]+)\|outcome=([^|]+)\|reason=([^\r\n]+)", line)
            if match:
                service_headers.append((*match.groups(), index))
        got_service = [(seed, fault) for seed, fault, _outcome, _reason, _index in service_headers]
        if got_service != expected_service:
            issues.append("service case order/count differs from exact 105 frozen seed/fault cases")
        for seed, fault, outcome, reason, index in service_headers:
            block = section(receipt_lines, index, ("Q30_CASE|", "PASS: Q30 service flow census "))
            row = re.compile(r"(?m)^PASS: Q30 service flow seed=" + re.escape(seed) +
                r" fault=" + re.escape(fault) + r" target=[A-Z0-9_]+ fingerprintHash=[0-9a-fA-F]{1,8}\r?$")
            final = re.compile(r"(?m)^PASS: Q30 service flow contracts \d+ assertions seed=" +
                re.escape(seed) + r" fault=" + re.escape(fault) + r"\r?$")
            if outcome != "PASS" or reason != "qualified" or len(row.findall(block)) != 1 or len(final.findall(block)) != 1:
                issues.append(f"service case result/detail failed for {seed}/{fault}")
            if "STDOUT_BEGIN" not in block or "STDOUT_END" not in block:
                issues.append(f"service case output framing missing for {seed}/{fault}")
        service_census = ("PASS: Q30 service flow census attempted=105 passed=105 failed=0 failedCases=none seeds=" +
            ",".join(seeds) + " faults=5 order=RELAY_<channel>_COIL_OPEN,DREV_OPEN,REN_OPEN,SENSOR_A_OPEN,DRIVE_A_OPEN childBudgetMs=60000")
        if len(lines_with(receipt, service_census)) != 1:
            issues.append("service census is not exactly 105/105 with unchanged 60,000ms child budget")
        cohort["serviceExpected"], cohort["serviceReceipt"] = len(expected_service), len(service_headers)

        sensitivity_headers = []
        for index, line in enumerate(receipt_lines):
            match = re.fullmatch(r"Q30_SENSITIVITY_CASE seed=((?:0|-?[1-9][0-9]*)) fault=([^ ]+) exit=(-?[0-9]+) termination=(True|False) qualified=(True|False)", line)
            if match:
                sensitivity_headers.append((*match.groups(), index))
        got_sensitivity = [(seed, fault) for seed, fault, *_rest in sensitivity_headers]
        if got_sensitivity != expected_sensitivity:
            issues.append("sensitivity case order/count differs from exact 105 frozen seed/fault cases")
        metadata_by_seed = {row.get("seed"): row for row in plan_records if isinstance(row, dict)}
        for seed, fault, exit_code, terminated, qualified, index in sensitivity_headers:
            block = section(receipt_lines, index, ("Q30_SENSITIVITY_CASE ", "Q30_SENSITIVITY_CENSUS "))
            case = case_by_seed.get(seed)
            metadata = metadata_by_seed.get(seed)
            support = metadata.get("support") if metadata else None
            support_text = None
            if isinstance(support, dict):
                support_text = (f"C12:{str(support.get('C12')).lower()},S5:{str(support.get('S5')).lower()},"
                    f"S12:{str(support.get('S12')).lower()},filters:{support.get('filters')},"
                    f"outputIndicators:{support.get('outputIndicators')},bleeder5:{str(support.get('bleeder5')).lower()}")
            topology = metadata.get("topology") if metadata else None
            canonical = case.get("canonical") if case else None
            pair = (f"Q30_STEP_PAIR seed={seed} support={support_text} topology={topology} canonicalPlan={canonical} fault={fault} "
                "referenceMaximumStepSeconds=2.50000000e-06 productionCandidateMaximumStepSeconds=5.00000000e-06 candidateKind=PRODUCTION_5_US")
            final = re.compile(r"(?m)^PASS: Q30 production solver step sensitivity assertions=\d+ seed=" + re.escape(seed) +
                r" support=" + re.escape(support_text or "") + r" topology=" + re.escape(topology or "") +
                r" canonicalPlan=" + re.escape(canonical or "") + r" faults=1 referenceMaximumStepSeconds=2\.50000000e-06 " +
                r"productionCandidateMaximumStepSeconds=5\.00000000e-06 candidateKind=PRODUCTION_5_US elapsedMillis=\d+\r?$")
            if exit_code != "0" or terminated != "True" or qualified != "True" or len(lines_with(block, pair)) != 1 or len(final.findall(block)) != 1:
                issues.append(f"sensitivity row failed identity/proof/exit checks for {seed}/{fault}")
        sens_census = "Q30_SENSITIVITY_CENSUS attempted=105 passed=105 failed=0 childBudgetMs=60000"
        if len(lines_with(receipt, sens_census)) != 1:
            issues.append("sensitivity census is not exactly 105/105 with unchanged 60,000ms child budget")
        cohort["sensitivityExpected"], cohort["sensitivityReceipt"] = len(expected_sensitivity), len(sensitivity_headers)

    full_only: dict[str, Any] = {}
    if batch == "native-full":
        oracle_counts = {marker: len(lines_with(receipt, "PASS: " + marker)) for marker in ORACLES}
        protocol_counts = {marker: len(lines_with(receipt, marker)) for marker in PROTOCOL}
        sidecars = []
        for ending in SIDECARS:
            path = Path(str(receipt_path) + ending)
            size = path.stat().st_size if path.is_file() else 0
            sidecars.append({"path": str(path), "bytes": size, "nonempty": size > 0})
        if any(value < 1 for value in oracle_counts.values()):
            issues.append("one or more independent oracle PASS markers are missing")
        if any(value < 1 for value in protocol_counts.values()):
            issues.append("report protocol or preview listener PASS marker is missing")
        if any(not item["nonempty"] for item in sidecars):
            issues.append("one or more required seven parity/seed/role/value sidecars are missing or empty")
        full_only = {"independentOracleMarkers": oracle_counts,
                     "reportAndListenerMarkers": protocol_counts, "sidecars": sidecars}

    report = {
        "schema": 1, "batch": batch, "startedUtc": started, "finishedUtc": now(),
        "auditStatus": "PASS" if not issues else "FAIL", "issues": issues,
        "taskRoot": str(task_root), "repository": str(REPO),
        "wrapper": {key: wrapper.get(key) for key in ("head", "consumedSourceIdentity", "consumedInputsVerified",
            "startedUtc", "finishedUtc", "elapsedSeconds", "exitCode", "status", "complete", "cleanupElapsedSeconds", "suiteCount")},
        "sourceInputs": source_result,
        "acceptance": {"planSha256": plan_sha, "baseHead": plan.get("baseHead"),
            "layoutEpoch": pointer.get("layoutEpoch"), "frozenRoots": len(cases),
            "serviceSensitivityRoots": len(seeds), "expectedSuiteCount": expected_suite_count,
            "expectedCorpusCount": expected_corpus_count},
        "suiteMarkers": {"maintainedDefinitionCount": len(suite_definitions), "requiredCount": len(definitions),
            "missing": missing_markers, "markerLineCounts": marker_lines},
        "cohorts": cohort, "fullOnly": full_only,
        "logs": {"finalMarker": final_marker, "finalMarkerCount": len(lines_with(log_text, final_marker)),
            "cleanupMarkerCount": len(lines_with(log_text, CLEANUP)), "failureMarkerCount": log_text.count("CURRENT_CONTRACT_FAILURE:")},
        "artifacts": {"wrapperResult": str(result_path), "nativeLog": str(log_path), "receipt": str(receipt_path)},
    }
    return report, issues, output_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", choices=("native-full", "native-append"), required=True)
    args = parser.parse_args()
    try:
        report, issues, output_path = audit(args.batch)
        if output_path.exists():
            print(f"REFUSED: preserve existing audit artifact: {output_path}", file=sys.stderr)
            return 3
        payload = (json.dumps(report, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        fd = os.open(str(output_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
        print(f"{report['auditStatus']}: {args.batch}; issues={len(issues)}; audit={output_path}")
        for issue in issues:
            print(f"ISSUE: {issue}")
        return 0 if not issues else 2
    except Exception as exc:
        print(f"NOT READY/FAIL: {args.batch}: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
