"""Summarize captured ordinary UI observations; no measurement or acceptance oracle."""
import json
from datetime import datetime
from pathlib import Path
N=Path(__file__).parent;U=Path((N/'headed-ui-root.txt').read_text(encoding='utf-8-sig').strip())
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
response=lambda number:read(U/'responses'/f'{number:04d}.json')
result=read(U/'result.json')
assert result['outcome']=='UI_SESSION_CLOSED_PENDING_FLOW_REVIEW'
assert result['inputsBefore']==result['inputsAfter']
assert result['inputsAfter']=={'status':'PASS','rawInputs':1355,'compiledFiles':357,'permutations':5,'deploymentFiles':6,'pinnedJars':9}
assert result['gameFunctionsCalled'] is False and result['pageEvaluateUsed'] is False
rows=[]
for size,seed,wait,ticket,powered,off,first,last in [(20,'10387',22,23,30,31,32,48),(30,'10226',65,66,72,73,74,83),(40,'10014',94,95,100,101,102,112)]:
 a,b,c,d=map(response,[powered,off,first,last])
 assert all(x['status']=='PASS' for x in [a,b,c,d])
 assert 'POWER OFF\nBoard Power: ON' in a['body']
 assert 'DISCHARGE\nBoard Power: OFF' in c['body'] and 'Board Power: OFF' in d['body']
 final_display=d['body'].split('\nDIODE\n',1)[1].split('\nBoard Power:',1)[0].strip()
 if size in [20,30]:assert final_display=='DISCHARGE'
 assert 'One or both loads fail to follow their sensor inputs.' in response(ticket)['body']
 elapsed=(datetime.fromisoformat(d['startedUtc'])-datetime.fromisoformat(b['finishedUtc'])).total_seconds()
 assert elapsed>300
 rows.append({'partCount':size,'seed':seed,'ordinaryUiTicketWaitSeconds':response(wait)['elapsedSeconds'],'ticketResponse':ticket,'poweredResponse':powered,'powerOffAction':off,'firstIsolationResponse':first,'finalIsolationResponse':last,'powerOffObservationSpanSeconds':elapsed,'observedPoweredStatus':'POWER OFF','observedIsolationStatus':final_display,'numericOhmDiodeRecovery':'NOT_OBSERVED' if final_display in ['DISCHARGE','UNKNOWN','SETTLING','POWER OFF'] else 'REQUIRES_NUMERIC_VALUE_REVIEW','scope':'Sampled ordinary UI observations; no simulated-time value or eventual-never-recovery claim'})
failed=[{'sequence':a['sequence'],'command':a['command'],'error':a.get('error')} for a in result['actions'] if a.get('status')!='PASS']
out={'schema':1,'scope':'PRIVATE_INSTRUMENT_DIAGNOSTIC_ONLY','result':'FAIL_REQUIRED_CHARGED_RECOVERY_NOT_OBSERVED','acceptanceStatus':'NOT_ASSESSED','sourceIdentity':'49bff7525b019d321a821eeafb7bb15ccc0fa5d101442820dabccded5126a45c','cases':rows,'actionCount':len(result['actions']),'passedActionCount':len(result['actions'])-len(failed),'failedActionsPreserved':failed,'wrongDefaultFamilyAttemptsPreserved':[{'prepareAction':4,'ticketWait':5,'ticketIdentity':6},{'prepareAction':52,'ticketWait':53,'ticketIdentity':54}],'wrongAttemptsExcludedFromQ30Evidence':True,'modeExit':'20 OHM reselect action36 and response37 shows --- V with board OFF','modeSwitchAndReversedProbes':'30 responses79/81 and40 responses106/109/111 show DISCHARGE with board OFF','sameGraphBoundary':'Between each power-off and final observation, commands are only dumps/screenshots/probe/mode input; no reset, repair, source injection or generation. The following Main menu/generation starts the next case.','dcObservation':{'response':43,'visibleReading':'43.52 mV','location':'20-part J1 visible +12V/GND pads; DC reading is not an active-meter recovery pass'},'inspectedScreenshots':['001-current-menu.png','002-current20-powered.png','003-current20-discharge.png','004-current30-powered.png','006-current40-powered.png'],'additionalCapturedScreenshotsNotInspected':['005-current30-discharge.png','007-current40-discharge.png'],'cleanupScope':'UI host pre-exit cleanup remains pending; actual separate release receipt is required. Browser-context close duration NOT RECORDED separately.','limits':'Application90,000ms/640shared/5,000active unchanged. UI ticket wait timings are ordinary end-to-end observation, not cold application receipts or cache-hit/warm-population attestation. Guided SDK input does not certify CDP wrapper or blind diagnosis.'}
p=U/'flow-review.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'result':out['result'],'actionCount':out['actionCount'],'failedActions':len(failed),'cases':rows}))
