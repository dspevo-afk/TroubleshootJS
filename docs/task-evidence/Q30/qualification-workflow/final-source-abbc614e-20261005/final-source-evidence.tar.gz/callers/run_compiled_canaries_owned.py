"""Task caller of the maintained process owner and existing compiled canaries."""
import ctypes,hashlib,json,os,sys
from datetime import datetime,timezone
from pathlib import Path
import serial_runner as owner
from receipts import write_exclusive
N=Path(__file__).resolve().parent
binding=json.loads((N/'epoch15-task-pointer.json').read_text())
T=Path(binding['taskRoot']); root=T/'compiled-canaries-controller'; root.mkdir(exist_ok=False)
physical=Path(r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe')
deps=Path(r'$OS_TEMP\q30-finish-0fa2512465\deps')
assert hashlib.sha256((N/'serial_runner.py').read_bytes()).hexdigest()=='19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6'
k=owner._api();k.GetCurrentProcess.restype=ctypes.c_void_p
image,birth=owner._identity(k,k.GetCurrentProcess(),physical.resolve(strict=True))
write_exclusive(root/'controller-identity.json',{'pid':os.getpid(),'executable':image,'creationFileTimeTicks':birth,'taskRoot':str(root),'scope':'Four existing compiled canaries/manifest freeze, no cold77'})
argv=[str(physical),'-B',str(N/'run_epoch15_canaries.py'),'--tag','compiled-canaries-py313','--dependency-path',str(deps),'--host-python',str(physical)]
child=None;waited=None
result={'status':'FAIL','startedUtc':datetime.now(timezone.utc).isoformat(),'operationLimitMilliseconds':900000,'cleanupLimitMilliseconds':15000,'sourceIdentity':binding['sourceIdentity'],'argv':argv,'errors':[]}
try:
    child=owner._spawn(k,{'executable':physical.resolve(strict=True)},argv,root)
    result['process']={key:child[value] for key,value in [('pid','pid'),('creationFileTimeTicks','creationTicks'),('executable','image'),('commandSha256','commandSha256')]}
    write_exclusive(root/'launch.json',{**result,'status':'RUNNING'})
    waited=owner._wait(k,child,900000);result['operation']=waited
    stage=json.loads((T/'compiled-canaries-py313-stage-result.json').read_text()) if (T/'compiled-canaries-py313-stage-result.json').exists() else None
    result['stage']=stage
    result['status']='PASS' if waited['exitCode']==0 and waited['reason'] is None and waited['cleanup']['cleanupVerified'] and stage and stage['status']=='PASS' else 'FAIL'
except BaseException as error:
    result['errors'].append(type(error).__name__+': '+str(error))
    if child is not None and waited is None: result['emergencyCleanup']=owner._wait(k,child,0)
finally:
    if child is not None:
        for key in ['job','thread','proc']:
            if child.get(key) and not k.CloseHandle(child[key]): result['errors'].append('CloseHandle failed '+key)
            child[key]=None
    if result['errors']:result['status']='FAIL'
    result['finishedUtc']=datetime.now(timezone.utc).isoformat()
    write_exclusive(root/'result.json',result)
print(json.dumps({'status':result['status'],'root':str(root),'errors':result['errors']}),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
