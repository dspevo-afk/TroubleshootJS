import hashlib,json,re,sys
from pathlib import Path
from types import SimpleNamespace
N=Path(__file__).resolve().parent
pointer=json.loads((N/'epoch15-task-pointer.json').read_text());T=Path(pointer['taskRoot'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
matched=N/'run_root75_matched_diagnostic.py';text=matched.read_text(encoding='utf-8')
assert text.count('"currentRepository1354"')==1 and text.count('"sourceFiles": 1354,')==1
text=text.replace('"currentRepository1354"','"currentRepository" + str(len(variants["current"]["snapshot"]["files"]))')
text=text.replace('"sourceFiles": 1354,','"sourceFiles": len(v["snapshot"]["files"]),')
matched.write_text(text,encoding='utf-8',newline='\r\n')
worker=N/'cold77_case_worker.py';text=worker.read_text(encoding='utf-8');assert len(re.findall(r"MATCHED_SHA = '[0-9a-f]{64}'",text))==1
text=re.sub(r"MATCHED_SHA = '[0-9a-f]{64}'","MATCHED_SHA = '"+sha(matched)+"'",text,count=1)
worker.write_text(text,encoding='utf-8',newline='\r\n')
import cold77_case_worker as case
from cold77_batch import WINDOW_MS
from receipts import LIMITS,write_exclusive
roles=json.loads((N/'test-roles.json').read_text());args=SimpleNamespace(**{k:Path(v) for k,v in roles.items()})
binding,variant,reader,loader=case.audit_inputs(args)
assert binding['repositoryInputs']==1355 and binding['baseHead']=='abbc614e9456d9fae56274da583175f8721a84c2'
write_exclusive(T/'fresh-cold-input-audit.json',{'status':'PASS_OFFLINE_INPUT_AUDIT','inputBinding':binding,'currentSourceInputs':1355,'planRoots':77,'candidateManifests':308,'coldAppRun':False})
negatives=[]
for label,role in [('stale-pointer','pointer'),('changed-loader','matched_helper')]:
    changed=SimpleNamespace(**vars(args))
    if role=='pointer': changed.pointer=N.parent/'epoch15-task-pointer.json'
    else:
        bad=T/'changed-loader-negative.py';write_exclusive(bad,b'') if False else None
        bad.write_bytes(matched.read_bytes()+b'\n# Invalid exact-byte negative; never executed\n');changed.matched_helper=bad
    try:case.audit_inputs(changed)
    except Exception as error:negatives.append({'case':label,'status':'EXPECTED_REJECTED','reason':type(error).__name__+': '+str(error)})
    else:raise AssertionError('Binding negative admitted '+label)
write_exclusive(T/'current-binding-negative-canaries.json',{'status':'PASS','scope':'Actual exact-source loader/pointer binding positive and negative checks; no browser or fabricated app receipts','negativeCases':negatives})
manifest={'schema':1,'limits':dict(LIMITS),'windowMs':WINDOW_MS,'inputBinding':binding,'sources':{name:{'sha256':sha(N/name),'size':(N/name).stat().st_size} for name in ['cold77_batch.py','cold77_case_worker.py']}}
write_exclusive(N/'cold77-candidate-manifest.json',manifest)
audit=json.loads((T/'cold-owner-adapter-audit.json').read_text());audit['changes'][0]['currentSha256']=sha(matched);audit['changes'][0]['scope']+='; report-only count fields derived from the selected snapshot';audit['changes'][1]['currentSha256']=sha(worker)
write_exclusive(T/'cold-owner-adapter-final-audit.json',audit)
print(json.dumps({'status':'PASS_CURRENT_COLD77_FREEZE_AND_BINDING_CANARIES','manifestSha256':sha(N/'cold77-candidate-manifest.json'),'inputBinding':binding,'negativeCases':negatives}),flush=True)
