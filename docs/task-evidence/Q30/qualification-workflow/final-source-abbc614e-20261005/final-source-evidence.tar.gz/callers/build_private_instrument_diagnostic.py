"""One-shot private instrument build; preserves the existing qualification gate.

Reuse the corrected source-copy/audit owners and maintained JDK8/GWT command.
This does not call their cold77-dependent qualification entrypoint or certify it.
"""
import ctypes, hashlib, importlib.util, json, os, subprocess, tempfile, uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import serial_runner as owner
from receipts import write_exclusive

N=Path(__file__).resolve().parent
pin=json.loads((N/'epoch15-task-pointer.json').read_text())
T=Path(pin['taskRoot']); R=Path(r'$REPO')
helper=N.parent/'run_epoch15_private_menu.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(helper)=='3847637a0c8281705f6cb061ebec4a916d6e3ff26e56717d4afad71d65fe079f'
assert sha(N/'serial_runner.py')=='19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6'
spec=importlib.util.spec_from_file_location('retained_private_copy_audit',helper)
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
api.EXPECTED_RAW_INPUTS=1355
api.EXPECTED_RAW_ROOT_COUNTS={'src':1132,'tests':174,'war':29,'scripts':20}
snapshot=json.loads((T/'source-snapshot.json').read_text())
prepare=json.loads((T/'isolated/prepare-receipt.json').read_text())
assert prepare['status']=='PREPARED'
assert snapshot['schema']==1 and prepare['sourceFileCount']==1355
assert snapshot['baseHead']==prepare['baseHead']==pin['baseHead']=='abbc614e9456d9fae56274da583175f8721a84c2'
assert snapshot['sourceIdentity']==prepare['sourceIdentity']==pin['sourceIdentity']=='49bff7525b019d321a821eeafb7bb15ccc0fa5d101442820dabccded5126a45c'
assert sha(T/'source-snapshot.json')==sha(T/'isolated/source-snapshot.json')==prepare['sourceSnapshotSha256']
assert len(snapshot['files'])==1355 and dict(Counter(row['path'].split('/')[0] for row in snapshot['files']))==api.EXPECTED_RAW_ROOT_COUNTS
canonical={key:snapshot[key] for key in ['schema','baseHead','files']}
assert hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')).hexdigest()==pin['sourceIdentity']
api.EXPECTED_BASE_HEAD=pin['baseHead']
api.EXPECTED_SOURCE_IDENTITY=pin['sourceIdentity']
git=['git','-c','safe.directory='+R.as_posix()]
assert subprocess.check_output(git+['rev-parse','HEAD'],cwd=R,text=True).strip()==pin['baseHead']
tracked=subprocess.check_output(git+['ls-files','--','src','war','scripts','tests'],cwd=R,text=True).splitlines()
assert sorted(tracked)==sorted(row['path'] for row in snapshot['files'])
repo_check=api.validate_repo_inputs(snapshot)
assert sha(T/'acceptance-plan.json')==pin['continuedPlanSha256']
assert (R/api.TARGET_CATALOG).read_bytes().count(api.FALSE_REGISTRATION)==1
failed=Path(r'$COLD_FAILED')
assert json.loads((failed/'controller-result.json').read_text())['qualified'] is False
physical=api.HOST_PYTHON.resolve(strict=True)
k=owner._api();k.GetCurrentProcess.restype=ctypes.c_void_p
image,birth=owner._identity(k,k.GetCurrentProcess(),physical)
out=T/'private-instrument-diagnostic';out.mkdir(exist_ok=False)
app=T.parent/('q30-private-instrument-'+uuid.uuid4().hex);app.mkdir(exist_ok=False)
record={'schema':1,'scope':'PRIVATE_INSTRUMENT_DIAGNOSTIC_ONLY','status':'RUNNING','acceptanceStatus':'NOT_ASSESSED','qualificationGate':'NOT_RUN; original gate remains cold77 dependent','cold77':'FAIL; 2 PASS, seed10014 TIMEOUT90621ms, 74 NOT_RUN; focused pass is not substitution','baseHead':pin['baseHead'],'sourceIdentity':pin['sourceIdentity'],'rawInputCount':1355,'privateSourceRoot':str(app),'helperSha256':sha(helper),'driverSha256':sha(__file__),'repoInputPreflight':repo_check,'controller':{'pid':os.getpid(),'executable':image,'creationFileTimeTicks':birth},'startedUtc':datetime.now(timezone.utc).isoformat(),'errors':[]}
write_exclusive(out/'launch.json',record)
child=None;waited=None
try:
    assert len(api.copy_bound_source(snapshot,app))==1355
    support=api.copy_build_inputs(app,snapshot)
    delta=api.copy_source_delta(snapshot,app)
    expected=api.expected_raw_source_inventory(snapshot,delta)
    assert api.inventory_tree(app,'war/circuitjs1',allow_missing=True)==[]
    record['sourceDelta']=delta;record['buildSupport']=support
    record['rawBefore']=api.require_inventory_matches(api.inventory_raw_source_roots(app),expected,'private diagnostic before build')
    pwsh=Path(r'$USER_HOME\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe').resolve(strict=True)
    argv=[str(pwsh),'-NoLogo','-NoProfile','-File',str(app/api.BUILD_SCRIPT),'-JavaHome',str(api.JAVA_HOME),'-Target','Compile','-Style','OBF','-ProcessTimeoutSeconds','900']
    record['buildCommand']=argv
    child=owner._spawn(k,{'executable':pwsh},argv,out)
    record['buildProcess']={key:child[value] for key,value in [('pid','pid'),('creationFileTimeTicks','creationTicks'),('executable','image'),('commandSha256','commandSha256')]}
    write_exclusive(out/'build-launch.json',record)
    waited=owner._wait(k,child,1020000);record['operation']=waited
    assert waited['exitCode']==0 and waited['reason'] is None and waited['cleanup']['cleanupVerified'] and waited['cleanup']['jobActiveProcesses']==0 and waited['cleanup']['drainsComplete']
    log=(out/'stdout.log').read_bytes()+(out/'stderr.log').read_bytes()
    assert b'Compilation succeeded --' in log and b'Linking succeeded --' in log and b'BUILD_INFRASTRUCTURE:' not in log
    compiled=api.inventory_tree(app,'war/circuitjs1')
    assert len(compiled)==357
    permutations=api.validate_five_gwt_permutations(compiled,'private instrument diagnostic')
    deploy=api.inventory_tree(app,'war/WEB-INF/deploy')
    assert len(deploy)==6
    record['rawAfter']=api.require_inventory_matches(api.inventory_raw_source_roots(app),expected,'private diagnostic after build')
    api.verify_build_support_unchanged(support)
    record['repoInputAfter']=api.validate_repo_inputs(snapshot)
    assert (R/api.TARGET_CATALOG).read_bytes().count(api.FALSE_REGISTRATION)==1
    record['compiled']=compiled;record['permutations']=permutations;record['deployment']=deploy
    write_exclusive(out/'private-source-snapshot.json',{'schema':1,'scope':record['scope'],'baseHead':pin['baseHead'],'sourceIdentity':pin['sourceIdentity'],'files':expected,'sourceDelta':delta})
    record['status']='PASS_PRIVATE_INSTRUMENT_BUILD_ONLY'
except BaseException as error:
    record['errors'].append(type(error).__name__+': '+str(error));record['status']='FAIL'
    if child is not None and waited is None:record['emergencyCleanup']=owner._wait(k,child,0)
finally:
    if child is not None:
        for key in ['job','thread','proc']:
            if child.get(key) and not k.CloseHandle(child[key]):record['errors'].append('CloseHandle failed '+key)
            child[key]=None
    if record['errors']:record['status']='FAIL'
    record['finishedUtc']=datetime.now(timezone.utc).isoformat()
    write_exclusive(out/'result.json',record)
print(json.dumps({'status':record['status'],'root':str(out),'app':str(app),'errors':record['errors']}),flush=True)
raise SystemExit(0 if record['status']=='PASS_PRIVATE_INSTRUMENT_BUILD_ONLY' else 1)
