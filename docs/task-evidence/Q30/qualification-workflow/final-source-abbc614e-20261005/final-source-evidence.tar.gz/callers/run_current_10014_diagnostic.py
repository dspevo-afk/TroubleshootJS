"""Focused diagnostic caller of the unchanged maintained serial case owner.

One predeclared failed root, not a cold77 qualification or replacement receipt.
"""
import ctypes, hashlib, json, os, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
import serial_runner as owner
from receipts import write_exclusive

N=Path(__file__).resolve().parent
binding=json.loads((N/'epoch15-task-pointer.json').read_text())
T=Path(binding['taskRoot'])
failed=Path(r'$COLD_FAILED')
spec=json.loads((failed/'batch-spec.json').read_text())
assert spec['sourceIdentity']==binding['sourceIdentity']
assert spec['baseHead']==binding['baseHead']
assert spec['limits']=={'jobMillis':90000,'sharedWork':640,'activeOperationMillis':5000}
assert hashlib.sha256((N/'serial_runner.py').read_bytes()).hexdigest()=='19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6'
steps=[row for row in spec['steps'] if row['rootSeed']=='10014']
assert len(steps)==1 and steps[0]['outerTimeoutMs']==180000
spec['steps']=steps
physical=Path(r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe')
k=owner._api();k.GetCurrentProcess.restype=ctypes.c_void_p
image,birth=owner._identity(k,k.GetCurrentProcess(),physical.resolve(strict=True))
root=T.parent/('q30-cold10014-diagnostic-'+uuid.uuid4().hex)
record={'scope':'Single diagnostic reproduction of retained cold77 TIMEOUT; no qualification substitution','sourceIdentity':binding['sourceIdentity'],'baseHead':binding['baseHead'],'pid':os.getpid(),'executable':image,'creationFileTimeTicks':birth,'sequenceRoot':str(root),'startedUtc':datetime.now(timezone.utc).isoformat(),'limits':spec['limits']}
write_exclusive(T/'focused-10014-diagnostic-owner.json',record)
print(json.dumps({'status':'RUNNING_FOCUSED_DIAGNOSTIC',**record}),flush=True)
summary=owner.run_serial(spec,root)
write_exclusive(T/'focused-10014-diagnostic-result.json',{'scope':record['scope'],'root':str(root),'finishedUtc':datetime.now(timezone.utc).isoformat(),'summary':summary})
print(json.dumps({'outcome':summary['outcome'],'root':str(root),'rows':summary['rows']}),flush=True)
raise SystemExit(0 if summary['outcome']=='PASS' else 1)
