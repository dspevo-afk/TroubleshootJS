$ErrorActionPreference='Stop'
$batch='$COLD_FAILED'
$task='$TASK_ROOT'
$records=@()
function AddRecorded($recordedPid,$created,$exe,$source,$fileTime) {
 $live=Get-CimInstance Win32_Process -Filter ('ProcessId='+$recordedPid)
 $same=$false
 if($null -ne $live){
  $birthMatches=if($fileTime){$live.CreationDate.ToUniversalTime().ToFileTimeUtc() -eq [long]$created}else{$live.CreationDate.ToUniversalTime() -eq [DateTime]::Parse($created).ToUniversalTime()}
  $same=$birthMatches -and $live.ExecutablePath -eq $exe
 }
 $script:records+=@{pid=$recordedPid;created=$created;executable=$exe;source=$source;exactInstancePresent=$same;pidPresent=$null -ne $live}
}
$owner=Get-Content -LiteralPath (Join-Path $task 'cold77-normal-launch\normal-owner.json') -Raw|ConvertFrom-Json -DateKind String
AddRecorded $owner.pid $owner.createdUtc $owner.executable 'normal-controller' $false
$launchOwner=Get-Content -LiteralPath (Join-Path $task 'cold77-normal-launch\launcher-identity.json') -Raw|ConvertFrom-Json -DateKind String
AddRecorded $launchOwner.pid $launchOwner.createdUtc $launchOwner.executable 'powershell-launcher' $false
$outer=Get-Content -LiteralPath (Join-Path $batch 'controller-result.json') -Raw|ConvertFrom-Json -DateKind String
AddRecorded $outer.process.pid $outer.process.creationFileTimeTicks $outer.process.executable 'serial-controller' $true
$ports=@()
foreach($case in @(Get-ChildItem -LiteralPath (Join-Path $batch 'sequence\cases') -Directory)){
 $step=Get-Content -LiteralPath (Join-Path $case.FullName 'step-result.json') -Raw|ConvertFrom-Json -DateKind String
 AddRecorded $step.process.pid $step.process.creationFileTimeTicks $step.process.executable ($case.Name+'/worker') $true
 $identity=Get-Content -LiteralPath (Join-Path $case.FullName 'host-output\identity.json') -Raw|ConvertFrom-Json -DateKind String
 AddRecorded $identity.runner.pid $identity.runner.created $identity.runner.executable ($case.Name+'/host') $false
 foreach($edge in $identity.edgeProcessesBeforeCases){AddRecorded $edge.pid $edge.created $edge.ExecutablePath ($case.Name+'/edge') $false}
 $owned=Get-Content -LiteralPath (Join-Path $case.FullName 'host-output\owned-processes-before-close.json') -Raw|ConvertFrom-Json -DateKind String
 foreach($p in $owned){AddRecorded $p.pid $p.created $p.ExecutablePath ($case.Name+'/before-close') $false}
 $listeners=@(Get-NetTCPConnection -LocalPort $identity.port -State Listen -ErrorAction SilentlyContinue)
 $ports+=@{case=$case.Name;port=$identity.port;listenerCount=$listeners.Count}
}
$unique=@($records | Sort-Object pid,created,executable -Unique)
$survivors=@($unique|Where-Object exactInstancePresent)
$open=@($ports|Where-Object {$_.listenerCount -gt 0})
$out=Join-Path $task 'cold77-failed-attempt-independent-release.json'
if(Test-Path -LiteralPath $out){throw 'Preserve existing release audit'}
$result=@{status=if($survivors.Count -eq 0 -and $open.Count -eq 0){'PASS_EXACT_INSTANCES_AND_PORTS_RELEASED'}else{'BLOCKED'};observedUtc=[DateTime]::UtcNow.ToString('o');scope='Recorded failed cold77 launcher/controller/workers/host/browser instances and three owned ports only';processes=$unique;ports=$ports;terminationAttempted=$false;qualification='FAIL_COLD77; release success does not change timeout'}
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $out
@{status=$result.status;instances=$unique.Count;ports=$ports.Count;output=$out}|ConvertTo-Json
if($survivors.Count -gt 0 -or $open.Count -gt 0){exit 2}
