$ErrorActionPreference='Stop'
$repo='$REPO'
$pin=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'epoch15-task-pointer.json') -Raw|ConvertFrom-Json
$task=$pin.taskRoot
$script=Join-Path $repo 'docs\task-evidence\Q30\resume-20261002\archive-q30-sources.ps1'
if((Get-FileHash -LiteralPath $script -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'd14c811e487c0817003d5171fc0c1c53820c5d213e05a9c2c5724fb808b9fb8d'){throw 'Maintained archive owner changed'}
$snapshot=Get-Content -LiteralPath (Join-Path $task 'source-snapshot.json') -Raw|ConvertFrom-Json
$prepared=Get-Content -LiteralPath (Join-Path $task 'isolated\prepare-receipt.json') -Raw|ConvertFrom-Json
if($prepared.status -ne 'PREPARED' -or $snapshot.sourceIdentity -ne $pin.sourceIdentity -or $snapshot.baseHead -ne $pin.baseHead -or $snapshot.files.Count -ne 1355){throw 'Current prepared source binding differs'}
foreach($row in $snapshot.files){if((Get-FileHash -LiteralPath (Join-Path $repo $row.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Raw source changed: '+$row.path)}}
if((Get-FileHash -LiteralPath (Join-Path $task 'isolated\source-snapshot.json') -Algorithm SHA256).Hash.ToLowerInvariant() -ne $prepared.sourceSnapshotSha256){throw 'Prepared snapshot hash differs'}
$archive=Join-Path $task 'current-source-archive'
$log=Join-Path $task 'current-source-archive.log'
$resultPath=Join-Path $task 'current-source-archive-result.json'
$ownerPath=Join-Path $task 'current-source-archive-owner.json'
foreach($path in @($archive,$log,$resultPath,$ownerPath)){if(Test-Path -LiteralPath $path){throw ('Preserve existing archive output '+$path)}}
$self=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID)
@{pid=$PID;createdUtc=$self.CreationDate.ToUniversalTime().ToString('o');executable=$self.ExecutablePath;command=$self.CommandLine;taskRoot=$task;scope='Direct unchanged maintained isolated source archive; acceptance NOT_ASSESSED'}|ConvertTo-Json|Set-Content -LiteralPath $ownerPath
# Process-local Git ownership authorization only; no global or repository config.
$env:GIT_CONFIG_COUNT='1';$env:GIT_CONFIG_KEY_0='safe.directory';$env:GIT_CONFIG_VALUE_0=$repo
$clock=[Diagnostics.Stopwatch]::StartNew();$started=[DateTime]::UtcNow
try{& $script -TaskRoot $task -Repo $repo -ArchiveRoot $archive -CandidateNames isolated -SkipProfile *> $log;$code=if($null -eq $LASTEXITCODE){0}else{$LASTEXITCODE}}
catch{$_|Out-String|Add-Content -LiteralPath $log;$code=1}
$clock.Stop()
$manifestPath=Join-Path $archive 'archive-manifest.json'
$manifest=if(Test-Path -LiteralPath $manifestPath){Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json}else{$null}
$valid=$code -eq 0 -and $manifest.archiveRunStatus -eq 'PASS' -and $manifest.acceptanceStatus -eq 'NOT_ASSESSED' -and $manifest.candidates.Count -eq 1 -and $manifest.invalidCandidates.Count -eq 0 -and $manifest.candidates[0].sourceFileCount -eq 1355 -and $manifest.candidates[0].sourceIdentity -eq $pin.sourceIdentity
@{status=if($valid){'PASS_SOURCE_ARCHIVE_ONLY'}else{'FAIL'};exitCode=$code;acceptanceStatus='NOT_ASSESSED';baseHead=$pin.baseHead;sourceIdentity=$pin.sourceIdentity;sourceInputs=1355;archiveRoot=$archive;startedUtc=$started.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');elapsedSeconds=$clock.Elapsed.TotalSeconds;cleanupElapsedSeconds='NOT_RECORDED_SEPARATELY';manifestSha256=if($null -ne $manifest){(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null}}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $resultPath
Get-Content -LiteralPath $log -Tail 3
if(-not $valid){exit 1}
