param([ValidateSet('native-full','native-append')][string]$Batch='native-full')
$ErrorActionPreference='Stop'
$workspace=$PSScriptRoot
$repo='$REPO'
$binding=Get-Content -LiteralPath (Join-Path $workspace 'epoch15-task-pointer.json') -Raw | ConvertFrom-Json
$integration=Get-Content -LiteralPath (Join-Path $workspace 'integration-pointer.json') -Raw | ConvertFrom-Json
if($binding.taskRoot -ne $integration.taskRoot -or $binding.baseHead -ne $integration.baseHead){throw 'Epoch15 task pointer differs from integrated candidate'}
$task=$binding.taskRoot
$snapshot=Get-Content -LiteralPath (Join-Path $task 'source-snapshot.json') -Raw | ConvertFrom-Json
if($snapshot.sourceIdentity -ne $binding.sourceIdentity -or $snapshot.baseHead -ne $binding.baseHead -or $snapshot.files.Count -ne 1355){throw 'Prepared source snapshot identity/count differs'}
foreach($row in $snapshot.files){if((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $repo $row.path)).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source changed: '+$row.path)}}
$planPath=Join-Path $task 'acceptance-plan.json'
if((Get-FileHash -Algorithm SHA256 -LiteralPath $planPath).Hash.ToLowerInvariant() -ne $binding.continuedPlanSha256){throw 'Frozen continuation bytes changed'}
$plan=Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
if($plan.baseHead -ne $binding.baseHead -or $plan.cases.Count -ne 77 -or $plan.serviceAndSensitivitySeeds.Count -ne 21){throw 'Frozen cohort head/count changed'}
$names=@([regex]::Matches([IO.File]::ReadAllText((Join-Path $repo 'scripts\verify-current-contracts.ps1')), "@\{ Name = '([^']+)'; Marker = ") | ForEach-Object {$_.Groups[1].Value})
if($names.Count -ne 83){throw 'Native suite count changed'}
$log=Join-Path $task ($Batch+'.log');$resultPath=Join-Path $task ($Batch+'-result.json');$receipt=Join-Path $task ($Batch+'.txt')
if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $resultPath) -or (Test-Path -LiteralPath $receipt) -or (Test-Path -LiteralPath (Join-Path $task ($Batch+'-ownership.json')))){throw 'Preserve existing native output'}
$self=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID)
@{schema=1;pid=$PID;createdUtc=$self.CreationDate.ToUniversalTime().ToString('o');executable=$self.ExecutablePath;command=$self.CommandLine;taskRoot=$task;batch=$Batch} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $task ($Batch+'-ownership.json'))
$nativeArgs=@{JavaHome='$OS_TEMP\q30-finish-0fa2512465\jdk\jdk8u502-b07';PythonExe='$USER_HOME\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe';ReceiptOutputPath=$receipt;Q30ServiceSeeds=[long[]]@($plan.serviceAndSensitivitySeeds | ForEach-Object {[long]::Parse($_)});Q30SensitivitySeeds=[long[]]@($plan.serviceAndSensitivitySeeds | ForEach-Object {[long]::Parse($_)});Q30CorpusSeeds=[long[]]@($plan.cases[0..50] | ForEach-Object {[long]::Parse($_.seed)})}
if($Batch -eq 'native-append'){$nativeArgs.Suite=@('Q30NormalCorpusContractTest');$nativeArgs.Q30CorpusSeeds=[long[]]@($plan.cases[51..76] | ForEach-Object {[long]::Parse($_.seed)})}
$started=[DateTime]::UtcNow;$timer=[Diagnostics.Stopwatch]::StartNew()
try{& (Join-Path $repo 'scripts\verify-current-contracts.ps1') @nativeArgs *> $log;$code=if($null -eq $LASTEXITCODE){0}else{$LASTEXITCODE}}
catch{$_ | Out-String | Add-Content -LiteralPath $log;$code=1}
$timer.Stop()
$content=Get-Content -LiteralPath $log -Raw
$finalMarker=if($Batch -eq 'native-full'){'PASS: current contracts; 83 Java suites, independent seed/value/role oracles and report protocol.'}else{'PASS: focused current contracts; 1 Java suites. Full matrix and independent oracles NOT RUN.'}
$complete=$content.Contains($finalMarker) -and $content.Contains('CLEANUP: current JVM contract classes and task-owned scratch removed.') -and -not $content.Contains('CURRENT_CONTRACT_FAILURE:')
@{schema=1;batch=$Batch;head=$binding.baseHead;consumedSourceIdentity=$snapshot.sourceIdentity;consumedInputsVerified=$snapshot.files.Count;startedUtc=$started.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');elapsedSeconds=$timer.Elapsed.TotalSeconds;exitCode=$code;status=if($code -eq 0 -and $complete){'COMMAND_PASS_PENDING_RECEIPT_REVIEW'}else{'FAIL'};complete=$complete;acceptancePlanSha256=$binding.continuedPlanSha256;serviceSeeds=@($nativeArgs.Q30ServiceSeeds | ForEach-Object {$_.ToString()});sensitivitySeeds=@($nativeArgs.Q30SensitivitySeeds | ForEach-Object {$_.ToString()});corpusSeeds=@($nativeArgs.Q30CorpusSeeds | ForEach-Object {$_.ToString()});suiteCount=if($Batch -eq 'native-full'){83}else{1};cleanupElapsedSeconds='NOT RECORDED separately'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $resultPath
Get-Content -LiteralPath $log -Tail 9
if($code -eq 0 -and -not $complete){exit 1}
exit $code
