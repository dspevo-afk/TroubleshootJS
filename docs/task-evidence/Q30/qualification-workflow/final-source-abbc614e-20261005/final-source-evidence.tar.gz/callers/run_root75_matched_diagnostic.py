"""Four bounded root-75 diagnostics (CURRENT, OLD, OLD, CURRENT), never qualification.

Root launches this with the bundled controller: python -B -u this_file --task-root <new-temp-root>
Uses the prepared apps directly, common pinned current host, maintained reader,
150-second host case and unchanged 90s/640/5s application budgets. No app copy/build.
"""
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import time

REPO = Path(r"$REPO")
HOST = Path("tests/qualification/q30-scale-acceptance/normal_screen_host.py")
READER = Path("tests/qualification/q30-scale-acceptance/q30_scale_reader.py")
BASE_READER = Path("tests/qualification/q30-normal-screen/q30_screen_reader.py")
HOST_SHA = "8da1af0f184cea190f17fb02629e4475013337558e32903e95992552723a4440"
HOST_PY = Path(r"C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe")
DEPS = Path(r"$OS_TEMP\q30-finish-0fa2512465\deps")
LIMITS = {"jobMillis": 90000, "sharedWork": 640, "activeOperationMillis": 5000}
TIMEOUT, OUTER = 150, 180
EXPECTED = {
    "current": ("abbc614e9456d9fae56274da583175f8721a84c2", "49bff7525b019d321a821eeafb7bb15ccc0fa5d101442820dabccded5126a45c", "q30-final-source-abbc614e-bbc566e8e9a741ed80cf14b904021f1e"),
    "old": ("7bdc23e8170e4a9e737b33daf4bb533f87468b22",
            "a3bd150019d00870a08896efd893c99aff120ce11a49f34cca0af07f33d59c31",
            "q30-epoch15-qualification-306d44cccd8d447abe0b257530b9354a"),
}
HERE = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def readj(path):
    raw = path.read_bytes()
    value = json.loads(raw.decode("utf-8"))
    need(isinstance(value, dict), "expected JSON object: " + str(path))
    return value, raw


def writej(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                    encoding="utf-8", newline="")


def safe_rel(text):
    need(isinstance(text, str) and text and ":" not in text and "\\" not in text,
         "unsafe relative path: " + repr(text))
    rel = PurePosixPath(text)
    need(not rel.is_absolute() and rel.as_posix() == text and
         all(part not in ("", ".", "..") for part in rel.parts), "unsafe path: " + text)
    return rel


def inside(root, rel):
    path = root.joinpath(*safe_rel(rel).parts).resolve(strict=True)
    base = root.resolve()
    need(base in path.parents and path.is_file(), "input escaped root/not file: " + rel)
    return path


def inventory(root, rows, verify=False):
    result = {}
    for row in rows:
        need(isinstance(row, dict), "malformed source row")
        rel = row.get("path")
        need(rel not in result, "duplicate source row: " + str(rel))
        data = inside(root, rel).read_bytes()
        actual = {"size": len(data), "sha256": digest(data)}
        if verify:
            need(type(row.get("size")) is int and row["size"] == actual["size"] and
                 row.get("sha256") == actual["sha256"], "source hash changed: " + rel)
        result[rel] = actual
    return result


def source_identity(head, rows):
    raw = json.dumps({"schema": 1, "baseHead": head, "files": rows}, sort_keys=True,
                     separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return digest(raw)


def app_state(v):
    app, snap, receipt = v["app"], v["snapshot"], v["receipt"]
    overlays = {}
    for row in receipt.get("overlayFiles", []):
        rel = row.get("path") if isinstance(row, dict) else None
        need(isinstance(rel, str), "malformed overlay row")
        data = inside(app, rel).read_bytes()
        need(type(row.get("size")) is int and len(data) == row["size"] and
             digest(data) == row.get("sha256"), "prepared overlay changed: " + rel)
        overlays[rel] = {"size": len(data), "sha256": digest(data)}
    cache = sorted((app / "war/circuitjs1").glob("*.cache.js"), key=lambda p: p.name.casefold())
    need(len(cache) == 5 and all(p.is_file() for p in cache), "expected exactly five GWT cache JS files")
    return {"appSources": inventory(app, snap["files"]), "overlays": overlays,
            "gwtCaches": {p.relative_to(app).as_posix(): {"size": p.stat().st_size, "sha256": sha(p)}
                          for p in cache}}


def load_variant(label, pointer_path):
    head, identity, tail = EXPECTED[label]
    pointer, pointer_raw = readj(pointer_path)
    task = Path(pointer["taskRoot"]).resolve(strict=True)
    need((pointer.get("baseHead"), pointer.get("sourceIdentity"), task.name) == (head, identity, tail),
         label + " pointer is not the authorized prepared root")
    root = task / "isolated"
    paths = {"snapshot": root / "source-snapshot.json", "receipt": root / "prepare-receipt.json",
             "plan": task / "scale-plan.json", "acceptance": task / "acceptance-plan.json"}
    data = {k: readj(p) for k, p in paths.items()}
    snap, snapraw = data["snapshot"]
    receipt, receiptraw = data["receipt"]
    plan, planraw = data["plan"]
    acceptance, acceptraw = data["acceptance"]
    need(len(snap.get("files", [])) == (1355 if label == "current" else 1354) and snap.get("baseHead") == head and
         snap.get("sourceIdentity") == identity and source_identity(head, snap["files"]) == identity,
         label + " snapshot identity/count mismatch")
    need(pointer.get("continuedPlanSha256") == digest(acceptraw) == plan.get("acceptancePlanSha256") and
         acceptance.get("baseHead") == plan.get("baseHead") == head, label + " acceptance binding mismatch")
    need(plan.get("sourceIdentity") == identity and plan.get("sourceSnapshotSha256") == digest(snapraw) and
         plan.get("sourceFiles") == snap["files"] == receipt.get("sourceFiles") and
         plan.get("limits") == LIMITS and plan.get("rootCount") == 77 and
         len(plan.get("cases", [])) == len(plan.get("coldOrder", [])) == 77, label + " scale plan changed")
    need(receipt.get("status") == "PREPARED" and receipt.get("sourceIdentity") == identity and
         receipt.get("baseHead") == head and receipt.get("sourceFileCount") == (1355 if label == "current" else 1354) and
         receipt.get("sourceSnapshotSha256") == digest(snapraw) and
         receipt.get("acceptancePlanSha256") == digest(acceptraw), label + " prep receipt mismatch")
    hostcopy = root / "host/normal_screen_host.py"
    need(sha(hostcopy) == receipt.get("hostRunnerSha256") == plan.get("hostRunnerSha256"),
         label + " retained host copy/plan pin mismatch")
    row = next((r for r in plan["cases"] if r.get("seed") == "75"), None)
    need(row is not None and type(row.get("manifestOrder")) is int and 0 <= row["manifestOrder"] < 77 and
         acceptance.get("cases", [])[row["manifestOrder"]].get("seed") == "75" and
         plan["coldOrder"] == acceptance.get("coldOrder") and len(row.get("candidates", [])) == 4,
         label + " seed-75 frozen root/candidate binding mismatch")
    return {"label": label, "pointerPath": pointer_path, "pointer": pointer,
            "pointerRaw": pointer_raw, "task": task, "app": root / "app", "snapshot": snap,
            "snapshotRaw": snapraw, "receipt": receipt, "receiptRaw": receiptraw,
            "plan": plan, "planRaw": planraw, "acceptance": acceptance,
            "acceptanceRaw": acceptraw, "paths": paths, "rootRow": row}


def plan_projection(p):
    return (p.get("coldOrder"), p.get("limits"), p.get("serviceAndSensitivitySeeds"),
            [{k: row.get(k) for k in ("manifestOrder", "seed", "canonical", "packages", "channels",
                                      "requestCanonical", "candidates")} for row in p.get("cases", [])])


def input_state(repo, variants, host, reader, base_reader):
    binding = {"host": {"sha256": sha(host), "size": host.stat().st_size},
               "scaleReader": {"sha256": sha(reader), "size": reader.stat().st_size},
               "baseReader": {"sha256": sha(base_reader), "size": base_reader.stat().st_size},
               "helper": {"sha256": sha(Path(__file__)), "size": Path(__file__).stat().st_size}}
    result = {"currentRepository" + str(len(variants["current"]["snapshot"]["files"])): inventory(repo, variants["current"]["snapshot"]["files"], True),
              "currentApp": app_state(variants["current"]), "oldApp": app_state(variants["old"]),
              "bindings": binding}
    for label, v in variants.items():
        for key, path in (("pointer", v["pointerPath"]), ("snapshot", v["paths"]["snapshot"]),
                          ("receipt", v["paths"]["receipt"]), ("plan", v["paths"]["plan"]),
                          ("acceptance", v["paths"]["acceptance"]),
                          ("preparedHost", v["task"] / "isolated/host/normal_screen_host.py")):
            result["bindings"][label + "." + key] = {"sha256": sha(path), "size": path.stat().st_size}
    return result


class FILETIME(ctypes.Structure):
    _fields_ = [("low", wintypes.DWORD), ("high", wintypes.DWORD)]


def filetime_utc(ft):
    return datetime.fromtimestamp(((ft.high << 32) | ft.low) / 10_000_000 - 11_644_473_600,
                                  timezone.utc).isoformat()


def process_times(handle):
    f = [FILETIME() for _ in range(4)]
    fn = ctypes.WinDLL("kernel32", use_last_error=True).GetProcessTimes
    fn.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(FILETIME)] * 4
    fn.restype = wintypes.BOOL
    need(fn(wintypes.HANDLE(handle), *(ctypes.byref(x) for x in f)), "GetProcessTimes failed")
    return filetime_utc(f[0])


def controller_identity():
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    cur = k.GetCurrentProcess; cur.restype = wintypes.HANDLE
    buf = ctypes.create_unicode_buffer(32768)
    getname = k.GetModuleFileNameW
    getname.argtypes = [wintypes.HANDLE, wintypes.LPWSTR, wintypes.DWORD]
    getname.restype = wintypes.DWORD
    n = getname(None, buf, len(buf))
    need(n > 0 and n < len(buf), "GetModuleFileNameW failed")
    return {"pid": os.getpid(), "createdUtc": process_times(cur()), "executable": buf.value,
            "reportedExecutable": sys.executable, "pythonVersion": sys.version}


def host_runtime(host_python, deps, output, env):
    code = ("import importlib.metadata as m, importlib.util, json, pathlib, sys, greenlet; "
            "import playwright.sync_api; "
            "p=importlib.util.find_spec('playwright'); g=importlib.util.find_spec('greenlet'); "
            "print(json.dumps({'version':list(sys.version_info[:3]),'playwright':m.version('playwright'),"
            "'greenlet':m.version('greenlet'),'playwrightOrigin':p.origin,'greenletOrigin':g.origin}))")
    r = subprocess.run([str(host_python), "-B", "-c", code], capture_output=True,
                       timeout=20, env=env, shell=False)
    (output / "host-runtime.stdout.bin").write_bytes(r.stdout)
    (output / "host-runtime.stderr.bin").write_bytes(r.stderr)
    need(r.returncode == 0, "pinned physical host Python imports failed")
    doc = json.loads(r.stdout.decode("utf-8")); root = deps.resolve(strict=True)
    for k in ("playwrightOrigin", "greenletOrigin"):
        p = Path(doc[k]).resolve(strict=True)
        need(root in p.parents, k + " loaded outside retained deps")
    need(doc.get("version") == [3, 13, 14] and doc.get("playwright") == "1.63.0" and
         doc.get("greenlet") == "3.5.6", "host Python/dependency version mismatch")
    doc["depsPath"] = str(root)
    return doc


def run_case(n, label, v, output, host, hostpy, reader, env):
    name = "%02d-%s-seed75" % (n, label.lower()); root = output / name; root.mkdir()
    dest, specpath = root / "host", root / "case-spec.json"
    spec = {"cases": [{"name": "cold-75", "path": "circuitjs.html?lang=en&tsjNormalMode=cold&tsjNormalSeed=75",
                        "stateAttribute": "data-tsj-q30-normal-state", "reportAttribute": "data-tsj-q30-normal-report",
                        "expectedPrefix": "SCREEN_DONE", "terminalPrefixes": ["SCREEN_DONE"],
                        "timeoutSeconds": TIMEOUT}]}
    writej(specpath, spec)
    row = {"index": n, "variant": label, "seed": "75", "qualification": False,
           "startedUtc": now(), "planSha256": sha(v["paths"]["plan"]),
           "acceptanceSha256": sha(v["paths"]["acceptance"]), "sourceIdentity": v["pointer"]["sourceIdentity"],
           "baseHead": v["pointer"]["baseHead"], "commonHostSha256": sha(host),
           "frozenHostRunnerSha256": v["plan"].get("hostRunnerSha256"),
           "specSha256": sha(specpath), "hostOuterLimitSeconds": OUTER}
    log = root / "host.stdout.bin"
    cmd = [str(hostpy), "-B", str(host), str(v["app"]), str(dest), str(specpath)]
    row["hostCommandSha256"] = digest(json.dumps(cmd).encode("utf-8"))
    start = time.monotonic()
    try:
        with log.open("xb") as stream:
            child = subprocess.Popen(cmd, stdout=stream, stderr=subprocess.STDOUT, env=env, shell=False)
            row["hostProcess"] = {"pid": child.pid, "executable": str(hostpy)}
            try: row["hostProcess"]["createdUtc"] = process_times(child._handle)
            except Exception as e: row["hostIdentityError"] = type(e).__name__ + ": " + str(e)
            writej(root / "case-progress.json", row)
            try: row["hostExitCode"] = child.wait(timeout=OUTER)
            except subprocess.TimeoutExpired:
                row.update({"status": "HOST_OUTER_TIMEOUT", "hostStillRunning": child.poll() is None,
                            "elapsedSeconds": round(time.monotonic() - start, 3)})
                writej(root / "case-progress.json", row)
                return row, False
    except Exception as e:
        row.update({"status": "HOST_LAUNCH_OR_OWNERSHIP_FAIL", "error": type(e).__name__ + ": " + str(e)})
        writej(root / "case-progress.json", row)
        return row, False
    row["hostLogSha256"] = sha(log); row["elapsedSeconds"] = round(time.monotonic() - start, 3)
    result_path, report_path = dest / "result.json", dest / "cases/001-cold-75.report.json"
    if not result_path.is_file() or not report_path.is_file():
        row.update({"status": "HOST_RECEIPT_MISSING", "missingResult": not result_path.is_file(),
                    "missingReport": not report_path.is_file()})
        writej(root / "case-result.json", row); return row, False
    hr, hraw = readj(result_path); report, rraw = readj(report_path)
    audit, clean = hr.get("inputAudit") or {}, hr.get("cleanup") or {}
    expected = v["plan"].get("preparedInputIdentity") or {}; common = sha(host)
    host_ok = (row.get("hostExitCode") == 0 and hr.get("outcome") == "PASS" and hr.get("errors") == [] and
               hr.get("caseCount") == 1 and len(hr.get("cases", [])) == 1 and audit.get("status") == "PASS" and
               "createdUtc" in row.get("hostProcess", {}) and
               audit.get("sourceSha256Before") == expected.get("sourceSha256") == audit.get("sourceSha256After") and
               audit.get("webSha256Before") == expected.get("webSha256") == audit.get("webSha256After") and
               audit.get("fileCountBefore") == expected.get("fileCount") == audit.get("fileCountAfter") and
               audit.get("runnerBeforeSha256") == common == audit.get("runnerAfterSha256"))
    clean_ok = clean.get("status") == "PASS" and clean.get("serverStopped") is True and \
               clean.get("ownedSurvivors") == [] and clean.get("errors") == []
    row.update({"hostResultSha256": digest(hraw), "reportSha256": digest(rraw),
                "hostOutcome": hr.get("outcome"), "hostInputAudit": audit, "cleanup": clean,
                "browser": (hr.get("identity") or {}).get("browser"),
                "browserStartupMilliseconds": hr.get("browserStartupMilliseconds"),
                "actualHostPass": host_ok, "actualCleanupPass": clean_ok,
                "app": {k: report.get(k) for k in ("classification", "applicationOutcome", "terminalStage",
                          "generationElapsedMs", "startToCallbackWallMs", "workUnits", "maxActiveOperationMs",
                          "maxCoordinatorAdvanceMs", "headroomMs", "yields", "routingElapsedMsNested",
                          "proofElapsedMsNested", "stages", "attempts", "candidates", "matrixObservations",
                          "observedMatrixOrderMax")}})
    reader_cmd = [sys.executable, "-B", str(reader), "--report", str(report_path), "--plan", str(v["paths"]["plan"]),
                  "--host-record", str(result_path), "--acceptance-plan", str(v["paths"]["acceptance"])]
    try:
        rr = subprocess.run(reader_cmd, capture_output=True, timeout=45, env=env, shell=False)
        (root / "reader.stdout.bin").write_bytes(rr.stdout); (root / "reader.stderr.bin").write_bytes(rr.stderr)
        checked = json.loads(rr.stdout.decode("utf-8")); row["readerExitCode"] = rr.returncode
        row["reader"] = {"status": checked.get("status"), "appStatus": (checked.get("app") or {}).get("status"),
                         "hostStatus": (checked.get("host") or {}).get("status"),
                         "hostErrors": (checked.get("host") or {}).get("errors"),
                         "appErrors": (checked.get("app") or {}).get("errors"),
                         "synthetic": checked.get("synthetic")}
    except Exception as e:
        row["readerError"] = type(e).__name__ + ": " + str(e)
        if isinstance(e, subprocess.TimeoutExpired):
            (root / "reader.stdout.bin").write_bytes(e.output or b"")
            (root / "reader.stderr.bin").write_bytes(e.stderr or b"")
    errs = row.get("reader", {}).get("hostErrors") or []
    exact_old_pin = ["host runner hash/count differs from frozen plan",
                     "host runner after hash/count differs from frozen plan"]
    old_pin_only = v["plan"].get("hostRunnerSha256") != common and errs == exact_old_pin
    appstatus = row.get("reader", {}).get("appStatus")
    app_timeout = report.get("classification") == report.get("applicationOutcome") == "TIMEOUT" and \
                 appstatus == "COMPLETED_NONPASS"
    ok = bool(host_ok and clean_ok and row.get("reader", {}).get("synthetic") is False and
              row.get("readerExitCode") in (0, 1) and (appstatus == "APP_PASS" or app_timeout) and
              (row.get("reader", {}).get("hostStatus") == "HOST_PASS" or old_pin_only))
    row["originalPlanHostPinMismatchOnly"] = bool(old_pin_only)
    row["continueReason"] = ("APP_PASS with host+cleanup PASS" if appstatus == "APP_PASS" and host_ok and clean_ok else
                              "application TIMEOUT with host+cleanup PASS" if app_timeout and host_ok and clean_ok else
                              "stop: host, cleanup, reader, or non-timeout app nonpass")
    row.update({"status": "APP_PASS_DIAGNOSTIC" if ok and appstatus == "APP_PASS" else
                "APP_TIMEOUT_DIAGNOSTIC" if ok and app_timeout else "STOPPED_NONPASS",
                "diagnosticOnly": True, "finishedUtc": now()})
    writej(root / "case-result.json", row)
    return row, ok


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--task-root", required=True, type=Path, help="new OS-temp task root; writes root75-matched-diagnostic")
    p.add_argument("--repo", type=Path, default=REPO)
    p.add_argument("--current-pointer", type=Path, default=HERE / "epoch15-task-pointer.json")
    p.add_argument("--old-pointer", type=Path, default=HERE.parent / "epoch15-task-pointer.json")
    p.add_argument("--host-python", type=Path, default=HOST_PY)
    p.add_argument("--deps", type=Path, default=DEPS)
    a = p.parse_args(); out = a.task_root.resolve() / "root75-matched-diagnostic"
    temp = Path(tempfile.gettempdir()).resolve()
    need(sys.platform == "win32", "Windows/Edge is required")
    need(str(out.resolve()).casefold().startswith((str(temp) + os.sep).casefold()), "output must be beneath OS Temp")
    need(not out.exists(), "refusing to replace existing diagnostic output")
    need(a.host_python.is_file() and a.deps.is_dir() and
         a.host_python.resolve(strict=True) == HOST_PY.resolve(strict=True) and
         a.deps.resolve(strict=True) == DEPS.resolve(strict=True), "approved physical host Python/deps absent or changed")
    out.mkdir(parents=True, exist_ok=False)
    run = {"schema": 1, "status": "RUNNING", "diagnosticOnly": True, "qualification": False,
           "scope": "Four matched root-75 observations CURRENT, OLD, OLD, CURRENT; not population/cause/qualification.",
           "caseOrder": ["current", "old", "old", "current"], "seed": "75", "hostSeconds": TIMEOUT,
           "outerSeconds": OUTER, "limits": LIMITS, "visibleHost": "Edge headful; automated observer, no player input.",
           "systemCpuSampling": "NOT SAMPLED", "startedUtc": now(), "cases": []}
    writej(out / "run.json", run); before = None
    try:
        run["controllerIdentity"] = controller_identity()
        repo = a.repo.resolve(strict=True); host = (repo / HOST).resolve(strict=True)
        reader, base_reader = (repo / READER).resolve(strict=True), (repo / BASE_READER).resolve(strict=True)
        need(sha(host) == HOST_SHA, "common current normal-screen host SHA mismatch")
        variants = {"current": load_variant("current", a.current_pointer.resolve(strict=True)),
                    "old": load_variant("old", a.old_pointer.resolve(strict=True))}
        ca, oa = variants["current"]["acceptance"], variants["old"]["acceptance"]
        need({k: v for k, v in ca.items() if k != "baseHead"} ==
             {k: v for k, v in oa.items() if k != "baseHead"}, "frozen acceptance differs beyond baseHead")
        need(plan_projection(variants["current"]["plan"]) == plan_projection(variants["old"]["plan"]),
             "candidate canonicals/order/limits differ")
        need(variants["current"]["plan"].get("hostRunnerSha256") == HOST_SHA,
             "current frozen plan does not pin shared host")
        before = input_state(repo, variants, host, reader, base_reader)
        writej(out / "hashes-before.json", before)
        run["bindings"] = {k: {"baseHead": v["pointer"]["baseHead"],
                    "sourceIdentity": v["pointer"]["sourceIdentity"], "sourceFiles": len(v["snapshot"]["files"]),
                    "snapshotSha256": digest(v["snapshotRaw"]), "prepareReceiptSha256": digest(v["receiptRaw"]),
                    "planSha256": digest(v["planRaw"]), "acceptanceSha256": digest(v["acceptanceRaw"]),
                    "hostRunnerSha256": v["plan"].get("hostRunnerSha256"),
                    "baselinePatchSha256": v["receipt"].get("baselinePatchSha256"),
                    "wrapperIdentity": v["receipt"].get("wrapperIdentity"),
                    "preparedInputIdentity": v["plan"].get("preparedInputIdentity"),
                    "overlays": before[k + "App"]["overlays"],
                    "gwtCaches": before[k + "App"]["gwtCaches"]}
                    for k, v in variants.items()}
        run["commonHostSha256"] = HOST_SHA; run["hostPython"] = str(a.host_python.resolve())
        run["depsPath"] = str(a.deps.resolve()); run["status"] = "PREFLIGHT_PASS_RUNNING"
        env = dict(os.environ, PYTHONPATH=str(a.deps.resolve()), PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
        run["hostPythonRuntime"] = host_runtime(a.host_python.resolve(strict=True), a.deps.resolve(strict=True), out, env)
        writej(out / "run.json", run)
        for i, label in enumerate(run["caseOrder"], 1):
            try: case, ok = run_case(i, label, variants[label], out, host, a.host_python.resolve(), reader, env)
            except Exception as e:
                case, ok = {"index": i, "variant": label, "seed": "75", "status": "HARNESS_EXCEPTION",
                            "error": type(e).__name__ + ": " + str(e), "diagnosticOnly": True}, False
            run["cases"].append(case); writej(out / "run.json", run)
            if not ok:
                run["status"] = "STOPPED_NONPASS"; run["stopReason"] = case.get("continueReason", case.get("status")); break
        else: run["status"] = "DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION"
    except Exception as e:
        run["status"] = "PREFLIGHT_OR_RUN_FAILURE"; run["stopReason"] = type(e).__name__ + ": " + str(e)
    finally:
        if before is not None:
            try:
                after = input_state(repo, variants, host, reader, base_reader)
                unchanged = after == before; after["unchanged"] = unchanged
                writej(out / "hashes-after.json", after); run["sourceBindingUnchangedBeforeAfter"] = unchanged
                if not unchanged: run["status"] = "FAIL_INPUT_MUTATION"
            except Exception as e:
                run["sourceBindingUnchangedBeforeAfter"] = False
                run["status"] = "FAIL_FINAL_SOURCE_AUDIT"; run["stopReason"] = type(e).__name__ + ": " + str(e)
        run.update({"finishedUtc": now(), "caseCount": len(run["cases"]),
                    "diagnosticConclusion": "Repeated seed-75 observations are not qualification evidence or proof of cause."})
        writej(out / "run.json", run)
    print(json.dumps({k: run.get(k) for k in ("status", "caseCount", "stopReason",
          "sourceBindingUnchangedBeforeAfter", "commonHostSha256", "diagnosticConclusion")}, indent=2))
    return 0 if run.get("status") == "DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION" and \
        run.get("sourceBindingUnchangedBeforeAfter") is True else 1


if __name__ == "__main__":
    raise SystemExit(main())
