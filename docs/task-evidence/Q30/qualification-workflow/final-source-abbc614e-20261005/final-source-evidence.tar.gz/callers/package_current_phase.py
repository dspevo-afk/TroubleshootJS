"""Portable evidence checkpoint only; does not run or waive qualification."""
import gzip,hashlib,importlib.util,io,json,re,tarfile
from pathlib import Path
N=Path(__file__).resolve().parent; W=N.parent
R=Path(r'$REPO')
pin=json.loads((N/'epoch15-task-pointer.json').read_text());T=Path(pin['taskRoot'])
B=Path(r'$COLD_FAILED')
D=Path(r'$FOCUSED_DIAGNOSTIC')
U=Path((N/'headed-ui-root.txt').read_text(encoding='utf-8-sig').strip())
spec=importlib.util.spec_from_file_location('retained_scrub_helpers',W/'save_process_final_cold_failure.py')
scrub=importlib.util.module_from_spec(spec);spec.loader.exec_module(scrub)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
readj=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert pin['baseHead']=='abbc614e9456d9fae56274da583175f8721a84c2'
assert readj(T/'native-full-audit.json')['auditStatus']==readj(T/'native-append-audit.json')['auditStatus']=='PASS'
assert readj(T/'current-source-archive-result.json')['status']=='PASS_SOURCE_ARCHIVE_ONLY'
assert readj(B/'controller-result.json')['qualified'] is False
assert readj(U/'result.json')['outcome']=='UI_SESSION_CLOSED_PENDING_FLOW_REVIEW'
assert readj(U/'independent-release-audit.json')['status']=='PASS_EXACT_INSTANCES_AND_PORT_RELEASED'
build=readj(T/'private-instrument-diagnostic/result.json');app=Path(build['privateSourceRoot'])
aliases={R:'$REPO',T:'$TASK_ROOT',B:'$COLD_FAILED',D:'$FOCUSED_DIAGNOSTIC',U:'$HEADED_CURRENT',app:'$PRIVATE_INSTRUMENT_APP',N:'$CURRENT_CALLERS',W:'$TASK_WORKSPACE'}
def text_portable(s):
 for p,a in sorted(aliases.items(),key=lambda x:len(str(x[0])),reverse=True):
  for v in [str(p),str(p).replace('\\','/'),str(p).replace('\\','\\\\')]:s=re.sub(re.escape(v),lambda m:a,s,flags=re.I)
 return scrub.scrub_text(s,R,T,W)
def portable(v):
 if isinstance(v,str):return text_portable(v)
 if isinstance(v,list):return [portable(x) for x in v]
 if isinstance(v,dict):return {k:portable(x) for k,x in v.items()}
 return v
members={};lineage=[]
def add(p,root,label,exact=False):
 p=p.resolve(strict=True); root=root.resolve(strict=True);rel=p.relative_to(root).as_posix();name=label+'/'+rel
 assert not p.is_symlink() and p.stat().st_size<=16*1024*1024 and name not in members
 raw=p.read_bytes()
 if exact:
  if p.suffix=='.png':out=raw
  elif p.name.endswith('.patch.gz'):
   with gzip.GzipFile(fileobj=io.BytesIO(raw),mode='rb') as gz:decompressed=gz.read(64*1024*1024+1)
   assert len(decompressed)<=64*1024*1024
   s=decompressed.decode('utf-8');assert scrub.USER_PATH.search(s) is None and scrub.POSIX_PATH.search(s) is None;out=raw
  elif p.name.endswith('.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
    for m in tf:
     assert not m.name.startswith(('/', '\\')) and '..' not in Path(m.name).parts and m.size<=16*1024*1024
     if m.isdir():continue
     assert m.isfile()
     s=tf.extractfile(m).read().decode('utf-8');assert scrub.USER_PATH.search(s) is None and scrub.POSIX_PATH.search(s) is None
   out=raw
  else:
   s=raw.decode('utf-8');assert text_portable(s)==s;out=raw
 else:
  s=scrub.decode(raw,name)
  out=((json.dumps(portable(json.loads(s)),indent=2,ensure_ascii=False)+'\n') if p.suffix=='.json' else text_portable(s)).encode('utf-8')
 members[name]=out;lineage.append({'member':name,'originalBytes':len(raw),'originalSha256':sha(raw),'portableBytes':len(out),'portableSha256':sha(out),'derivation':'EXACT_BYTES' if exact else 'PATH_AND_CREDENTIAL_STRING_SANITIZATION; semantic keys/booleans/numbers retained'})
for root,label in [(T,'current'),(B,'cold-failed'),(D,'focused-diagnostic')]:
 for p in sorted(root.glob('*.json')):add(p,root,label)
for folder in ['isolated','cold77-normal-launch','private-instrument-diagnostic','current-source-archive']:
 for p in sorted((T/folder).glob('*.json')):add(p,T,'current')
for p in sorted((T/'current-source-archive/isolated').iterdir()):
 if p.suffix=='.json' or p.name.endswith('.gz'):add(p,T,'current',exact=p.name.endswith('.gz'))
for root,label,caseparent in [(B,'cold-failed',B/'sequence'),(D,'focused-diagnostic',D)]:
 for p in sorted(caseparent.glob('*.json')):
  if label+'/'+p.relative_to(root).as_posix() not in members:add(p,root,label)
 for case in sorted((caseparent/'cases').glob('*')):
  if not case.is_dir():continue
  for p in sorted(case.glob('*.json')):add(p,root,label)
  for p in sorted((case/'host-output').glob('*.json')):add(p,root,label)
  for p in sorted((case/'host-output/cases').glob('*.report.json')):add(p,root,label,exact=True)
for name in ['isolated-build.log','native-full.log','native-full.txt','native-append.log','native-append.txt','current-source-archive.log']:
 add(T/name,T,'current')
for name in ['stdout.log','stderr.log']:add(T/'private-instrument-diagnostic'/name,T,'current')
for p in sorted(U.glob('*.json')):add(p,U,'headed-current')
for p in sorted((U/'responses').glob('*.json')):add(p,U,'headed-current')
for p in sorted((U/'commands').glob('*.json')):add(p,U,'headed-current')
for p in sorted(N.glob('*.py')):add(p,N,'callers')
for p in sorted(N.glob('*.ps1')):add(p,N,'callers')
for name in ['epoch15-task-pointer.json','integration-pointer.json','prelaunch-helper-notes.json']:add(N/name,N,'callers')
flow=readj(U/'flow-review.json');assert flow['scope']=='PRIVATE_INSTRUMENT_DIAGNOSTIC_ONLY'
for name in flow['inspectedScreenshots']:add(U/'screenshots'/name,U,'headed-current',exact=True)
assert len(members)<500 and sum(len(x) for x in members.values())<=96*1024*1024
dest=R/'docs/task-evidence/Q30/qualification-workflow/final-source-abbc614e-20261005';dest.mkdir(exist_ok=False)
archive=dest/'final-source-evidence.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name,raw in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tf:
 assert sorted(tf.getnames())==sorted(members)
 for m in tf:assert tf.extractfile(m).read()==members[m.name]
derived={'schema':1,'scope':'Evidence packaging only; acceptance BLOCKED','candidate':pin['baseHead'],'sourceIdentity':pin['sourceIdentity'],'rawInputCount':1355,'files':lineage,'sanitizerBoundary':'String values/local paths sanitized; semantic JSON keys, booleans and numbers retained. Exact originals and all failures retained locally. Sanitized task callers are evidence derivatives, not executable reconstruction promises. Exact gzip patches/overlay archives and app reports were bounded and inspected for personal path patterns.'}
(dest/'derivation.json').write_text(json.dumps(derived,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest={'schema':1,'scope':'FINAL_SOURCE_SUPPORTING_EVIDENCE_NOT_ACCEPTANCE','candidate':pin['baseHead'],'sourceIdentity':pin['sourceIdentity'],'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [archive,dest/'derivation.json']},'members':len(members),'roundTrip':'PASS','cold77':'FAIL','publicQ30':'DISABLED','flow':flow['result']}
(dest/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS_EVIDENCE_PACKAGE_ONLY','path':str(dest),'members':len(members),'archiveSha256':sha(archive.read_bytes())}))
