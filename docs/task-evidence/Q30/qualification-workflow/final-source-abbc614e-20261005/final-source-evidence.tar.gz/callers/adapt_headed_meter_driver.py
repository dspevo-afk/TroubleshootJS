"""Bind the retained ordinary-input driver to the separate current diagnostic."""
from pathlib import Path
import hashlib, json
N=Path(__file__).resolve().parent
original=N.parent/'headed_q30_ui.py'
target=N/'headed_q30_ui.py'
assert not target.exists()
text=original.read_text()
old="""build=json.loads((private/'private-menu-result.json').read_text(encoding='utf-8-sig'))
app=Path(build['privateSourceRoot'])
spec=importlib.util.spec_from_file_location('input_owner',private/'run_epoch15_private_menu.corrected.py')
input_owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(input_owner)
snapshot=json.loads((private/'source-snapshot.json').read_text(encoding='utf-8-sig'))
reuse=json.loads((private/'private-build-reuse-audit.json').read_text(encoding='utf-8-sig'))"""
new="""build=json.loads((private/'result.json').read_text(encoding='utf-8-sig'))
if build['status']!='PASS_PRIVATE_INSTRUMENT_BUILD_ONLY' or build['acceptanceStatus']!='NOT_ASSESSED' or build['rawInputCount']!=1355:
    raise RuntimeError('Current private instrument diagnostic build is not verified')
app=Path(build['privateSourceRoot'])
helper=Path(__file__).resolve().parent.parent/'run_epoch15_private_menu.py'
import hashlib
if hashlib.sha256(helper.read_bytes()).hexdigest()!='3847637a0c8281705f6cb061ebec4a916d6e3ff26e56717d4afad71d65fe079f':
    raise RuntimeError('Retained source inventory owner changed')
spec=importlib.util.spec_from_file_location('input_owner',helper)
input_owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(input_owner)
snapshot=json.loads((private.parent/'source-snapshot.json').read_text(encoding='utf-8-sig'))
if snapshot['baseHead']!=build['baseHead'] or snapshot['sourceIdentity']!=build['sourceIdentity'] or len(snapshot['files'])!=1355:
    raise RuntimeError('Current diagnostic source pin differs')"""
assert text.count(old)==1
text=text.replace(old,new,1)
replacements={
 "build['catalogSourceDelta']":"build['sourceDelta']",
 "build['compiledInventoryAfter']":"build['compiled']",
 "reuse['deploymentOutputs']":"build['deployment']",
 "'rawInputs':1354":"'rawInputs':1355",
 "result['cleanup']={'seconds':time.monotonic()-cleanup,'recordedSurvivors':remaining,'previewExitCode':preview.poll() if preview else None}":"result['cleanup']={'seconds':time.monotonic()-cleanup,'recordedSurvivorsBeforeControllerExit':remaining,'previewExitCode':preview.poll() if preview else None,'status':'PENDING_INDEPENDENT_POST_EXIT_RELEASE','boundary':'This live controller cannot certify release of its own console; all recorded identities still require independent post-exit audit'}",
 "and not result['errors'] and not remaining and (preview is None":"and not result['errors'] and (preview is None",
}
for old,new in replacements.items():
    assert text.count(old)==1,old
    text=text.replace(old,new,1)
target.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'status':'DRIVER_BOUND_NOT_RUN','originalSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'currentSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Current build source fields and honest deferred post-exit release only; actual locator/mouse/keyboard/screenshot operations preserved'}))
