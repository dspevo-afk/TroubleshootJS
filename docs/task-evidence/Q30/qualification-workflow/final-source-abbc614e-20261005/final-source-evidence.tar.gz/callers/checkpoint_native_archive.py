from pathlib import Path
import json
R=Path(r'$REPO')
T=Path(json.loads((Path(__file__).parent/'epoch15-task-pointer.json').read_text())['taskRoot'])
assert json.loads((T/'native-full-audit.json').read_text())['auditStatus']=='PASS'
assert json.loads((T/'native-append-audit.json').read_text())['auditStatus']=='PASS'
assert json.loads((T/'current-source-archive-result.json').read_text())['status']=='PASS_SOURCE_ARCHIVE_ONLY'
p=R/'docs/CODEX_TASK_REPORT.md'; raw=p.read_bytes(); text=raw.decode('utf-8')
split='\r\n---\r\n\r\n# Historical checkpoint:'
current,history=text.split(split,1)
current=current.replace('# Current checkpoint: current-source Q30 cold77 failed; final regression running','# Current checkpoint: Q30 cold77 failed; final native/source archive passed')
current=current.replace('2026-10-04. Candidate','2026-10-05. Candidate',1)
current=current.replace('Slowdown cause UNKNOWN;\r\nsource review comparing this proof path is in progress. Failures retained.','Slowdown cause UNKNOWN. Same-day prior accepted\r\nroot10014 was 75,535 ms/440 units; current focused hypothesis proof took\r\n13.234 s longer. Source review found no demonstrated cause. Failures retained.')
old='Fresh full83 native matrix/independent oracles RUNNING via maintained verifier;\r\nappend26 structural cohort NOT RUN. No parallel build/browser/test matrix.'
new='Fresh full83 native matrix/independent oracles PASS/exit0/4,384.108 s; strict\r\nreceipt audit PASS/zero issues. 105 service/repair and 105 sensitivity cases,\r\n51 structural roots, four independent oracles and cleanup marker verified.\r\nAppend26 PASS/exit0/216.548 s; strict audit PASS/zero issues. Combined 77\r\nstructural roots: 70 accepted/seven valid rejected/zero contract failures.\r\nCleanup duration NOT RECORDED separately. No parallel expensive gate.'
assert old in current; current=current.replace(old,new)
old='Current private build/menu/replay and visible charged-to-DISCHARGE-to-numeric\r\nmeter recovery have not run; prior private source binding is stale.'
new='Separate current-source private instrument diagnostic build RUNNING; acceptance\r\nNOT ASSESSED. Qualified private menu/replay and visible charged-to-DISCHARGE-to-\r\nnumeric recovery have not run; prior private source binding remains historical.'
assert old in current; current=current.replace(old,new)
current=current.replace('Source archive reconstruction and\r\nparent acceptance pending.','Current compact source archive reconstruction PASS/exit0/80.951 s: exact\r\n1,355-input receipt binding, source-delta/three overlays/four baseline-patch\r\ndifferences verified. Source-only acceptance NOT ASSESSED; full trees omitted\r\nby maintained compact mode, scratch retained. Parent acceptance pending.')
current=current.replace('Full-native launcher ownership\r\nrecorded at launch.','Native/archive launch ownership\r\nrecorded; current private build process ownership recorded.')
current=current.replace('Next: finish native83/append, investigate the deadline miss, then resume dependent\r\ngates only with their preconditions satisfied. Parent owns final acceptance.','Next: finish independently scoped private instrument build and actual ordinary\r\nUI recovery observation; preserve any failure. Qualified admission still needs\r\ncold77 PASS and parent acceptance. No new full77 retry without a controlled\r\ncomparison rationale; no budget waiver. Parent owns final acceptance.')
p.write_bytes((current+split+history).encode('utf-8'))
p=R/'docs/ROADMAP.md'; text=p.read_bytes().decode('utf-8')
text=text.replace('**Q30 NOT ACCEPTED - current-source cold77 failed; final regression running**','**Q30 NOT ACCEPTED - current-source cold77 failed; native/archive passed**',1)
old='Failed cohort and cleanup/release receipts retained. Full83 native RUNNING;\r\ndependent private admission/current visible meter recovery and warm distribution\r\npending.'
new='Failed cohort and cleanup/release receipts retained. Fresh full83 native and\r\nappend26 strict audits PASS: 105 repair/105 sensitivity/77 structural roots,\r\nfour independent oracles. Current compact source reconstruction PASS/source-only.\r\nSeparate private instrument build RUNNING; qualified admission/current visible\r\nmeter recovery and original warm distribution pending.'
assert old in text; text=text.replace(old,new,1);p.write_bytes(text.encode('utf-8'))
print('CHECKPOINT: native83/append26/archive audited PASS; cold77 FAIL; private diagnostic RUNNING')
