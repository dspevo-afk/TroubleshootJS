import hashlib,json
from pathlib import Path
N=Path(__file__).resolve().parent
pin=json.loads((N/'fixed-source-pointer.json').read_text());T=Path(pin['taskRoot'])
R=Path(r'$REPO')
snap=json.loads((T/'source-snapshot.json').read_text())
issues=[]
for row in snap['files']:
    if hashlib.sha256((R/row['path']).read_bytes()).hexdigest()!=row['sha256']:issues.append('changed input '+row['path'])
receipt=(T/'native.txt').read_text(encoding='utf-8-sig')
markers=['PASS: generated power control observation contracts assertions=16','PASS: Q30 plan contracts 4381 assertions','PASS: Q30 power readiness contracts 144 assertions seeds=3 realOhm=3 realDiode=3','PASS: Q30 temporal work contracts 161 assertions','PASS: A06 power contracts assertions=152','PASS: A10 dependency contracts assertions=15','PASS: U02 measurement contracts assertions=585','PASS: U03 observation contracts assertions=17','Q30_NATURAL_RECOVERY seed=10387 additionalSolverSeconds=12.315279999572832 liveFrames=2463 residualVolts=0.24991668647120496 realOhm=179.99999999999727 realDiode=0.45762711864406125']
for marker in markers:
    if receipt.count(marker)!=1:issues.append('missing/duplicate '+marker)
log=(T/'native.log').read_text(encoding='utf-8-sig')
if 'CLEANUP: current JVM contract classes and task-owned scratch removed.' not in log:issues.append('missing cleanup marker')
result=json.loads((T/'native-result.json').read_text(encoding='utf-8-sig'))
if result['exitCode']!=0 or result['status']!='COMMAND_PASS_PENDING_RECEIPT_REVIEW':issues.append('command failure')
out={'status':'PASS_FOCUSED_RECEIPT_ONLY' if not issues else 'FAIL','issues':issues,'sourceIdentity':snap['sourceIdentity'],'head':snap['baseHead'],'inputsVerified':1355,'javaSuites':8,'assertionMarkers':markers,'fullMatrix':'NOT_RUN on changed source','cold77':'NOT_RUN; prior FAIL preserved','cleanupElapsedSeconds':'NOT_RECORDED separately'}
(T/'native-audit.json').write_text(json.dumps(out,indent=2)+'\n')
(N/'early-failures.json').write_text(json.dumps({'status':'PRESERVED_PRELAUNCH_FAILURES','items':[{'phase':'fixed source snapshot prepare','result':'FAIL WinError5 task-temp mkdir under managed sandbox; no compile launched','retry':'narrow authorized execution succeeded'},{'phase':'public build Python owner image canary','result':'FAIL created image differs from expected physical Python; no build child launched','retry':'launched exact physical Python image; actual GWT build PASS'}]},indent=2)+'\n')
print(json.dumps(out));raise SystemExit(bool(issues))
