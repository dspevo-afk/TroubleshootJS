$ErrorActionPreference='Stop'
$root=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'headed-ui-root.txt') -Raw).Trim()
$bounded=Get-Content -LiteralPath (Join-Path $root 'bounded-process-result.json') -Raw|ConvertFrom-Json -DateKind String
if(-not $bounded.TerminationProven){throw 'Outer owner termination is not proven'}
$records=@()
function AddRecorded($recordedPid,$created,$exe,$source) {
 if(-not $recordedPid -or -not $created -or -not $exe){throw ('Incomplete identity '+$source)}
 $live=Get-CimInstance Win32_Process -Filter ('ProcessId='+$recordedPid)
 $same=$false
 if($null -ne $live){$same=$live.CreationDate.ToUniversalTime() -eq [DateTime]::Parse($created).ToUniversalTime() -and $live.ExecutablePath -eq $exe}
 $script:records+=@{pid=$recordedPid;created=$created;executable=$exe;source=$source;exactInstancePresent=$same;pidPresent=$null -ne $live}
}
$launcher=Get-Content -LiteralPath (Join-Path $root 'bounded-controller-identity.json') -Raw|ConvertFrom-Json -DateKind String
AddRecorded $launcher.pid $launcher.created $launcher.executable 'bounded-launcher'
foreach($name in @('controller-identity.json','preview-process-identity.json')){
 $p=Get-Content -LiteralPath (Join-Path $root $name) -Raw|ConvertFrom-Json -DateKind String
 AddRecorded $p.pid $p.created $p.ExecutablePath $name
}
$owned=Get-Content -LiteralPath (Join-Path $root 'owned-processes.json') -Raw|ConvertFrom-Json -DateKind String
foreach($p in $owned){AddRecorded $p.pid $p.created $p.ExecutablePath 'recorded-descendant'}
$unique=@($records|Sort-Object pid,created,executable -Unique)
$serving=Get-Content -LiteralPath (Join-Path $root 'preview-serving-identity.json') -Raw|ConvertFrom-Json
if(-not $serving.previewPort){throw 'Dynamic owned preview port absent'}
$listeners=@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object {$_.LocalPort -eq $serving.previewPort})
$survivors=@($unique|Where-Object exactInstancePresent)
$out=Join-Path $root 'independent-release-audit.json'
if(Test-Path -LiteralPath $out){throw 'Preserve existing release audit'}
$result=@{status=if($survivors.Count -eq 0 -and $listeners.Count -eq 0){'PASS_EXACT_INSTANCES_AND_PORT_RELEASED'}else{'BLOCKED'};observedUtc=[DateTime]::UtcNow.ToString('o');scope='Current headed launcher/controller/preview and recorded descendants; independent post-exit read only';processes=$unique;port=$serving.previewPort;listenerCount=$listeners.Count;outerTerminationProven=$bounded.TerminationProven;terminationAttempted=$false;acceptanceStatus='NOT_ASSESSED'}
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $out
@{status=$result.status;recordedInstances=$unique.Count;port=$result.port;output=$out}|ConvertTo-Json
if($survivors.Count -gt 0 -or $listeners.Count -gt 0){exit 2}
