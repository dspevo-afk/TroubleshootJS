$ErrorActionPreference='Stop'
$roots=@(
 '$TASK_TEMP\q30-targeted-discharge-244dc5df28e14c3685eb4b0bb2c68247',
 '$TASK_TEMP\q30-targeted-discharge-0963fe8f085249e8990f5880400970bb',
 '$TASK_TEMP\q30-targeted-fix-7c5821f7b1084e1e8b420afbadb72a5a',
 (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'fixed-root.txt') -Raw).Trim())
$records=@()
function CheckOwner($recordedPid,$birth,$image,$source) {
 if(-not $recordedPid -or -not $birth -or -not $image){throw ('Incomplete recorded identity '+$source)}
 $live=Get-CimInstance Win32_Process -Filter ('ProcessId='+$recordedPid)
 $same=$null -ne $live -and $live.ExecutablePath -eq $image -and $live.CreationDate.ToUniversalTime() -eq $birth.ToUniversalTime()
 $script:records+=@{pid=$recordedPid;birthUtc=$birth.ToUniversalTime().ToString('o');executable=$image;source=$source;exactInstancePresent=$same;pidPresent=$null -ne $live}
}
foreach($root in $roots){
 foreach($name in @('controller-identity.json','native-controller-identity.json')){
  $path=Join-Path $root $name
  if(Test-Path -LiteralPath $path){
   $p=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json -DateKind String
   CheckOwner $p.pid ([DateTime]::Parse($p.createdUtc)) $p.executable ($root+'\'+$name)
  }
 }
 foreach($dir in @('public-disabled-build','private-instrument-diagnostic')){
  $path=Join-Path $root ($dir+'\result.json')
  if(Test-Path -LiteralPath $path){
   $p=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json -DateKind String
   CheckOwner $p.controller.pid ([DateTime]::FromFileTimeUtc([long]$p.controller.creationFileTimeTicks)) $p.controller.executable ($root+'\'+$dir+'\controller')
   CheckOwner $p.buildProcess.pid ([DateTime]::FromFileTimeUtc([long]$p.buildProcess.creationFileTimeTicks)) $p.buildProcess.executable ($root+'\'+$dir+'\buildProcess')
  }
 }
}
$survivors=@($records|Where-Object exactInstancePresent)
$result=@{status=if($survivors.Count -eq 0){'PASS_RECORDED_OWNERS_RELEASED'}else{'BLOCKED'};observedUtc=[DateTime]::UtcNow.ToString('o');records=$records;terminationAttempted=$false;scope='Recorded diagnostic/focused-native launchers and public/private build Python/PowerShell owners only. Maintained child job cleanup is separate; headed identity/port audits are separate.'}
$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'recorded-owner-release.json')
@{status=$result.status;checked=$records.Count}|ConvertTo-Json
if($survivors.Count -ne 0){exit 2}
