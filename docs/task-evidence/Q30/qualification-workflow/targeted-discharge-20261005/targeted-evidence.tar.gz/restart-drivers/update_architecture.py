from pathlib import Path
R=Path(r'$REPO')
p=R/'docs/ARCHITECTURE.md'; raw=p.read_bytes(); text=raw.decode('utf-8').replace('\r\n','\n')
old='''controls. Ordinary CircuitJS UI stepping remains active; Q30 adds only 0.1 ms
per live frame, while explicit input profiles retain their full 30 ms interval.'''
new='''controls. Ordinary CircuitJS UI stepping remains active. Q30 retains its 0.1 ms
additional live increment while any actual source switch is connected; once all
external sources are isolated, its family behavior advances the same transient
in bounded 5 ms slices. Explicit input profiles retain their full 30 ms interval,
adaptive solver step bounds and work budgets. Both live intervals are immutable
temporal-dependency parameters, independent of the current source-control state.
This scheduling does not reset capacitors, add discharge paths, alter the 0.25 V
active-meter guard or grant readiness from wall time. An open DREV can leave the
optional fused-input capacitor charged; an open REN leaves the slower real 1 MOhm
regulator-input leakage path. Pending OHM/CONT and DIODE readings retry when the
actual readiness reaches READY with both probes present, then use the existing
temporary-source transaction and cleanup. Powered, stale and residual states
continue to block injection. The isolated-capacitor repair-to-readiness player
flow remains qualification work; Q30 normal admission is still disabled.'''
assert text.count(old)==1;text=text.replace(old,new)
if b'\r\n' in raw:text=text.replace('\n','\r\n')
p.write_bytes(text.encode('utf-8'));print('ARCHITECTURE_UPDATED')
