import hashlib,json
from pathlib import Path
N=Path(__file__).resolve().parent; W=N.parent
old=(W/'final-source-abbc614e-20261004-r2/build_private_instrument_diagnostic.py').read_text()
start=old.index("pin=json.loads")
end=old.index("physical=api.HOST_PYTHON",start)
setup='''pin=json.loads((N/'fixed-source-pointer.json').read_text())
T=Path(pin['taskRoot']); R=Path(r'$REPO')
helper=N.parent/'run_epoch15_private_menu.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(helper)=='3847637a0c8281705f6cb061ebec4a916d6e3ff26e56717d4afad71d65fe079f'
assert sha(N/'serial_runner.py')=='19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6'
spec=importlib.util.spec_from_file_location('retained_private_copy_audit',helper)
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
api.EXPECTED_RAW_INPUTS=1355
api.EXPECTED_RAW_ROOT_COUNTS={'src':1132,'tests':174,'war':29,'scripts':20}
snapshot=json.loads((T/'source-snapshot.json').read_text())
assert snapshot['baseHead']==pin['head']=='529f42582d903843254fc7cd73624b92eff55bdc'
assert snapshot['sourceIdentity']==pin['sourceIdentity']
assert len(snapshot['files'])==1355 and dict(Counter(row['path'].split('/')[0] for row in snapshot['files']))==api.EXPECTED_RAW_ROOT_COUNTS
canonical={key:snapshot[key] for key in ['schema','baseHead','files']}
assert hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')).hexdigest()==pin['sourceIdentity']
api.EXPECTED_BASE_HEAD=pin['head']; api.EXPECTED_SOURCE_IDENTITY=pin['sourceIdentity']
pin['baseHead']=pin['head']
git=['git','-c','safe.directory='+R.as_posix()]
assert subprocess.check_output(git+['rev-parse','HEAD'],cwd=R,text=True).strip()==pin['head']
tracked=subprocess.check_output(git+['ls-files','--','src','war','scripts','tests'],cwd=R,text=True).splitlines()
assert sorted(tracked)==sorted(row['path'] for row in snapshot['files'])
repo_check=api.validate_repo_inputs(snapshot)
assert (R/api.TARGET_CATALOG).read_bytes().count(api.FALSE_REGISTRATION)==1
'''
base=old[:start]+setup+old[end:]
public=base.replace("'private-instrument-diagnostic'","'public-disabled-build'").replace("'q30-private-instrument-'","'q30-targeted-public-'").replace("'PRIVATE_INSTRUMENT_DIAGNOSTIC_ONLY'","'PUBLIC_DISABLED_BUILD_ONLY'")
public=public.replace('delta=api.copy_source_delta(snapshot,app)\n    expected=api.expected_raw_source_inventory(snapshot,delta)',"delta=[]\n    expected=[{'path':row['path'],'size':row['size'],'sha256':row['sha256']} for row in snapshot['files']]")
public=public.replace('PASS_PRIVATE_INSTRUMENT_BUILD_ONLY','PASS_PUBLIC_DISABLED_BUILD_ONLY')
(N/'build_public_disabled.py').write_text(public)
private=base.replace("'q30-private-instrument-'","'q30-targeted-private-'")
bridge='''
    private String getQ30ReadOnlySnapshot() {
        if (generatedBoardInstance == null) return "{}";
        GeneratedBoardInstance owner = generatedBoardInstance;
        CircuitPostMeasurementEndpoint red = (CircuitPostMeasurementEndpoint)owner.getSimulationBindings().getEndpoint("JOA.1");
        CircuitPostMeasurementEndpoint black = (CircuitPostMeasurementEndpoint)owner.getSimulationBindings().getEndpoint("JOA.2");
        StringBuilder result = new StringBuilder("{\\"solverSeconds\\":").append(t)
            .append(",\\"seed\\":\\"").append(owner.getSeed()).append("\\",\\"isolated\\":")
            .append(boardPowerController.isElectricallyUnpowered())
            .append(",\\"readiness\\":\\"").append(getActiveMeasurementReadiness(red, black).name()).append("\\"");
        CircuitPostMeasurementEndpoint reference = (CircuitPostMeasurementEndpoint)owner.getSimulationBindings().getEndpointsForNet("CTRL_RETURN").firstElement();
        for (String net : new String[] {"RAW12", "FUSED12", "RAIL12", "RAIL5", "EN5"}) {
            CircuitPostMeasurementEndpoint endpoint = (CircuitPostMeasurementEndpoint)owner.getSimulationBindings().getEndpointsForNet(net).firstElement();
            double volts = endpoint.getElement().getPostVoltage(endpoint.getPostIndex()) - reference.getElement().getPostVoltage(reference.getPostIndex());
            result.append(",\\"").append(net).append("\\":").append(volts);
        }
        return result.append("}").toString();
    }
    private native void installQ30ReadOnlySnapshot() /*-{
        var instance = this;
        $wnd.q30ReadOnlySnapshot = function() {
            return instance.@com.lushprojects.circuitjs1.client.CirSim::getQ30ReadOnlySnapshot()();
        };
    }-*/;
'''
insertion='''
    overlay=app/'src/com/lushprojects/circuitjs1/client/CirSim.java'
    original=overlay.read_bytes(); text=original.decode('utf-8')
    anchor='installStressDeveloperBridge();'
    assert text.count(anchor)==1
    text=text.replace(anchor,anchor+'\\n        installQ30ReadOnlySnapshot();')
    anchor='    private void advanceLiveGeneratedTemporalSimulation() {'
    assert text.count(anchor)==1
    text=text.replace(anchor,BRIDGE+'\\n'+anchor)
    overlay.write_bytes(text.encode('utf-8'))
    row=next(row for row in expected if row['path']=='src/com/lushprojects/circuitjs1/client/CirSim.java')
    before=dict(row);row['size']=overlay.stat().st_size;row['sha256']=sha(overlay)
    delta.append({'path':row['path'],'beforeSha256':before['sha256'],'afterSha256':row['sha256'],'afterSize':row['size'],'scope':'PRIVATE_ONLY_READ_ONLY_SOLVER_SNAPSHOT; no stepping/mutation/player input'})
'''
private=private.replace('    assert api.inventory_tree(app,',insertion+'    assert api.inventory_tree(app,',1)
private=private.replace("physical=api.HOST_PYTHON",'BRIDGE='+repr(bridge)+'\nphysical=api.HOST_PYTHON',1)
private=private.replace("record['rawBefore']", "record['expectedRawInputs']=expected\n    record['rawBefore']",1)
(N/'build_private_readonly.py').write_text(private)
print(json.dumps({'status':'BUILD_DRIVERS_PREPARED','publicSha256':hashlib.sha256(public.encode()).hexdigest(),'privateSha256':hashlib.sha256(private.encode()).hexdigest()}))
