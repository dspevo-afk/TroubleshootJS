import hashlib,json,shutil,subprocess,uuid
from pathlib import Path
N=Path(__file__).resolve().parent; W=N.parent
R=Path(r'$REPO')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=['git','-c','safe.directory='+R.as_posix()]
head=subprocess.check_output(git+['rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='529f42582d903843254fc7cd73624b92eff55bdc'
paths=sorted(subprocess.check_output(git+['ls-files','--','src','tests','war','scripts'],cwd=R,text=True).splitlines())
assert len(paths)==1355
files=[{'path':p,'size':(R/p).stat().st_size,'sha256':sha(R/p)} for p in paths]
snapshot={'schema':1,'baseHead':head,'files':files}
snapshot['sourceIdentity']=hashlib.sha256(json.dumps(snapshot,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
T=Path(r'$TASK_TEMP')/('q30-targeted-fix-'+uuid.uuid4().hex);T.mkdir()
(T/'source-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
(N/'fixed-root.txt').write_text(str(T))
(N/'fixed-source-pointer.json').write_text(json.dumps({'taskRoot':str(T),'head':head,'sourceIdentity':snapshot['sourceIdentity'],'sourceInputs':1355,'scope':'TARGETED_FIX_ONLY; full qualification remains failed/disabled'},indent=2)+'\n')
for name in ['serial_runner.py','receipts.py']:
    shutil.copyfile(W/'final-source-abbc614e-20261004-r2'/name,N/name)
s=(W/'run_power_fix_focused.ps1').read_text()
s=s.replace("$workspace=$PSScriptRoot","$workspace=$PSScriptRoot")
start=s.index("$taskRoot=Join-Path")
end=s.index("$self=Get-CimInstance",start)
s=s[:start]+"$taskRoot=(Get-Content -LiteralPath (Join-Path $workspace 'fixed-root.txt') -Raw).Trim()\n"+s[end:]
s=s.replace("'Q30PowerReadinessContractTest','Q30PlanContractTest','A06PowerContractTest','U02MeasurementContractTest','GeneratedExternalPowerBindingsControlObservationContractTest'", "'Q30PowerReadinessContractTest','Q30PlanContractTest','A06PowerContractTest','U02MeasurementContractTest','U03ObservationContractTest','GeneratedExternalPowerBindingsControlObservationContractTest','A10DependencyContractTest','Q30TemporalWorkContractTest'")
s=s.replace('Focused five suites','Focused eight suites').replace('focused current contracts; 5 Java suites','focused current contracts; 8 Java suites')
(N/'run_fixed_focused.ps1').write_text(s)
print(json.dumps({'status':'PREPARED','taskRoot':str(T),'sourceIdentity':snapshot['sourceIdentity'],'inputs':1355}))
