import hashlib,json,shutil
from pathlib import Path
N=Path(__file__).resolve().parent; old=N.parent/'final-source-abbc614e-20261004-r2'
s=(old/'headed_q30_ui.py').read_text()
s=s.replace("input_owner.expected_raw_source_inventory(snapshot,build['sourceDelta'])","build['expectedRawInputs']")
s=s.replace("'gameFunctionsCalled':False,'pageEvaluateUsed':False", "'gameFunctionsCalled':False,'pageEvaluateUsed':True,'readOnlyDeveloperObservation':'private q30ReadOnlySnapshot reads actual solver time, node voltages and readiness; no mutation/stepping'")
anchor="                elif op=='dump':"
assert s.count(anchor)==1
s=s.replace(anchor,"                elif op=='observe':\n                    action['solverSnapshot']=json.loads(page.evaluate('() => window.q30ReadOnlySnapshot()'))\n"+anchor)
(N/'headed_q30_ui.py').write_text(s)
shutil.copyfile(old/'headed_q30_command.py',N/'headed_q30_command.py')
s=(old/'headed_current_meter_launch.ps1').read_text().replace("'epoch15-task-pointer.json'","'fixed-source-pointer.json'").replace('q30-headed-current-meter-','q30-headed-targeted-fix-').replace('Current 20/30/40 charged isolation and meter recovery','Targeted natural residual decay and automatic pending-meter recovery').replace('3700000','1900000')
(N/'headed_launch.ps1').write_text(s)
shutil.copyfile(old/'audit_current_headed_release.ps1',N/'audit_headed_release.ps1')
print(json.dumps({'status':'PREPARED_PRIVATE_READONLY_UI_DRIVER','driverSha256':hashlib.sha256((N/'headed_q30_ui.py').read_bytes()).hexdigest(),'builtInBrowser':'UNAVAILABLE in active tool list; headed ordinary Playwright visible SDK input fallback'}))
