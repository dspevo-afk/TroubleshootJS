"""Export bounded portable Q30 fix evidence; never certifies full acceptance."""
import hashlib,io,json,re,shutil,subprocess,tarfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
N=Path(__file__).resolve().parent; W=N.parent
R=Path(r'$REPO')
pin=json.loads((N/'fixed-source-pointer.json').read_text());T=Path(pin['taskRoot'])
U=Path((N/'headed-ui-root.txt').read_text(encoding='utf-8-sig').strip())
D=Path(r'$TASK_TEMP\q30-targeted-discharge-0963fe8f085249e8990f5880400970bb')
P3=Path(r'$TASK_TEMP\q30-targeted-fix-7c5821f7b1084e1e8b420afbadb72a5a')
U3=Path(r'$TASK_TEMP\q30-headed-targeted-fix-0cc97f98f4aa4e2caf596da4e0b1f109')
E=R/'docs/task-evidence/Q30/qualification-workflow/targeted-discharge-20261005'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert read(T/'native-audit.json')['status']=='PASS_FOCUSED_RECEIPT_ONLY'
snap=read(T/'source-snapshot.json')
for row in snap['files']:assert sha((R/row['path']).read_bytes())==row['sha256']
builds={x:read(T/x/'result.json') for x in ['public-disabled-build','private-instrument-diagnostic']}
for name,b in builds.items():
    assert b['status'].startswith('PASS_') and b['sourceIdentity']==pin['sourceIdentity'] and not b['errors']
    assert b['operation']['exitCode']==0 and b['operation']['cleanup']['cleanupVerified'] and b['operation']['cleanup']['jobActiveProcesses']==0
    assert len(b['compiled'])==357 and len(b['permutations'])==5 and len(b['deployment'])==6
ui=read(U/'result.json');a={row['sequence']:row for row in ui['actions']}
assert ui['outcome']=='UI_SESSION_CLOSED_PENDING_FLOW_REVIEW' and not ui['errors']
assert all(row['status']=='PASS' for row in ui['actions'])
assert ui['inputsBefore']==ui['inputsAfter'] and ui['inputsAfter']['rawInputs']==1355
assert read(U/'bounded-command-result.json')['exitCode']==0
assert read(U/'independent-release-audit.json')['status']=='PASS_EXACT_INSTANCES_AND_PORT_RELEASED'
assert read(N/'recorded-owner-release.json')['status']=='PASS_RECORDED_OWNERS_RELEASED'
assert a[12]['solverSnapshot']['readiness']=='POWER_OFF' and a[19]['solverSnapshot']['readiness']=='DISCHARGE'
assert a[26]['solverSnapshot']['readiness']=='READY' and a[26]['solverSnapshot']['isolated']
assert '\n180 Ohm\n' in a[27]['body'] and 'Board Power: OFF' in a[27]['body']
assert a[32]['solverSnapshot']['readiness']=='POWER_OFF' and a[35]['solverSnapshot']['readiness']=='DISCHARGE'
assert a[38]['solverSnapshot']['readiness']=='READY' and a[38]['solverSnapshot']['isolated']
assert '\n457.627 mV\n' in a[39]['body'] and 'Board Power: OFF' in a[39]['body']
for lo,hi in [(19,25),(35,37)]:
    assert all(row['command']['op'] in ['observe','dump','shot','wait','pause'] for k,row in a.items() if lo<=k<=hi)
assert a[41]['command']=={'op':'click','name':'DIODE'} and '--- V' in a[42]['body'] and a[43]['solverSnapshot']['isolated']
elapsed=lambda lo,hi:(datetime.fromisoformat(a[hi]['finishedUtc'])-datetime.fromisoformat(a[lo]['finishedUtc'])).total_seconds()
flow={'status':'PASS_TARGETED_20_RECOVERY_ONLY','sourceIdentity':pin['sourceIdentity'],'seed':'10387','packages':20,'ohmWallSecondsUntilVisibleReading':elapsed(18,25),'diodeWallSecondsUntilVisibleReading':elapsed(34,37),'ohmReadySnapshot':a[26]['solverSnapshot'],'diodeReadySnapshot':a[38]['solverSnapshot'],'actualOhmDisplay':'180 Ohm','actualDiodeDisplay':'457.627 mV','automaticRecovery':'No mode,probe,power,reset,mutation or injected stepping between DISCHARGE and numeric reading in either cycle','activeModeToggleExit':'PASS via second DIODE click; board remains OFF','actions':len(a),'failedActions':0,'pageEvaluateUsed':True,'observationBoundary':'Private-only read-only getter reads actual CircuitJS time/voltages/readiness; ordinary SDK input drives all gameplay. No injected controller/solver calls. Built-in Browser unavailable. Not CDP wrapper or blind diagnosis certification.','screenshotsInspected':['001-final20-powered.png','002-final20-discharge.png','004-final20-ohm-recovered.png','005-final20-diode-recovered.png'],'threeRootRecovery':'NOT PROVEN;30 DREV-isolated C12 persists,40 REN-open tail slower. Fresh visible repair/retest on this source NOT RUN.','cleanup':ui['cleanup'],'independentRelease':read(U/'independent-release-audit.json')['status'],'acceptance':'Q30 DISABLED / NOT ACCEPTED'}
(T/'visible-flow-audit.json').write_text(json.dumps(flow,indent=2)+'\n')
rows=[]; members={}
replacements=[(str(R),'$REPO'),(str(W),'$TASK_WORKSPACE'),(str(Path(r'$TASK_TEMP')),'$TASK_TEMP'),('$USER_HOME','$USER_HOME'),('$USER_HOME','$USER_HOME'),('$WINDOWSAPPS','$WINDOWSAPPS')]
def portable(data):
    if data.startswith(b'\x89PNG'):return data
    text=data.decode('utf-8-sig')
    for old,new in replacements:
        text=text.replace(old,new).replace(old.replace('\\','\\\\'),new).replace(old.replace('\\','/'),new)
    assert not re.search(r'(?i)[A-Z]:[\\/]+Users[\\/]+david|[A-Z]:[\\/]+Program Files[\\/]+WindowsApps',text)
    assert not re.search(r'(?i)(Bearer\s+[A-Za-z0-9_-]{12}|gh[pousr]_[A-Za-z0-9]{20}|AKIA[A-Z0-9]{16})',text)
    return text.encode('utf-8')
def add(path,label):
    if not path.exists():return
    raw=path.read_bytes();data=portable(raw);assert label not in members
    members[label]=data;rows.append({'member':label,'rawSha256':sha(raw),'portableSha256':sha(data),'portableBytes':len(data)})
for name in ['source-snapshot.json','native.txt','native.log','native-result.json','native-controller-identity.json','native-audit.json','visible-flow-audit.json']:
    add(T/name,'final/'+name)
for directory in builds:
    for name in ['result.json','launch.json','build-launch.json','stdout.log','stderr.log','private-source-snapshot.json']:
        add(T/directory/name,'final/'+directory+'/'+name)
for name in ['result.json','source-binding.json','compile-result.json','controller-identity.json','sources.txt']:
    add(D/name,'baseline-real-solver/'+name)
for p in sorted(D.glob('case-*')):
    if p.is_file():add(p,'baseline-real-solver/'+p.name)
failed=Path(r'$TASK_TEMP\q30-targeted-discharge-244dc5df28e14c3685eb4b0bb2c68247')
for name in ['result.json','source-binding.json','compile-result.json','case-10387.json','case-10387.stdout.txt','case-10387.stderr.txt']:
    add(failed/name,'preserved-failed-fixture-r2/'+name)
add(N.parent/'targeted-q30-discharge-20261005'/'preparation-failure.json','preserved-failed-prepare-r1/preparation-failure.json')
for name in ['result.json','controller-identity.json','preview-process-identity.json','preview-serving-identity.json','owned-processes.json','bounded-process-result.json','bounded-command-result.json','independent-release-audit.json','preview.log']:
    add(U/name,'final/visible/'+name)
for directory in ['commands','responses']:
    for p in sorted((U/directory).glob('*.json')):add(p,'final/visible/'+directory+'/'+p.name)
for name in ['result.json','native-result.json','native-audit.json']:
    add(P3/name,'superseded-r3/'+name)
add(U3/'result.json','superseded-r3/visible/result.json')
add(U3/'independent-release-audit.json','superseded-r3/visible/independent-release-audit.json')
for p in sorted(N.glob('*.py')):add(p,'restart-drivers/'+p.name)
for p in sorted(N.glob('*.ps1')):add(p,'restart-drivers/'+p.name)
for name in ['seed10014-comparison-review.json','recorded-owner-release.json','early-failures.json']:
    add(N/name,'review/'+name)
for name in ['implementation-before.json','probe-guard-review-fix.json']:
    add(N.parent/'targeted-q30-discharge-20261005-r3'/name,'review/'+name)
for name in flow['screenshotsInspected']:add(U/'screenshots'/name,'screenshots/'+name)
original=read(Path(r'$TASK_TEMP\q30-final-source-abbc614e-bbc566e8e9a741ed80cf14b904021f1e')/'preserved-evidence-audit.json')
preserved=original['untracked']
for row in preserved:
    assert sha((R/row['path']).read_bytes())==row['sha256']
preservation={'status':'PASS','unchangedPreexistingUntrackedFiles':len(preserved),'untracked':preserved,'consumedSourceInputsVerified':1355,'sourceIdentity':pin['sourceIdentity'],'baselineInputsChangedOnly':['src/com/lushprojects/circuitjs1/client/Rb30Behavior.java','src/com/lushprojects/circuitjs1/client/ResistanceInstrumentMode.java','src/com/lushprojects/circuitjs1/client/DiodeTestInstrumentMode.java','tests/contracts/Q30PowerReadinessContractTest.java'],'noEvidenceDeletion':True,'DesktopSibling':'PRESERVED; no writes','resources':'Recorded owners and headed instances/owned ports released; task-temp evidence,classes,private/public copies and browser profiles retained'}
members['review/preservation-audit.json']=portable(json.dumps(preservation,indent=2).encode())
E.mkdir(exist_ok=False)
archive=E/'targeted-evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
    for name,data in sorted(members.items()):
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(members)
    for item in tar.getmembers():assert item.isfile() and item.size<4_000_000 and tar.extractfile(item).read()==members[item.name]
for name in flow['screenshotsInspected']:shutil.copyfile(U/'screenshots'/name,E/name)
(E/'seed10014-comparison-review.json').write_bytes(portable((N/'seed10014-comparison-review.json').read_bytes()))
(E/'visible-flow-audit.json').write_bytes(portable((T/'visible-flow-audit.json').read_bytes()))
(E/'preservation-audit.json').write_bytes(portable(json.dumps(preservation,indent=2).encode()))
manifest={'status':'PASS_EVIDENCE_ONLY','sourceHead':pin['head'],'sourceIdentity':pin['sourceIdentity'],'sourceBinding':'HEAD529f4258 + four final source/test edits,1355 raw inputs; later local commit may reuse only if every consumed byte remains identical','archiveSha256':sha(archive.read_bytes()),'regularMembers':len(members),'artifactDerivation':rows,'acceptance':'DISABLED / NOT ACCEPTED; no new cohort/full matrix/warm/menu/replay/archive gate','privacy':'Every included text artifact normalized for known personal roots and scanned for listed credential patterns; no comprehensive privacy claim','resources':{'recordedOwners':read(N/'recorded-owner-release.json')['status'],'headed':read(U/'independent-release-audit.json')['status']}}
(E/'packet-audit.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={'status':'LOCAL_TARGETED_FIX_VERIFIED_PENDING_COMMIT','sourceIdentity':pin['sourceIdentity'],'packet':E.relative_to(R).as_posix(),'packetSha256':manifest['archiveSha256'],'members':len(members),'flow':flow,'native':read(T/'native-result.json'),'buildOperations':{name:b['operation'] for name,b in builds.items()},'remaining':'New-source full77,full native matrix/compiled canaries,warm population,qualified menu/replay,visible30/40 repair-to-readiness/source archive/enabled build and independent parent acceptance; no public enablement'}
(N/'checkpoint-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'packet':str(E),'regularMembers':len(members),'archiveSha256':manifest['archiveSha256'],'flow':{k:flow[k] for k in ['status','actions','ohmWallSecondsUntilVisibleReading','diodeWallSecondsUntilVisibleReading']}}))
