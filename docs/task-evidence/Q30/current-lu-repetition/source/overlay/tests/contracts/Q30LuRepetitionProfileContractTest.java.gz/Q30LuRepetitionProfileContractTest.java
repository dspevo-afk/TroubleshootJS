package com.lushprojects.circuitjs1.client;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Vector;

/** Focused native contract for the opt-in, read-only adjacent-LU sampler. */
public final class Q30LuRepetitionProfileContractTest {
    private static final String PROFILE_CLASS =
        "com.lushprojects.circuitjs1.client.CirSim$LuRepetitionProfile";

    public static void main(String[] args) throws Exception {
        verifyAdjacentPositionsAndReuse();
        verifyWorkScopeAndBoundaryAborts();
        verifyDimensionOwnerAndAnalysisAborts();
        verifyExactValuesAndSignedZero();
        verifySamplingDoesNotFactorOrMutate();
        verifyInactiveEndIsNull();
        System.out.println("PASS: Q30 LU repetition profile contracts sampler=adjacent");
    }

    private static void verifyAdjacentPositionsAndReuse() throws Exception {
        Object profile = newProfile();
        setScope(profile, true);
        double[][] matrix = { { 2, -0.0 }, { 0.5, 3 } };
        String before = bits(matrix);
        for (int factor = 1; factor < 1021; factor++)
            require(action(profile) == none(), "unexpected early sample at factor " + factor);
        require(action(profile) == start(), "factor 1021 was not a sample start");
        capture(profile, matrix, 9, 4);
        require(bits(matrix).equals(before), "sample start changed the matrix");
        require(action(profile) == compare(), "factor 1022 was not the adjacent comparison");
        compare(profile, matrix, 9, 4);
        require(bits(matrix).equals(before), "sample comparison changed the matrix");
        require(!booleanValue(profile, "pairPending") &&
            !booleanValue(profile, "compareNextFactor"),
            "completed pair left pending state behind");
        Object reusableBuffer = field(profile, "sampleBuffer");

        for (int factor = 1023; factor < 2042; factor++)
            require(action(profile) == none(), "unexpected sample before factor " + factor);
        require(action(profile) == start(), "factor 2042 was not the next sample start");
        capture(profile, matrix, 9, 4);
        require(field(profile, "sampleBuffer") == reusableBuffer,
            "completed-pair snapshot buffer was not reused");
        require(action(profile) == compare(), "factor 2043 was not its adjacent comparison");
        compare(profile, matrix, 9, 4);
        require(intValue(profile, "completedPairs") == 2, "two adjacent pairs were not completed");
        require(intValue(profile, "matchedPairs") == 2, "identical matrices did not match exactly");
        require(longValue(profile, "comparedEntries") == 8,
            "bulk compared-entry accounting lost matrix cells");
        require(intValue(profile, "sampledStarts") == 2, "sample start count mismatch");
        require(intValue(profile, "compareAttempts") == 2, "sample comparison count mismatch");
        require(intValue(profile, "workScopeWindows") == 1, "work scope window count mismatch");
        require(vector(profile, "startPositions").toString().equals("[1021, 2042]"),
            "sample start positions were not auditable");
        require(vector(profile, "comparePositions").toString().equals("[1022, 2043]"),
            "adjacent comparison positions were not auditable");
        setScope(profile, false);
        clear(profile);
    }

    private static void verifyWorkScopeAndBoundaryAborts() throws Exception {
        Object profile = newProfile();
        setScope(profile, true);
        double[][] matrix = { { 4, 1 }, { 2, 3 } };
        for (int factor = 1; factor < 1021; factor++) action(profile);
        require(action(profile) == start(), "scope fixture failed to reach first start");
        capture(profile, matrix, 1, 1);
        setScope(profile, false);
        require(intValue(profile, "abortedPendingPairs") == 1,
            "closing the owned-work window did not abort its pending pair");
        require(!booleanValue(profile, "pairPending"), "pending pair crossed work-window boundary");
        int callsAtWindowEnd = intValue(profile, "factorCalls");
        require(action(profile) == none() && intValue(profile, "factorCalls") == callsAtWindowEnd,
            "out-of-window factor attempt changed profile counters");
        setScope(profile, true);
        require(action(profile) == none(), "next work window compared across a foreign interval");
        require(intValue(profile, "compareAttempts") == 0,
            "out-of-window factor attempt was included in profile counts");
        setScope(profile, false);
        clear(profile);
    }

    private static void verifyDimensionOwnerAndAnalysisAborts() throws Exception {
        double[][] matrix = { { 2, 1 }, { 0, 4 } };

        Object dimension = newProfile();
        setScope(dimension, true);
        startPair(dimension, matrix, 7, 3);
        compare(dimension, new double[][] { { 2 } }, 7, 3);
        require(intValue(dimension, "completedPairs") == 0 &&
            intValue(dimension, "abortedPendingPairs") == 1,
            "matrix-size mismatch was accepted as a pair");
        setScope(dimension, false);
        clear(dimension);

        Object owner = newProfile();
        setScope(owner, true);
        startPair(owner, matrix, 7, 3);
        compare(owner, matrix, 8, 3);
        require(intValue(owner, "completedPairs") == 0 &&
            intValue(owner, "abortedPendingPairs") == 1,
            "generation change was accepted as a pair");
        setScope(owner, false);
        clear(owner);

        Object revision = newProfile();
        setScope(revision, true);
        startPair(revision, matrix, 7, 3);
        compare(revision, matrix, 7, 4);
        require(intValue(revision, "completedPairs") == 0 &&
            intValue(revision, "abortedPendingPairs") == 1,
            "revision change was accepted as a pair");
        setScope(revision, false);
        clear(revision);

        Object epoch = newProfile();
        setScope(epoch, true);
        startPair(epoch, matrix, 7, 3);
        invoke(epoch, "analysisBoundary", new Class<?>[0]);
        require(intValue(epoch, "completedPairs") == 0 &&
            intValue(epoch, "abortedPendingPairs") == 1 &&
            !booleanValue(epoch, "compareNextFactor"),
            "analysis boundary did not abort the pair and next-call marker");
        require(action(epoch) == none(), "analysis boundary left a scheduled comparison");
        setScope(epoch, false);
        clear(epoch);
    }

    private static void verifyExactValuesAndSignedZero() throws Exception {
        Object signedZero = newProfile();
        setScope(signedZero, true);
        startPair(signedZero, new double[][] { { 0.0 } }, 2, 5);
        compare(signedZero, new double[][] { { -0.0 } }, 2, 5);
        require(intValue(signedZero, "differentPairs") == 1 &&
            intValue(signedZero, "signedZeroDifferencePairs") == 1 &&
            longValue(signedZero, "signedZeroDifferenceEntries") == 1,
            "signed-zero matrix difference was not preserved");
        setScope(signedZero, false);
        clear(signedZero);

        Object changed = newProfile();
        setScope(changed, true);
        startPair(changed, new double[][] { { 1.0, 2.0 } }, 2, 5);
        compare(changed, new double[][] { { Math.nextUp(1.0), 2.0 } }, 2, 5);
        require(intValue(changed, "differentPairs") == 1 &&
            intValue(changed, "matchedPairs") == 0,
            "distinct finite matrix values were treated as equal");
        setScope(changed, false);
        clear(changed);
    }

    private static void verifySamplingDoesNotFactorOrMutate() throws Exception {
        Object profile = newProfile();
        setScope(profile, true);
        double[][] matrix = { { 4, 1 }, { 2, 3 } };
        String before = bits(matrix);
        startPair(profile, matrix, 3, 8);
        compare(profile, matrix, 3, 8);
        require(bits(matrix).equals(before), "sampling itself factored or mutated the matrix");
        require(CirSim.lu_factor(matrix, 2, new int[2]),
            "ordinary LU call after sampling was skipped or failed");
        require(!bits(matrix).equals(before), "ordinary LU call did not factor the matrix");
        setScope(profile, false);
        clear(profile);
    }

    private static void verifyInactiveEndIsNull() throws Exception {
        Class<?> unsafeType = Class.forName("sun.misc.Unsafe");
        Field singleton = unsafeType.getDeclaredField("theUnsafe");
        singleton.setAccessible(true);
        Object unsafe = singleton.get(null);
        Object sim = unsafeType.getMethod("allocateInstance", Class.class)
            .invoke(unsafe, CirSim.class);
        Method end = CirSim.class.getDeclaredMethod("endLuRepetitionProfile");
        end.setAccessible(true);
        require(end.invoke(sim) == null, "inactive profile end did not return null");
    }

    private static Object newProfile() throws Exception {
        Class<?> type = Class.forName(PROFILE_CLASS);
        Constructor<?> constructor = type.getDeclaredConstructor(String.class);
        constructor.setAccessible(true);
        return constructor.newInstance("contract");
    }

    private static int none() throws Exception { return constant("SAMPLE_NONE"); }
    private static int start() throws Exception { return constant("SAMPLE_START"); }
    private static int compare() throws Exception { return constant("SAMPLE_COMPARE"); }

    private static int constant(String name) throws Exception {
        Field field = Class.forName(PROFILE_CLASS).getDeclaredField(name);
        field.setAccessible(true);
        return field.getInt(null);
    }

    private static int action(Object profile) throws Exception {
        return ((Integer)invoke(profile, "factorAction", new Class<?>[0])).intValue();
    }

    private static void setScope(Object profile, boolean active) throws Exception {
        invoke(profile, "setWorkScope", new Class<?>[] { Boolean.TYPE }, Boolean.valueOf(active));
    }

    private static void capture(Object profile, double[][] matrix, long generation, long revision)
            throws Exception {
        invoke(profile, "captureStart", new Class<?>[] {
            double[][].class, Integer.TYPE, Long.TYPE, Long.TYPE
        }, matrix, Integer.valueOf(matrix.length), Long.valueOf(generation), Long.valueOf(revision));
    }

    private static void startPair(Object profile, double[][] matrix, long generation, long revision)
            throws Exception {
        Field factorCalls = profile.getClass().getDeclaredField("factorCalls");
        factorCalls.setAccessible(true);
        factorCalls.setInt(profile, 1020);
        require(action(profile) == start(), "fixture did not produce a sample start");
        capture(profile, matrix, generation, revision);
        require(action(profile) == compare(), "fixture did not schedule the adjacent comparison");
    }

    private static void compare(Object profile, double[][] matrix, long generation, long revision)
            throws Exception {
        invoke(profile, "compareNext", new Class<?>[] {
            double[][].class, Integer.TYPE, Long.TYPE, Long.TYPE
        }, matrix, Integer.valueOf(matrix.length), Long.valueOf(generation), Long.valueOf(revision));
    }

    private static Object invoke(Object target, String name, Class<?>[] parameterTypes,
            Object... arguments) throws Exception {
        Method method = target.getClass().getDeclaredMethod(name, parameterTypes);
        method.setAccessible(true);
        return method.invoke(target, arguments);
    }

    private static void clear(Object profile) throws Exception {
        invoke(profile, "clear", new Class<?>[0]);
        require(field(profile, "sampleBuffer") == null, "clear retained the snapshot buffer");
    }

    private static Object field(Object target, String name) throws Exception {
        Field field = target.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(target);
    }

    private static int intValue(Object target, String name) throws Exception {
        return ((Integer)field(target, name)).intValue();
    }

    private static long longValue(Object target, String name) throws Exception {
        return ((Long)field(target, name)).longValue();
    }

    private static boolean booleanValue(Object target, String name) throws Exception {
        return ((Boolean)field(target, name)).booleanValue();
    }

    @SuppressWarnings("unchecked")
    private static Vector<Integer> vector(Object target, String name) throws Exception {
        return (Vector<Integer>)field(target, name);
    }

    private static String bits(double[][] matrix) {
        StringBuilder result = new StringBuilder();
        for (double[] row : matrix) {
            for (double value : row)
                result.append(Long.toHexString(Double.doubleToLongBits(value))).append(',');
            result.append(';');
        }
        return result.toString();
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
