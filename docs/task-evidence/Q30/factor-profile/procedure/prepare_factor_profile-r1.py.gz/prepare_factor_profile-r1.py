from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import subprocess


PREPARATION = Path(__file__).resolve().parent
TASK_SCRATCH = PREPARATION.parents[1]
REPOSITORY = Path(
    "[REDACTED_USER_PATH]"
)
EXPECTED_HEAD = "57929125daf6322006fe7da871b2edc7cca9590d"
EXPECTED_BASE_AUDIT_SHA256 = (
    "9186034b2cfe23a3c77f6e2c0d31c466bbc6ee798feadc1fa9542397381d680c"
)
EXPECTED_FACTOR_DRAFT_BASE_CIR = (
    "60371360961abf8645c388b06d8f3741d311d4b0a3d045b6cc1ba2e123b887fc"
)
EXPECTED_FACTOR_DRAFT_CIR = (
    "102d41b1f5e5c644eb38d23fdea70586d03746b5d41ce615b9778a1bb c069957"
    .replace(" ", "")
)
EXPECTED_FACTOR_TEST = (
    "3bf74b9406eb1bc70e4499004949446513ff56b3abd457cc0ee0b23f3811068d"
)
EXPECTED_ROOT_CIRSIM = (
    "2658e94560fd9e1f0e9157a54be773bd9568d9350fa6ce56c39acaa7cf87e0b1"
)
EXPECTED_ROOT_LU_CHECKS = (
    "d558d7d10706cb1da22d20f795ece6448e714be5d16315ad51a125c70b429c6c"
)
EXPECTED_REVIEW_SHA256 = ""
SOLVE_PROFILE_POINTER = TASK_SCRATCH / "solve-profile-source-path.txt"
FACTOR_DRAFT = TASK_SCRATCH / "factor-profile-draft"
FACTOR_DRAFT_README = FACTOR_DRAFT / "README.md"
FACTOR_DRAFT_HASH_MANIFEST = FACTOR_DRAFT / "source-hashes.json"
REVIEW_PATH = TASK_SCRATCH / "scratch" / "factor-profile-independent-review.md"
BASE_CIR_PATH = "src/com/lushprojects/circuitjs1/client/CirSim.java"
LU_CHECKS_PATH = "src/com/lushprojects/circuitjs1/client/LuFactorizationChecks.java"
DRIVER_PATH = "scripts/verify-current-contracts.ps1"
FACTOR_TEST_PATH = "tests/contracts/Q30LuFactorProfileContractTest.java"
ROOT_CIRSIM = REPOSITORY / Path(*PurePosixPath(BASE_CIR_PATH).parts)
ROOT_LU_CHECKS = REPOSITORY / Path(*PurePosixPath(LU_CHECKS_PATH).parts)
FACTOR_CANDIDATE_CIRSIM = FACTOR_DRAFT / "candidate" / Path(*PurePosixPath(BASE_CIR_PATH).parts)
FACTOR_BASELINE_CIRSIM = FACTOR_DRAFT / "baseline" / Path(*PurePosixPath(BASE_CIR_PATH).parts)
FACTOR_TEST = FACTOR_DRAFT / "candidate" / Path(*PurePosixPath(FACTOR_TEST_PATH).parts)
FIXTURE = PREPARATION / "fixture"
POINTER_OUT = PREPARATION / "factor-profile-source-path.txt"
AUDIT_OUT = PREPARATION / "source-audit.json"
FOCUSED_COMMAND = (
    "powershell -NoProfile -ExecutionPolicy Bypass -File "
    "scripts/verify-current-contracts.ps1 -Suite Q30LuFactorProfileContractTest"
)
EXPECTED_TEST_MARKER = "PASS: Q30 LU factor profile contracts assertions=<n>"
EXPECTED_DRIVER_MARKER = (
    "PASS: focused current contracts; 1 Java suites. Full matrix and "
    "independent oracles NOT RUN."
)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def safe_relative_path(value):
    relative = PurePosixPath(value)
    require(not relative.is_absolute() and ".." not in relative.parts,
            "unsafe source manifest path: " + value)
    require(value and "\\" not in value,
            "non-canonical source manifest path: " + value)
    return relative


def rows_by_path(rows):
    result = {}
    for row in rows:
        path = row["path"]
        require(path not in result, "duplicate source input path: " + path)
        result[path] = row
    return result


def java_method_span(source, method_name):
    pattern = re.compile(r"(?m)^[ \t]*static[ \t]+void[ \t]+" +
                         re.escape(method_name) + r"[ \t]*\(")
    matches = list(pattern.finditer(source))
    require(len(matches) == 1,
            "expected one static void " + method_name + " method, found " + str(len(matches)))
    start = matches[0].start()
    open_brace = source.find("{", matches[0].end())
    require(open_brace >= 0, "method declaration has no opening brace: " + method_name)

    depth = 0
    state = "code"
    index = open_brace
    while index < len(source):
        current = source[index]
        following = source[index + 1] if index + 1 < len(source) else ""
        if state == "line-comment":
            if current == "\n":
                state = "code"
        elif state == "block-comment":
            if current == "*" and following == "/":
                state = "code"
                index += 1
        elif state == "string" or state == "character":
            closing = '"' if state == "string" else "'"
            if current == "\\":
                index += 1
            elif current == closing:
                state = "code"
        else:
            if current == "/" and following == "/":
                state = "line-comment"
                index += 1
            elif current == "/" and following == "*":
                state = "block-comment"
                index += 1
            elif current == '"':
                state = "string"
            elif current == "'":
                state = "character"
            elif current == "{":
                depth += 1
            elif current == "}":
                depth -= 1
                if depth == 0:
                    return start, index + 1
        index += 1
    raise RuntimeError("method body did not close: " + method_name)


def graft_root_method(candidate_bytes, root_bytes, method_name):
    candidate = candidate_bytes.decode("utf-8")
    root = root_bytes.decode("utf-8")
    candidate_start, candidate_end = java_method_span(candidate, method_name)
    root_start, root_end = java_method_span(root, method_name)
    method = root[root_start:root_end]
    result = candidate[:candidate_start] + method + candidate[candidate_end:]
    result_start, result_end = java_method_span(result, method_name)
    require(result[result_start:result_end] == method,
            "grafted method is not byte-exact root " + method_name)
    require(candidate[:candidate_start] == result[:result_start] and
            candidate[candidate_end:] == result[result_end:],
            "source outside " + method_name + " changed during the graft")
    return result.encode("utf-8"), sha256(method.encode("utf-8"))


def main():
    require(not FIXTURE.exists() and not POINTER_OUT.exists() and not AUDIT_OUT.exists(),
            "factor-profile outputs already exist; refusing to overwrite")
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=str(REPOSITORY), text=True
    ).strip()
    require(head == EXPECTED_HEAD, "root HEAD differs from pinned factor-profile identity")

    base_path = Path(SOLVE_PROFILE_POINTER.read_text(encoding="utf-8").strip())
    base_audit_path = base_path / "source-audit.json"
    base_audit_raw = base_audit_path.read_bytes()
    require(sha256(base_audit_raw) == EXPECTED_BASE_AUDIT_SHA256,
            "validated solve-profile source audit changed")
    base_audit = json.loads(base_audit_raw)
    require(base_audit.get("head") == EXPECTED_HEAD and
            len(base_audit.get("inputs", [])) == 1341 and
            len(base_audit.get("rootInputs", [])) == 1339,
            "validated solve-profile fixture is not the pinned 1341-input source")
    base_inputs = rows_by_path(base_audit["inputs"])
    require(BASE_CIR_PATH in base_inputs and LU_CHECKS_PATH in base_inputs and
            DRIVER_PATH in base_inputs and FACTOR_TEST_PATH not in base_inputs,
            "solve-profile inputs do not match the expected factor-profile base")

    factor_base = FACTOR_BASELINE_CIRSIM.read_bytes()
    factor_candidate = FACTOR_CANDIDATE_CIRSIM.read_bytes()
    factor_test = FACTOR_TEST.read_bytes()
    require(sha256(factor_base) == EXPECTED_FACTOR_DRAFT_BASE_CIR,
            "factor draft baseline does not match validated solve-profile CirSim")
    require(sha256(factor_candidate) == EXPECTED_FACTOR_DRAFT_CIR,
            "factor draft CirSim candidate hash changed")
    require(sha256(factor_test) == EXPECTED_FACTOR_TEST,
            "factor contract test hash changed")
    base_cir_row = base_inputs[BASE_CIR_PATH]
    require(base_cir_row["sha256"] == EXPECTED_FACTOR_DRAFT_BASE_CIR,
            "factor draft baseline and solve-profile input hash differ")

    root_cir_bytes = ROOT_CIRSIM.read_bytes()
    root_lu_bytes = ROOT_LU_CHECKS.read_bytes()
    require(sha256(root_cir_bytes) == EXPECTED_ROOT_CIRSIM,
            "current root CirSim does not match accepted sticky-finite source")
    require(sha256(root_lu_bytes) == EXPECTED_ROOT_LU_CHECKS,
            "current root LuFactorizationChecks does not match accepted source")
    factor_candidate_with_root_solve, root_solve_method_sha256 = graft_root_method(
        factor_candidate, root_cir_bytes, "lu_solve"
    )

    FIXTURE.mkdir()
    for path, row in base_inputs.items():
        relative = safe_relative_path(path)
        source = base_path.joinpath(*relative.parts)
        require(source.is_file() and not source.is_symlink(),
                "validated solve-profile input missing or symlinked: " + path)
        raw = source.read_bytes()
        require(len(raw) == row["bytes"] and sha256(raw) == row["sha256"],
                "validated solve-profile input hash mismatch: " + path)
        destination = FIXTURE.joinpath(*relative.parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)

    (FIXTURE / Path(*PurePosixPath(BASE_CIR_PATH).parts)).write_bytes(
        factor_candidate_with_root_solve
    )
    (FIXTURE / Path(*PurePosixPath(LU_CHECKS_PATH).parts)).write_bytes(root_lu_bytes)
    factor_test_target = FIXTURE / Path(*PurePosixPath(FACTOR_TEST_PATH).parts)
    require(not factor_test_target.exists(), "factor-profile test already exists in base")
    factor_test_target.parent.mkdir(parents=True, exist_ok=True)
    factor_test_target.write_bytes(factor_test)

    driver_target = FIXTURE / Path(*PurePosixPath(DRIVER_PATH).parts)
    driver_before = driver_target.read_bytes()
    require(sha256(driver_before) == base_inputs[DRIVER_PATH]["sha256"],
            "focused native driver differs from validated solve-profile input")
    driver = driver_before.decode("utf-8")
    anchor = (
        "        @{ Name = 'Q30OwnedLuZeroRowContractTest'; "
        "Marker = 'Q30 owned LU zero-row contracts ' },"
    )
    registration = (
        "        @{ Name = 'Q30LuFactorProfileContractTest'; "
        "Marker = 'Q30 LU factor profile contracts ' },"
    )
    require(driver.count(anchor) == 1 and registration not in driver,
            "native driver anchor is missing/duplicated or factor suite is already registered")
    newline = "\r\n" if "\r\n" in driver else "\n"
    driver = driver.replace(anchor, anchor + newline + registration, 1)
    driver_target.write_bytes(driver.encode("utf-8"))

    paths = set(base_inputs)
    paths.add(FACTOR_TEST_PATH)
    require(len(paths) == 1342, "final fixture input count is not 1342")
    actual_paths = {
        path.relative_to(FIXTURE).as_posix()
        for path in FIXTURE.rglob("*") if path.is_file()
    }
    require(actual_paths == paths, "final fixture file set differs from 1341 inputs plus factor test")

    final_inputs = []
    for path in sorted(paths):
        raw = FIXTURE.joinpath(*safe_relative_path(path).parts).read_bytes()
        final_inputs.append({"path": path, "sha256": sha256(raw), "bytes": len(raw)})
    final_rows = rows_by_path(final_inputs)

    changed_from_base = []
    for path, row in base_inputs.items():
        if final_rows[path]["sha256"] != row["sha256"]:
            changed_from_base.append(path)
    changed_from_base.append(FACTOR_TEST_PATH)
    expected_changed = {BASE_CIR_PATH, LU_CHECKS_PATH, DRIVER_PATH, FACTOR_TEST_PATH}
    require(set(changed_from_base) == expected_changed,
            "fixture differs from solve-profile base outside intended factor overlays")

    test_text = factor_test.decode("utf-8")
    require('PASS: Q30 LU factor profile contracts assertions=' in test_text,
            "factor native test PASS marker changed")
    require(registration in driver and driver.count(registration) == 1,
            "focused native driver registration did not persist exactly once")
    war_count = sum(1 for path in paths if path.startswith("war/"))
    jar_count = sum(1 for path in paths if path.lower().endswith(".jar"))
    require(war_count == 29 and jar_count == 9,
            "final source fixture WAR/JAR inventory differs from pinned base")

    review_hash = sha256(REVIEW_PATH.read_bytes()) if REVIEW_PATH.is_file() else None
    audit = {
        "status": "SOURCE_ONLY_FIXTURE_PREPARED_NOT_VALIDATED",
        "scope": "factor-profile source candidate over validated solve-profile inputs; no build/test/browser gate or production integration",
        "head": head,
        "baseFixture": {
            "pointer": str(SOLVE_PROFILE_POINTER),
            "path": str(base_path),
            "sourceAuditPath": str(base_audit_path),
            "sourceAuditSha256": EXPECTED_BASE_AUDIT_SHA256,
            "inputCount": len(base_inputs),
            "rootInputCount": len(base_audit["rootInputs"]),
        },
        "factorDraft": {
            "readmePath": str(FACTOR_DRAFT_README),
            "hashManifestPath": str(FACTOR_DRAFT_HASH_MANIFEST),
            "baselineCirSimSha256": EXPECTED_FACTOR_DRAFT_BASE_CIR,
            "candidateCirSimSha256": EXPECTED_FACTOR_DRAFT_CIR,
            "newTestSha256": EXPECTED_FACTOR_TEST,
            "independentReviewPath": str(REVIEW_PATH),
            "independentReviewSha256": review_hash,
        },
        "acceptedRootSolverSources": {
            "rootCirSimPath": str(ROOT_CIRSIM),
            "rootCirSimSha256": EXPECTED_ROOT_CIRSIM,
            "rootLuFactorizationChecksPath": str(ROOT_LU_CHECKS),
            "rootLuFactorizationChecksSha256": EXPECTED_ROOT_LU_CHECKS,
            "rootLuSolveMethodSha256": root_solve_method_sha256,
        },
        "focusedNativeContract": {
            "script": "scripts/verify-current-contracts.ps1",
            "suite": "Q30LuFactorProfileContractTest",
            "command": FOCUSED_COMMAND,
            "testPassMarker": EXPECTED_TEST_MARKER,
            "driverPassMarker": EXPECTED_DRIVER_MARKER,
            "status": "NOT RUN",
        },
        "inputs": final_inputs,
        "overlays": [
            {"path": BASE_CIR_PATH,
             "action": "replace factor-draft baseline with factor candidate plus exact current root lu_solve",
             "sha256": final_rows[BASE_CIR_PATH]["sha256"],
             "bytes": final_rows[BASE_CIR_PATH]["bytes"]},
            {"path": LU_CHECKS_PATH,
             "action": "replace with current accepted root file",
             "sha256": EXPECTED_ROOT_LU_CHECKS,
             "bytes": final_rows[LU_CHECKS_PATH]["bytes"]},
            {"path": FACTOR_TEST_PATH,
             "action": "add factor-profile native contract test",
             "sha256": EXPECTED_FACTOR_TEST,
             "bytes": final_rows[FACTOR_TEST_PATH]["bytes"]},
            {"path": DRIVER_PATH,
             "action": "register focused factor-profile suite and exact PASS marker",
             "sha256": final_rows[DRIVER_PATH]["sha256"],
             "bytes": final_rows[DRIVER_PATH]["bytes"]},
        ],
        "changedFromSolveProfileBase": sorted(expected_changed),
        "generatedWarCopied": False,
        "warFileCount": war_count,
        "pinnedJarCount": jar_count,
        "validation": {"native": "NOT RUN", "GWT": "NOT RUN", "browser": "NOT RUN"},
    }
    audit_path = PREPARATION / "source-audit.json"
    audit_path.write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    POINTER_OUT.write_text(str(FIXTURE) + "\n", encoding="utf-8")
    readme = (
        "# LU factor-profile source fixture\n\n"
        "Source-only candidate based on the validated 1,341-input solve-profile fixture. "
        "The factor candidate retains profiler work while only `lu_solve` is grafted "
        "from the accepted current root CirSim; current accepted LuFactorizationChecks "
        "are copied whole. The new factor test is registered in the copied native driver.\n\n"
        "Focused native command (NOT RUN):\n\n"
        "```powershell\n" + FOCUSED_COMMAND + "\n```\n\n"
        "Expected test line: `" + EXPECTED_TEST_MARKER + "`; expected focused-driver line: `" +
        EXPECTED_DRIVER_MARKER + "`. No build, test, browser gate, or production integration "
        "is claimed. See `source-audit.json` for every final source hash and exact overlays.\n"
    )
    (PREPARATION / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps({
        "fixture": str(FIXTURE),
        "head": head,
        "baseInputCount": len(base_inputs),
        "finalInputCount": len(final_inputs),
        "changedFromBase": sorted(expected_changed),
        "rootLuSolveMethodSha256": root_solve_method_sha256,
        "warFiles": war_count,
        "pinnedJars": jar_count,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
