# LU whole-factor metadata validator

Scratch-only module: `factor-profile-metadata-validator.py`

- SHA-256: `ABD0A4352F2505055F36AC16BA0987EAE102C8CB8381378C909A842978A6D490`.
- Candidate field identity: factor-profile-draft `CirSim.java`, SHA-256 `102D41B1F5E5C644EB38D23FDEA70586D03746B5D41CE615B9778A1BBC069957`.
- Public API: `validate(profile)` returns a JSON-compatible summary; `negative_canaries(profile)` mutates actual factor/preflight fields and returns `{case,status,reason}` records. Invalid inputs raise `FactorMetadataValidationError` (an `AssertionError`).
- It validates exactly the ten `luFactor*` fields added by the draft and does not change or replace the existing solve/preflight validator. It ties timing attempts to `sampledStarts + compareAttempts`, keeps all selected outcomes successful, balances starts/completions/samples/errors and outcomes, requires the whole-factor elapsed time to be finite and nonnegative, and confirms it is at least the nested zero-row-preflight time.
- Clock modes are distinct. `performance.now` requires one valid timing sample per selected factor and no unavailable clocks/errors. `unavailable-native` requires one unavailable-clock count per factor, zero elapsed samples/errors and zero elapsed milliseconds. The native mode is structural evidence only; it cannot support a browser timing claim.

A lightweight synthetic self-check passed for one browser profile, one native profile, and 15 negative mutations to actual fields (boolean/missing/unexpected fields, attempt/completion/sample/error/outcome/native-clock counts, NaN/negative/non-inclusive elapsed, scope/clock identity, and nested preflight completion). This is module-level validation only. No live Q30 profile report, browser, build, or gate was run.

The module intentionally has no coordinator report argument, so it does not bound factor milliseconds by phase elapsed/deadline and does not run solve-profile/full-parity checks. The root integration should compose `validate(profile)` with the unchanged solve/preflight validator and require the browser summary's `measured` flag before comparing factor time to the approximately 22.5-second routing stage. Do not add `luFactorMillis` to `zeroRowPreflightMillis`; the factor interval includes preflight.

Example import uses `importlib.util.spec_from_file_location(...)` for the hyphenated filename, then `summary = module.validate(profile)`. The module's synthetic negative canaries require a GWT-timed baseline.