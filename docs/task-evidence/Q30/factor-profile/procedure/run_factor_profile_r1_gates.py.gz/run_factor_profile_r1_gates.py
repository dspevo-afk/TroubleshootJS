from pathlib import Path
import hashlib,json,subprocess,sys,time
s=Path(__file__).resolve().parent
repo=Path(r'[REDACTED_USER_PATH]
fixture=Path(sys.argv[1]);audit_path=Path(sys.argv[2]);native=Path(sys.argv[3])
audit_raw=audit_path.read_bytes();audit=json.loads(audit_raw)
out=s/'factor-profile-r1-gates.json';assert not out.exists()
receipt={'status':'RUNNING','scope':'isolated selected whole-factor timing gates; not Q30 acceptance','sourceAuditSha256':hashlib.sha256(audit_raw).hexdigest(),'steps':[]}
def unchanged():
 for e in audit['inputs']:
  b=(fixture/e['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'] and len(b)==e['bytes'],e['path']
def save():out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
def run(label,args):
 unchanged();print('START '+label,flush=True);started=time.monotonic()
 p=subprocess.run(args,check=False)
 receipt['steps'].append({'name':label,'command':args,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-started});save()
 assert p.returncode==0,label
 unchanged();print('PASS '+label,flush=True)
save()
try:
 run('native8',['pwsh','-NoProfile','-File',str(native),'-SourceRoot',str(fixture),'-Label','native-factor-profile-r1'])
 run('gwt5',['pwsh','-NoProfile','-File',str(s/'build-run.ps1'),'-SourceRoot',str(fixture),'-Label','factor-profile-r1-gwt'])
 run('compiled-a07-disabled-normal',[sys.executable,'-B',str(s/'run_current_solver_canaries.py'),str(repo),str(s),str(fixture),'factor-profile-r1-canaries'])
 host=json.loads((s/'factor-profile-r1-canaries/result.json').read_bytes())
 assert host['outcome']=='PASS' and host['inputAudit']['status']=='PASS' and len(host['cases'])==2
 c=host['cleanup'];assert c['status']=='PASS' and c['serverStopped'] and not c['errors'] and not c['ownedSurvivors']
 a07=[]
 for row in host['cases']:
  assert row['outcome']=='PASS' and row['stateMatch'] and row['reportMatch'] and not row['timedOut'] and not row['navigationError']
  for key in ('pageErrors','httpErrors','consoleErrors','attributeReadErrors','listenerCleanupErrors'):assert row[key]==[]
  raw=(s/'factor-profile-r1-canaries'/row['reportFile']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['reportSha256']
  if row['observedState']=='PASS:a07':a07.append(s/'factor-profile-r1-canaries'/row['reportFile'])
 assert len(a07)==1
 run('exact-a07-reader-three-corruptions',['pwsh','-NoProfile','-File',str(s/'read_a07.ps1'),'-Repo',str(repo),'-Report',str(a07[0])])
 receipt['status']='FOCUSED_GATES_PASS_NOT_ACCEPTANCE';save()
except BaseException as error:
 receipt['status']='STOPPED_FAILURE';receipt['failure']=str(error);save();raise
