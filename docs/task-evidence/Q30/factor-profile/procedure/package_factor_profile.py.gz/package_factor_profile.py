#!/usr/bin/env python3
"""Package the frozen factor-profile diagnostic and its validation receipts."""
import argparse, gzip, hashlib, json, re, sys
from pathlib import Path

PRIVATE = re.compile(rb'(?i)[a-z]:[/\\]+Users[/\\]+david(?:[/\\][^\\/\s"<>|?*:,;]+)*')
LABELS = ('factor-profile-01-off-10014', 'factor-profile-02-profile-10014')
CHANGED = (
 'scripts/verify-current-contracts.ps1',
 'src/com/lushprojects/circuitjs1/client/CirSim.java',
 'src/com/lushprojects/circuitjs1/client/LuFactorizationChecks.java',
 'tests/contracts/Q30LuFactorProfileContractTest.java',
)
def sha(b): return hashlib.sha256(b).hexdigest()
def fail(s): raise RuntimeError(s)
def readj(p):
 try: return json.loads(p.read_text(encoding='utf-8'))
 except Exception as e: fail(f'bad JSON {p}: {e}')
def scrub(b, exact=False):
 if exact and PRIVATE.search(b): fail('personal path in exact source/report payload')
 if exact: return b, 0
 out,n=PRIVATE.subn(b'[REDACTED_USER_PATH]',b)
 if PRIVATE.search(out): fail('path scrub incomplete')
 return out,n

a=argparse.ArgumentParser(description=__doc__)
a.add_argument('--repo',required=True,type=Path); a.add_argument('--scratch',required=True,type=Path); a.add_argument('--replace-owned',action='store_true')
x=a.parse_args(); repo=x.repo.resolve(strict=True); S=x.scratch.resolve(strict=True)
if not (repo/'.git').exists(): fail('repo path is not a Git checkout')
out=repo/'docs/task-evidence/Q30/factor-profile'
out.mkdir(parents=True,exist_ok=True)
existing=[p for p in out.rglob('*') if p.is_file()]
if existing:
 if not x.replace_owned: fail('output folder already populated; pass --replace-owned only for a prior packet from this packager')
 ip=out/'inventory.json'; sp=out/'inventory.sha256'
 if not ip.is_file() or not sp.is_file(): fail('existing packet has no inventory; refusing replacement')
 old=json.loads(ip.read_text(encoding='utf-8')); expected={e['path'] for e in old.get('files',[])}
 actual={p.relative_to(out).as_posix() for p in existing if p not in (ip,sp)}
 if actual!=expected or sha(ip.read_bytes())!=sp.read_text(encoding='ascii').split()[0]: fail('existing packet inventory/path audit failed; refusing replacement')
 for entry in old['files']:
  q=(out/entry['path']).resolve(strict=True)
  try: q.relative_to(out.resolve(strict=True))
  except ValueError: fail('owned packet path escapes output')
  if sha(q.read_bytes())!=entry.get('sha256'): fail('existing packet file hash mismatch; refusing replacement')
  q.unlink()
 ip.unlink(); sp.unlink()
planp=S/'factor-profile-measurement-plan.json'; seqp=S/'factor-profile-sequence-result.json'
gate1p=S/'factor-profile-r1-gates.json'; gate2p=S/'factor-profile-r2-gates.json'
valp=next(S.glob('factor-profile-02-profile-10014-vs-factor-profile-01-off-10014-factor-profile-validation-*.json'))
plan=readj(planp); seq=readj(seqp); g1=readj(gate1p); g2=readj(gate2p); val=readj(valp)
if plan.get('status')!='PREDECLARED' or str(plan.get('seed'))!='10014' or plan.get('requestedPackageCount')!=40: fail('frozen plan identity mismatch')
if sha(planp.read_bytes())!='fbe3cca3c934ad786bf75ff1e0504b0a10cdb7439b4d97856193121f295f8cd7': fail('frozen plan hash mismatch')
if seq.get('status')!='HOST_CAPTURE_PASS_PENDING_STRICT_PROFILE_VALIDATION' or seq.get('planSha256')!=sha(planp.read_bytes()): fail('historical timing sequence changed')
rows={r['label']:r for r in seq.get('rows',[])}
if set(rows)!=set(LABELS) or any(rows[k].get('runnerOutcome')!='PASS' or rows[k].get('exitCode')!=0 for k in LABELS): fail('timing pair incomplete')
if sha(gate2p.read_bytes())!=seq.get('gatesSha256') or g2.get('status')!='FOCUSED_GATES_PASS_NOT_ACCEPTANCE': fail('R2 gate receipt linkage mismatch')
if gate2p.read_bytes()!= (S/'factor-profile-r2-gates.json').read_bytes(): fail('gate receipt changed')
if g1.get('status')!='STOPPED_FAILURE' or g1.get('failure')!='native8' or g1.get('steps',[{}])[0].get('exitCode')!=2: fail('R1 failure was not preserved as recorded')
if val.get('status')!='PASS' or val.get('requestExact') is not True or val.get('reportExactOutsideDeclaredTimingAndProfileFields') is not True: fail('strict root pair validation not PASS')
if val.get('requestedPackageCount')!=40 or val.get('observedPackageCounts')!=[40,40] or val.get('packageCount40ValidatedInBothReports') is not True: fail('pair package-count proof mismatch')
if len(val.get('metadataNegativeCanaries',[]))!=109 or any(n.get('status')!='REJECTED_AS_EXPECTED' for n in val['metadataNegativeCanaries']): fail('metadata negative count/status mismatch')
if len(val.get('runs',[]))!=2 or len(val.get('strictReaderSourceHashes',{}))!=2: fail('pair validation missing runs/readers')
for r in val['runs']:
 sr=r.get('strictReader',{})
 if sr.get('readerExitCode')!=0 or sr.get('currentPlan4Pass') is not True or sr.get('selfNegativeCanaries')!=43: fail('strict reader or negative cases failed')
 if r.get('reportExactOutsideDeclaredTimingAndProfileFields') is False: fail('raw report parity failure')
 h=r.get('hostAudit',{}); errs=h.get('errorArrays',{})
 if h.get('runnerExitCode')!=0 or h.get('hostOutcome')!='PASS' or h.get('caseOutcome')!='PASS' or h.get('timedOut') is not False: fail('host report not PASS')
 if any(errs.get(k) for k in ('pageErrors','httpErrors','consoleErrors','attributeReadErrors','listenerCleanupErrors')): fail('host error array nonempty')
 if h.get('cleanup',{}).get('status')!='PASS' or h.get('cleanup',{}).get('ownedSurvivors') or h.get('cleanup',{}).get('errors'): fail('host cleanup not PASS')
# Compare exact source inventory to the committed solve-profile baseline; only four deltas are allowed.
base=repo/'docs/task-evidence/Q30/solve-profile'; baseinvp=base/'source/input-hash-inventory.json.gz'; base_inventory=readj_bytes=gzip.decompress(baseinvp.read_bytes())
baseinv=json.loads(base_inventory); base_sum=(base/'inventory.sha256').read_text(encoding='utf-8').split()[0]
if sha((base/'inventory.json').read_bytes())!=base_sum: fail('base packet inventory hash invalid')
sa_path=S/'scratch/factor-profile-r2-preparation/source-audit.json'; sa=readj(sa_path)
r1auditp=S/'scratch/factor-profile-preparation/source-audit.json'; r1audit=readj(r1auditp)
r1test=S/'scratch/factor-profile-preparation/fixture/tests/contracts/Q30LuFactorProfileContractTest.java'
if sha(r1auditp.read_bytes())!='503aad667a6cd65222e4cccdc23eb8a8772f1f475b1d6ca40c3bdfb90ababa1d' or sha(r1test.read_bytes())!='3bf74b9406eb1bc70e4499004949446513ff56b3abd457cc0ee0b23f3811068d': fail('R1 audit/test provenance changed')
if sha(sa_path.read_bytes())!='01457c30b313a288e70c0e60bdab0a90d115d09948595a8714a7822f235b5aa4' or sa.get('status')!='SOURCE_ONLY_R2_PREPARED_NOT_VALIDATED': fail('frozen source audit identity/status mismatch')
if sa.get('generatedWarCopied') is not False: fail('fixture unexpectedly copied generated WAR')
base_map={i['path']:i for i in baseinv.get('inputs',[])}; src_map={i['path']:i for i in sa.get('inputs',[])}
if len(base_map)!=1341 or len(src_map)!=1342 or set(src_map)-set(base_map)!={CHANGED[-1]} or set(base_map)-set(src_map): fail('source chain does not contain exactly the four declared overlays')
changed={p for p in base_map if base_map[p]['sha256']!=src_map[p]['sha256']}
if changed!=set(CHANGED[:-1]) or CHANGED[-1] not in src_map: fail('source delta differs from four declared paths')
fixture=S/'scratch/factor-profile-r2-preparation/fixture'; overlays={o['path']:o for o in sa.get('overlays',[])}
if set(overlays)!=set(CHANGED): fail('overlay manifest path set mismatch')
# The frozen audit overlay summary retains its pre-R2 test hash; its full inputs inventory and fixture are authoritative.
if overlays[CHANGED[-1]].get('sha256')==src_map[CHANGED[-1]].get('sha256'): stale_test_overlay_summary=False
else: stale_test_overlay_summary=True
# Stored files are compressed deterministically; transformations retain original and stored identities.
files={}; xforms=[]
def put(name,data,source,*,exact=False,jsoncheck=False,compress=True):
 orig=data; oh=sha(orig); data,n=scrub(data,exact)
 if jsoncheck:
  try: json.loads(data.decode('utf-8'))
  except Exception as e: fail(f'scrubbed JSON invalid for {source}: {e}')
 payload=gzip.compress(data,mtime=0) if compress else data
 if name in files: fail(f'duplicate output path: {name}')
 files[name]=payload
 xforms.append({'source':source,'stored':name,'originalBytes':len(orig),'originalSha256':oh,'redactions':n,
  'storedPayloadBytes':len(data),'storedPayloadSha256':sha(data),'storedBytes':len(payload),'storedSha256':sha(payload),'gzip':compress,'byteExactPayload':exact})
def cp(src,name,**kw):
 if not src.is_file(): fail(f'missing input: {src.name}')
 put(name,src.read_bytes(),src.name,**kw)
def addj(name,obj,source): put(name,(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode(),source,jsoncheck=True,compress=False)
# Four byte-exact source overlays and complete hash inventory, reconstructed from the committed base packet.
for rel in CHANGED:
 ent=src_map[rel]; src=fixture/rel; data=src.read_bytes()
 if len(data)!=ent.get('bytes') or sha(data)!=ent.get('sha256'): fail(f'overlay bytes/hash mismatch: {rel}')
 put('source/overlays/'+rel+'.gz',data,'R2 fixture/'+rel,exact=True)
put('source/source-audit.json.gz',sa_path.read_bytes(),sa_path.name,jsoncheck=True)
put('source/r1/source-audit.json.gz',r1auditp.read_bytes(),r1auditp.name,jsoncheck=True)
put('source/r1/Q30LuFactorProfileContractTest.java.gz',r1test.read_bytes(),r1test.name,exact=True)
cp(S/'scratch/factor-profile-preparation/prepare_factor_profile.py','procedure/prepare_factor_profile-r1.py.gz')
cp(S/'prepare_factor_r2_root.py','procedure/prepare_factor_profile-r2.py.gz')
put('source/input-hash-inventory.json.gz',json.dumps({'schema':1,'head':sa.get('head'),'rootInputCount':sa.get('baseFixture',{}).get('rootInputCount'),'inputCount':len(src_map),'inputs':sa['inputs']},indent=2).encode(),'factor-profile source audit input list',jsoncheck=True)
addj('source/base-reference.json',{'packet':'../solve-profile','inventorySha256':base_sum,'baseInputCount':len(base_map),'candidateInputCount':len(src_map),'unchangedInputs':len(src_map)-len(CHANGED),'overlayPaths':list(CHANGED),'staleOverlaySummaryTestHash':stale_test_overlay_summary,'auditOverlaySummaryTestSha256':overlays[CHANGED[-1]].get('sha256'),'authoritativeR2TestSha256':src_map[CHANGED[-1]].get('sha256'),'reconstruction':'Use the committed solve-profile source inventory/baseline, then apply the four byte-exact overlays in source/overlays. All remaining source inputs match by SHA-256.'},'verified solve-profile source baseline')
# Timing pair: custody metadata is scrubbed; the two application reports remain byte-exact.
for label in LABELS:
 row=rows[label]; d=S/label
 if row.get('cleanup',{}).get('status')!='PASS' or row.get('cleanup',{}).get('ownedSurvivors') or row.get('cleanup',{}).get('errors'): fail(f'cleanup failed: {label}')
 ia=row.get('inputAudit',{})
 if ia.get('status')!='PASS' or ia.get('beforeSha256')!=ia.get('afterSha256') or ia.get('sourceSha256Before')!=ia.get('sourceSha256After') or ia.get('webSha256Before')!=ia.get('webSha256After') or ia.get('runnerBeforeSha256')!=ia.get('runnerAfterSha256'): fail(f'input identity changed: {label}')
 for fn in ('identity.json','progress.json','result.json','run-start.json','runner-before.json','runner-after.json','owned-processes-before.json','owned-processes-before-close.json','spec.json','input-manifest-before.json','input-manifest-after.json'):
  cp(d/fn,f'runs/{label}/{fn}.gz',jsoncheck=fn.endswith('.json'))
 cp(S/f'{label}-summary.json',f'runs/{label}/summary.json.gz',jsoncheck=True)
 cp(S/f'{label}.log',f'runs/{label}/host.log.gz')
 # Case records, state, and immutable raw app report.
 for vrun in val['runs']:
  if vrun.get('label')==label: vr=vrun; break
 else: fail(f'validation run absent: {label}')
 rp=S/vr['reportPath']; raw=rp.read_bytes()
 if sha(raw)!=vr.get('reportSha256') or len(raw)!=vr.get('rawReportByteLength'): fail(f'raw app report identity mismatch: {label}')
 put(f'runs/{label}/application-report.json.gz',raw,rp.name,exact=True,jsoncheck=True)
 cp(rp.with_name(rp.name.replace('.report.json','.json')),f'runs/{label}/case-metadata.json.gz',jsoncheck=True)
 cp(rp.with_name(rp.name.replace('.report.json','.state.txt')),f'runs/{label}/case-state.txt.gz')
# Focused R1 failure, R2 gates and later strict full-pair validator.
for fn in ('factor-profile-r1-gates.json','factor-profile-r2-gates.json','native-factor-profile-r1.json','native-factor-profile-r1.log','native-factor-profile-r2.json','native-factor-profile-r2.log','native-factor-profile-r2-receipt.txt','factor-profile-r2-gwt.json','factor-profile-r2-gwt.log','factor-profile-r2-canaries-spec.json','factor-profile-r2-canaries-summary.json','factor-profile-r2-canaries.log','factor-profile-sequence-result.json','factor-profile-sequence.log','factor-profile-actual-metadata-only.json','lu-sampler-metadata-canaries.json','factor-profile-validation-root-r1.log'):
 p=S/fn
 if p.exists(): cp(p,'gates/'+fn+'.gz',jsoncheck=p.suffix=='.json')
cp(valp,'validation/root-pair-validation.json.gz',jsoncheck=True)
# Exact R2 gate and host-case input custody, excluding browser profiles/caches.
can=S/'factor-profile-r2-canaries'
for fn in ('spec.json','identity.json','progress.json','result.json','run-start.json','runner-before.json','runner-after.json','input-manifest-before.json','input-manifest-after.json'):
 p=can/fn
 if p.exists(): cp(p,'canaries/'+fn+'.gz',jsoncheck=fn.endswith('.json'))
for case,idx in (('factor-profile-r2-canaries-a07','001'),('factor-profile-r2-canaries-disabled','002')):
 d=can/'cases'; prefix=f'{idx}-{case}'
 for suf in ('.json','.state.txt'):
  p=d/(prefix+suf)
  if p.exists(): cp(p,f'canaries/cases/{prefix}{suf}.gz',jsoncheck=suf=='.json')
 rp=d/(prefix+'.report.json'); raw=rp.read_bytes(); case_meta=readj(d/(prefix+'.json'))
 if sha(raw)!=case_meta.get('reportSha256'): fail(f'compiled canary report hash mismatch: {case}')
 put(f'canaries/cases/{prefix}.report.json.gz',raw,rp.name,exact=True,jsoncheck=True)
# Strict wrappers and their frozen reader sources.
reader_dir=repo/'docs/task-evidence/Q30/scale-plan-4'
for name,h in val['strictReaderSourceHashes'].items():
 p=reader_dir/name
 if not p.is_file() or sha(p.read_bytes())!=h: fail(f'strict reader source hash mismatch: {name}')
 cp(p,'validation/readers/'+name+'.gz',exact=True)
for label in LABELS:
 cp(S/f'{label}-strict-wrapper-factor-profile-validation-root-r1.json',f'validation/{label}-strict-wrapper.json.gz',jsoncheck=True)
 cp(S/f'{label}-strict-reader-factor-profile-validation-root-r1.txt',f'validation/{label}-strict-reader.txt.gz')
# Procedures and review notes: only bounded scripts/notes, never WARs, JARs, caches or profiles.
procedures=('factor-profile-measurement-plan.json','factor-profile-metadata-validator.py','factor-profile-metadata-validator.md','run_factor_profile_pair.py','run_timing.py','native-factor-profile.ps1','build-run.ps1','run_current_solver_canaries.py','read_a07.ps1','run_factor_profile_r1_gates.py','run_factor_profile_r2_gates.py','validate_factor_profile_pair_root.py')
for fn in procedures:
 p=S/fn
 if p.exists(): cp(p,'procedure/'+fn+'.gz',jsoncheck=fn.endswith('.json'))
for fn in ('factor-profile-independent-review.md','factor-profile-validator-plan.md'):
 p=S/'scratch'/fn
 if p.exists(): cp(p,'reviews/'+fn+'.gz')
review=S/'factor-profile-validator-independent-review.md'
if not review.is_file() or sha(review.read_bytes())!='5370a1653629772cf98cfd24e75f338b2771e402fa7425a9cf9375d559057ed1': fail('independent validator review identity mismatch')
cp(review,'reviews/factor-profile-validator-independent-review.md.gz')
# Pin the validator, browser, and canary dependencies by their executed bytes.
helper=S/'validate_lu_repetition_pair.py'; checker=S/'check_lu_sampler_metadata_canaries.py'; solve_meta=base/'procedure/solve-profile-metadata-validator.py.gz'
if sha(helper.read_bytes())!='56d11822c0456ef4372bfa7cdfc0f3d79965e6aa895fcfd665e0d4a8b72da312': fail('pair helper hash mismatch')
if sha(checker.read_bytes())!='a776cfa51880a2a13d87e4cf5be7daa28ee1897213cbf522d13cdb13f27c1342': fail('legacy canary checker hash mismatch')
if sha(gzip.decompress(solve_meta.read_bytes()))!='58a0c3003c7279f61d100d87cf853ea453d4a04261c76431a15ab5215d20e337': fail('solve metadata validator hash mismatch')
put('procedure/dependencies/validate_lu_repetition_pair.py.gz',helper.read_bytes(),helper.name,jsoncheck=False)
put('procedure/dependencies/check_lu_sampler_metadata_canaries.py.gz',checker.read_bytes(),checker.name,exact=True)
put('procedure/dependencies/solve-profile-metadata-validator.py.gz',gzip.decompress(solve_meta.read_bytes()),'../solve-profile/procedure/solve-profile-metadata-validator.py.gz',exact=True)
root_spec=S/'root-routing-integrated-canaries-spec.json'; canary_runner=S/'run_current_solver_canaries.py'
if sha(root_spec.read_bytes())!='1dc1082c01ea815940be6a192227a9886777a4f6c1dd5c974e5e8570da81de8b': fail('compiled-canary root spec hash mismatch')
put('procedure/dependencies/root-routing-integrated-canaries-spec.json.gz',root_spec.read_bytes(),root_spec.name,exact=True,jsoncheck=True)
put('procedure/dependencies/run_current_solver_canaries.py.gz',canary_runner.read_bytes(),canary_runner.name)
browser=repo/'tests/browser/compiled_attribute_acceptance.py'
if sha(browser.read_bytes())!='1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4': fail('browser runner hash mismatch')
put('procedure/dependencies/compiled_attribute_acceptance.py.gz',browser.read_bytes(),'repo/tests/browser/compiled_attribute_acceptance.py',exact=True)
# The helper's generated factor spec is already archived with the R2 gate receipts.
dep_map={
 'schema':1,
 'fullPairValidator':{'path':'procedure/validate_factor_profile_pair_root.py.gz','originalSha256':'386da5bf31947bc3c8a4e92a3c1713e7a0bc1f529ea5f89f1acd7dcad4adcb03','dependencies':[
  {'name':'validate_lu_repetition_pair.py','path':'procedure/dependencies/validate_lu_repetition_pair.py.gz','executedSha256':'56d11822c0456ef4372bfa7cdfc0f3d79965e6aa895fcfd665e0d4a8b72da312','archivedCopyIsPathScrubbed':True},
  {'name':'check_lu_sampler_metadata_canaries.py','path':'procedure/dependencies/check_lu_sampler_metadata_canaries.py.gz','sha256':'a776cfa51880a2a13d87e4cf5be7daa28ee1897213cbf522d13cdb13f27c1342'},
  {'name':'solve-profile-metadata-validator.py','path':'procedure/dependencies/solve-profile-metadata-validator.py.gz','sha256':'58a0c3003c7279f61d100d87cf853ea453d4a04261c76431a15ab5215d20e337'}]},
 'pairHostRunner':{'path':'procedure/run_factor_profile_pair.py.gz','sha256':'45367eec97265bcf88698de7ff63089dc51c0a2892338787220c0919268bca37'},
 'browserRunner':{'path':'procedure/dependencies/compiled_attribute_acceptance.py.gz','repoPath':'tests/browser/compiled_attribute_acceptance.py','sha256':'1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4'},
 'runTimingPy':{'path':'procedure/run_timing.py.gz','sha256':'a7ef67c63397a28c1781b40746507fc0fa129f030742b8c6201350f099a9765f','executedByPair':False},
 'compiledCanaries':{'runnerPath':'procedure/dependencies/run_current_solver_canaries.py.gz','runnerOriginalSha256':'62f98058d12f94f0ac1cb0544454aef4cd2ec86ac210619fbcfafeac3974b807','baseSpecPath':'procedure/dependencies/root-routing-integrated-canaries-spec.json.gz','baseSpecSha256':'1dc1082c01ea815940be6a192227a9886777a4f6c1dd5c974e5e8570da81de8b','generatedFactorSpecPath':'gates/factor-profile-r2-canaries-spec.json.gz','generatedFactorSpecSha256':sha((S/'factor-profile-r2-canaries-spec.json').read_bytes())},
 'redactionLedger':'provenance/archive-transforms.json'}
addj('provenance/dependency-map.json',dep_map,'exact dependency/reference map')
# Make executed packager available as a reproducibility artifact; the inventory excludes only itself and its digest.
script=Path(__file__).read_bytes(); put('procedure/package_factor_profile.py.gz',script,'scratch/package_factor_profile.py',exact=True)
# Verify path privacy on every stored payload and decompressed payload before writing.
for name,payload in files.items():
 content=gzip.decompress(payload) if name.endswith('.gz') else payload
 if PRIVATE.search(payload) or PRIVATE.search(content): fail(f'personal path in archive member: {name}')
# README states the evidence boundary and limits; pending sequence receipt is kept as historical raw evidence.
profile=json.loads((S/'factor-profile-02-profile-10014/cases/001-factor-profile-02-profile-10014.report.json').read_text())['cold']['luRepetitionProfile']
off=rows[LABELS[0]]['cold']; prof=rows[LABELS[1]]['cold']
readme=f'''# Whole-factor profile — intermediate diagnostic\n\n**Q30 remains BLOCKED. This packet is not acceptance evidence or a measured optimization.** It records one private seed-10014 off/profile pair on the frozen sticky-finite source base. The profile sampler was not integrated into production.\n\n| Run | Cold (ms) | Proof (ms) | Routing (ms) | Host (s) | Cleanup (s) |\n|---|---:|---:|---:|---:|---:|\n| {LABELS[0]} | {off['elapsedMs']} | {off['proofElapsedMs']} | {off['routingElapsedMs']} | {rows[LABELS[0]]['hostMonotonicSeconds']:.3f} | {rows[LABELS[0]]['cleanup']['seconds']:.3f} |\n| {LABELS[1]} | {prof['elapsedMs']} | {prof['proofElapsedMs']} | {prof['routingElapsedMs']} | {rows[LABELS[1]]['hostMonotonicSeconds']:.3f} | {rows[LABELS[1]]['cleanup']['seconds']:.3f} |\n\nThe profile selected {profile['luFactorTimingSamples']:,} of {profile['factorCalls']:,} complete factor calls. Across {profile['sampledMatrixInputs']:,} sampled matrices, `performance.now` recorded {profile['luFactorMillis']:.1f} ms inclusive factor time, {profile['luSolveMillis']:.1f} ms for the separate sampled solve scope, and {profile['zeroRowPreflightMillis']:.1f} ms of nested preflight time. Preflight overlaps factor time and must not be added. Sampling copy/compare cost was {profile['probeOverheadMillis']:.1f} ms inside the profile brackets, outside factor timing; it excludes per-call cadence bookkeeping and compilation. Sparse selection and clock granularity limit interpretation.\n\nA rough mean-cost projection is about 33.620 s across all factor calls and 9.146 s for solve calls. These are extrapolations for ranking only, not measured elapsed time or savings. The near-identical off/profile cold totals do not establish zero overhead. The cold run reports 390 hypothesis work units across five hypotheses. The warm result is a separate private proof-cache hit with one hypothesis work unit; it is not evidence of numerical factor reuse.\n\nThe R1 native gate failed with exit 2 because the native JVM test attempted a GWT `JSONObject` construction; this failure is preserved. R2 focused native, maintained JDK8/GWT, compiled A07/disabled-normal canaries and the exact A07 reader with three corruptions passed. The timing-sequence receipt is preserved with its original pending-validation status. The subsequent root pair validator passed exact request and non-profile report parity, plus the frozen 40-package request and audited plan/topology assertions for both runs. Its `observedPackageCounts` field ([40, 40]) echoes the request checked against those assertions; it is not an independent enumeration from the application reports. It also passed 109 expected metadata-negative cases, and both strict current-plan-4 readers passed 43 corruption cases each. Input identity, host error arrays and owned cleanup were checked. This remains one-seed diagnostic evidence, not cohort or electrical acceptance.\n\nThe 1,342-input source inventory reconstructs from the committed [solve-profile source packet](../solve-profile/README.md) plus four byte-exact overlays. Source audit status remains historically `SOURCE_ONLY_R2_PREPARED_NOT_VALIDATED`; later gate receipts bind that audit. Its overlay summary still lists the pre-R2 test hash (3bf74b…); the complete source input inventory and frozen R2 fixture both identify the repaired test as b82c79… (12,731 bytes), which is the exact overlay archived here. Raw application reports are gzip-compressed byte-for-byte. Sanitized metadata retains original and stored hashes/redaction counts in `provenance/archive-transforms.json`. Browser profiles, generated WARs, JARs and caches are excluded.\n\nThe independent validator review is archived in `reviews/`. `provenance/dependency-map.json` pins the executed helper chain, browser runner, and compiled-canary spec. `run_timing.py` is included as an incidental procedure artifact; the pair runner does not invoke it. The R1 source audit and exact pre-repair R1 test are retained under `source/r1/`.

`inventory.json` covers every stored file except itself and `inventory.sha256`; gzip members include decompressed hashes. The inventory SHA-256 checks its bytes; it is not keyed authentication.\n'''
files['README.md']=readme.encode()
transforms_data=(json.dumps({'schema':1,'items':xforms},indent=2)+'\n').encode()
files['provenance/archive-transforms.json']=transforms_data
# Write bundle members first, then inventory and its detached digest.
for name,data in files.items():
 p=out/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
entries=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or p.name in ('inventory.json','inventory.sha256'): continue
 b=p.read_bytes(); e={'path':p.relative_to(out).as_posix(),'bytes':len(b),'sha256':sha(b)}
 if p.name.endswith('.gz'):
  raw=gzip.decompress(b); e.update(uncompressedBytes=len(raw),uncompressedSha256=sha(raw))
 entries.append(e)
inventory=(json.dumps({'schema':1,'files':entries},indent=2)+'\n').encode(); (out/'inventory.json').write_bytes(inventory); (out/'inventory.sha256').write_text(sha(inventory)+'  inventory.json\n',encoding='ascii')
# Final privacy scan includes source script and expanded gzip members.
for p in out.rglob('*'):
 if not p.is_file(): continue
 b=p.read_bytes()
 if PRIVATE.search(b): fail(f'privacy scan failed: {p.relative_to(out)}')
 if p.name.endswith('.gz') and PRIVATE.search(gzip.decompress(b)): fail(f'decompressed privacy scan failed: {p.relative_to(out)}')
print(json.dumps({'status':'PACKAGED','path':str(out),'files':len(entries)+2,'inventorySha256':sha(inventory),'transformRecords':len(xforms),'timingRows':len(rows),'validation':'PASS','sourceAudit':'SOURCE_ONLY_R2_PREPARED_NOT_VALIDATED'}))




