from pathlib import Path
import json,hashlib,shutil
s=Path(__file__).resolve().parent
old=s/'scratch/factor-profile-preparation'
audit_raw=(old/'source-audit.json').read_bytes();audit=json.loads(audit_raw)
assert hashlib.sha256(audit_raw).hexdigest()=='503aad667a6cd65222e4cccdc23eb8a8772f1f475b1d6ca40c3bdfb90ababa1d'
prep=s/'scratch/factor-profile-r2-preparation';assert not prep.exists()
fixture=prep/'fixture';fixture.mkdir(parents=True)
for e in audit['inputs']:
 b=(old/'fixture'/e['path']).read_bytes();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
 p=fixture/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
p=fixture/'tests/contracts/Q30LuFactorProfileContractTest.java'
t=p.read_text()
before='''        String report = invokeFinish(profile).toString();
        require(report.contains("luFactorTimingScope") &&
                report.contains("overlaps zeroRowPreflightMillis"),
                "report did not disclose inclusive factor/preflight timing scopes");
        require(report.contains("luFactorTimingAttempts") &&
                report.contains("luFactorNativeClockUnavailable"),
                "report omitted factor timing counters or clock status");'''
after='''        // JSONObject serialization needs the real GWT runtime. The composed
        // browser reader requires the exact scope and counter fields; the JVM
        // checks native clock absence and released workspace directly.
        Field elapsed = profile.getClass().getDeclaredField("luFactorMillis");
        elapsed.setAccessible(true);
        require(elapsed.getDouble(profile) == 0,
                "native unavailable clock must not fabricate elapsed time");
        require(invokeWorkspaceBoolean(workspace, "allCountsZeroForChecks") &&
                invokeWorkspaceBoolean(workspace, "allRowReferencesNullForChecks"),
                "successful selected factors retained workspace state");'''
assert before in t;t=t.replace(before,after)
unused='''    private static Object invokeFinish(Object profile) throws Exception {
        Method method = profile.getClass().getDeclaredMethod("finish");
        method.setAccessible(true);
        return method.invoke(profile);
    }

'''
assert unused in t;t=t.replace(unused,'');p.write_text(t,encoding='utf-8')
audit['status']='SOURCE_ONLY_R2_PREPARED_NOT_VALIDATED'
audit['r1AuditSha256']=hashlib.sha256(audit_raw).hexdigest()
audit['r1Failure']='Native gate exit2 after33.9502555s: test attempted GWT JSONObject native construction. R1 preserved; R2 changes only test; exact JSON scope/counters must be validated in real browser reader.'
audit['inputs']=[{'path':e['path'],'bytes':len((fixture/e['path']).read_bytes()),'sha256':hashlib.sha256((fixture/e['path']).read_bytes()).hexdigest()} for e in audit['inputs']]
(prep/'source-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
(s/'factor-profile-source-path.txt').write_text(str(fixture),encoding='utf-8')
t=(s/'run_factor_profile_r1_gates.py').read_text().replace('factor-profile-r1','factor-profile-r2')
(s/'run_factor_profile_r2_gates.py').write_text(t,encoding='utf-8')
print(json.dumps({'fixture':str(fixture),'auditSha256':hashlib.sha256((prep/'source-audit.json').read_bytes()).hexdigest(),'testSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'inputs':len(audit['inputs'])}))
