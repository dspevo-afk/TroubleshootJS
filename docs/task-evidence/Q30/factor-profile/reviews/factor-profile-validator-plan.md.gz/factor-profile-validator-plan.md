# Factor-profile strict pair validator preparation

## Purpose and lineage

prepare_factor_profile_validator.py deterministically adapts the frozen full
validate_solve_profile_pair_root.py reader to the factor-profile off/profile pair.
It preserves the solve/preflight validators and the existing host/input/cleanup,
profile-off parity, and maintained strict-reader/self-negative path. It adds the
factor metadata module's validate(profile) and negative_canaries(profile) calls
for each cold and warm profile record.

The adapter pins the explicitly supplied source fixture, source-audit SHA-256,
predeclared plan SHA-256, runner SHA-256, and factor metadata module SHA-256. It
also verifies every one of the frozen 1,342 source-audit entries before producing
the adapted reader. Source identities are arguments to the generator, not stale
solve-profile constants. The output embeds these frozen identities and is
syntax-parsed before it is written.

The plan requires 40 packages, and the generated reader checks both
requestedPackageCount == 40 in the plan and the exact packages=40 member in
each cold/off and profile report's canonical request. Profile/off parity remains
outside a single existing stripping rule: remove_profile_fields removes only
cold.luRepetitionProfile and warm.luRepetitionProfile. The new factor fields
stay inside those objects; the adapter adds no field-specific stripping path.

## Frozen preparation inputs

- Source fixture: scratch/factor-profile-r2-preparation/fixture
- Source audit: scratch/factor-profile-r2-preparation/source-audit.json
  - SHA-256: 01457c30b313a288e70c0e60bdab0a90d115d09948595a8714a7822f235b5aa4
  - Input count: 1,342
- Plan: factor-profile-measurement-plan.json
  - SHA-256: fbe3cca3c934ad786bf75ff1e0504b0a10cdb7439b4d97856193121f295f8cd7
  - Off/profile labels: factor-profile-01-off-10014, factor-profile-02-profile-10014
  - Seed/package count: 10014 / 40
- Host runner: run_factor_profile_pair.py
  - SHA-256: 45367eec97265bcf88698de7ff63089dc51c0a2892338787220c0919268bca37
- Factor metadata module: factor-profile-metadata-validator.py
  - SHA-256: abd0a4352f2505055f36ac16ba0987eae102c8cb8381378c909a842978a6d490
- Base full reader: validate_solve_profile_pair_root.py
  - SHA-256: dfcdf80d9246fc87d49e5c6fbe8c05b2a6e1e7b86f39212ae47f1f37635b1db3

## Generated artifact and execution boundary

The generator produced validate_factor_profile_pair_root.py with SHA-256
386da5bf31947bc3c8a4e92a3c1713e7a0bc1f529ea5f89f1acd7dcad4adcb03.
The generator reported GENERATED_NOT_EXECUTED. It only checked frozen source,
plan, runner, and metadata-module inputs, transformed exact template anchors,
and parsed the generated Python syntax. I did not execute the generated
pair validator or rerun the timing sequence.

When the root runs the generated reader, it still requires the frozen
factor-profile-sequence-result.json, factor-profile-r2-gates.json, both run
summaries/specifications, source manifests, reports, host cleanup receipts, and
the unchanged current plan-4 reader/parser. It preserves strict negative checks
by calling the original solve/preflight metadata canaries and helper.strict_reader
for both rows, then adds the factor module's negative canaries for cold and warm.
A generated-validator PASS is evidence validation for this single pair only; it
does not qualify normal Q30 acceptance or support a population-speed claim.

## Reproduction

From the task scratch root, rerun the generator using the frozen paths/hashes
above and a fresh output path. The exact current output path is intentionally
write-once; the script refuses to overwrite it. After all four focused gates and
both host rows are complete, execute only the generated validator with the
maintained repo path, factor plan, seed, exact labels, and a fresh output tag.
Do not treat generator success or host capture alone as strict validation.



Generator command shape (replace TASK_SCRATCH with the task temp root):

    python TASK_SCRATCH/scratch/prepare_factor_profile_validator.py --scratch TASK_SCRATCH --template TASK_SCRATCH/validate_solve_profile_pair_root.py --output TASK_SCRATCH/validate_factor_profile_pair_root.py --source-path TASK_SCRATCH/scratch/factor-profile-r2-preparation/fixture --source-audit TASK_SCRATCH/scratch/factor-profile-r2-preparation/source-audit.json --source-audit-sha256 01457c30b313a288e70c0e60bdab0a90d115d09948595a8714a7822f235b5aa4 --source-input-count 1342 --plan TASK_SCRATCH/factor-profile-measurement-plan.json --plan-sha256 fbe3cca3c934ad786bf75ff1e0504b0a10cdb7439b4d97856193121f295f8cd7 --runner TASK_SCRATCH/run_factor_profile_pair.py --runner-sha256 45367eec97265bcf88698de7ff63089dc51c0a2892338787220c0919268bca37 --factor-metadata-validator TASK_SCRATCH/factor-profile-metadata-validator.py --factor-metadata-sha256 abd0a4352f2505055f36ac16ba0987eae102c8cb8381378c909a842978a6d490 --seed 10014 --profile-label factor-profile-02-profile-10014 --off-label factor-profile-01-off-10014 --package-count 40

After gates and captured rows finish, the generated reader command shape is:

    python TASK_SCRATCH/validate_factor_profile_pair_root.py --scratch TASK_SCRATCH --repo REPOSITORY --plan TASK_SCRATCH/factor-profile-measurement-plan.json --seed 10014 --profile-label factor-profile-02-profile-10014 --off-label factor-profile-01-off-10014 --tag factor-r2-strict-01

