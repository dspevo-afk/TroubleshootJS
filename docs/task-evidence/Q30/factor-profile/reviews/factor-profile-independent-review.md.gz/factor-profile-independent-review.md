# Independent source review: LU factor profile draft

## Scope and source identity

Reviewed only the frozen `factor-profile-draft` baseline/candidate `CirSim.java` and `Q30LuFactorProfileContractTest.java`. SHA-256 values match the fixture manifest: baseline `60371360961ABF8645C388B06D8F3741D311D4B0A3D045B6CC1BA2E123B887FC`, candidate `102D41B1F5E5C644EB38D23FDEA70586D03746B5D41CE615B9778A1BBC069957`, test `3BF74B9406EB1BC70E4499004949446513FF56B3ABD457CC0EE0B23F3811068D`.

## Findings

No source-level blocker found in the requested scope. At the existing `SAMPLE_START` / `SAMPLE_COMPARE` branch, only the selected factor call changes to `lu_factorNonlinearProfiled`. Sample matrix capture/comparison occurs before that call, and solve remains after it. The comparison-owner result only decides whether to attach `solveProfile`; it does not suppress timing of a selected mismatched comparison, so the scope correctly includes that factorization while leaving it out of paired solve timing.

The wrapper brackets the whole `lu_factorNonlinearOwned(..., profile)` call. This includes workspace reset, the nested zero-row preflight, factor arithmetic, and the owned method's `finally` workspace clear. The nested preflight timer overlaps the new factor total; these measurements must not be summed. The inclusive total also contains the nested preflight timer's own clock/counter overhead, so it is an instrumented inclusive measurement, not a pure uninstrumented LU-core cost. Sample copy/compare and `lu_solve` are outside the outer bracket.

Cleanup and counter paths are structurally balanced: `beginLuFactorTiming` uses the safe clock wrapper; the factor call runs inside `try`; `finishLuFactorTiming` and then `recordFactorOutcome` are nested in `finally`. Thus a `false` return or thrown factor still completes timing and records failure, while the existing owned-factor `finally` clears workspace state. Clock absence/errors return `NaN` and become timing metadata rather than changing factor behavior. The native test covers successful, false-return, thrown-preflight, owner-mismatched compare, native-clock-unavailable, and workspace-cleanup paths.

Unsampled factors continue through the pre-existing unprofiled owned overload. The new wrapper is reached only for selected start/compare actions; it adds no per-factor traversal or allocation, only the selected-call counters and timing pair. No LU arithmetic, selection cadence, proof, or factor-input behavior changes appear in the diff.

The added result fields use the existing JSON shape (`JSONNumber` for counters/totals and `JSONString` for clock/scope). The intended conservation checks are coherent: completions track attempts; success plus failure tracks completed calls; in GWT, samples plus timing errors track attempts; on native JVM, the separate unavailable-clock count tracks attempts. The test checks native clock-unavailable reporting, but neither this source fixture nor this review establishes exact compatibility with the root's strict browser-profile reader or validates an actual GWT `performance.now` output.

## Validation limits

This was source review only. The fixture manifest reports builds, tests, browser validation, and gates as NOT RUN. In particular, no claim is made about generated GWT behavior, real-clock granularity, or profiler overhead versus an uninstrumented build.
