package com.lushprojects.circuitjs1.client;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Native structural canaries for whole sampled LU factor timing. */
public final class Q30LuFactorProfileContractTest {
    private static final String PROFILE_CLASS =
        "com.lushprojects.circuitjs1.client.CirSim$LuRepetitionProfile";
    private static final String WORKSPACE_CLASS =
        "com.lushprojects.circuitjs1.client.CirSim$LuFactorizationWorkspace";
    private static int assertions;

    public static void main(String[] args) throws Exception {
        int count = run();
        System.out.println("PASS: Q30 LU factor profile contracts assertions=" + count);
    }

    public static int run() throws Exception {
        assertions = 0;
        verifySelectedStartAndCompareCallsAreConserved();
        verifyOwnerMismatchedCompareStillTimesItsSelectedFactor();
        verifyFalseFactorReturnCountsAsFailure();
        verifyThrowingFactorBalancesTimingAndWorkspace();
        return assertions;
    }

    private static void verifySelectedStartAndCompareCallsAreConserved() throws Exception {
        Object profile = newProfile();
        Object workspace = newWorkspace();
        double[][] matrix = { { 4.0, 1.0 }, { 2.0, 3.0 } };
        int[] pivots = new int[2];
        setInt(profile, "factorCalls", 1020);

        require(invokeFactorAction(profile) == 1, "work-scope cadence did not select a start");
        invokeCaptureStart(profile, matrix, 2, 7, 4);
        require(invokeProfiledFactor(matrix, 2, pivots, workspace, profile),
                "regular finite matrix did not factor successfully");

        require(invokeFactorAction(profile) == 2,
                "adjacent comparison was not selected after the start");
        require(invokeCompare(profile, matrix, 2, 7, 4),
                "matching same-generation/revision comparison was not recognized");
        require(invokeProfiledFactor(matrix, 2, pivots, workspace, profile),
                "comparison factor did not complete successfully");

        require(intValue(profile, "sampledStarts") == 1 &&
                intValue(profile, "compareAttempts") == 1,
                "profile did not record one selected start and comparison");
        require(intValue(profile, "luFactorTimingAttempts") == 2 &&
                intValue(profile, "luFactorTimingCompletions") == 2,
                "selected factor timing did not conserve start and comparison calls");
        require(intValue(profile, "luFactorSuccesses") == 2 &&
                intValue(profile, "luFactorFailures") == 0,
                "successful factor outcomes were not recorded");
        require(intValue(profile, "luFactorNativeClockUnavailable") == 2 &&
                intValue(profile, "luFactorTimingSamples") == 0 &&
                intValue(profile, "luFactorTimingErrors") == 0,
                "native clock absence was confused with elapsed samples or clock errors");
        require(invokeClock(profile).equals("unavailable-native"),
                "native factor clock identity was incorrect");
        require(intValue(profile, "preflightTimingAttempts") == 2 &&
                intValue(profile, "preflightTimingCompletions") == 2,
                "full factor wrapper did not retain the nested zero-row preflight");

        // JSONObject serialization needs the real GWT runtime. The composed
        // browser reader requires the exact scope and counter fields; the JVM
        // checks native clock absence and released workspace directly.
        Field elapsed = profile.getClass().getDeclaredField("luFactorMillis");
        elapsed.setAccessible(true);
        require(elapsed.getDouble(profile) == 0,
                "native unavailable clock must not fabricate elapsed time");
        require(invokeWorkspaceBoolean(workspace, "allCountsZeroForChecks") &&
                invokeWorkspaceBoolean(workspace, "allRowReferencesNullForChecks"),
                "successful selected factors retained workspace state");
    }

    private static void verifyOwnerMismatchedCompareStillTimesItsSelectedFactor()
            throws Exception {
        Object profile = newProfile();
        Object workspace = newWorkspace();
        double[][] matrix = { { 4.0, 1.0 }, { 2.0, 3.0 } };
        int[] pivots = new int[2];
        setInt(profile, "factorCalls", 1020);

        require(invokeFactorAction(profile) == 1, "mismatch canary did not select a start");
        invokeCaptureStart(profile, matrix, 2, 7, 4);
        require(invokeProfiledFactor(matrix, 2, pivots, workspace, profile),
                "mismatch canary start factor failed");
        require(invokeFactorAction(profile) == 2,
                "mismatch canary did not select its adjacent comparison");
        require(!invokeCompare(profile, matrix, 2, 8, 4),
                "changed-generation comparison unexpectedly matched");
        require(invokeProfiledFactor(matrix, 2, pivots, workspace, profile),
                "owner-mismatched factor itself did not complete");
        require(intValue(profile, "sampledStarts") +
                intValue(profile, "compareAttempts") == 2 &&
                intValue(profile, "luFactorTimingAttempts") == 2,
                "factor timing excluded a selected owner-mismatched comparison");
        require(intValue(profile, "luFactorSuccesses") == 2 &&
                intValue(profile, "luFactorFailures") == 0,
                "owner-mismatched comparison altered factor outcome counts");
    }

    private static void verifyFalseFactorReturnCountsAsFailure() throws Exception {
        Object profile = newProfile();
        Object workspace = newWorkspace();
        double[][] matrix = { { 1.0, 0.0 }, { 0.0, 0.0 } };
        boolean factored = invokeProfiledFactor(matrix, 2, new int[2], workspace, profile);
        require(!factored, "all-zero row was not rejected by the owned factor path");
        require(intValue(profile, "luFactorTimingAttempts") == 1 &&
                intValue(profile, "luFactorTimingCompletions") == 1,
                "false factor return left its timing interval unbalanced");
        require(intValue(profile, "luFactorSuccesses") == 0 &&
                intValue(profile, "luFactorFailures") == 1,
                "false factor return was not counted as a factor failure");
        require(intValue(profile, "preflightTimingAttempts") == 1 &&
                intValue(profile, "preflightTimingCompletions") == 1,
                "false return did not complete the nested preflight timer");
    }

    private static void verifyThrowingFactorBalancesTimingAndWorkspace() throws Exception {
        Object profile = newProfile();
        Object workspace = newWorkspace();
        boolean failed = false;
        try {
            invokeProfiledFactor(new double[][] { { 1.0, 0.0 }, {} }, 2,
                    new int[2], workspace, profile);
        } catch (ArrayIndexOutOfBoundsException expected) {
            failed = true;
        }
        require(failed, "malformed matrix did not exercise the throwing preflight path");
        require(intValue(profile, "luFactorTimingAttempts") == 1 &&
                intValue(profile, "luFactorTimingCompletions") == 1,
                "throwing factor left its timing interval unbalanced");
        require(intValue(profile, "luFactorSuccesses") == 0 &&
                intValue(profile, "luFactorFailures") == 1,
                "throwing factor was not recorded as a failure");
        require(intValue(profile, "preflightTimingAttempts") == 1 &&
                intValue(profile, "preflightTimingCompletions") == 1,
                "throwing factor did not complete the nested preflight timer");
        require(intValue(profile, "luFactorNativeClockUnavailable") == 1 &&
                intValue(profile, "luFactorTimingSamples") == 0 &&
                intValue(profile, "luFactorTimingErrors") == 0,
                "throwing native factor confused clock absence with clock error");
        require(invokeWorkspaceBoolean(workspace, "allCountsZeroForChecks") &&
                invokeWorkspaceBoolean(workspace, "allRowReferencesNullForChecks"),
                "throwing factor left scratch workspace state behind");
    }

    private static Object newProfile() throws Exception {
        Class<?> type = Class.forName(PROFILE_CLASS);
        Constructor<?> constructor = type.getDeclaredConstructor(String.class);
        constructor.setAccessible(true);
        Object profile = constructor.newInstance("factor-contract");
        Method setScope = type.getDeclaredMethod("setWorkScope", Boolean.TYPE);
        setScope.setAccessible(true);
        setScope.invoke(profile, Boolean.TRUE);
        return profile;
    }

    private static Object newWorkspace() throws Exception {
        Class<?> type = Class.forName(WORKSPACE_CLASS);
        Constructor<?> constructor = type.getDeclaredConstructor();
        constructor.setAccessible(true);
        return constructor.newInstance();
    }

    private static int invokeFactorAction(Object profile) throws Exception {
        Method method = profile.getClass().getDeclaredMethod("factorAction");
        method.setAccessible(true);
        return ((Integer) method.invoke(profile)).intValue();
    }

    private static void invokeCaptureStart(Object profile, double[][] matrix, int n,
            long generation, long revision) throws Exception {
        Method method = profile.getClass().getDeclaredMethod("captureStart",
                double[][].class, Integer.TYPE, Long.TYPE, Long.TYPE);
        method.setAccessible(true);
        method.invoke(profile, matrix, Integer.valueOf(n), Long.valueOf(generation),
                Long.valueOf(revision));
    }

    private static boolean invokeCompare(Object profile, double[][] matrix, int n,
            long generation, long revision) throws Exception {
        Method method = profile.getClass().getDeclaredMethod("compareNext",
                double[][].class, Integer.TYPE, Long.TYPE, Long.TYPE);
        method.setAccessible(true);
        return ((Boolean) method.invoke(profile, matrix, Integer.valueOf(n),
                Long.valueOf(generation), Long.valueOf(revision))).booleanValue();
    }

    private static boolean invokeProfiledFactor(double[][] matrix, int n, int[] pivots,
            Object workspace, Object profile) throws Exception {
        Class<?> workspaceType = Class.forName(WORKSPACE_CLASS);
        Class<?> profileType = Class.forName(PROFILE_CLASS);
        Method method = CirSim.class.getDeclaredMethod("lu_factorNonlinearProfiled",
                double[][].class, Integer.TYPE, int[].class, workspaceType, profileType);
        method.setAccessible(true);
        try {
            return ((Boolean) method.invoke(null, matrix, Integer.valueOf(n), pivots,
                    workspace, profile)).booleanValue();
        } catch (InvocationTargetException wrapped) {
            Throwable cause = wrapped.getCause();
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            if (cause instanceof Error) throw (Error) cause;
            throw wrapped;
        }
    }

    private static String invokeClock(Object profile) throws Exception {
        Method method = profile.getClass().getDeclaredMethod("luFactorClock");
        method.setAccessible(true);
        return (String) method.invoke(profile);
    }

    private static boolean invokeWorkspaceBoolean(Object workspace, String name)
            throws Exception {
        Method method = workspace.getClass().getDeclaredMethod(name);
        method.setAccessible(true);
        return ((Boolean) method.invoke(workspace)).booleanValue();
    }

    private static int intValue(Object profile, String fieldName) throws Exception {
        Field field = profile.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getInt(profile);
    }

    private static void setInt(Object object, String fieldName, int value) throws Exception {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.setInt(object, value);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private Q30LuFactorProfileContractTest() { }
}