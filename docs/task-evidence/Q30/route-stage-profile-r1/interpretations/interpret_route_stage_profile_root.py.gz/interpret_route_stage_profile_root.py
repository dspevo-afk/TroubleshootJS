from pathlib import Path
import hashlib, json

s = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
continuation = json.loads((s / 'route-stage-profile-continuation-result.json').read_bytes())
assert continuation['status'] == 'FOCUSED_PROFILE_BOTH_CONTROL_COMPARISONS_PASS_PENDING_ROOT_INTERPRETATION'
pairs = [json.loads((s / ('route-stage-profile-pair-' + str(i) + '-reader-r2-validation.json')).read_bytes()) for i in (1, 2)]
assert all(p['status'] == 'PASS' and p['reportExactOutsideDeclaredProfileAndTimingFields'] for p in pairs)
rows = []
reports = []
for label in ('route-stage-profile-01-control-10014', 'route-stage-profile-02-profile-10014', 'route-stage-profile-03-control-10014'):
    host = json.loads((s / label / 'result.json').read_bytes())
    assert host['cleanup']['status'] == 'PASS' and not host['cleanup']['ownedSurvivors'] and not host['cleanup']['errors']
    case = host['cases'][0]
    raw = (s / label / case['reportFile']).read_bytes()
    assert sha(raw) == case['reportSha256']
    report = json.loads(raw)
    summary = json.loads((s / (label + '-summary.json')).read_bytes())
    reports.append(report)
    rows.append({'label': label, 'reportSha256': sha(raw),
                 'coldApplicationWallElapsedMs': report['cold']['elapsedMs'],
                 'coldApplicationWallProofMs': report['cold']['proofElapsedMs'],
                 'coldApplicationWallRoutingMs': report['cold']['routingElapsedMs'],
                 'hostMonotonicSeconds': summary['hostMonotonicSeconds'],
                 'cleanupMonotonicSeconds': host['cleanup']['seconds']})
profile = reports[1]['cold']['routeStageProfile']
assert profile['valid'] and profile['frozen']
assert all(profile[key] == 0 for key in ('clockErrors', 'scopeErrors', 'openScopes', 'lateScopeErrors'))
phases = profile['phases']
ms = lambda name: phases[name]['elapsedMs']
p05_children = ['P05_ROUTER_SETUP', 'P05_GOAL_MASK', 'P05_DISTANCE_FIELD', 'P05_ASTAR',
                'P05_PATH_MATERIALIZATION', 'P05_OCCUPANCY_CHECK', 'P05_CANONICALIZATION',
                'P05_GEOMETRY_VALIDATION', 'P05_QUALITY_VALIDATION']
p07_children = ['P07_SEARCH_SETUP', 'P07_GOAL_MASK', 'P07_LOWER_BOUND', 'P07_FINAL_GEOMETRY',
                'P07_RULE_VALIDATION', 'P07_QUALITY_VALIDATION']
partitions = []
for parent, children, residual_name in [('P05_ROUTE_CALL', p05_children, 'Ordering/copy/recovery and other untimed route work'),
                                       ('P07_SLICE', p07_children, 'A* plus publisher/state-machine and other untimed slice work')]:
    residual = ms(parent) - sum(ms(child) for child in children)
    assert residual >= 0
    partitions.append({'inclusiveParent': parent, 'elapsedMs': ms(parent),
                       'disjointChildren': [{'phase': child, 'elapsedMs': ms(child)} for child in children],
                       'residualName': residual_name, 'residualMs': residual})
controls = [rows[i]['coldApplicationWallElapsedMs'] for i in (0, 2)]
route_controls = [rows[i]['coldApplicationWallRoutingMs'] for i in (0, 2)]
result = {
    'status': 'PASS_COARSE_PRIVATE_ATTRIBUTION_ONLY', 'normalQ30Acceptance': 'BLOCKED',
    'sourceAuditSha256': '01a0c70a2117720f6e16ae000924cc201c8e0b0b0d15d19db2e4347f4425324a',
    'planSha256': 'fbb94d97463303b99186673e546c5356f1f15f5a4dd70454314ed4d5393a36f6',
    'coldRows': rows, 'controlColdRangeMs': max(controls) - min(controls),
    'profileColdWithinControlRange': min(controls) <= rows[1]['coldApplicationWallElapsedMs'] <= max(controls),
    'profileRoutingMinusLowerControlMs': rows[1]['coldApplicationWallRoutingMs'] - min(route_controls),
    'monotonicTimingSource': 'performance.now; 22 coarse phases, no per-node or edge clocks',
    'monotonicRoutingPartitions': partitions,
    'nestedDetailNotAddedAgain': {'parent': 'P07_SEARCH_SETUP', 'child': 'P07_ROUTER_SETUP', 'childElapsedMs': ms('P07_ROUTER_SETUP')},
    'outsideParentScopes': [{'phase': name, 'elapsedMs': ms(name)} for name in
                            ('P05_CANDIDATE_SETUP', 'P05_POLICY_FINALIZATION', 'P07_SESSION_SETUP', 'P07_POLICY_FINALIZATION')],
    'profileCalls': sum(row['calls'] for row in phases.values()), 'clockReads': profile['clockReads'],
    'work': profile['work'],
    'physicalAttempts': 'All three P05 route attempts reject. P07 evaluates placement attempts 3,1,4: rejected, successful, rejected; selects attempt 1. All orderings, searches and final physical admission remain in raw parity receipts.',
    'metadataNegativeCasesPerPhase': {key: len(value) for key, value in pairs[0]['metadataNegativeCanaries'].items()},
    'strictNegativeCasesPerArmPerComparison': pairs[0]['strictReaderCanaryCounts']['corruptionCanaries'],
    'limits': [
        'All three cold measurements exceed the frozen normal 90000ms deadline. These private measurements do not establish normal timing, scale or acceptance.',
        'Only one profile observation with two controls; compiled-code-shape and clock overhead are not separated. Control drift is retained; no zero-overhead or exact production cost claim.',
        'P07 residual is not pure A*: publisher, copying, state transitions and unmeasured work remain in it. Nested setup is not double-counted.',
        'Application elapsed/proof/routing fields are wall-clock values. Coarse profile scopes use a monotonic clock and slightly different boundaries; they need not sum exactly to the legacy routing field.',
        'P05 post-search validators have zero calls because all P05 attempts reject before reaching them, not because validation was disabled.',
        'Original sequence reader CLI failure is preserved. Only its argparse Path conversion was repaired; original first two raw captures revalidated before the third row. Application source, workload, plan and thresholds unchanged.',
        'The accepted validator output contains a static generic todo list; its bound identities, profile rules, raw hashes and actual comparisons are checked and PASS. That guidance is not an unresolved gate result.'
    ]
}
out = s / 'route-stage-profile-root-interpretation.json'
assert not out.exists()
out.write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'status': result['status'], 'outputSha256': sha(out.read_bytes()),
                  'P05ResidualMs': partitions[0]['residualMs'], 'P07ResidualMs': partitions[1]['residualMs']}))
