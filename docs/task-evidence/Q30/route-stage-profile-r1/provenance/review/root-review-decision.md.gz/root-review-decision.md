# Root routing profile review decision

Scope: frozen 1,343-input private profiler fixture, source audit
`01a0c70a2117720f6e16ae000924cc201c8e0b0b0d15d19db2e4347f4425324a`.
Root approves focused measurement, subject to the frozen strict reader rejecting
invalid metadata and requiring full ordinary proof parity. No source integration,
speedup or Q30 acceptance is approved.

The independent review confirmed nullable/default-off plumbing, generic ownership,
unchanged routing predicates/order/work, complete validation and coarse timer
placement. Root reviewed the same diff and restored the original P07 wall timer
boundary after materialization before gates. Native9, including 145 new collector
assertions, GWT5, compiled A07/disabled-normal and three strict negatives passed.

Two review objections are resolved as follows. First, electrical qualification
status and profile validity are separate. The collector intentionally invalidates
only timing when its clock fails, preserving the measured workload. The frozen
plan requires: “Profile must freeze with zero clock/scope/open/late errors” and
“Validate all profiler fields before removing only those declared fields from
the comparison copy; keep raw reports unchanged.” It does not require changing
the electrical result for a clock failure. The metadata reader rejects invalid,
unfrozen or nonzero-error profiles before comparison; the sequence aborts on any
nonzero reader exit and records STOPPED_FAILURE. Thus a successful electrical
report containing invalid timing cannot become accepted profile evidence.

Second, the frozen verifier's finishWithoutTouchingSuccessor freezes the sidecar,
sets finished, publishes FAIL, and only then clears routeStageProfile. Its publish
method emits the frozen routeStageProfileIncomplete for this terminal case. The
review's claim that the reference is cleared before publication is incorrect.
The original independent review is preserved; its author was asked to reassess.

Reader validation remains a separate gate. Before any cold measurement, root
corrected a contradictory requirement that clockReads be zero (it must be a
nonnegative integer equal to twice phase calls; error counters remain zero).
An actual prior off/control report exposed a second reader defect: the maintained
host's identity.profile is its browser directory. Only that exact host key is now
allowed and required to be a string. The failed preflight and original readers
are retained; the corrected real off-reader preflight passes. No positive profile
has been fabricated. Actual profile metadata and corruption checks remain pending.

P07_ROUTER_SETUP is nested in P07_SEARCH_SETUP; only its parent is subtracted
when computing slice residual. The residual includes A* plus publisher and state
work. Inclusive phase totals are not summed as disjoint routing time.
