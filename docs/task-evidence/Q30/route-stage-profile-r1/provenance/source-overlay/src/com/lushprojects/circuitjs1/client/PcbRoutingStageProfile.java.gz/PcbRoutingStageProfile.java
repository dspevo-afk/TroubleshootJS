package com.lushprojects.circuitjs1.client;

import com.google.gwt.json.client.JSONBoolean;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONObject;

/** Optional value-only timing sidecar for the private Q30 routing verifier. */
final class PcbRoutingStageProfile {
    interface Clock { double nowMillis(); }

    enum Phase {
        P05_ROUTE_CALL, P05_CANDIDATE_SETUP, P05_ROUTER_SETUP, P05_GOAL_MASK,
        P05_DISTANCE_FIELD,
        P05_ASTAR, P05_PATH_MATERIALIZATION, P05_OCCUPANCY_CHECK,
        P05_CANONICALIZATION, P05_GEOMETRY_VALIDATION, P05_QUALITY_VALIDATION,
        P05_POLICY_FINALIZATION,
        P07_SESSION_SETUP, P07_ROUTER_SETUP, P07_SLICE, P07_GOAL_MASK,
        P07_LOWER_BOUND, P07_FINAL_GEOMETRY, P07_RULE_VALIDATION,
        P07_QUALITY_VALIDATION, P07_SEARCH_SETUP, P07_POLICY_FINALIZATION
    }
    enum Count {
        P05_ORDERINGS, P05_BRANCHES, P05_EXPANSIONS, P07_SLICE_OPERATIONS,
        P07_EXPANSIONS, P07_BRANCHES, P07_ORDERINGS
    }

    private final Clock clock;
    private final double[] elapsed = new double[Phase.values().length];
    private final int[] calls = new int[Phase.values().length];
    private final int[] failures = new int[Phase.values().length];
    private final long[] counts = new long[Count.values().length];
    private boolean valid = true;
    private boolean frozen;
    private double previous = Double.NaN;
    private int clockReads, clockErrors, scopeErrors, openScopes, lateScopeErrors;

    PcbRoutingStageProfile(Clock clock) {
        if (clock == null) throw new IllegalArgumentException("Missing routing profile clock");
        this.clock = clock;
    }
    static Clock browserClock() {
        return new Clock() { public double nowMillis() { return browserNowMillis(); } };
    }
    private static native double browserNowMillis() /*-{
        return $wnd.performance.now();
    }-*/;

    double begin() {
        if (frozen) { lateScopeErrors++; return Double.NaN; }
        if (!valid) return Double.NaN;
        double started = now();
        if (!Double.isNaN(started)) openScopes++;
        return started;
    }
    void record(Phase phase, double started, boolean failed) {
        if (frozen) { lateScopeErrors++; return; }
        if (phase == null) { scopeErrors++; return; }
        int index = phase.ordinal();
        calls[index]++;
        if (failed) failures[index]++;
        if (!Double.isNaN(started)) {
            if (openScopes > 0) openScopes--;
            else scopeErrors++;
        }
        if (Double.isNaN(started) || !valid) return;
        double ended = now();
        if (!valid) return;
        double duration = ended - started;
        if (Double.isNaN(duration) || Double.isInfinite(duration) || duration < 0) {
            valid = false; clockErrors++; return;
        }
        elapsed[index] += duration;
    }
    void count(Count count, long amount) {
        if (frozen) { lateScopeErrors++; return; }
        if (count == null || amount < 0) { scopeErrors++; return; }
        counts[count.ordinal()] += amount;
    }
    void freeze() {
        if (openScopes != 0) {
            scopeErrors += openScopes;
            openScopes = 0;
        }
        frozen = true;
    }

    boolean isValid() { return valid; }
    boolean isFrozen() { return frozen; }
    int clockReads() { return clockReads; }
    int clockErrors() { return clockErrors; }
    int scopeErrors() { return scopeErrors; }
    int openScopes() { return openScopes; }
    int lateScopeErrors() { return lateScopeErrors; }
    int calls(Phase phase) { return calls[phase.ordinal()]; }
    int failures(Phase phase) { return failures[phase.ordinal()]; }
    double millis(Phase phase) { return elapsed[phase.ordinal()]; }
    long count(Count count) { return counts[count.ordinal()]; }

    JSONObject toJson() {
        JSONObject result = new JSONObject();
        result.put("schema", new JSONNumber(1));
        result.put("clockSource", new JSONString("performance.now"));
        result.put("valid", JSONBoolean.getInstance(valid));
        result.put("frozen", JSONBoolean.getInstance(frozen));
        result.put("clockReads", new JSONNumber(clockReads));
        result.put("clockErrors", new JSONNumber(clockErrors));
        result.put("scopeErrors", new JSONNumber(scopeErrors));
        result.put("openScopes", new JSONNumber(openScopes));
        result.put("lateScopeErrors", new JSONNumber(lateScopeErrors));
        JSONObject phases = new JSONObject();
        for (Phase phase : Phase.values()) {
            int index = phase.ordinal();
            JSONObject row = new JSONObject();
            row.put("calls", new JSONNumber(calls[index]));
            row.put("failures", new JSONNumber(failures[index]));
            row.put("elapsedMs", new JSONNumber(elapsed[index]));
            phases.put(phase.name(), row);
        }
        result.put("phases", phases);
        JSONObject work = new JSONObject();
        for (Count count : Count.values())
            work.put(count.name(), new JSONNumber(counts[count.ordinal()]));
        result.put("work", work);
        return result;
    }

    private double now() {
        if (frozen || !valid) return Double.NaN;
        double value;
        clockReads++;
        try { value = clock.nowMillis(); }
        catch (Throwable failure) { clockErrors++; valid = false; return Double.NaN; }
        if (Double.isNaN(value) || Double.isInfinite(value) ||
                (!Double.isNaN(previous) && value < previous)) {
            clockErrors++; valid = false; return Double.NaN;
        }
        previous = value;
        return value;
    }
}
