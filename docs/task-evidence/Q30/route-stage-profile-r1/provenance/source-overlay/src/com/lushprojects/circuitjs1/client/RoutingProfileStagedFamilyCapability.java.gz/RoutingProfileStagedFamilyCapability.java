package com.lushprojects.circuitjs1.client;

/** Optional generic capability for a private request-scoped routing profile. */
interface RoutingProfileStagedFamilyCapability extends StagedFamilyCapability {
    ConstructionSession beginConstruction(Plan plan, PcbRoutingStageProfile routingProfile);
}
