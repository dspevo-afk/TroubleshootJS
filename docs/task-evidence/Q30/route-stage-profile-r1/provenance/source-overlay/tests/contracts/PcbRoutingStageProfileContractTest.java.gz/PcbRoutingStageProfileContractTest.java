package com.lushprojects.circuitjs1.client;

/** Native contracts for the private Q30 routing stage timing sidecar. */
public final class PcbRoutingStageProfileContractTest {
    private static int assertions;

    private PcbRoutingStageProfileContractTest() { }

    public static void main(String[] args) {
        nestedIntervalsAccumulateIndependentWork();
        independentRequestProfilesDoNotShareState();
        invalidClocksMakeTheProfileUnusableWithoutThrowing();
        freezePreservesPublishedValues();
        freezeDetectsAnUnmatchedBegin();
        profiledP07RoutePreservesTheUnprofiledResult();
        System.out.println("PASS: Pcb routing stage profile contracts (" + assertions +
            " assertions)");
    }

    private static void nestedIntervalsAccumulateIndependentWork() {
        PcbRoutingStageProfile profile = new PcbRoutingStageProfile(
            new SequenceClock(100, 110, 130, 150));
        double routeStarted = profile.begin();
        require(routeStarted == 100, "outer route interval starts at the first clock value");
        profile.count(PcbRoutingStageProfile.Count.P05_BRANCHES, 3);
        double searchStarted = profile.begin();
        require(searchStarted == 110, "nested search interval starts at the second clock value");
        profile.count(PcbRoutingStageProfile.Count.P05_EXPANSIONS, 7);
        profile.record(PcbRoutingStageProfile.Phase.P05_ASTAR, searchStarted, true);
        profile.record(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL, routeStarted, false);

        require(profile.isValid(), "nested valid intervals leave the profile usable");
        require(profile.clockReads() == 4, "nested intervals use one start/end read each");
        require(profile.calls(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL) == 1,
            "outer route call count is recorded once");
        require(profile.calls(PcbRoutingStageProfile.Phase.P05_ASTAR) == 1,
            "inner A-star call count is recorded once");
        require(profile.failures(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL) == 0,
            "successful outer route is not recorded as a failure");
        require(profile.failures(PcbRoutingStageProfile.Phase.P05_ASTAR) == 1,
            "failed inner A-star is recorded independently");
        require(profile.millis(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL) == 50,
            "outer interval includes the nested interval numerically");
        require(profile.millis(PcbRoutingStageProfile.Phase.P05_ASTAR) == 20,
            "inner interval keeps its own numeric duration");
        require(profile.count(PcbRoutingStageProfile.Count.P05_BRANCHES) == 3,
            "branch work count preserves its independent total");
        require(profile.count(PcbRoutingStageProfile.Count.P05_EXPANSIONS) == 7,
            "expansion work count preserves its independent total");
        require(profile.openScopes() == 0 && profile.scopeErrors() == 0,
            "nested intervals close without scope errors");
        profile.freeze();
        require(profile.isFrozen(), "nested profile can be frozen after all intervals close");
    }

    private static void independentRequestProfilesDoNotShareState() {
        PcbRoutingStageProfile cold = new PcbRoutingStageProfile(
            new SequenceClock(10, 14));
        double coldStarted = cold.begin();
        cold.record(PcbRoutingStageProfile.Phase.P05_ROUTER_SETUP, coldStarted, false);
        cold.count(PcbRoutingStageProfile.Count.P05_BRANCHES, 2);
        cold.freeze();

        PcbRoutingStageProfile warm = new PcbRoutingStageProfile(
            new SequenceClock(20, 29));
        double warmStarted = warm.begin();
        warm.record(PcbRoutingStageProfile.Phase.P07_SEARCH_SETUP, warmStarted, true);
        warm.count(PcbRoutingStageProfile.Count.P07_EXPANSIONS, 4);
        warm.freeze();

        require(cold.clockReads() == 2 && warm.clockReads() == 2,
            "cold and warm request owners retain separate clock reads");
        require(cold.millis(PcbRoutingStageProfile.Phase.P05_ROUTER_SETUP) == 4,
            "cold request retains only its own elapsed time");
        require(warm.millis(PcbRoutingStageProfile.Phase.P07_SEARCH_SETUP) == 9,
            "warm request retains only its own elapsed time");
        require(cold.calls(PcbRoutingStageProfile.Phase.P05_ROUTER_SETUP) == 1 &&
                warm.calls(PcbRoutingStageProfile.Phase.P07_SEARCH_SETUP) == 1,
            "cold and warm request owners retain their own phase calls");
        require(cold.failures(PcbRoutingStageProfile.Phase.P05_ROUTER_SETUP) == 0 &&
                warm.failures(PcbRoutingStageProfile.Phase.P07_SEARCH_SETUP) == 1,
            "failure counts do not cross request owners");
        require(cold.count(PcbRoutingStageProfile.Count.P05_BRANCHES) == 2 &&
                cold.count(PcbRoutingStageProfile.Count.P07_EXPANSIONS) == 0 &&
                warm.count(PcbRoutingStageProfile.Count.P05_BRANCHES) == 0 &&
                warm.count(PcbRoutingStageProfile.Count.P07_EXPANSIONS) == 4,
            "work totals do not cross cold and warm request owners");
        require(cold.scopeErrors() == 0 && warm.scopeErrors() == 0 &&
                cold.openScopes() == 0 && warm.openScopes() == 0,
            "independent request profiles close all of their own scopes");
    }

    private static void invalidClocksMakeTheProfileUnusableWithoutThrowing() {
        verifyInvalidClock("backward", new SequenceClock(25, 24));
        verifyInvalidClock("NaN", new SequenceClock(35, Double.NaN));
        verifyInvalidClock("infinite", new SequenceClock(45, Double.POSITIVE_INFINITY));
        verifyInvalidClock("throwing", new ThrowingClock(55));
    }

    private static void verifyInvalidClock(String name, PcbRoutingStageProfile.Clock clock) {
        PcbRoutingStageProfile profile = new PcbRoutingStageProfile(clock);
        double started = profile.begin();
        require(!Double.isNaN(started), name + " clock supplies a usable initial timestamp");
        boolean threw = false;
        try {
            profile.record(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL, started, true);
        } catch (Throwable failure) {
            threw = true;
        }
        require(!threw, name + " clock failure is contained by record");
        require(!profile.isValid(), name + " clock makes the profile invalid");
        require(profile.clockErrors() == 1, name + " clock contributes one clock error");
        require(profile.calls(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL) == 1 &&
                profile.failures(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL) == 1,
            name + " clock still records the attempted phase and failure");
        require(profile.millis(PcbRoutingStageProfile.Phase.P05_ROUTE_CALL) == 0,
            name + " clock failure publishes no elapsed duration");
        int reads = profile.clockReads();
        require(Double.isNaN(profile.begin()), name + " invalid profile rejects a later begin");
        require(profile.clockReads() == reads,
            name + " unusable profile does not read the clock again");
        profile.freeze();
        require(profile.isFrozen() && profile.scopeErrors() == 0 && profile.openScopes() == 0,
            name + " unusable profile still freezes without a scope error");
    }

    private static void freezePreservesPublishedValues() {
        PcbRoutingStageProfile profile = new PcbRoutingStageProfile(
            new SequenceClock(7, 12));
        double started = profile.begin();
        profile.record(PcbRoutingStageProfile.Phase.P05_GEOMETRY_VALIDATION, started, false);
        profile.count(PcbRoutingStageProfile.Count.P07_EXPANSIONS, 5);
        profile.freeze();

        int reads = profile.clockReads();
        boolean valid = profile.isValid();
        int scopeErrors = profile.scopeErrors();
        int openScopes = profile.openScopes();
        double[] millis = new double[PcbRoutingStageProfile.Phase.values().length];
        int[] calls = new int[PcbRoutingStageProfile.Phase.values().length];
        int[] failures = new int[PcbRoutingStageProfile.Phase.values().length];
        for (PcbRoutingStageProfile.Phase phase : PcbRoutingStageProfile.Phase.values()) {
            int index = phase.ordinal();
            millis[index] = profile.millis(phase);
            calls[index] = profile.calls(phase);
            failures[index] = profile.failures(phase);
        }
        long[] work = new long[PcbRoutingStageProfile.Count.values().length];
        for (PcbRoutingStageProfile.Count count : PcbRoutingStageProfile.Count.values())
            work[count.ordinal()] = profile.count(count);

        require(Double.isNaN(profile.begin()), "frozen profile rejects a new scope");
        profile.record(PcbRoutingStageProfile.Phase.P05_ASTAR, started, true);
        profile.count(PcbRoutingStageProfile.Count.P07_EXPANSIONS, 99);
        profile.freeze();

        require(profile.isFrozen() && profile.isValid() == valid,
            "freeze keeps terminal and validity state stable");
        require(profile.clockReads() == reads, "frozen operations do not read the clock");
        require(profile.scopeErrors() == scopeErrors && profile.openScopes() == openScopes,
            "frozen operations do not change scope state");
        require(profile.lateScopeErrors() == 3,
            "begin, record, and count each report one rejected late operation");
        for (PcbRoutingStageProfile.Phase phase : PcbRoutingStageProfile.Phase.values()) {
            int index = phase.ordinal();
            require(profile.millis(phase) == millis[index],
                "frozen operations preserve elapsed " + phase);
            require(profile.calls(phase) == calls[index],
                "frozen operations preserve calls " + phase);
            require(profile.failures(phase) == failures[index],
                "frozen operations preserve failures " + phase);
        }
        for (PcbRoutingStageProfile.Count count : PcbRoutingStageProfile.Count.values())
            require(profile.count(count) == work[count.ordinal()],
                "frozen operations preserve work " + count);
    }

    private static void freezeDetectsAnUnmatchedBegin() {
        PcbRoutingStageProfile profile = new PcbRoutingStageProfile(new SequenceClock(90));
        double started = profile.begin();
        require(started == 90 && profile.openScopes() == 1,
            "an unmatched begin leaves one open scope before freeze");
        int reads = profile.clockReads();
        profile.freeze();
        require(profile.isFrozen(), "unmatched profile still reaches the frozen state");
        require(profile.openScopes() == 0 && profile.scopeErrors() == 1,
            "freeze detects and closes the unmatched begin");
        require(profile.clockReads() == reads && profile.lateScopeErrors() == 0,
            "unmatched-scope detection does not read the clock or report a late call");
    }

    private static void profiledP07RoutePreservesTheUnprofiledResult() {
        P06FactoryLinkFixtures.Fixture unprofiledFixture =
            new P06FactoryLinkFixtures.Fixture(true, 0, 0, true);
        PcbLayerRoutingPrototype.Result unprofiled = PcbLayerRoutingPrototype.route(
            unprofiledFixture.board, unprofiledFixture.layout,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,
            P06FactoryLinkFixtures.OBSERVER);

        P06FactoryLinkFixtures.Fixture profiledFixture =
            new P06FactoryLinkFixtures.Fixture(true, 0, 0, true);
        PcbRoutingStageProfile profile = new PcbRoutingStageProfile(new TickClock(1000));
        PcbLayerRoutingPrototype.Session session = PcbLayerRoutingPrototype.begin(
            profiledFixture.board, profiledFixture.layout,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,
            P06FactoryLinkFixtures.OBSERVER, PcbLayerRoutingPrototype.MAX_EXPANSIONS, profile);
        int slices = 0;
        while (!session.advanceSlice()) {
            if (++slices > 100000)
                throw new AssertionError("profiled P07 route exceeded the native slice bound");
        }
        slices++;
        PcbLayerRoutingPrototype.Result profiled = session.result();
        profile.freeze();

        require(slices > 0 && unprofiled.accepted() && profiled.accepted(),
            "small P07 fixture completes in both profile modes");
        require(unprofiled.outcome.equals(profiled.outcome) &&
                unprofiled.expansions == profiled.expansions &&
                unprofiled.orderings == profiled.orderings &&
                unprofiled.vias == profiled.vias &&
                unprofiled.links == profiled.links,
            "profiled P07 routing preserves outcome and work identity");
        require(unprofiled.layout.geometryFingerprint().equals(
                profiled.layout.geometryFingerprint()),
            "profiled P07 routing preserves exact geometry");
        require(profile.isFrozen() && profile.isValid() && profile.scopeErrors() == 0 &&
                profile.openScopes() == 0 && profile.lateScopeErrors() == 0,
            "profiled P07 route closes every timing scope before freeze");
        require(profile.clockReads() > 0 &&
                profile.calls(PcbRoutingStageProfile.Phase.P07_SLICE) > 0 &&
                profile.calls(PcbRoutingStageProfile.Phase.P07_ROUTER_SETUP) > 0,
            "profiled P07 route records its slice and router setup phases");
        require(profile.millis(PcbRoutingStageProfile.Phase.P07_SLICE) > 0 &&
                profile.count(PcbRoutingStageProfile.Count.P07_SLICE_OPERATIONS) > 0 &&
                profile.count(PcbRoutingStageProfile.Count.P07_EXPANSIONS) == profiled.expansions &&
                profile.count(PcbRoutingStageProfile.Count.P07_ORDERINGS) == profiled.orderings &&
                profile.count(PcbRoutingStageProfile.Count.P07_BRANCHES) > 0,
            "profiled P07 route records positive slice time and exact routing work");
    }

    private static void require(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }

    private static final class SequenceClock implements PcbRoutingStageProfile.Clock {
        private final double[] values;
        private int next;

        SequenceClock(double... values) { this.values = values; }

        public double nowMillis() {
            if (next >= values.length)
                throw new AssertionError("test clock read past its declared sequence");
            return values[next++];
        }
    }

    private static final class ThrowingClock implements PcbRoutingStageProfile.Clock {
        private final double first;
        private int reads;

        ThrowingClock(double first) { this.first = first; }

        public double nowMillis() {
            if (reads++ == 0) return first;
            throw new IllegalStateException("synthetic clock failure");
        }
    }

    private static final class TickClock implements PcbRoutingStageProfile.Clock {
        private double value;

        TickClock(double initial) { value = initial; }

        public double nowMillis() { return value++; }
    }
}
