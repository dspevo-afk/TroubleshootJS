# Q30 routing-stage profiler draft

This is a scratch-only, source-instrumentation draft on the frozen pivot/lower-fusion R2 fixture. It is not an optimization or qualification result. The predeclared comparison is the three-row seed-10014 sequence recorded in route-stage-profile-measurement-plan.json: fresh uninstrumented control, profiled candidate, fresh uninstrumented control. It compares code shape and timer overhead, and requires full parity on both controls; it does not assume profiling is free. The base is the 1,340-input fixture identified in manifest.json.

The profile is opt-in only through the private Q30 verifier query tsjQ30RouteStageProfile=true. A request-owned nullable sidecar carries a monotonic performance.now clock. With no profile, no clock is read. Invalid, backwards, throwing, or non-finite clock values invalidate only the profile. The sidecar retains scalar timings and counts, no board or graph references. It remains attached through exact-candidate retry cleanup and is released with the coordinator's saved owners.

## Timing nesting and interpretation

These are coarse scopes, not per-node or per-edge timers.

- P05_ROUTE_CALL encloses a complete P05 route call. Within it, P05_ROUTER_SETUP covers router construction. Each branch separately records P05_GOAL_MASK, P05_DISTANCE_FIELD, and P05_ASTAR. P05_PATH_MATERIALIZATION covers path reconstruction and copper marking. After search, P05_OCCUPANCY_CHECK, P05_CANONICALIZATION, P05_GEOMETRY_VALIDATION, and P05_QUALITY_VALIDATION are sibling scopes in their actual order. P05_CANDIDATE_SETUP and P05_POLICY_FINALIZATION belong to the seeded-layout attempt outside the route call. Nested inclusive values must not be added as though disjoint.
- P07_SESSION_SETUP wraps route-plan materialization and two-layer session construction. Each P07_SLICE wraps one existing bounded advanceSlice operation. Within a slice, P07_SEARCH_SETUP covers per-ordering search setup. The two P07_ROUTER_SETUP scopes for its two layer faces are nested inside P07_SEARCH_SETUP; do not subtract them again alongside that enclosing time. Per-branch P07_GOAL_MASK and P07_LOWER_BOUND are sibling scopes at slice level. After a path is found, final geometry, rules, and quality are sibling validation scopes. P07_POLICY_FINALIZATION runs in the seeded-layout owner after the complete session.
- The P07 slice timer is deliberately inclusive: it measures unchanged slice state-machine work, including A* expansion and neighbor checks, heap operations, and state transitions. It is a broad search bracket, not a pure A* timer. Its residual after subtracting separately measured nested phases is “A* plus slice publisher/state-machine work”; it is not labeled as A* alone. P05 has an explicit A* loop bracket, which is inclusive of that loop's existing search operations.

Call/failure counts accompany phases. Work counters count existing orderings, branches, expansions, slice operations, and P07 slice expansion deltas. The clock-read count exposes timer sampling volume. No timing is collected inside expansion loops. The collector checks unmatched scopes at freeze, rejects late records without changing frozen measurements, and reports clock/scope errors. These safeguards and phase names remain subject to root's focused contract and full-source gates.

## Scope and review

The overlays carry the nullable profile through the private Q30 verifier, generic coordinator/request/capability adapter, and P05/P07 routing owners. Family-specific opt-in stays in the Q30 verifier; there is no static active flag or generic coordinator family test. Normal construction follows the existing capability path. The profile is designed not to alter route ordering, candidate selection, geometry predicates, work limits, cancellation calls, proofs, or budgets; this is a source-review expectation, not yet gated proof.

The frozen contract-test overlay is owned by Raman and is listed with its hash in manifest.json; this task did not edit it. source-review.patch.gz is a normalized-LF review diff; decompress it to inspect. Overlay bytes retain unchanged base line endings where source lines were unchanged. The manifest records both stored-byte and normalized-source hashes.

Prior routing-bookkeeping and distance-transform experiments are not reused as current timings. The distance-transform experiment was inconclusive and changed only Router's P05 field; it does not establish which P07 stage dominates.

No build, tests, browser checks, or timing runs were executed for this draft. Status is pending root source review and the predeclared gates. This is not an accepted optimization and does not change Q30 acceptance.
