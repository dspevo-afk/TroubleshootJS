#!/usr/bin/env python3
"""Read-only validator for a private Q30 route-stage profile sequence.

This draft reader is deliberately bound by an explicit JSON file.  The binding
must be frozen and must name the final plan, accepted/base fixture, candidate
source audit, runner, gate, preserved timing-pair adapter, strict reader and
the actual raw terminal reports.  It also supplies the collector's exact phase
and work-counter lists, so this reader never infers an enum from an old draft.

The normal final shape is three independent seed-10014 rows: an uninstrumented
control before the profile arm, the profile-enabled candidate, and an
uninstrumented control after it.  Pass one or both control role keys with
``--control-key``.  Every selected arm receives the unchanged current Q30
strict-reader/self-test adapter against its full original report.  Only after
that validation does this reader make a comparison-only deep copy and remove
the explicitly allowlisted route-profile fields and the timing fields owned by
the preserved adapter.  All other report values must remain byte-data-equivalent
as parsed JSON.

The output is private experiment evidence.  A successful result is not a
production acceptance result, a routing-budget decision, or a zero-overhead
claim.  This script never launches a browser, host, build or test and never
edits production files.

Binding JSON contract (paths may be absolute; identity paths are resolved
relative to the binding file, strict-reader paths relative to ``repo``, and
report paths relative to ``scratch``):

    {
      "schema": 1, "status": "FROZEN",
      "privateExperiment": true, "productionAcceptance": false,
      "zeroInstrumentationOverheadClaim": false,
      "purpose": "...",
      "seed": "10014", "packages": 40, "hypothesisWork": 390,
      "acceptedSource": {"commit": "ffe9132", "audit": {"path": ..., "sha256": ...}},
      "baseFixture": {"path": ...},
      "profileSource": {"root": ..., "audit": {"path": ..., "sha256": ...},
                         "files": [{"path": ..., "sha256": ..., "bytes": ...}]},
      "plan": {"path": ..., "sha256": ...},
      "runner": {"path": ..., "sha256": ...},
      "gate": {"path": ..., "sha256": ...},
      "timingAdapter": {"path": ..., "sha256": ...},
      "strictReader": {
        "reader": {"path": ..., "sha256": ...},
        "parser": {"path": ..., "sha256": ...}
      },
      "reports": {
        "controlBefore": {"label": ..., "mode": "off", "reportPath": ..., "sha256": ..., "byteLength": ...},
        "profile": {"label": ..., "mode": "profile", "reportPath": ..., "sha256": ..., "byteLength": ...},
        "controlAfter": {"label": ..., "mode": "off", "reportPath": ..., "sha256": ..., "byteLength": ...}
      },
      "phaseNames": [ ... ], "workNames": [ ... ],
      "phaseParentRelations": [{"parent": ..., "child": ..., "justification": ...}]
    }

``phaseParentRelations`` may be empty.  When present, each edge is checked
individually as an inclusive parent >= child inequality; child values are never
summed.  The binding is therefore the place where source inspection justifies
any such relationship.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
import math
import re
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlsplit


SEED = "10014"
PACKAGES = 40
HYPOTHESIS_WORK = 390
PROFILE_QUERY_KEY = "tsjQ30RouteStageProfile"
PROFILE_QUERY = PROFILE_QUERY_KEY + "=true"
PAIR_SCHEMA = 1
PURPOSE = "PRIVATE_ROUTE_STAGE_PROFILE_EXPERIMENT"
REPORT_MODES = ("off", "profile")
SAFE_NAME = re.compile(r"[A-Za-z0-9._-]{1,96}\Z")
SAFE_TAG = re.compile(r"[A-Za-z0-9._-]{1,64}\Z")
HASH_RE = re.compile(r"[0-9a-fA-F]{64}\Z")
COMMIT_RE = re.compile(r"[0-9a-fA-F]{7,40}\Z")
ERROR_ARRAYS = (
    "pageErrors", "httpErrors", "consoleErrors", "attributeReadErrors",
    "listenerCleanupErrors",
)
APP_PHASE_TIMINGS = (
    "elapsedMs", "wallElapsedMs", "maxAdvanceMs", "maxManualUnitMs",
    "routingElapsedMs", "proofElapsedMs", "cleanupElapsedMs",
)


class ValidationError(Exception):
    pass


def need(condition, message):
    if not condition:
        raise ValidationError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValidationError("could not read UTF-8 JSON {}: {}".format(
            path.name, error))


def load_json_bytes(path, label):
    try:
        raw = path.read_bytes()
        text = raw.decode("utf-8")
        value = json.loads(text)
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValidationError("could not read UTF-8 JSON {}: {}".format(
            label, error))
    return raw, text, value


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


def write_json_new(path, value):
    need(not path.exists(),
         "refusing to overwrite existing validation output: " + str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json_bytes(value))


def exact_int(value, label, minimum=None):
    need(type(value) is int,
         label + " must be an integer (booleans are not integers)")
    if minimum is not None:
        need(value >= minimum, label + " is below its minimum")
    return value


def finite(value, label, minimum=None):
    need(type(value) in (int, float) and not isinstance(value, bool) and
         math.isfinite(value), label + " must be finite")
    value = float(value)
    if minimum is not None:
        need(value >= minimum, label + " is below its minimum")
    return value


def safe_name(value, label, pattern=SAFE_NAME):
    need(isinstance(value, str) and pattern.fullmatch(value) is not None and
         value not in (".", ".."), label + " contains unsafe path characters")
    return value


def resolve_path(value, base, label):
    need(isinstance(value, str) and value, label + " path is missing")
    raw = Path(value)
    target = raw if raw.is_absolute() else (base / raw)
    return target.resolve()


def safe_relative_child(root, relative, label):
    need(isinstance(relative, str) and relative,
         label + " relative path is missing")
    path = Path(relative.replace("/", "\\"))
    need(not path.is_absolute() and ".." not in path.parts,
         label + " escapes its declared root")
    target = (root / path).resolve()
    root = root.resolve()
    need(target != root and root in target.parents,
         label + " escapes its declared root")
    return target


def verify_hashed_file(spec, label, base, require_bytes=False):
    need(isinstance(spec, dict), label + " must be an object")
    need(isinstance(spec.get("path"), str) and spec["path"],
         label + " path is missing")
    expected = spec.get("sha256")
    need(isinstance(expected, str) and HASH_RE.fullmatch(expected) is not None,
         label + " sha256 is missing or malformed")
    path = resolve_path(spec["path"], base, label)
    need(path.is_file(), label + " file does not exist: " + str(path))
    raw = path.read_bytes()
    actual = sha256(raw)
    need(actual.casefold() == expected.casefold(),
         label + " sha256 changed")
    if require_bytes or "bytes" in spec:
        expected_bytes = exact_int(spec.get("bytes"), label + " bytes", 0)
        need(len(raw) == expected_bytes, label + " byte length changed")
    return {"path": str(path), "sha256": actual, "bytes": len(raw)}


def verify_source_bundle(spec, label, base, metadata_module):
    need(isinstance(spec, dict), label + " must be an object")
    root_value = spec.get("root")
    root = resolve_path(root_value, base, label + " root")
    need(root.is_dir(), label + " root is not a directory")
    audit = verify_hashed_file(spec.get("audit"), label + " audit", base)
    files = spec.get("files", [])
    need(isinstance(files, list), label + " files must be an array")
    file_results = []
    for index, file_spec in enumerate(files):
        need(isinstance(file_spec, dict),
             "{} file {} must be an object".format(label, index))
        relative = file_spec.get("path")
        target = safe_relative_child(root, relative,
                                     "{} file {}".format(label, index))
        actual_spec = dict(file_spec)
        actual_spec["path"] = str(target)
        file_results.append(verify_hashed_file(
            actual_spec, "{} file {}".format(label, index), root,
            require_bytes=True))
    return {"root": str(root), "audit": audit, "files": file_results,
            "enumSource": metadata_module.__name__}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    need(spec is not None and spec.loader is not None,
         "could not load " + name)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_binding(binding, binding_path, scratch, repo, profile_key,
                     control_keys, metadata_module):
    need(isinstance(binding, dict), "binding must be a JSON object")
    required = (
        "schema", "status", "privateExperiment", "productionAcceptance",
        "zeroInstrumentationOverheadClaim", "purpose", "seed", "packages",
        "hypothesisWork", "acceptedSource", "baseFixture", "profileSource",
        "plan", "runner", "gate", "timingAdapter", "strictReader",
        "reports", "phaseNames", "workNames", "phaseParentRelations",
    )
    missing = [key for key in required if key not in binding]
    need(not missing, "binding is missing fields: " + ", ".join(missing))
    exact_int(binding["schema"], "binding schema", PAIR_SCHEMA)
    need(binding["schema"] == PAIR_SCHEMA,
         "unsupported route-stage profile binding schema")
    need(binding["status"] == "FROZEN", "binding is not frozen")
    need(binding["privateExperiment"] is True,
         "binding does not identify a private experiment")
    need(binding["productionAcceptance"] is False,
         "binding must explicitly forbid production acceptance")
    need(binding["zeroInstrumentationOverheadClaim"] is False,
         "binding must explicitly forbid a zero-overhead claim")
    need(isinstance(binding["purpose"], str) and binding["purpose"].strip(),
         "binding purpose is missing")
    need(binding["seed"] == SEED and binding["seed"] == binding.get("seed"),
         "binding seed must be exact signed-long seed 10014")
    exact_int(binding["packages"], "binding packages", PACKAGES)
    exact_int(binding["hypothesisWork"], "binding hypothesisWork", HYPOTHESIS_WORK)
    commit = binding["acceptedSource"].get("commit") if isinstance(
        binding["acceptedSource"], dict) else None
    need(isinstance(commit, str) and COMMIT_RE.fullmatch(commit) is not None,
         "accepted source commit must be a hexadecimal commit identity")

    source_audit = verify_hashed_file(
        binding["acceptedSource"].get("audit"),
        "accepted source audit", binding_path.parent)
    base_fixture = binding["baseFixture"]
    need(isinstance(base_fixture, dict), "baseFixture must be an object")
    base_fixture_path = resolve_path(base_fixture.get("path"),
                                    binding_path.parent, "baseFixture")
    need(base_fixture_path.is_dir(),
         "baseFixture directory does not exist: " + str(base_fixture_path))

    phase_names, work_names = metadata_module.normalize_enum_lists(
        binding["phaseNames"], binding["workNames"])
    relations = binding["phaseParentRelations"]
    need(isinstance(relations, list), "phaseParentRelations must be an array")
    relation_edges = set()
    for index, relation in enumerate(relations):
        need(isinstance(relation, dict),
             "phase parent relation {} must be an object".format(index))
        need(set(relation) == {"parent", "child", "justification"},
             "phase parent relation {} has unexpected keys".format(index))
        parent, child = relation["parent"], relation["child"]
        need(parent in phase_names and child in phase_names and parent != child,
             "phase parent relation {} names invalid phases".format(index))
        need(isinstance(relation["justification"], str) and
             relation["justification"].strip(),
             "phase parent relation {} lacks source justification".format(index))
        edge = (parent, child)
        need(edge not in relation_edges,
             "phase parent relation {} is duplicated".format(index))
        relation_edges.add(edge)

    identity_results = {}
    for identity_name in ("plan", "runner", "gate"):
        identity_results[identity_name] = verify_hashed_file(
            binding[identity_name], identity_name, binding_path.parent)

    adapter_identity = verify_hashed_file(
        binding["timingAdapter"], "timing adapter", binding_path.parent)
    adapter = load_module(Path(adapter_identity["path"]),
                          "route_stage_timing_adapter")
    need(callable(getattr(adapter, "strict_reader", None)),
         "timing adapter does not expose strict_reader")
    need(callable(getattr(adapter, "remove_declared_timings", None)),
         "timing adapter does not expose remove_declared_timings")

    strict_reader = binding["strictReader"]
    need(isinstance(strict_reader, dict) and
         set(strict_reader) == {"reader", "parser"},
         "strictReader must bind reader and parser identities")
    strict_reader_results = {}
    for name in ("reader", "parser"):
        strict_reader_results[name] = verify_hashed_file(
            strict_reader[name], "strict reader " + name, repo)

    profile_source = verify_source_bundle(
        binding["profileSource"], "profile source", binding_path.parent,
        metadata_module)
    identity_results["acceptedSourceAudit"] = source_audit
    identity_results["baseFixture"] = {"path": str(base_fixture_path)}
    identity_results["profileSource"] = profile_source
    identity_results["timingAdapter"] = adapter_identity
    identity_results["strictReader"] = strict_reader_results

    reports = binding["reports"]
    need(isinstance(reports, dict) and reports,
         "binding reports must be a non-empty object")
    selected_keys = [profile_key] + list(control_keys)
    need(len(selected_keys) == len(set(selected_keys)),
         "profile and control report role keys must be distinct")
    report_results = {}
    for key in selected_keys:
        safe_name(key, "report role key")
        need(key in reports, "binding has no report role: " + key)
        entry = reports[key]
        need(isinstance(entry, dict), "report role {} must be an object".format(key))
        for field in ("label", "mode", "reportPath", "sha256", "byteLength"):
            need(field in entry, "report role {} is missing {}".format(key, field))
        label = safe_name(entry["label"], "report role {} label".format(key))
        mode = entry["mode"]
        need(mode in REPORT_MODES,
             "report role {} has an invalid mode".format(key))
        expected_mode = "profile" if key == profile_key else "off"
        need(mode == expected_mode,
             "report role {} mode does not match its selected arm".format(key))
        report_path = resolve_path(entry["reportPath"], scratch,
                                   "report role {}".format(key))
        need(report_path.is_file(),
             "report role {} raw report is missing".format(key))
        raw = report_path.read_bytes()
        expected_hash = entry["sha256"]
        need(isinstance(expected_hash, str) and HASH_RE.fullmatch(expected_hash),
             "report role {} sha256 is malformed".format(key))
        need(sha256(raw).casefold() == expected_hash.casefold(),
             "report role {} raw report sha256 changed".format(key))
        byte_length = exact_int(entry["byteLength"],
                                "report role {} byteLength".format(key), 1)
        need(len(raw) == byte_length,
             "report role {} raw report byte length changed".format(key))
        report_results[key] = {
            "role": key,
            "label": label,
            "mode": mode,
            "reportPath": str(report_path),
            "reportSha256": sha256(raw),
            "reportByteLength": len(raw),
        }
    need(profile_key in reports, "profile role is not bound")
    selected_labels = [report_results[key]["label"] for key in selected_keys]
    need(len(selected_labels) == len(set(selected_labels)),
         "selected report roles must name distinct host rows")
    selected_paths = [report_results[key]["reportPath"] for key in selected_keys]
    need(len(selected_paths) == len(set(selected_paths)),
         "selected report roles must name distinct raw reports")

    return {
        "binding": binding,
        "bindingSha256": sha256(binding_path.read_bytes()),
        "acceptedSourceCommit": commit,
        "sourceAudit": source_audit,
        "baseFixture": {"path": str(base_fixture_path)},
        "identity": identity_results,
        "phaseNames": phase_names,
        "workNames": work_names,
        "phaseParentRelations": relations,
        "adapter": adapter,
        "adapterIdentity": adapter_identity,
        "strictReader": strict_reader_results,
        "reports": report_results,
        "profileKey": profile_key,
        "controlKeys": list(control_keys),
    }


def reject_profile_keys(value, path, allowed_paths=()):
    """Reject profile-named transport keys except exact bound diagnostics."""
    if isinstance(value, dict):
        for key, item in value.items():
            current = path + "." + str(key)
            if "profile" in str(key).casefold():
                need(current in allowed_paths,
                     "unexpected profile field in " + current)
            reject_profile_keys(item, current, allowed_paths)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            reject_profile_keys(item, "{}[{}]".format(path, index),
                                allowed_paths)


def validate_profile_query(path, seed, mode, label):
    need(isinstance(path, str) and path, label + " path is missing")
    query = parse_qs(urlsplit(path).query, keep_blank_values=True)
    need(query.get("tsjQ30Seed") == [seed],
         label + " path does not carry the exact requested seed")
    profile_keys = [key for key in query
                    if "profile" in key.casefold()]
    if mode == "profile":
        need(query.get(PROFILE_QUERY_KEY) == ["true"],
             label + " path does not carry the exact route-stage profile query")
        need(profile_keys == [PROFILE_QUERY_KEY],
             label + " path contains another profile query")
    else:
        need(not profile_keys,
             label + " off path unexpectedly carries a profile query")


def check_terminal_profile_fields(report, mode, expected_phases,
                                  expected_work, parent_relations,
                                  metadata_module, label):
    """Validate profile presence, location and terminal lifecycle semantics."""
    need(isinstance(report, dict), label + " report must be an object")
    allowed = {
        "report.routeStageProfileQuery",
        "report.routeStageProfileRequested",
        "report.cold.routeStageProfile",
        "report.warm.routeStageProfile",
    }

    def visit(value, path):
        if isinstance(value, dict):
            for key, item in value.items():
                current = path + "." + str(key)
                if str(key) == "routeStageProfileCurrent":
                    raise ValidationError(
                        label + " terminal report persisted routeStageProfileCurrent")
                if "profile" in str(key).casefold():
                    if mode != "profile" or current not in allowed:
                        raise ValidationError(
                            label + " has profile field outside its allowlist: " + current)
                visit(item, current)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                visit(item, "{}[{}]".format(path, index))

    visit(report, "report")
    if mode == "profile":
        need("routeStageProfileIncomplete" not in report,
             label + " terminal PASS report contains routeStageProfileIncomplete")
        need(report.get("routeStageProfileQuery") == PROFILE_QUERY,
             label + " report is missing the exact route profile query receipt")
        need(report.get("routeStageProfileRequested") is True,
             label + " report is missing routeStageProfileRequested=true")
        need("routeStageProfileCurrent" not in report,
             label + " terminal report contains routeStageProfileCurrent")
        for phase in ("cold", "warm"):
            run = report.get(phase)
            need(isinstance(run, dict) and
                 isinstance(run.get("routeStageProfile"), dict),
                 label + " " + phase + " is missing routeStageProfile")
            metadata_module.validate_profile_record(
                run["routeStageProfile"], expected_phases, expected_work,
                parent_relations)
    else:
        need(not any(key in report for key in (
            "routeStageProfileQuery", "routeStageProfileRequested",
            "routeStageProfileCurrent")),
             label + " off report contains route-stage profile root metadata")
        for phase in ("cold", "warm"):
            run = report.get(phase)
            need(isinstance(run, dict) and "routeStageProfile" not in run,
                 label + " off report contains " + phase + ".routeStageProfile")


def safe_report_path(output_dir, report_file):
    need(isinstance(report_file, str) and report_file,
         "host case omitted its standalone report path")
    relative = Path(report_file.replace("/", "\\"))
    need(not relative.is_absolute() and ".." not in relative.parts,
         "host case report path is not a safe relative path")
    root = output_dir.resolve()
    target = (output_dir / relative).resolve()
    need(target != root and root in target.parents,
         "host case report path escapes its output directory")
    return target


def manifest_content(manifest):
    keys = (
        "schema", "roots", "files", "fileCount", "sourceFileCount",
        "webFileCount", "sha256", "sourceSha256", "webSha256",
    )
    need(all(key in manifest for key in keys),
         "input manifest omitted required identity fields")
    return {key: manifest[key] for key in keys}


def validate_request_contract(report, seed, packages, hypothesis_work, label):
    request = report.get("request")
    need(isinstance(request, str), label + " request is missing")
    need(re.search(r"(?m)^root-seed=" + re.escape(seed) +
                   r";quickPlay=false;layout=", request),
         label + " request does not carry the exact root seed")
    need("device-intent=RB30_CONTROL@1" in request and
         ";qualification=true;explicitCompletion=true;planEpoch=4;" in request,
         label + " request is not the exact private Q30 plan-4 qualification request")
    need(";packages={};".format(packages) in request,
         label + " request does not declare the exact package count" )
    need(request.endswith(";physicalAdmission=MEDIUM_BOARD_NORMAL@1"),
         label + " request does not carry the normal-medium admission identity")
    for phase, expected in (("cold", hypothesis_work), ("warm", 1)):
        run = report.get(phase)
        need(isinstance(run, dict), label + " report is missing " + phase)
        need(run.get("hypothesisWork") == expected,
             label + " " + phase + " hypothesis work differs from the exact contract")


def validate_host_row(scratch, entry, seed, packages, hypothesis_work,
                      expected_phases, expected_work, parent_relations,
                      metadata_module):
    """Preserve the current timing reader's host/input/cleanup checks."""
    label, mode = entry["label"], entry["mode"]
    output_dir = scratch / label
    need(output_dir.is_dir(), "missing host output directory: " + label)
    result = load_json(output_dir / "result.json")
    before = load_json(output_dir / "input-manifest-before.json")
    after = load_json(output_dir / "input-manifest-after.json")
    runner_before = load_json(output_dir / "runner-before.json")
    runner_after = load_json(output_dir / "runner-after.json")
    spec = load_json(scratch / (label + "-spec.json"))
    host = load_json(scratch / (label + "-summary.json"))

    # These containers must not grow a second profile transport.  The exact
    # terminal report is checked separately because it has an allowlist.
    # The maintained host records its owned browser profile directory here.
    # It is process provenance, not application instrumentation metadata.
    need(isinstance(result.get("identity", {}).get("profile"), str),
         label + " host identity omitted its owned browser profile directory")
    reject_profile_keys(result, label + ".result",
                        {label + ".result.identity.profile"})
    reject_profile_keys(before, label + ".inputBefore")
    reject_profile_keys(after, label + ".inputAfter")
    reject_profile_keys(runner_before, label + ".runnerBefore")
    reject_profile_keys(runner_after, label + ".runnerAfter")
    reject_profile_keys(spec, label + ".spec")
    summary_path = label + ".summary"
    allowed_summary_profile_paths = {
        summary_path + ".profile",
        summary_path + ".cold.profileKeys",
        summary_path + ".warm.profileKeys",
    }
    reject_profile_keys(host, summary_path, allowed_summary_profile_paths)

    need(result.get("outcome") == "PASS" and result.get("caseCount") == 1 and
         result.get("errors") == [],
         label + " host result did not PASS exactly one case")
    audit = result.get("inputAudit", {})
    need(audit.get("status") == "PASS", label + " input audit did not PASS")
    for before_key, after_key in (
            ("beforeSha256", "afterSha256"),
            ("sourceSha256Before", "sourceSha256After"),
            ("webSha256Before", "webSha256After"),
            ("runnerBeforeSha256", "runnerAfterSha256"),
            ("fileCountBefore", "fileCountAfter")):
        need(audit.get(before_key) is not None and
             audit.get(before_key) == audit.get(after_key),
             label + " input audit changed " + before_key)

    need(manifest_content(before) == manifest_content(after),
         label + " before/after file manifests differ")
    need(before.get("sha256") == audit.get("beforeSha256") and
         after.get("sha256") == audit.get("afterSha256") and
         before.get("sourceSha256") == audit.get("sourceSha256Before") and
         after.get("sourceSha256") == audit.get("sourceSha256After") and
         before.get("webSha256") == audit.get("webSha256Before") and
         after.get("webSha256") == audit.get("webSha256After") and
         before.get("fileCount") == audit.get("fileCountBefore") and
         after.get("fileCount") == audit.get("fileCountAfter"),
         label + " manifest contents disagree with the host input audit")
    need(runner_before.get("sha256") == audit.get("runnerBeforeSha256") and
         runner_after.get("sha256") == audit.get("runnerAfterSha256") and
         runner_before == runner_after,
         label + " browser runner identity changed or disagrees with host audit")

    cleanup = result.get("cleanup", {})
    need(cleanup.get("status") == "PASS" and
         cleanup.get("serverStopped") is True and
         cleanup.get("ownedSurvivors") == [] and cleanup.get("errors") == [],
         label + " owned host cleanup did not PASS")
    cases = result.get("cases")
    need(isinstance(cases, list) and len(cases) == 1,
         label + " host case census is invalid")
    case = cases[0]
    receipt_case = case.get("case", {})
    need(receipt_case.get("name") == label and case.get("outcome") == "PASS" and
         case.get("terminalReached") is True and case.get("stateMatch") is True and
         case.get("observedState") == "PASS:complete" and
         case.get("lastObservedState") == "PASS:complete" and
         case.get("timedOut") is False and case.get("navigationError") is None and
         case.get("reportObserved") is True and case.get("reportJsonValid") is True and
         case.get("reportMatch") is True,
         label + " case state, terminal, timeout, navigation, or report check failed")
    for key in ERROR_ARRAYS:
        need(case.get(key) == [], label + " has host errors in " + key)

    spec_cases = spec.get("cases")
    need(isinstance(spec_cases, list) and len(spec_cases) == 1,
         label + " browser spec must contain exactly one case")
    spec_case = spec_cases[0]
    need(spec_case.get("name") == label and
         spec_case.get("path") == receipt_case.get("path") and
         spec_case.get("expectedState") == "PASS:complete" and
         receipt_case.get("expectedState") == "PASS:complete",
         label + " host receipt does not match its exact browser spec")
    validate_profile_query(spec_case.get("path"), seed, mode, label)
    validate_profile_query(receipt_case.get("path"), seed, mode,
                           label + " receipt")
    if isinstance(host.get("url"), str) and "tsjQ30Seed" in host["url"]:
        validate_profile_query(host["url"], seed, mode, label + " host URL")

    need(host.get("label") == label and
         host.get("exitCode") == 0 and host.get("runnerOutcome") == "PASS",
         label + " host wrapper did not exit PASS")
    if "mode" in host:
        need(host["mode"] == mode,
             label + " host wrapper mode disagrees with the planned arm mode")
    if "profile" in host:
        need(type(host["profile"]) is bool and
             host["profile"] is (mode == "profile"),
             label + " host wrapper profile flag disagrees with the planned arm")
    host_monotonic = finite(host.get("hostMonotonicSeconds"),
                            label + " hostMonotonicSeconds", minimum=0)
    host_drift = finite(host.get("wallMinusMonotonicSeconds"),
                        label + " wallMinusMonotonicSeconds")
    if "cleanup" in host:
        need(host["cleanup"].get("status") == "PASS" and
             host["cleanup"].get("ownedSurvivors") == [] and
             host["cleanup"].get("errors") == [],
             label + " summary cleanup differs from passing host cleanup")

    report_path = safe_report_path(output_dir, case.get("reportFile"))
    raw_report = report_path.read_bytes()
    report_text = raw_report.decode("utf-8")
    report_digest = sha256(raw_report)
    need(case.get("reportSha256") == report_digest and
         case.get("reportLength") == len(report_text),
         label + " standalone report differs from embedded UTF-8 receipt")
    report = json.loads(report_text)
    need(isinstance(report, dict) and report.get("status") == "PASS" and
         report.get("seed") == seed and report.get("requestedSeed") == seed,
         label + " raw coordinator report status/seed is not the exact run")
    need(report_path.resolve() == Path(entry["reportPath"]).resolve(),
         label + " report path differs from the frozen report binding")
    need(report_digest.casefold() == entry["reportSha256"].casefold() and
         len(raw_report) == entry["reportByteLength"],
         label + " raw report differs from its frozen binding digest")
    validate_request_contract(report, seed, packages, hypothesis_work, label)
    check_terminal_profile_fields(
        report, mode, expected_phases, expected_work, parent_relations,
        metadata_module, label)
    embedded = case.get("report")
    if embedded is not None:
        if isinstance(embedded, str):
            need(embedded.encode("utf-8") == raw_report,
                 label + " inline report string differs from standalone report")
        else:
            need(embedded == report,
                 label + " inline report object differs from standalone report")

    summary_timings = {
        "totalElapsedMs": report.get("totalElapsedMs"),
        "phaseElapsedMs": report.get("phaseElapsedMs"),
        "cold": {key: report["cold"].get(key) for key in APP_PHASE_TIMINGS},
        "warm": {key: report["warm"].get(key) for key in APP_PHASE_TIMINGS},
    }
    for phase in ("cold", "warm"):
        need(isinstance(report.get(phase), dict),
             label + " report is missing " + phase)
        summary_phase = host.get(phase)
        if isinstance(summary_phase, dict) and "profileKeys" in summary_phase:
            expected_profile_keys = ["routeStageProfile"] if mode == "profile" else []
            need(summary_phase["profileKeys"] == expected_profile_keys,
                 label + " host profileKeys summary disagrees with the terminal report")
        for key in ("elapsedMs", "wallElapsedMs", "proofElapsedMs",
                    "routingElapsedMs"):
            finite(report[phase].get(key), label + " " + phase + " app " + key,
                   minimum=0)
        for summary_key, report_key in (
                ("elapsedMs", "elapsedMs"),
                ("proofElapsedMs", "proofElapsedMs"),
                ("routingElapsedMs", "routingElapsedMs"),
                ("totalWork", "totalWork"),
                ("hypothesisWork", "hypothesisWork")):
            if summary_key in host.get(phase, {}):
                need(host[phase][summary_key] == report[phase].get(report_key),
                     label + " host timing summary disagrees with raw " +
                     phase + "." + report_key)

    return {
        "role": entry["role"],
        "label": label,
        "mode": mode,
        "outputDir": label,
        "reportPath": report_path.relative_to(scratch).as_posix(),
        "reportSha256": report_digest,
        "reportLength": len(report_text),
        "reportByteLength": len(raw_report),
        "sourceSha256": before["sourceSha256"],
        "webSha256": before["webSha256"],
        "inputManifestSha256": before["sha256"],
        "runnerSha256": runner_before["sha256"],
        "hostMonotonicSeconds": host_monotonic,
        "wallMinusMonotonicSeconds": host_drift,
        "appTimings": summary_timings,
        "report": report,
        "rawReportBytes": raw_report,
    }


def remove_route_profile_fields(report, enabled):
    """Copy only the declared route-stage fields for parity comparison."""
    projected = copy.deepcopy(report)
    removed = []

    def pop(mapping, key, path):
        if isinstance(mapping, dict) and key in mapping:
            mapping.pop(key)
            removed.append(path + "/" + key)

    if enabled:
        pop(projected, "routeStageProfileQuery", "")
        pop(projected, "routeStageProfileRequested", "")
        for phase in ("cold", "warm"):
            run = projected.get(phase)
            pop(run, "routeStageProfile", "/" + phase)
    return projected, removed


def validate_sequence(context, scratch, repo, tag):
    binding = context["binding"]
    adapter = context["adapter"]
    metadata_module = context["metadata_module"]
    roles = [context["profileKey"]] + context["controlKeys"]
    rows = []
    for role in roles:
        entry = context["reports"][role]
        rows.append(validate_host_row(
            scratch, entry, SEED, PACKAGES, HYPOTHESIS_WORK,
            context["phaseNames"], context["workNames"],
            context["phaseParentRelations"], metadata_module))

    # Build negative metadata mutations from the actual terminal profile, only
    # after the host report was validated and before parity copies are made.
    profile_row = next(row for row in rows if row["mode"] == "profile")
    metadata_canaries = {}
    for phase in ("cold", "warm"):
        record = profile_row["report"][phase]["routeStageProfile"]
        metadata_canaries[phase] = metadata_module.run_negative_canaries(
            record, context["phaseNames"], context["workNames"],
            context["phaseParentRelations"])

    # The adapter writes new, tag-scoped wrappers/readers.  Refuse collisions
    # before invoking it, and pass the original parsed report unchanged.
    adapter_outputs = []
    for row in rows:
        for suffix in ("strict-wrapper-{}.json".format(tag),
                       "strict-reader-{}.txt".format(tag)):
            path = scratch / (row["label"] + "-" + suffix)
            need(not path.exists(), "strict-reader output already exists: " + str(path))
            adapter_outputs.append(path)
    strict_results = []
    adapter_path = Path(context["adapterIdentity"]["path"])
    expected_adapter_hash = context["adapterIdentity"]["sha256"]
    for row in rows:
        strict_result = adapter.strict_reader(
            scratch, repo, row, SEED, tag)
        need(strict_result.get("currentPlan4Pass") is True and
             strict_result.get("fullTimingReportPreserved") is True,
             row["label"] + " strict reader did not preserve a full timing report")
        counts = strict_result.get("selfTestCanaryCounts", {})
        need(isinstance(counts, dict) and
             counts.get("corruptionCanaries", 0) > 0,
             row["label"] + " strict reader reported no corruption canaries")
        need(strict_result.get("readerSha256") == context["strictReader"]["reader"]["sha256"] and
             strict_result.get("parserSha256") == context["strictReader"]["parser"]["sha256"],
             row["label"] + " strict reader identity differs from frozen binding")
        strict_results.append(strict_result)
        need(sha256(adapter_path.read_bytes()).casefold() ==
             expected_adapter_hash.casefold(),
             "timing adapter source changed during validation")

    strict_canaries = [item.get("selfTestCanaryCounts") for item in strict_results]
    need(all(item == strict_canaries[0] for item in strict_canaries[1:]),
         "strict reader self-test canary counts differ between arms")

    reports = [row["report"] for row in rows]
    need(all(report["request"] == reports[0]["request"] for report in reports[1:]),
         "selected arms use different exact qualification requests")

    projections = []
    removed_profile_paths = []
    removed_timing_paths = []
    for row in rows:
        profile_projection, profile_paths = remove_route_profile_fields(
            row["report"], row["mode"] == "profile")
        timing_projection, timing_paths = adapter.remove_declared_timings(
            profile_projection)
        projections.append(timing_projection)
        removed_profile_paths.append(profile_paths)
        removed_timing_paths.append(timing_paths)
    need(removed_profile_paths[0] == [
        "/routeStageProfileQuery", "/routeStageProfileRequested",
        "/cold/routeStageProfile", "/warm/routeStageProfile"],
         "profile arm exposed different declared route profile paths")
    for paths in removed_profile_paths[1:]:
        need(paths == [], "off arm exposed a route profile field to remove")
    need(all(paths == removed_timing_paths[0] for paths in removed_timing_paths[1:]),
         "selected reports expose different declared timing paths")
    need(all(projection == projections[0] for projection in projections[1:]),
         "selected reports differ outside declared route-profile/timing fields")

    for row in rows:
        report_path = scratch / row["reportPath"]
        need(sha256(report_path.read_bytes()) == row["reportSha256"] and
             len(report_path.read_bytes()) == row["reportByteLength"],
             row["label"] + " raw report changed during validation")

    run_summaries = []
    for row, strict_result in zip(rows, strict_results):
        run_summary = {key: value for key, value in row.items()
                       if key not in ("report", "rawReportBytes")}
        run_summary["strictReader"] = strict_result
        run_summaries.append(run_summary)

    profile_index = roles.index(context["profileKey"])
    comparisons = []
    profile_report = reports[profile_index]
    for index, role in enumerate(roles):
        if role == context["profileKey"]:
            continue
        control_report = reports[index]
        comparisons.append({
            "profileRole": context["profileKey"],
            "controlRole": role,
            "reportExactOutsideDeclaredFields": True,
            "coldElapsedMsProfileMinusControl": (
                profile_report["cold"]["elapsedMs"] - control_report["cold"]["elapsedMs"]),
            "coldRoutingElapsedMsProfileMinusControl": (
                profile_report["cold"]["routingElapsedMs"] -
                control_report["cold"]["routingElapsedMs"]),
            "coldProofElapsedMsProfileMinusControl": (
                profile_report["cold"]["proofElapsedMs"] -
                control_report["cold"]["proofElapsedMs"]),
            "warmElapsedMsProfileMinusControl": (
                profile_report["warm"]["elapsedMs"] - control_report["warm"]["elapsedMs"]),
            "warmRoutingElapsedMsProfileMinusControl": (
                profile_report["warm"]["routingElapsedMs"] -
                control_report["warm"]["routingElapsedMs"]),
            "warmProofElapsedMsProfileMinusControl": (
                profile_report["warm"]["proofElapsedMs"] -
                control_report["warm"]["proofElapsedMs"]),
            "hostMonotonicSecondsProfileMinusControl": (
                rows[profile_index]["hostMonotonicSeconds"] -
                rows[index]["hostMonotonicSeconds"]),
        })

    return {
        "schema": PAIR_SCHEMA,
        "status": "PASS",
        "purpose": PURPOSE,
        "privateExperiment": True,
        "productionAcceptance": False,
        "zeroInstrumentationOverheadClaim": False,
        "seed": SEED,
        "packages": PACKAGES,
        "hypothesisWork": HYPOTHESIS_WORK,
        "bindingSha256": context["bindingSha256"],
        "boundIdentities": context["identity"],
        "baseFixture": context["baseFixture"],
        "phaseNames": list(context["phaseNames"]),
        "workNames": list(context["workNames"]),
        "phaseParentRelations": context["phaseParentRelations"],
        "pairValidatorSha256": sha256(Path(__file__).resolve().read_bytes()),
        "metadataValidatorSha256": context["metadataValidatorSha256"],
        "acceptedSourceCommit": context["acceptedSourceCommit"],
        "runs": run_summaries,
        "requestExact": True,
        "reportExactOutsideDeclaredProfileAndTimingFields": True,
        "removedProfilePaths": removed_profile_paths,
        "removedTimingPaths": removed_timing_paths[0],
        "metadataNegativeCanaries": metadata_canaries,
        "strictReaderCanaryCounts": strict_canaries[0],
        "comparisons": comparisons,
        "crossArmBuildEqualityRequired": False,
        "limits": {
            "sourceAndRunnerManifestsMustBeStableWithinEachArm": True,
            "profileMetadataValidatedBeforeComparisonCopy": True,
            "strictReaderPerSelectedArmOnOriginalReport": True,
            "phaseNamesAndWorkNamesComeFromFrozenBinding": True,
            "phaseParentRelationsCheckedOnlyWhenBindingJustifiesThem": True,
            "rawReportBytesRetainedAndRehashed": True,
            "notProductionAcceptance": True,
            "notZeroInstrumentationOverheadClaim": True,
            "noProductionCodeOrRunnerMutation": True,
        },
        "todo": [
            "bind the final source, runner and gate hashes before the final run",
            "bind the collector's final phase/work enum lists and any source-justified parent edges",
            "capture and bind actual terminal off/profile reports before validation",
            "confirm terminal reports omit routeStageProfileCurrent while running snapshots may expose it",
        ],
    }


def load_context(args):
    binding_path = args.binding.resolve()
    need(binding_path.is_file(), "binding file does not exist")
    binding_raw, _, binding = load_json_bytes(binding_path, "binding")
    metadata_path = resolve_path(str(args.metadata_validator),
                                 binding_path.parent, "metadata validator")
    need(metadata_path.is_file(), "metadata validator file does not exist")
    metadata_module = load_module(metadata_path, "route_stage_profile_metadata")
    context = validate_binding(
        binding, binding_path, args.scratch.resolve(), args.repo.resolve(),
        args.profile_key, args.control_keys, metadata_module)
    context["bindingSha256"] = sha256(binding_raw)
    context["metadata_module"] = metadata_module
    context["metadataPath"] = str(metadata_path)
    context["metadataValidatorSha256"] = sha256(metadata_path.read_bytes())
    return context


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scratch", type=Path,
                        help="scratch root containing selected host rows")
    parser.add_argument("repo", type=Path,
                        help="repository root for the unchanged strict reader")
    parser.add_argument("--binding", type=Path, required=True,
                        help="frozen binding JSON; no implicit binding is allowed")
    parser.add_argument("--metadata-validator", type=Path, required=True,
                        help="route-stage-profile-metadata-validator.py")
    parser.add_argument("--profile-key", default="profile",
                        help="report role key for the profile-enabled arm")
    parser.add_argument("--control-key", dest="control_keys", action="append",
                        required=True,
                        help="report role key for an off control; repeat for the second control")
    parser.add_argument("--seed", default=SEED,
                        help="exact seed; this reader only accepts 10014")
    parser.add_argument("--tag", required=True,
                        help="fresh suffix for strict-reader wrapper/output files")
    parser.add_argument("--output", type=Path, required=True,
                        help="new JSON validation summary path")
    args = parser.parse_args()
    summary_path = args.output.resolve()
    try:
        safe_name(args.profile_key, "profile role key")
        need(args.control_keys, "at least one --control-key is required")
        for key in args.control_keys:
            safe_name(key, "control role key")
        safe_name(args.tag, "tag", SAFE_TAG)
        need(args.seed == SEED,
             "this route-stage profile reader requires exact seed 10014")
        scratch, repo = args.scratch.resolve(), args.repo.resolve()
        need(scratch.is_dir(), "scratch directory does not exist")
        need(repo.is_dir(), "repository directory does not exist")
        context = load_context(args)
        summary = validate_sequence(context, scratch, repo, args.tag)
        write_json_new(summary_path, summary)
        print(json.dumps(summary, ensure_ascii=False, separators=(",", ":")))
        return 0
    except Exception as error:
        failure = {
            "schema": PAIR_SCHEMA,
            "status": "FAIL",
            "purpose": PURPOSE,
            "privateExperiment": True,
            "productionAcceptance": False,
            "zeroInstrumentationOverheadClaim": False,
            "seed": args.seed,
            "error": str(error),
        }
        if not summary_path.exists():
            try:
                write_json_new(summary_path, failure)
            except Exception:
                pass
        print("FAIL: " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    sys.exit(main())
