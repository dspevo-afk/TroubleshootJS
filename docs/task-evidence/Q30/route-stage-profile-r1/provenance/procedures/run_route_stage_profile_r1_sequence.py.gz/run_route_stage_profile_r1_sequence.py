from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, time

s = Path(__file__).resolve().parent
repo = Path('<REPO_ROOT>')
sha = lambda b: hashlib.sha256(b).hexdigest()
# Root freezes this file and the binding after source review and focused gates.
binding_raw = (s / 'route-stage-profile-execution-binding.json').read_bytes()
binding = json.loads(binding_raw)
assert binding['status'] == 'FROZEN_READY_FOR_FOCUSED_MEASUREMENT'
assert sha(Path(__file__).read_bytes()) == binding['sequenceDriverSha256']
for entry in binding['files']:
    assert sha((s / entry['path']).read_bytes()) == entry['sha256'], entry['path']
audit_raw = (s / 'route-stage-profile-r1-preparation/source-audit.json').read_bytes()
audit = json.loads(audit_raw)
plan_raw = (s / 'route-stage-profile-measurement-plan.json').read_bytes()
plan = json.loads(plan_raw)
assert sha(plan_raw) == 'fbb94d97463303b99186673e546c5356f1f15f5a4dd70454314ed4d5393a36f6'
gate_raw = (s / 'route-stage-profile-r1-gates.json').read_bytes()
gate = json.loads(gate_raw)
assert gate['status'] == 'FOCUSED_GATES_PASS_NOT_ACCEPTANCE'
assert gate['sourceAuditSha256'] == sha(audit_raw) and gate['planSha256'] == sha(plan_raw)
assert len(gate['steps']) == 4 and all(r['exitCode'] == 0 for r in gate['steps'])
assert gate['controlEvidenceReuse']['status'] == 'PASS'
hostpath = repo / 'tests/browser/compiled_attribute_acceptance.py'
assert sha(hostpath.read_bytes()) == '1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4'
spec = importlib.util.spec_from_file_location('route_profile_host', hostpath)
hostmod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hostmod)
roots = {'control': Path(audit['controlSource']), 'profile': Path(audit['candidateSource'])}
out = s / 'route-stage-profile-sequence-result.json'
assert not out.exists()
result = {'status': 'RUNNING', 'planSha256': sha(plan_raw),
          'bindingSha256': sha(binding_raw), 'sourceAuditSha256': sha(audit_raw),
          'gateSha256': sha(gate_raw), 'rows': [], 'pairs': [],
          'notRun': [r['label'] for r in plan['sequence']]}

def save():
    out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')

def unchanged():
    for arm, root in roots.items():
        entries = audit['armInputs']['control' if arm == 'control' else 'candidate']
        for entry in entries:
            b = (root / entry['path']).read_bytes()
            assert len(b) == entry['bytes'] and sha(b) == entry['sha256'], (arm, entry['path'])
        current = hostmod.capture_input_manifest(root)
        assert {k: current[k] for k in binding['runtime'][arm]} == binding['runtime'][arm], arm
    for entry in binding['files']:
        assert sha((s / entry['path']).read_bytes()) == entry['sha256'], entry['path']

def hostcheck(row, summary):
    folder = s / row['label']
    host = json.loads((folder / 'result.json').read_bytes())
    assert host['outcome'] == 'PASS' and host['errors'] == [] and host['inputAudit']['status'] == 'PASS'
    cleanup = host['cleanup']
    assert cleanup['status'] == 'PASS' and cleanup['serverStopped'] and not cleanup['errors'] and not cleanup['ownedSurvivors']
    assert len(host['cases']) == 1
    case = host['cases'][0]
    assert case['outcome'] == 'PASS' and case['terminalReached'] and case['stateMatch'] and case['reportMatch'] and case['reportJsonValid']
    assert not case['timedOut'] and not case['navigationError']
    for key in ('pageErrors', 'httpErrors', 'consoleErrors', 'attributeReadErrors', 'listenerCleanupErrors'):
        assert case[key] == [], key
    raw = (folder / case['reportFile']).read_bytes()
    assert sha(raw) == case['reportSha256']
    report = json.loads(raw)
    assert report['seed'] == plan['seed'] and report['requestedSeed'] == plan['seed']
    expected = ['routeStageProfile'] if row['profile'] else []
    for phase in ('cold', 'warm'):
        assert summary[phase]['cleanupComplete'] and summary[phase]['profileKeys'] == expected
    identity = host['inputAudit']
    runtime = binding['runtime'][row['arm']]
    for actual, expected_key in [('beforeSha256', 'sha256'), ('sourceSha256Before', 'sourceSha256'),
                                 ('webSha256Before', 'webSha256'), ('fileCountBefore', 'fileCount')]:
        assert identity[actual] == runtime[expected_key], actual
    return {'reportSha256': sha(raw), 'cleanup': cleanup, 'inputAudit': identity}

save()
try:
    for index, row in enumerate(plan['sequence']):
        unchanged()
        label = row['label']
        for path in (s / label, s / (label + '-summary.json'), s / (label + '-spec.json')):
            assert not path.exists(), path
        print('START ' + label, flush=True)
        command = [sys.executable, '-B', str(s / 'run_route_stage_timing.py'), str(repo), str(s),
                   str(roots[row['arm']]), label, plan['seed']]
        if row['profile']:
            command.append('profile')
        proc = subprocess.run(command, capture_output=True, text=True)
        assert proc.returncode == 0, proc.stdout + proc.stderr
        summary = json.loads((s / (label + '-summary.json')).read_bytes())
        assert summary['exitCode'] == 0
        details = hostcheck(row, summary)
        unchanged()
        result['rows'].append({**row, 'summary': summary, **details})
        result['notRun'].remove(label)
        save()
        print(json.dumps({'label': label, 'cold': summary['cold'],
                          'hostSeconds': summary['hostMonotonicSeconds'],
                          'cleanupSeconds': details['cleanup']['seconds']}), flush=True)
        if index >= 1:
            # The exact validator invocation is frozen in the binding, not guessed here.
            validation = binding['validationCommands'][index - 1]
            began = time.monotonic()
            proc = subprocess.run([sys.executable, '-B'] + validation['args'], capture_output=True, text=True)
            log = s / validation['log']
            assert not log.exists()
            log.write_text(proc.stdout + proc.stderr, encoding='utf-8')
            assert proc.returncode == 0, proc.stdout + proc.stderr
            checked = json.loads(proc.stdout)
            assert checked['status'] == 'PASS'
            result['pairs'].append({'status': 'PASS', 'validationLog': validation['log'],
                                    'validationLogSha256': sha(log.read_bytes()),
                                    'elapsedSeconds': time.monotonic() - began})
            save()
    result['status'] = 'FOCUSED_PROFILE_PAIRS_PASS_PENDING_ROOT_INTERPRETATION'
    save()
except BaseException as error:
    result['status'] = 'STOPPED_FAILURE'
    result['failure'] = str(error)
    save()
    raise
