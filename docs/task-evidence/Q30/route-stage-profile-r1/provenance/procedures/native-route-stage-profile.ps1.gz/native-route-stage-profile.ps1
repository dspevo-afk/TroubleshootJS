param([Parameter(Mandatory=$true)][string]$SourceRoot,[Parameter(Mandatory=$true)][string]$Label)
$ErrorActionPreference='Stop'
$q30Suites=@('PcbRoutingStageProfileContractTest','P04RoutingContractTest','P05RoutingContractTest','P07TwoLayerContractTest','PcbLayerRoutingResumptionContractTest','MediumBoardPhysicalPolicyContractTest','Q30GenerationMeasurementBudgetContractTest','StagedFamilyRegistrationContractTest','Q30GenerationRequestContractTest')
$q30Watch=[Diagnostics.Stopwatch]::StartNew()
Push-Location -LiteralPath $SourceRoot
try {
  & ./scripts/verify-current-contracts.ps1 -JavaHome '<PRIVATE_PATH>sktop/TroubleshootJS/.tools/jdk8-download/jdk8u502-b07' -Suite $q30Suites -ReceiptOutputPath (Join-Path $PSScriptRoot ($Label+'-receipt.txt')) *> (Join-Path $PSScriptRoot ($Label+'.log'))
  $q30Exit=$LASTEXITCODE
} finally { Pop-Location }
$q30Watch.Stop()
[ordered]@{status=$(if($q30Exit -eq 0){'PASS'}else{'FAIL'});exitCode=$q30Exit;elapsedSeconds=$q30Watch.Elapsed.TotalSeconds;phase='focused private routing-profile clock/freeze/parity and routing/physical/resumption/budget/generic-family contracts including maintained cleanup';suites=$q30Suites} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.json'))
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.json'))
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.log')) -Tail 14
exit $q30Exit
