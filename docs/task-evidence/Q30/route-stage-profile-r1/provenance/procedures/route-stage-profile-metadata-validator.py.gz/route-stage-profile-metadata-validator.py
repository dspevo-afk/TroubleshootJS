#!/usr/bin/env python3
"""Strict value validator for the private Q30 route-stage profile.

The Java collector owns the wire format.  This module deliberately does not
hard-code the collector's enum order: the final phase and work-counter lists
must be supplied by the frozen measurement binding.  That keeps a draft reader
from turning a changed collector into apparently comparable evidence.

The accepted record is the terminal, frozen ``routeStageProfile`` object.  A
passing record has schema 1, ``clockSource == "performance.now"``, true
``valid`` and ``frozen`` flags, no error/open-scope counters, finite
non-negative elapsed values, integer non-negative counters, and exactly two
clock reads per recorded phase call.  Optional parent/child inequalities are
checked one edge at a time only when the binding explicitly supplies a
source-justified edge; child timings are never summed, avoiding inclusive-time
double counting.

The negative canary helper mutates a deep copy of an actual terminal record.
It is intended for the pair reader after a real report has been captured; it
does not manufacture a passing report or a measurement result.
"""

import copy
import math
import re


SCHEMA = 1
CLOCK_SOURCE = "performance.now"

TOP_LEVEL_KEYS = (
    "schema", "clockSource", "valid", "frozen", "clockReads",
    "clockErrors", "scopeErrors", "openScopes", "lateScopeErrors",
    "phases", "work",
)
PHASE_KEYS = ("calls", "failures", "elapsedMs")


class ValidationError(Exception):
    """Raised when a profile record or binding-declared relation is invalid."""


def need(condition, message):
    if not condition:
        raise ValidationError(message)


def _exact_int(value, label, minimum=0):
    need(type(value) is int, label + " must be an integer (booleans are not integers)")
    need(value >= minimum, label + " is below its minimum")
    return value


def _finite_nonnegative(value, label):
    need(type(value) in (int, float),
         label + " must be a finite number (booleans are not numbers)")
    need(math.isfinite(value), label + " must be finite")
    need(value >= 0, label + " is below zero")
    return float(value)


def _name_list(value, label):
    need(isinstance(value, (list, tuple)) and value,
         label + " must be a non-empty ordered name list")
    names = []
    for index, item in enumerate(value):
        need(isinstance(item, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", item),
             "{}[{}] is not a valid enum name".format(label, index))
        need(item not in names, label + " contains a duplicate name: " + item)
        names.append(item)
    return tuple(names)


def normalize_enum_lists(expected_phases, expected_work):
    """Validate and freeze binding-provided collector enum lists."""
    return (_name_list(expected_phases, "expected phases"),
            _name_list(expected_work, "expected work counters"))


def _exact_keys(value, expected, label, preserve_order=False):
    need(isinstance(value, dict), label + " must be an object")
    expected_set = set(expected)
    actual_set = set(value)
    missing = [key for key in expected if key not in value]
    extra = [key for key in value if key not in expected_set]
    need(not missing, label + " is missing keys: " + ", ".join(missing))
    need(not extra, label + " has unexpected keys: " + ", ".join(map(str, extra)))
    if preserve_order:
        need(list(value.keys()) == list(expected),
             label + " key order differs from the frozen collector enum")


def validate_phase_parent_relations(profile, relations, expected_phases):
    """Check explicitly bound inclusive parent >= child timing edges.

    ``relations`` is a list of objects with ``parent``, ``child`` and a
    non-empty ``justification`` string.  The check is intentionally per edge;
    it never adds multiple child timings, because overlapping children would
    otherwise double-count inclusive time.
    """
    need(isinstance(relations, (list, tuple)),
         "phase parent relations must be an array")
    phase_set = set(expected_phases)
    seen = set()
    checks = []
    for index, relation in enumerate(relations):
        _exact_keys(relation, ("parent", "child", "justification"),
                    "phase parent relation {}".format(index))
        parent = relation["parent"]
        child = relation["child"]
        need(isinstance(parent, str) and parent in phase_set,
             "phase parent relation {} names an unknown parent".format(index))
        need(isinstance(child, str) and child in phase_set,
             "phase parent relation {} names an unknown child".format(index))
        need(parent != child,
             "phase parent relation {} cannot be self-referential".format(index))
        justification = relation["justification"]
        need(isinstance(justification, str) and justification.strip(),
             "phase parent relation {} lacks source justification".format(index))
        edge = (parent, child)
        need(edge not in seen,
             "phase parent relation is duplicated: {} -> {}".format(parent, child))
        seen.add(edge)
        parent_ms = profile["phases"][parent]["elapsedMs"]
        child_ms = profile["phases"][child]["elapsedMs"]
        need(parent_ms >= child_ms,
             "phase parent elapsed time is below child: {} < {}".format(parent, child))
        checks.append({
            "parent": parent,
            "child": child,
            "parentElapsedMs": parent_ms,
            "childElapsedMs": child_ms,
            "justification": justification,
        })
    return checks


def validate_profile_record(profile, expected_phases, expected_work,
                            phase_parent_relations=()):
    """Validate one terminal route-stage profile and return a compact census.

    The input is not modified.  Expected enum lists and optional parent edges
    are caller/binding inputs and are validated before the record is read.
    """
    phases, work_names = normalize_enum_lists(expected_phases, expected_work)
    _exact_keys(profile, TOP_LEVEL_KEYS, "route stage profile")
    _exact_int(profile["schema"], "profile schema", SCHEMA)
    need(profile["schema"] == SCHEMA,
         "route stage profile schema must be {}".format(SCHEMA))
    need(profile["clockSource"] == CLOCK_SOURCE,
         "route stage profile clockSource must be performance.now")
    need(type(profile["valid"]) is bool,
         "route stage profile valid must be a boolean")
    need(type(profile["frozen"]) is bool,
         "route stage profile frozen must be a boolean")
    need(profile["valid"] is True, "route stage profile is not valid")
    need(profile["frozen"] is True, "route stage profile is not frozen")

    counter_names = ("clockReads", "clockErrors", "scopeErrors",
                     "openScopes", "lateScopeErrors")
    counters = {}
    for name in counter_names:
        counters[name] = _exact_int(profile[name], "profile " + name)
        if name != "clockReads":
            need(counters[name] == 0,
                 "route stage profile {} must be zero".format(name))

    _exact_keys(profile["phases"], phases, "route stage profile phases",
                preserve_order=True)
    phase_summary = {}
    total_calls = 0
    total_elapsed = 0.0
    for phase in phases:
        row = profile["phases"][phase]
        _exact_keys(row, PHASE_KEYS, "route stage profile phase " + phase,
                    preserve_order=True)
        calls = _exact_int(row["calls"], phase + " calls")
        failures = _exact_int(row["failures"], phase + " failures")
        elapsed = _finite_nonnegative(row["elapsedMs"], phase + " elapsedMs")
        need(failures <= calls,
             phase + " failures exceed calls")
        if calls == 0:
            need(elapsed == 0,
                 phase + " has zero calls but non-zero elapsedMs")
        total_calls += calls
        total_elapsed += elapsed
        phase_summary[phase] = {
            "calls": calls,
            "failures": failures,
            "elapsedMs": row["elapsedMs"],
        }

    _exact_keys(profile["work"], work_names, "route stage profile work",
                preserve_order=True)
    work_summary = {}
    for name in work_names:
        work_summary[name] = _exact_int(profile["work"][name], "work " + name)

    need(profile["clockReads"] == 2 * total_calls,
         "clockReads must equal two reads per phase call")
    parent_checks = validate_phase_parent_relations(
        profile, phase_parent_relations, phases)
    return {
        "schema": profile["schema"],
        "clockSource": profile["clockSource"],
        "valid": profile["valid"],
        "frozen": profile["frozen"],
        "clockReads": profile["clockReads"],
        "phaseCount": len(phases),
        "workCounterCount": len(work_names),
        "totalCalls": total_calls,
        "summedInclusivePhaseElapsedMs": total_elapsed,
        "phases": phase_summary,
        "work": work_summary,
        "parentChecks": parent_checks,
    }


def _first_phase(profile, expected_phases):
    for phase in expected_phases:
        return phase
    raise ValidationError("cannot construct canaries without a phase")


def _first_work(profile, expected_work):
    for counter in expected_work:
        return counter
    raise ValidationError("cannot construct canaries without a work counter")


def negative_canary_mutations(profile, expected_phases, expected_work,
                              phase_parent_relations=()):
    """Return named mutations for a real profile record.

    Each mutator receives a fresh deep copy.  The list intentionally covers
    schema shape, types, finite values, negatives, counter relationships,
    lifecycle/error flags, and clock accounting.
    """
    phases, work_names = normalize_enum_lists(expected_phases, expected_work)
    phase = _first_phase(profile, phases)
    work = _first_work(profile, work_names)

    def missing_schema(candidate):
        del candidate["schema"]

    def extra_top_level(candidate):
        candidate["unexpected"] = 1

    def wrong_schema_type(candidate):
        candidate["schema"] = "1"

    def wrong_valid_type(candidate):
        candidate["valid"] = 1

    def boolean_counter_type(candidate):
        candidate["clockReads"] = False

    def missing_phase_key(candidate):
        del candidate["phases"][phase]

    def extra_phase_key(candidate):
        candidate["phases"]["UNBOUND_EXTRA_PHASE"] = {
            "calls": 0, "failures": 0, "elapsedMs": 0,
        }

    def missing_phase_field(candidate):
        del candidate["phases"][phase]["calls"]

    def extra_phase_field(candidate):
        candidate["phases"][phase]["unexpected"] = 0

    def wrong_phase_type(candidate):
        candidate["phases"][phase]["calls"] = "0"

    def missing_work_key(candidate):
        del candidate["work"][work]

    def extra_work_key(candidate):
        candidate["work"]["UNBOUND_EXTRA_WORK"] = 0

    def wrong_work_type(candidate):
        candidate["work"][work] = False

    def nan_elapsed(candidate):
        candidate["phases"][phase]["elapsedMs"] = float("nan")

    def infinity_elapsed(candidate):
        candidate["phases"][phase]["elapsedMs"] = float("inf")

    def negative_clock_reads(candidate):
        candidate["clockReads"] = -1

    def negative_phase_calls(candidate):
        candidate["phases"][phase]["calls"] = -1

    def negative_elapsed(candidate):
        candidate["phases"][phase]["elapsedMs"] = -1

    def failures_exceed_calls(candidate):
        calls = candidate["phases"][phase]["calls"]
        candidate["phases"][phase]["failures"] = calls + 1

    def negative_work(candidate):
        candidate["work"][work] = -1

    def clock_error(candidate):
        candidate["clockErrors"] = 1

    def scope_error(candidate):
        candidate["scopeErrors"] = 1

    def open_scope(candidate):
        candidate["openScopes"] = 1

    def late_scope_error(candidate):
        candidate["lateScopeErrors"] = 1

    def invalid_flag(candidate):
        candidate["valid"] = False

    def unfrozen(candidate):
        candidate["frozen"] = False

    def wrong_clock(candidate):
        candidate["clockSource"] = "Date.now"

    def wrong_clock_reads(candidate):
        candidate["clockReads"] += 1

    def zero_calls_nonzero_elapsed(candidate):
        candidate["phases"][phase]["calls"] = 0
        candidate["phases"][phase]["failures"] = 0
        candidate["phases"][phase]["elapsedMs"] = 1
        candidate["clockReads"] = 2 * sum(
            candidate["phases"][name]["calls"] for name in phases)

    return [
        ("missing top-level key", missing_schema),
        ("extra top-level key", extra_top_level),
        ("wrong schema type", wrong_schema_type),
        ("wrong boolean type", wrong_valid_type),
        ("boolean counter type", boolean_counter_type),
        ("missing phase key", missing_phase_key),
        ("extra phase key", extra_phase_key),
        ("missing phase field", missing_phase_field),
        ("extra phase field", extra_phase_field),
        ("wrong phase type", wrong_phase_type),
        ("missing work key", missing_work_key),
        ("extra work key", extra_work_key),
        ("wrong work type", wrong_work_type),
        ("NaN elapsed", nan_elapsed),
        ("infinite elapsed", infinity_elapsed),
        ("negative counter", negative_clock_reads),
        ("negative phase calls", negative_phase_calls),
        ("negative phase elapsed", negative_elapsed),
        ("failures exceed calls", failures_exceed_calls),
        ("negative work counter", negative_work),
        ("clock error counter", clock_error),
        ("scope error counter", scope_error),
        ("open scope counter", open_scope),
        ("late scope error counter", late_scope_error),
        ("invalid valid flag", invalid_flag),
        ("unfrozen record", unfrozen),
        ("wrong clock source", wrong_clock),
        ("wrong clock accounting", wrong_clock_reads),
        ("zero-call nonzero elapsed", zero_calls_nonzero_elapsed),
    ]


def run_negative_canaries(profile, expected_phases, expected_work,
                          phase_parent_relations=()):
    """Reject every mutation of an actual validated profile record."""
    validate_profile_record(profile, expected_phases, expected_work,
                            phase_parent_relations)
    results = []
    for name, mutate in negative_canary_mutations(
            profile, expected_phases, expected_work, phase_parent_relations):
        candidate = copy.deepcopy(profile)
        try:
            mutate(candidate)
            validate_profile_record(candidate, expected_phases, expected_work,
                                    phase_parent_relations)
        except ValidationError as error:
            results.append({
                "case": name,
                "status": "REJECTED_AS_EXPECTED",
                "error": str(error),
            })
        else:
            raise ValidationError("profile negative canary was accepted: " + name)
    need(len(results) == len(negative_canary_mutations(
        profile, expected_phases, expected_work, phase_parent_relations)),
         "not every profile negative canary produced a rejection")
    return results


def validate(profile, expected_phases, expected_work, phase_parent_relations=()):
    """Compatibility alias used by the pair reader."""
    return validate_profile_record(profile, expected_phases, expected_work,
                                   phase_parent_relations)
