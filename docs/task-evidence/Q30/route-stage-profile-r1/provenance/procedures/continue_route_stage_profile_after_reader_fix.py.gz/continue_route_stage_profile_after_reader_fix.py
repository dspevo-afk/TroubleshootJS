from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, time

s = Path(__file__).resolve().parent
repo = Path('<REPO_ROOT>')
sha = lambda b: hashlib.sha256(b).hexdigest()
original_raw = (s / 'route-stage-profile-sequence-result.json').read_bytes()
original = json.loads(original_raw)
assert original['status'] == 'STOPPED_FAILURE' and original['failure'] == 'FAIL: metadata validator path is missing\n'
assert len(original['rows']) == 2 and original['pairs'] == []
assert original['notRun'] == ['route-stage-profile-03-control-10014']
execution_raw = (s / 'route-stage-profile-execution-binding.json').read_bytes()
execution = json.loads(execution_raw)
assert sha(execution_raw) == '5ed0eb3c3f95282d404e5d5b084f04850e8bba1b9dc354cb0a601d790d5a3c3d'
reader = s / 'validate_route_stage_profile_pair.py'
assert sha(reader.read_bytes()) == '7be7939a429a313d40638b03799653318e8c7cf40afc58476342981cb4f2b3af'
assert sha((s / 'validate_route_stage_profile_pair.before-cli-path-fix.py').read_bytes()) == '1975c827fe4d94646d67c8df67b5694b91b2a03f598fee76c8759d07bbccba25'
before_reader = (s / 'validate_route_stage_profile_pair.before-cli-path-fix.py').read_text()
assert reader.read_text() == before_reader.replace('resolve_path(args.metadata_validator,', 'resolve_path(str(args.metadata_validator),')
recheck_path = s / 'route-stage-profile-pair-1-reader-r2-validation.json'
recheck = json.loads(recheck_path.read_bytes())
assert recheck['status'] == 'PASS' and recheck['reportExactOutsideDeclaredProfileAndTimingFields'] is True
assert recheck['pairValidatorSha256'] == sha(reader.read_bytes())
audit = json.loads((s / 'route-stage-profile-r1-preparation/source-audit.json').read_bytes())
hostpath = repo / 'tests/browser/compiled_attribute_acceptance.py'
assert sha(hostpath.read_bytes()) == '1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4'
spec = importlib.util.spec_from_file_location('route_resume_host', hostpath)
hostmod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hostmod)

def unchanged():
    for entry in execution['files']:
        if entry['path'] == 'validate_route_stage_profile_pair.py':
            assert sha((s / entry['path']).read_bytes()) == '7be7939a429a313d40638b03799653318e8c7cf40afc58476342981cb4f2b3af'
            continue
        assert sha((s / entry['path']).read_bytes()) == entry['sha256'], entry['path']
    for arm, key in [('control', 'control'), ('profile', 'candidate')]:
        root = Path(audit[key + 'Source'])
        for entry in audit['armInputs'][key]:
            raw = (root / entry['path']).read_bytes()
            assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], entry['path']
        current = hostmod.capture_input_manifest(root)
        assert {k: current[k] for k in execution['runtime'][arm]} == execution['runtime'][arm]

plan = json.loads((s / 'route-stage-profile-measurement-plan.json').read_bytes())
row = plan['sequence'][2]
label = row['label']
assert row == {'label': 'route-stage-profile-03-control-10014', 'arm': 'control', 'profile': False}
out = s / 'route-stage-profile-continuation-result.json'
assert not out.exists()
result = {'status': 'RUNNING', 'originalSequenceSha256': sha(original_raw),
          'executionBindingSha256': sha(execution_raw), 'firstPairRevalidationSha256': sha(recheck_path.read_bytes()),
          'readerSha256': sha(reader.read_bytes()), 'driverSha256': sha(Path(__file__).read_bytes()),
          'repair': 'Only convert the argparse Path to string at the strict string resolver boundary. Original failure and first two cold captures retained; actual full parity/metadata/negative/strict checks now PASS before continuing the predeclared third row. No application/build/plan/threshold change.',
          'notRun': [label]}
def save():
    out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
save()
try:
    unchanged()
    for path in (s / label, s / (label + '-spec.json'), s / (label + '-summary.json')):
        assert not path.exists(), path
    print('START ' + label, flush=True)
    proc = subprocess.run([sys.executable, '-B', str(s / 'run_route_stage_timing.py'), str(repo), str(s),
                           audit['controlSource'], label, '10014'], capture_output=True, text=True)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    unchanged()
    summary = json.loads((s / (label + '-summary.json')).read_bytes())
    assert summary['exitCode'] == 0
    result['row'] = {**row, 'summary': summary}
    result['notRun'] = []
    save()
    print(json.dumps({'label': label, 'cold': summary['cold'], 'hostSeconds': summary['hostMonotonicSeconds'],
                      'cleanupSeconds': summary['cleanup']['seconds']}), flush=True)
    template_raw = (s / 'route-stage-profile-validation-template.json').read_bytes()
    bound = json.loads(template_raw)
    assert bound['status'] == 'FROZEN_INPUT_TEMPLATE' and bound['reports'] == {}
    for role, index in [('profile', 1), ('controlAfter', 2)]:
        item = plan['sequence'][index]
        folder = s / item['label']
        host = json.loads((folder / 'result.json').read_bytes())
        assert host['outcome'] == 'PASS' and len(host['cases']) == 1
        case = host['cases'][0]
        path = (folder / case['reportFile']).resolve()
        assert folder.resolve() in path.parents
        raw = path.read_bytes()
        assert sha(raw) == case['reportSha256']
        bound['reports'][role] = {'label': item['label'], 'mode': 'profile' if item['profile'] else 'off',
                                  'reportPath': path.relative_to(s).as_posix(), 'sha256': sha(raw), 'byteLength': len(raw)}
    bound['status'] = 'FROZEN'
    bound['templateSha256'] = sha(template_raw)
    bound['executionBindingSha256'] = sha(execution_raw)
    bound['readerRepair'] = result['repair']
    binding_path = s / 'route-stage-profile-pair-2-reader-r2-binding.json'
    assert not binding_path.exists()
    binding_path.write_text(json.dumps(bound, indent=2) + '\n', encoding='utf-8')
    checked_path = s / 'route-stage-profile-pair-2-reader-r2-validation.json'
    log_path = s / 'route-stage-profile-pair-2-reader-r2-validation.log'
    assert not checked_path.exists() and not log_path.exists()
    began = time.monotonic()
    with log_path.open('w', encoding='utf-8') as log:
        proc = subprocess.run([sys.executable, '-B', str(reader), str(s), str(repo), '--binding', str(binding_path),
                               '--metadata-validator', str(s / 'route-stage-profile-metadata-validator.py'),
                               '--control-key', 'controlAfter', '--seed', '10014', '--tag', 'route-stage-profile-pair-2-reader-r2',
                               '--output', str(checked_path)], stdout=log, stderr=subprocess.STDOUT)
    assert proc.returncode == 0, log_path.read_text()[-2000:]
    checked = json.loads(checked_path.read_bytes())
    assert checked['status'] == 'PASS' and checked['reportExactOutsideDeclaredProfileAndTimingFields'] is True
    unchanged()
    result['secondPairValidation'] = {'status': 'PASS', 'sha256': sha(checked_path.read_bytes()),
                                       'elapsedSeconds': time.monotonic() - began}
    result['status'] = 'FOCUSED_PROFILE_BOTH_CONTROL_COMPARISONS_PASS_PENDING_ROOT_INTERPRETATION'
    save()
    print(result['status'], flush=True)
except BaseException as error:
    result['status'] = 'STOPPED_FAILURE'
    result['failure'] = str(error)
    save()
    raise
