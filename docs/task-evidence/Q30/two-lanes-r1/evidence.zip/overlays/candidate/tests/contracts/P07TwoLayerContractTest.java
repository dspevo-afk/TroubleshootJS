package com.lushprojects.circuitjs1.client;

public final class P07TwoLayerContractTest {
    private static int checks;
    static void require(boolean ok,String why) { checks++; if(!ok) throw new AssertionError(why); }
    public static void main(String[] args) {
        typedQueueMatchesPriorityQueue();
        primitiveNodeMapMatchesHashMap();
        for(boolean linked:new boolean[]{false,true}) {
            P06FactoryLinkFixtures.Fixture fixture=new P06FactoryLinkFixtures.Fixture(true,0,0,!linked);
            String original=fixture.layout.geometryFingerprint();
            for(PcbLayerRoutingPrototype.Policy policy:PcbLayerRoutingPrototype.Policy.values()) {
                PcbLayerRoutingPrototype.Result result=PcbLayerRoutingPrototype.route(fixture.board,fixture.layout,
                    policy,P06FactoryLinkFixtures.OBSERVER);
                require(original.equals(fixture.layout.geometryFingerprint()),"input placement was mutated");
                require(result.expansions<=PcbLayerRoutingPrototype.MAX_EXPANSIONS,"bounded work");
                System.out.println("P07_SMALL linked="+linked+" policy="+policy+" outcome="+result.outcome+
                    " expansions="+result.expansions+" vias="+result.vias+
                    " length="+(result.accepted()?PcbRouteMetrics.measure(result.layout.getTraces()).uniqueLength:0));
                if(result.accepted()) {
                    result.layout.validateRoutingGeometry(fixture.board);
                    new PcbTwoLayerRules(fixture.board,result.layout).validate(result.layout);
                    require(result.vias<=policy.vias,"via cap");
                }
            }
        }
        negatives(); barriers(); surfacePadEnvelope();
        System.out.println("PASS: P07 two-layer contracts assertions="+checks);
    }
    @SuppressWarnings({"rawtypes","unchecked"})
    private static void typedQueueMatchesPriorityQueue() {
        try {
            Class<?> nodeType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$Node");
            java.lang.reflect.Constructor<?> nodeConstructor=nodeType.getDeclaredConstructor(
                int.class,int.class,int.class,int.class,int.class,int.class,int.class,int.class,nodeType);
            nodeConstructor.setAccessible(true);
            Class<?> queueType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$NodeQueue");
            java.lang.reflect.Constructor<?> queueConstructor=queueType.getDeclaredConstructor();
            queueConstructor.setAccessible(true);
            Object queue=queueConstructor.newInstance();
            java.lang.reflect.Method add=queueType.getDeclaredMethod("add",nodeType);
            java.lang.reflect.Method poll=queueType.getDeclaredMethod("poll");
            add.setAccessible(true); poll.setAccessible(true);
            java.util.PriorityQueue oracle=new java.util.PriorityQueue();
            require(poll.invoke(queue)==oracle.poll(),"empty typed queue matches PriorityQueue");
            for(int i=0;i<1024;i++) {
                int total=i%17,heuristic=(i/3)%(total+1),cost=total-heuristic;
                Object node=nodeConstructor.newInstance((i*11)%31,(i/13)%2,(i/7)%5,(i/37)%5,
                    cost,heuristic,i,31,null);
                add.invoke(queue,node); oracle.add(node);
                if(i%5==2 || i%7==3) require(poll.invoke(queue)==oracle.poll(),
                    "typed queue poll identity matches PriorityQueue during mixed operations");
            }
            Object tiedFirst=nodeConstructor.newInstance(4,1,2,3,20,6,2048,31,null);
            Object tiedSecond=nodeConstructor.newInstance(4,1,2,3,20,6,2049,31,null);
            require(((Comparable)tiedFirst).compareTo(tiedSecond)<0,"serial orders equal A* priority fields");
            add.invoke(queue,tiedFirst); oracle.add(tiedFirst);
            add.invoke(queue,tiedSecond); oracle.add(tiedSecond);
            while(!oracle.isEmpty()) require(poll.invoke(queue)==oracle.poll(),
                "typed queue preserves full PriorityQueue dequeue identity order");
            require(poll.invoke(queue)==null,"typed queue returns null after drain");
        } catch(Exception failure) {
            throw new AssertionError("typed route queue must match PriorityQueue identity order",failure);
        }
    }
    @SuppressWarnings({"rawtypes","unchecked"})
    private static void primitiveNodeMapMatchesHashMap() {
        try {
            Class<?> nodeType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$Node");
            java.lang.reflect.Constructor<?> nodeConstructor=nodeType.getDeclaredConstructor(
                int.class,int.class,int.class,int.class,int.class,int.class,int.class,int.class,nodeType);
            nodeConstructor.setAccessible(true);
            Class<?> mapType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$IntNodeMap");
            java.lang.reflect.Constructor<?> mapConstructor=mapType.getDeclaredConstructor();
            mapConstructor.setAccessible(true);
            java.lang.reflect.Method get=mapType.getDeclaredMethod("get",int.class);
            java.lang.reflect.Method put=mapType.getDeclaredMethod("put",int.class,nodeType);
            get.setAccessible(true); put.setAccessible(true);
            Object map=mapConstructor.newInstance();
            java.util.HashMap<Integer,Object> oracle=new java.util.HashMap<Integer,Object>();
            int maximumKey=50*PcbLayerRoutingPrototype.MAX_CELLS-1;
            require(get.invoke(map,1)==null && get.invoke(map,maximumKey)==null,"empty map misses absent and boundary keys");
            Object zero=routeNode(nodeConstructor,0,10,1);
            Object boundary=routeNode(nodeConstructor,maximumKey,20,2);
            put.invoke(map,0,zero); oracle.put(0,zero);
            put.invoke(map,maximumKey,boundary); oracle.put(maximumKey,boundary);
            require(get.invoke(map,0)==zero && get.invoke(map,maximumKey)==boundary,"zero and maximum encoded keys retain identity");
            require(get.invoke(map,1)==null,"probe chain stops at a truly absent key");
            Object zeroReplacement=routeNode(nodeConstructor,0,11,3);
            put.invoke(map,0,zeroReplacement); oracle.put(0,zeroReplacement);
            require(get.invoke(map,0)==zeroReplacement && oracle.get(0)==zeroReplacement,"replacement preserves the new Node identity");

            int[] firstAtHome=new int[16]; java.util.Arrays.fill(firstAtHome,-1);
            int collisionA=-1,collisionB=-1;
            for(int key=0;key<100 && collisionB<0;key++) {
                int home=mapHash(key)&15;
                if(firstAtHome[home]>=0) { collisionA=firstAtHome[home]; collisionB=key; }
                else firstAtHome[home]=key;
            }
            require(collisionB>=0,"collision fixture found two distinct keys with one initial bucket");
            Object collisionMap=mapConstructor.newInstance();
            java.util.HashMap<Integer,Object> collisionOracle=new java.util.HashMap<Integer,Object>();
            Object first=routeNode(nodeConstructor,collisionA,30,4),second=routeNode(nodeConstructor,collisionB,31,5);
            put.invoke(collisionMap,collisionA,first); collisionOracle.put(collisionA,first);
            put.invoke(collisionMap,collisionB,second); collisionOracle.put(collisionB,second);
            require(get.invoke(collisionMap,collisionA)==collisionOracle.get(collisionA) &&
                get.invoke(collisionMap,collisionB)==collisionOracle.get(collisionB),"linear probing preserves colliding keys");

            int count=30000; int[] keys=new int[count]; Object[] expected=new Object[count];
            for(int i=0;i<count;i++) {
                int key=100000+i*251; keys[i]=key;
                Object value=routeNode(nodeConstructor,key,i%97,i+10);
                put.invoke(map,key,value); oracle.put(key,value); expected[i]=value;
                if(i%7==0) {
                    Object replacement=routeNode(nodeConstructor,key,(i%97)-1,i+count);
                    put.invoke(map,key,replacement); oracle.put(key,replacement); expected[i]=replacement;
                }
            }
            boolean matches=true;
            for(int i=0;i<count;i++)
                if(get.invoke(map,keys[i])!=expected[i] || expected[i]!=oracle.get(keys[i])) matches=false;
            require(matches && get.invoke(map,0)==oracle.get(0) &&
                get.invoke(map,maximumKey)==oracle.get(maximumKey),"large corpus survives repeated resizes and replacements");

            Class<?> queueType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$NodeQueue");
            java.lang.reflect.Constructor<?> queueConstructor=queueType.getDeclaredConstructor(); queueConstructor.setAccessible(true);
            java.lang.reflect.Method poll=queueType.getDeclaredMethod("poll"); poll.setAccessible(true);
            Class<?> searchType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$Search");
            java.lang.reflect.Method offer=searchType.getDeclaredMethod("offer",queueType,mapType,nodeType); offer.setAccessible(true);
            Class<?> budgetType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$Budget");
            java.lang.reflect.Constructor<?> budgetConstructor=budgetType.getDeclaredConstructor(int.class);
            budgetConstructor.setAccessible(true);
            java.lang.reflect.Constructor<?> searchConstructor=searchType.getDeclaredConstructor(
                TroubleshootBoard.class,PcbBoardLayout.class,PcbLayerRoutingPrototype.Policy.class,
                SeededPcbLayoutGenerator.AttemptObserver.class,budgetType,int.class);
            searchConstructor.setAccessible(true);
            P06FactoryLinkFixtures.Fixture fixture=new P06FactoryLinkFixtures.Fixture(true,0,0,true);
            Object search=searchConstructor.newInstance(fixture.board,fixture.layout,
                PcbLayerRoutingPrototype.Policy.ONE_LAYER,P06FactoryLinkFixtures.OBSERVER,
                budgetConstructor.newInstance(100),0);
            Object offerMap=mapConstructor.newInstance(),queue=queueConstructor.newInstance();
            Object stale=routeNode(nodeConstructor,42,20,100),tie=routeNode(nodeConstructor,42,20,101);
            Object worse=routeNode(nodeConstructor,42,30,102),better=routeNode(nodeConstructor,42,10,103);
            offer.invoke(search,queue,offerMap,stale); offer.invoke(search,queue,offerMap,tie);
            offer.invoke(search,queue,offerMap,worse); offer.invoke(search,queue,offerMap,better);
            Object current=poll.invoke(queue);
            require(current==better && get.invoke(offerMap,42)==current,"offers accept strict improvements and dequeue the best identity");
            Object obsolete=poll.invoke(queue);
            require(obsolete==stale && get.invoke(offerMap,42)!=obsolete,"repeated offers leave stale queue nodes identifiable");
            require(poll.invoke(queue)==null,"only strict improvements are queued");
        } catch(Exception failure) {
            throw new AssertionError("primitive branch-node map must match HashMap and preserve route offer identity",failure);
        }
    }
    private static Object routeNode(java.lang.reflect.Constructor<?> constructor,int key,int cost,int serial) throws Exception {
        int cells=PcbLayerRoutingPrototype.MAX_CELLS,group=key/cells,kind=group/5;
        return constructor.newInstance(key%cells,kind%2,group%5,kind/2,cost,0,serial,cells,null);
    }
    private static int mapHash(int key) {
        int value=key;
        value^=(value>>>20)^(value>>>12);
        return value^(value>>>7)^(value>>>4);
    }
    private static void reject(Runnable action,String why) {
        boolean rejected=false;
        try { action.run(); }
        catch(IllegalArgumentException expected) { rejected=true; }
        catch(IllegalStateException expected) { rejected=true; }
        require(rejected,why);
    }
    private static PcbBoardLayout copy(P06FactoryLinkFixtures.Fixture fixture,PcbBoardLayout routed,
            boolean holes,boolean bottom) {
        PcbBoardLayout result=fixture.layout.copyForRouting();
        for(PcbTraceGeometry trace:routed.getTraces())
            if(bottom || trace.getLayer()!=PcbCopperLayer.BOTTOM) result.addTrace(trace);
        if(holes) for(PcbBoardHole hole:routed.getHoles()) result.addHole(hole);
        return result;
    }
    private static void negatives() {
        final P06FactoryLinkFixtures.Fixture f=new P06FactoryLinkFixtures.Fixture(true,0,0,true);
        final PcbLayerRoutingPrototype.Result result=PcbLayerRoutingPrototype.route(f.board,f.layout,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,P06FactoryLinkFixtures.OBSERVER);
        require(result.accepted() && result.vias==2,"positive two-via crossing witness");
        PcbLayerRoutingPrototype.Result repeat=PcbLayerRoutingPrototype.route(f.board,f.layout,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,P06FactoryLinkFixtures.OBSERVER);
        require(result.layout.geometryFingerprint().equals(repeat.layout.geometryFingerprint()) &&
            result.expansions==repeat.expansions,"deterministic source geometry, ordering and work");
        final PcbBoardLayout noVia=copy(f,result.layout,false,true);
        reject(new Runnable(){public void run(){noVia.validateRoutingGeometry(f.board);}},"unplated projected crossings cannot join layers");
        final PcbBoardLayout wrong=copy(f,result.layout,false,true);
        boolean changed=false;
        for(PcbBoardHole hole:result.layout.getHoles()) {
            wrong.addHole(PcbTwoLayerRules.via(hole.id,changed?hole.netId:
                hole.netId.equals("OVER")?"UNDER":"OVER",hole.x,hole.y)); changed=true;
        }
        reject(new Runnable(){public void run(){wrong.validateRoutingGeometry(f.board);}},"wrong-net via rejected");
        final PcbBoardLayout invisible=copy(f,result.layout,true,false);
        reject(new Runnable(){public void run(){invisible.validateRoutingGeometry(f.board);}},"omitted underside cannot satisfy required connectivity");
        reject(new Runnable(){public void run(){PcbTwoLayerRules.requireDeveloperAdmission(result.layout,false);}},"normal admission rejects prototype copper");
        PcbLayerRoutingPrototype.Result exhausted=PcbLayerRoutingPrototype.route(f.board,f.layout,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,P06FactoryLinkFixtures.OBSERVER,1);
        require(!exhausted.accepted() && exhausted.expansions==1 && f.layout.getTraces().isEmpty() &&
            f.layout.getHoles().isEmpty(),"budget exhaustion publishes neither copper nor holes");
        final RuntimeException cancelled=new RuntimeException("P07 cancellation witness");
        boolean propagated=false;
        try { PcbLayerRoutingPrototype.route(f.board,f.layout,PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,
            new SeededPcbLayoutGenerator.AttemptObserver(){int calls;public void check(int attempt){if(++calls==4)throw cancelled;}}); }
        catch(RuntimeException expected) { propagated=expected==cancelled; }
        require(propagated && f.layout.getTraces().isEmpty() && f.layout.getHoles().isEmpty(),"mid-search cancellation propagates unchanged and atomic");
        PcbConductorGraph.Snapshot copper=result.layout.captureConductorGraph(f.board).pristine();
        require(copper.padsConnected("L.1","R.1") && copper.padsConnected("A.1","B.1") &&
            !copper.padsConnected("L.1","A.1"),"two physical islands cross without shorting");
        int bottomTargets=0;
        for(PcbConductorGraph.Surface surface:copper.getGraph().getSurfaces()) if(surface.edgeId!=null && surface.layer==PcbCopperLayer.BOTTOM) {
            require(!PcbCopperProbeAccess.available(copper,surface,PcbBoardSide.TOP) &&
                PcbCopperProbeAccess.available(copper,surface,PcbBoardSide.BOTTOM),"surface access requires its real face"); bottomTargets++;
            require(PcbCopperProbeAccess.connectedPad(copper.withCut(surface.edgeId,true),surface.id)==null,"cut surface has no phantom probe endpoint");
        }
        require(bottomTargets>0,"bottom-face negative cases executed");
        PcbBoardLayout floating=copy(f,result.layout,true,true);
        floating.addTrace(new PcbTraceGeometry("isolated","OVER",null,null,PcbCopperLayer.TOP,
            PcbCopperAccess.Exposure.EXPOSED,new int[]{480,480},new int[]{140,180}));
        PcbConductorGraph.Snapshot islands=floating.captureConductorGraph(f.board).pristine(); int isolated=0;
        for(PcbConductorGraph.Surface surface:islands.getGraph().getSurfaces()) if(surface.edgeId!=null &&
                islands.getGraph().getEdges().get(surface.edgeId).getSources().contains("isolated")) {
            require(PcbCopperProbeAccess.connectedPad(islands,surface.id)==null,"same logical label cannot attach a floating physical island"); isolated++;
        }
        require(isolated>0,"floating island falsifier executed");
    }
    private static void surfacePadEnvelope() {
        for(PcbBoardSide side:PcbBoardSide.values()) {
            TroubleshootBoard board=new TroubleshootBoard("P07_SMD_ENVELOPE");
            board.addNet(new BoardNet("ONE")); board.addNet(new BoardNet("TWO"));
            PhysicalPackage physical=PhysicalPackages.DEV_SMD_0805;
            BoardComponent part=new BoardComponent("SMD","STRUCTURAL",physical); board.addComponent(part);
            board.addPad(new BoardPad("SMD.1","SMD","1","ONE"));
            board.addPad(new BoardPad("SMD.2","SMD","2","TWO")); board.validate();
            PcbBoardLayout layout=new PcbBoardLayout(1100,650,new Rectangle(100,100,600,400),new Rectangle(820,120,200,400));
            PcbFootprint footprint=PcbFootprint.fromPhysicalPackage(part,
                new PcbPackagePose(180,180,PcbRotation.DEG_0,side),physical.getGeometry());
            layout.addComponent(footprint.getPlacement());
            for(PcbPadPlacement pad:footprint.getPads()) layout.addPad(pad);
            layout.validateAgainst(board);
            boolean rejected=false;
            try { PcbLayerRoutingPrototype.route(board,layout,
                PcbLayerRoutingPrototype.Policy.FULLER_TWO_LAYER,P06FactoryLinkFixtures.OBSERVER); }
            catch(IllegalArgumentException expected) {
                rejected=expected.getMessage().startsWith("P07 routing prototype requires plated-through-hole pads");
            }
            require(rejected,"SMD cannot acquire an implicit opposite-face connection: "+side);
            require(layout.getTraces().isEmpty() && layout.getHoles().isEmpty(),"unsupported package leaves input intact");
        }
    }
    private static void addPoint(TroubleshootBoard board,PcbBoardLayout layout,String id,String net,int x,int y) {
        PhysicalPackage physical=P06FactoryLinkFixtures.TEST_POINT;
        BoardComponent component=new BoardComponent(id,"STRUCTURAL",physical); board.addComponent(component);
        board.addPad(new BoardPad(id+".1",id,"1",net));
        PcbPackagePose reference=new PcbPackagePose(100,100,PcbRotation.DEG_0,PcbBoardSide.BOTTOM);
        Point local=physical.getGeometry().placedAt(reference).getPadPoint(0);
        PcbPackagePose pose=new PcbPackagePose(100+x-local.x,100+y-local.y,PcbRotation.DEG_0,PcbBoardSide.BOTTOM);
        PcbFootprint footprint=PcbFootprint.fromPhysicalPackage(component,pose,physical.getGeometry());
        layout.addComponent(footprint.getPlacement()); for(PcbPadPlacement pad:footprint.getPads()) layout.addPad(pad);
    }
    private static void barriers() {
        final TroubleshootBoard board=new TroubleshootBoard("P07_ISOLATION");
        board.addNet(new BoardNet("PRIMARY")); board.addNet(new BoardNet("SECONDARY"));
        final PcbBoardLayout placement=new PcbBoardLayout(1100,650,new Rectangle(100,100,600,400),new Rectangle(820,120,200,400));
        addPoint(board,placement,"P1","PRIMARY",170,200); addPoint(board,placement,"P2","PRIMARY",270,200);
        addPoint(board,placement,"S1","SECONDARY",530,200); addPoint(board,placement,"S2","SECONDARY",630,200);
        java.util.Vector<PcbPlacementConstraints.Part> parts=new java.util.Vector<PcbPlacementConstraints.Part>();
        for(String id:board.getComponentIds()) {
            String domain=id.startsWith("P")?"PRIMARY":"SECONDARY";
            parts.add(new PcbPlacementConstraints.Part(id,domain,domain,domain,PcbPlacementConstraints.Anchor.NONE,20));
        }
        java.util.Vector<PcbPlacementConstraints.Barrier> barriers=new java.util.Vector<PcbPlacementConstraints.Barrier>();
        barriers.add(new PcbPlacementConstraints.Barrier("PRIMARY","SECONDARY",80));
        board.setPlacementConstraints(new PcbPlacementConstraints(parts,barriers)); board.validate();
        final PcbTwoLayerRules rules=new PcbTwoLayerRules(board,placement);
        PcbLayerRoutingPrototype.Result legal=PcbLayerRoutingPrototype.route(board,placement,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,P06FactoryLinkFixtures.OBSERVER);
        require(legal.accepted(),"both domains route legally without crossing the corridor");
        for(PcbCopperLayer layer:PcbCopperLayer.values()) {
            final PcbBoardLayout illegal=placement.copyForRouting();
            illegal.addTrace(new PcbTraceGeometry("forbidden","PRIMARY",null,null,layer,
                PcbCopperAccess.Exposure.EXPOSED,new int[]{270,530},new int[]{200,200}));
            reject(new Runnable(){public void run(){rules.validate(illegal);}},"corridor blocks copper on "+layer);
        }
        final PcbBoardLayout illegalVia=placement.copyForRouting();
        illegalVia.addHole(PcbTwoLayerRules.via("forbidden-via","PRIMARY",400,300));
        reject(new Runnable(){public void run(){rules.validate(illegalVia);}},"via cannot tunnel through an isolation corridor");
        require(!rules.permits("PRIMARY",new Rectangle(530,300,10,10)),"net cannot reappear in the opposite isolated domain");
        final PcbBoardLayout padDrill=placement.copyForRouting();
        padDrill.addHole(PcbTwoLayerRules.via("pad-drill","PRIMARY",170,200));
        reject(new Runnable(){public void run(){rules.validate(padDrill);}},"via cannot drill through a component pad");
        reject(new Runnable(){public void run(){new PcbBoardHole("same-face",PcbBoardHole.Kind.VIA,"PRIMARY",200,300,2,6,
            PcbCopperLayer.TOP,PcbCopperLayer.TOP,PcbCopperAccess.Exposure.EXPOSED);}},"same-face declaration is not plating");
    }
}
