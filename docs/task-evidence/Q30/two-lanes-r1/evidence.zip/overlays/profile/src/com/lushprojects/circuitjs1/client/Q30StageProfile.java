package com.lushprojects.circuitjs1.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONBoolean;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import java.util.LinkedHashMap;
import java.util.Map;

/** Opt-in stage timing for the isolated private Q30 qualification verifier. */
final class Q30StageProfile {
    private static final int MAX_DEPTH = 32;
    static final int GEOMETRY_SAMPLE_EXPANSION_INTERVAL = 128;
    private static final int CLOCK_CALIBRATION_PAIRS = 32;
    private static boolean requested;
    private static boolean enabled;
    private static boolean clockAvailable;
    private static int depth;
    private static int overflowScopes;
    private static int mismatchedScopes;
    private static final String[] names = new String[MAX_DEPTH];
    private static final double[] started = new double[MAX_DEPTH];
    private static final double[] childMillis = new double[MAX_DEPTH];
    private static Map<String, Stat> timings = new LinkedHashMap<String, Stat>();
    private static Map<String, double[]> counts = new LinkedHashMap<String, double[]>();
    private static int geometrySampleClockPairs;
    private static double calibratedClockPairMillis;

    private Q30StageProfile() { }

    static void reset(boolean enable) {
        requested = enable;
        clockAvailable = !GWT.isScript() || browserClockAvailable();
        enabled = enable && clockAvailable;
        for (int i = 0; i < MAX_DEPTH; i++) { names[i] = null; started[i] = childMillis[i] = 0; }
        depth = overflowScopes = mismatchedScopes = 0;
        timings = new LinkedHashMap<String, Stat>();
        counts = new LinkedHashMap<String, double[]>();
        geometrySampleClockPairs = 0;
        calibratedClockPairMillis = 0;
        if (enabled) {
            double calibrationStarted = nowMillis();
            for (int i = 0; i < CLOCK_CALIBRATION_PAIRS; i++) {
                nowMillis();
                nowMillis();
            }
            calibratedClockPairMillis = Math.max(0,
                (nowMillis() - calibrationStarted) / CLOCK_CALIBRATION_PAIRS);
        }
    }

    static String currentProofLabel() {
        for (int i = depth - 1; i >= 0; i--) if (names[i].startsWith("proof.h")) return names[i];
        return depth == 0 ? "unscoped" : names[0];
    }

    static boolean isEnabled() { return enabled; }
    static double now() { return enabled ? nowMillis() : -1; }
    static double elapsedSince(double start) {
        if (!enabled || start < 0) return 0;
        double elapsed = nowMillis() - start;
        return elapsed < 0 || Double.isNaN(elapsed) || Double.isInfinite(elapsed) ? 0 : elapsed;
    }

    static int begin(String name) {
        if (!enabled) return -1;
        if (depth >= MAX_DEPTH) { overflowScopes++; return -1; }
        int slot = depth++;
        names[slot] = name;
        started[slot] = nowMillis();
        childMillis[slot] = 0;
        return slot + 1;
    }

    static void end(int token) {
        if (token <= 0 || !enabled) return;
        if (token != depth) { mismatchedScopes++; return; }
        int slot = --depth;
        double elapsed = nowMillis() - started[slot];
        if (elapsed < 0 || Double.isNaN(elapsed) || Double.isInfinite(elapsed)) elapsed = 0;
        double exclusive = Math.max(0, elapsed - childMillis[slot]);
        if (slot > 0) childMillis[slot - 1] += elapsed;
        String name = names[slot];
        names[slot] = null;
        Stat stat = timings.get(name);
        if (stat == null) { stat = new Stat(); timings.put(name, stat); }
        stat.calls++;
        stat.maxMillis = Math.max(stat.maxMillis, elapsed);
        stat.inclusiveMillis += elapsed;
        stat.exclusiveMillis += exclusive;
    }

    static void count(String name) { addCount(name, 1.0); }

    static void addCount(String name, double amount) {
        if (!enabled || amount == 0) return;
        double[] value = counts.get(name);
        if (value == null) { value = new double[1]; counts.put(name, value); }
        value[0] += amount;
    }

    /** Sampled predicate span; deliberately not nested in the A* coarse timer. */
    static void sampleElapsed(String name, double start) {
        if (!enabled || start < 0) return;
        double elapsed = nowMillis() - start;
        if (elapsed < 0 || Double.isNaN(elapsed) || Double.isInfinite(elapsed)) elapsed = 0;
        geometrySampleClockPairs++;
        Stat stat = timings.get(name);
        if (stat == null) { stat = new Stat(); timings.put(name, stat); }
        stat.calls++;
        stat.maxMillis = Math.max(stat.maxMillis, elapsed);
        stat.inclusiveMillis += elapsed;
        stat.exclusiveMillis += elapsed;
    }

    static JSONObject snapshot() {
        if (!requested) return null;
        JSONObject result = new JSONObject();
        result.put("protocol", new JSONString("TSJ-Q30-TWO-LANES-1"));
        result.put("clock", new JSONString(enabled ? (GWT.isScript() ? "performance.now" : "System.currentTimeMillis (native tests only)") : "unavailable"));
        result.put("clockAvailable", JSONBoolean.getInstance(clockAvailable));
        result.put("enabled", JSONBoolean.getInstance(enabled));
        put(result, "openScopes", depth);
        put(result, "overflowScopes", overflowScopes);
        put(result, "mismatchedScopes", mismatchedScopes);
        JSONArray rows = new JSONArray();
        for (Map.Entry<String, Stat> entry : timings.entrySet()) {
            JSONObject row = new JSONObject();
            row.put("name", new JSONString(entry.getKey()));
            Stat stat = entry.getValue();
            put(row, "calls", stat.calls);
            put(row, "inclusiveMs", stat.inclusiveMillis);
            put(row, "exclusiveMs", stat.exclusiveMillis);
            put(row, "maxMs", stat.maxMillis);
            rows.set(rows.size(), row);
        }
        result.put("timings", rows);
        JSONObject countValues = new JSONObject();
        for (Map.Entry<String, double[]> entry : counts.entrySet())
            put(countValues, entry.getKey(), entry.getValue()[0]);
        result.put("counts", countValues);
        put(result, "clockCalibrationPairs", CLOCK_CALIBRATION_PAIRS);
        put(result, "calibratedClockPairMs", calibratedClockPairMillis);
        result.put("timingBoundary", new JSONString("Nested scopes: inclusive overlaps; exclusive subtracts child scopes. Clock quantization and observer overhead remain; no corrected production-time claim."));
        return result;
    }

    static void clear() { reset(false); }

    private static void put(JSONObject target, String key, int value) {
        target.put(key, new JSONNumber(value));
    }
    private static void put(JSONObject target, String key, double value) {
        target.put(key, new JSONNumber(value));
    }
    private static double nowMillis() { return GWT.isScript() ? browserNowMillis() : (double)System.currentTimeMillis(); }
    private static native boolean browserClockAvailable() /*-{
        return !!($wnd.performance && typeof $wnd.performance.now === "function");
    }-*/;
    private static native double browserNowMillis() /*-{
        return $wnd.performance.now();
    }-*/;

    private static final class Stat {
        int calls;
        double inclusiveMillis;
        double exclusiveMillis;
        double maxMillis;
    }
}


