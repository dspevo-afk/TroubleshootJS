package com.lushprojects.circuitjs1.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONBoolean;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/** Diagnostic-only observation of the accepted CircuitJS solver path. */
final class Q30SolverWorkProfile {
    private static final int LABEL_LIMIT = 128;
    private static final int GRAPH_LIMIT = 128;
    private static final double MAX_EXACT_COUNT = 9007199254740991.0;
    private static final String[] OPERATION_NAMES = { "analyze", "ui", "steps", "duration" };
    private boolean requested;
    private boolean enabled;
    private boolean browserClock;
    private boolean clockAvailable;
    private double clockAnomalies;
    private double simulationTimeAnomalies;
    private double counterAnomalies;
    private double unbalancedOperations;

    double trialAttempts, nonlinearTrials, acceptedSteps, stepRetries;
    double convergenceFailures, timeAdvanced;
    double analysisCalls, stampCircuitCalls;
    double factorCalls, nonlinearFactors, solveCalls, runCalls, doStepCalls;
    double matrixCopySlots, rhsCopySlots, lhsCopySlots;
    double wireRefreshCalls, publicationCalls, controlRevisionInvalidations;
    double graphBindings, graphRebindings, graphOverflow, labelOverflow;
    double maxMatrixSize, maxElementCount;

    private double matrixCopyMillis, maxMatrixCopyMillis;
    private double doStepMillis, maxDoStepMillis;
    private double factorMillis, maxFactorMillis;
    private double solveMillis, maxSolveMillis;
    private double publicationMillis, maxPublicationMillis;
    private double wireRefreshMillis, maxWireRefreshMillis;
    private double stampCircuitMillis, maxStampCircuitMillis;
    private double[] operationCalls = new double[4];
    private double[] operationFailures = new double[4];
    private double[] operationMillis = new double[4];
    private double[] operationMaxMillis = new double[4];
    private double[] operationAdvanced = new double[4];
    private int activeOperation = -1;
    private int activeLabel = -1;
    private double activeOperationStarted;
    private double lastAcceptedTime;

    private final String[] labels = new String[LABEL_LIMIT];
    private final double[] labelOperations = new double[LABEL_LIMIT];
    private final double[] labelAccepted = new double[LABEL_LIMIT];
    private final double[] labelAdvanced = new double[LABEL_LIMIT];
    private final double[] labelMillis = new double[LABEL_LIMIT];
    private int labelCount;
    private final int[] ownerHashes = new int[GRAPH_LIMIT];
    private final int[] graphHashes = new int[GRAPH_LIMIT];
    private final double[] graphBinds = new double[GRAPH_LIMIT];
    private final double[] graphAnalyses = new double[GRAPH_LIMIT];
    private final double[] graphOperations = new double[GRAPH_LIMIT];
    private final int[] graphElements = new int[GRAPH_LIMIT];
    private int graphCount;
    private int activeGraph = -1;

    void reset(boolean request) {
        clear();
        requested = request;
        if (!request) return;
        browserClock = GWT.isScript();
        clockAvailable = !browserClock || browserClockAvailable();
        enabled = request && clockAvailable;
    }

    void clear() {
        requested = enabled = browserClock = clockAvailable = false;
        clockAnomalies = simulationTimeAnomalies = counterAnomalies = unbalancedOperations = 0;
        trialAttempts = nonlinearTrials = acceptedSteps = stepRetries = 0;
        convergenceFailures = timeAdvanced = 0;
        analysisCalls = stampCircuitCalls = 0;
        factorCalls = nonlinearFactors = solveCalls = runCalls = doStepCalls = 0;
        matrixCopySlots = rhsCopySlots = lhsCopySlots = 0;
        wireRefreshCalls = publicationCalls = controlRevisionInvalidations = 0;
        graphBindings = graphRebindings = graphOverflow = labelOverflow = 0;
        maxMatrixSize = maxElementCount = 0;
        matrixCopyMillis = maxMatrixCopyMillis = 0;
        doStepMillis = maxDoStepMillis = 0;
        factorMillis = maxFactorMillis = 0;
        solveMillis = maxSolveMillis = 0;
        publicationMillis = maxPublicationMillis = 0;
        wireRefreshMillis = maxWireRefreshMillis = 0;
        stampCircuitMillis = maxStampCircuitMillis = 0;
        for (int i = 0; i < operationCalls.length; i++) {
            operationCalls[i] = operationFailures[i] = operationMillis[i] = 0;
            operationMaxMillis[i] = operationAdvanced[i] = 0;
        }
        for (int i = 0; i < labelCount; i++) {
            labels[i] = null;
            labelOperations[i] = labelAccepted[i] = labelAdvanced[i] = labelMillis[i] = 0;
        }
        for (int i = 0; i < graphCount; i++) {
            ownerHashes[i] = graphHashes[i] = graphElements[i] = 0;
            graphBinds[i] = graphAnalyses[i] = graphOperations[i] = 0;
        }
        labelCount = graphCount = 0;
        activeGraph = activeOperation = activeLabel = -1;
        activeOperationStarted = lastAcceptedTime = 0;
    }

    boolean isEnabled() { return enabled; }

    double now() {
        return browserClock ? browserNowMillis() : (double)System.currentTimeMillis();
    }

    private double elapsed(double began) {
        double duration = now() - began;
        if (Double.isNaN(duration) || Double.isInfinite(duration) || duration < 0) {
            clockAnomalies++;
            return 0;
        }
        return duration;
    }

    void onGraphBind(Object owner, Object graph, int elements) {
        if (!enabled) return;
        graphBindings++;
        if (elements > maxElementCount) maxElementCount = elements;
        int ownerHash = System.identityHashCode(owner);
        int graphHash = System.identityHashCode(graph);
        int slot = -1;
        for (int i = 0; i < graphCount; i++) {
            if (ownerHashes[i] == ownerHash && graphHashes[i] == graphHash) {
                slot = i;
                graphRebindings++;
                break;
            }
        }
        if (slot < 0 && graphCount < GRAPH_LIMIT) {
            slot = graphCount++;
            ownerHashes[slot] = ownerHash;
            graphHashes[slot] = graphHash;
            graphElements[slot] = elements;
        } else if (slot < 0) graphOverflow++;
        activeGraph = slot;
        if (slot >= 0) graphBinds[slot]++;
    }

    void onControlRevisionInvalidation() {
        if (enabled) controlRevisionInvalidations++;
    }

    void beginOperation(int kind, String label, double simulationTime) {
        if (!enabled) return;
        if (activeOperation >= 0) unbalancedOperations++;
        double started = now();
        int labelIndex = labelSlot(label == null ? "unscoped" : label);
        activeOperation = kind;
        activeOperationStarted = started;
        lastAcceptedTime = simulationTime;
        activeLabel = labelIndex;
        operationCalls[kind]++;
        if (activeLabel >= 0) labelOperations[activeLabel]++;
        if (activeGraph >= 0) graphOperations[activeGraph]++;
        if (kind == 0) {
            analysisCalls++;
            if (activeGraph >= 0) graphAnalyses[activeGraph]++;
        }
    }

    void finishOperation(boolean failed) {
        if (!enabled) return;
        int kind = activeOperation;
        if (kind < 0) { unbalancedOperations++; return; }
        try {
            double duration = elapsed(activeOperationStarted);
            operationMillis[kind] += duration;
            if (duration > operationMaxMillis[kind]) operationMaxMillis[kind] = duration;
            if (activeLabel >= 0) labelMillis[activeLabel] += duration;
            if (failed) operationFailures[kind]++;
        } finally {
            activeOperation = activeLabel = -1;
            activeOperationStarted = lastAcceptedTime = 0;
        }
    }

    void accepted(double simulationTime) {
        if (!enabled) return;
        double advanced = simulationTime - lastAcceptedTime;
        if (Double.isNaN(advanced) || Double.isInfinite(advanced) || advanced < 0) {
            simulationTimeAnomalies++;
            advanced = 0;
        }
        acceptedSteps++;
        timeAdvanced += advanced;
        if (activeOperation >= 0) operationAdvanced[activeOperation] += advanced;
        if (activeLabel >= 0) {
            labelAccepted[activeLabel]++;
            labelAdvanced[activeLabel] += advanced;
        }
        lastAcceptedTime = simulationTime;
    }

    void matrixSize(int size) {
        if (enabled && size > maxMatrixSize) maxMatrixSize = size;
    }
    void matrixCopy(double began) { if (enabled) {
        double value = elapsed(began); matrixCopyMillis += value;
        if (value > maxMatrixCopyMillis) maxMatrixCopyMillis = value;
    } }
    void doStep(double began) { if (enabled) {
        double value = elapsed(began); doStepMillis += value;
        if (value > maxDoStepMillis) maxDoStepMillis = value;
    } }
    void factor(double began) { if (enabled) {
        double value = elapsed(began); factorMillis += value;
        if (value > maxFactorMillis) maxFactorMillis = value;
    } }
    void solve(double began) { if (enabled) {
        double value = elapsed(began); solveMillis += value;
        if (value > maxSolveMillis) maxSolveMillis = value;
    } }
    void publish(double began) { if (enabled) {
        double value = elapsed(began); publicationMillis += value;
        if (value > maxPublicationMillis) maxPublicationMillis = value;
    } }
    void wireRefresh(double began) { if (enabled) {
        double value = elapsed(began); wireRefreshMillis += value;
        if (value > maxWireRefreshMillis) maxWireRefreshMillis = value;
    } }
    void stampCircuit(double began) { if (enabled) {
        double value = elapsed(began); stampCircuitMillis += value;
        if (value > maxStampCircuitMillis) maxStampCircuitMillis = value;
    } }

    private int labelSlot(String label) {
        for (int i = 0; i < labelCount; i++) if (labels[i].equals(label)) return i;
        if (labelCount >= LABEL_LIMIT) { labelOverflow++; return -1; }
        labels[labelCount] = label;
        return labelCount++;
    }

    JSONObject snapshot() {
        JSONObject out = new JSONObject();
        put(out, "requested", requested);
        put(out, "enabled", enabled);
        put(out, "clock", browserClock ? "performance.now" : "System.currentTimeMillis (native tests only)");
        put(out, "clockAvailable", clockAvailable);
        put(out, "clockAnomalies", clockAnomalies);
        put(out, "simulationTimeAnomalies", simulationTimeAnomalies);
        put(out, "counterAnomalies", countAnomalies());
        put(out, "unbalancedOperations", unbalancedOperations + (activeOperation >= 0 ? 1 : 0));
        put(out, "measurementValid", enabled && clockAnomalies == 0 &&
            simulationTimeAnomalies == 0 && counterAnomalies == 0 &&
            unbalancedOperations == 0 && activeOperation < 0);
        put(out, "trialAttempts", trialAttempts);
        put(out, "nonlinearTrials", nonlinearTrials);
        put(out, "acceptedSteps", acceptedSteps);
        put(out, "stepRetries", stepRetries);
        put(out, "convergenceFailures", convergenceFailures);
        put(out, "timeAdvanced", timeAdvanced);
        put(out, "analysisCalls", analysisCalls);
        put(out, "stampCircuitCalls", stampCircuitCalls);
        put(out, "factorCalls", factorCalls);
        put(out, "nonlinearFactors", nonlinearFactors);
        put(out, "solveCalls", solveCalls);
        put(out, "runCalls", runCalls);
        put(out, "doStepCalls", doStepCalls);
        put(out, "matrixCopySlots", matrixCopySlots);
        put(out, "rhsCopySlots", rhsCopySlots);
        put(out, "lhsCopySlots", lhsCopySlots);
        put(out, "wireRefreshCalls", wireRefreshCalls);
        put(out, "publicationCalls", publicationCalls);
        put(out, "controlRevisionInvalidations", controlRevisionInvalidations);
        put(out, "graphBindings", graphBindings);
        put(out, "graphRebindings", graphRebindings);
        put(out, "graphOverflow", graphOverflow);
        put(out, "labelOverflow", labelOverflow);
        put(out, "maxMatrixSize", maxMatrixSize);
        put(out, "maxElementCount", maxElementCount);
        timing(out, "matrixCopy", matrixCopyMillis, maxMatrixCopyMillis);
        timing(out, "doStep", doStepMillis, maxDoStepMillis);
        timing(out, "factor", factorMillis, maxFactorMillis);
        timing(out, "solve", solveMillis, maxSolveMillis);
        timing(out, "publication", publicationMillis, maxPublicationMillis);
        timing(out, "wireRefresh", wireRefreshMillis, maxWireRefreshMillis);
        timing(out, "stampCircuit", stampCircuitMillis, maxStampCircuitMillis);
        put(out, "timingRelationship", "Full operations include inner phases; stampCircuit may include linear factorization. Do not sum all timing rows.");
        JSONArray operations = new JSONArray();
        for (int i = 0; i < OPERATION_NAMES.length; i++) {
            JSONObject row = new JSONObject();
            put(row, "kind", OPERATION_NAMES[i]);
            put(row, "calls", operationCalls[i]);
            put(row, "failures", operationFailures[i]);
            put(row, "totalMs", operationMillis[i]);
            put(row, "maxMs", operationMaxMillis[i]);
            put(row, "timeAdvanced", operationAdvanced[i]);
            operations.set(i, row);
        }
        out.put("operations", operations);
        JSONArray byLabel = new JSONArray();
        for (int i = 0; i < labelCount; i++) {
            JSONObject row = new JSONObject();
            put(row, "label", labels[i]);
            put(row, "operations", labelOperations[i]);
            put(row, "acceptedSteps", labelAccepted[i]);
            put(row, "timeAdvanced", labelAdvanced[i]);
            put(row, "operationMs", labelMillis[i]);
            byLabel.set(i, row);
        }
        out.put("byProofLabel", byLabel);
        JSONArray graphs = new JSONArray();
        for (int i = 0; i < graphCount; i++) {
            JSONObject row = new JSONObject();
            put(row, "ownerIdentityHash", ownerHashes[i]);
            put(row, "graphIdentityHash", graphHashes[i]);
            put(row, "elementCountAtBind", graphElements[i]);
            put(row, "binds", graphBinds[i]);
            put(row, "analyses", graphAnalyses[i]);
            put(row, "operations", graphOperations[i]);
            graphs.set(i, row);
        }
        out.put("graphIdentityHashes", graphs);
        put(out, "graphIdentityLimit", GRAPH_LIMIT);
        put(out, "graphIdentityMeaning", "Identity hashes and element counts show observed rebinding only; equal hashes or controls do not prove electrical equivalence.");
        return out;
    }

    private double countAnomalies() {
        counterAnomalies = 0;
        double[] values = { trialAttempts, nonlinearTrials, acceptedSteps, stepRetries,
            convergenceFailures, analysisCalls, stampCircuitCalls, factorCalls,
            nonlinearFactors, solveCalls, runCalls, doStepCalls, matrixCopySlots,
            rhsCopySlots, lhsCopySlots, wireRefreshCalls, publicationCalls,
            controlRevisionInvalidations, graphBindings, graphRebindings,
            graphOverflow, labelOverflow };
        for (double value : values)
            if (!finiteExactCount(value)) counterAnomalies++;
        for (double value : operationCalls) if (!finiteExactCount(value)) counterAnomalies++;
        for (double value : labelAccepted) if (!finiteExactCount(value)) counterAnomalies++;
        return counterAnomalies;
    }

    private static boolean finiteExactCount(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value) && value >= 0 &&
            value <= MAX_EXACT_COUNT && value == Math.floor(value);
    }
    private static void timing(JSONObject out, String name, double total, double max) {
        JSONObject row = new JSONObject();
        put(row, "totalMs", total);
        put(row, "maxMs", max);
        out.put(name, row);
    }
    private static void put(JSONObject out, String key, boolean value) {
        out.put(key, JSONBoolean.getInstance(value));
    }
    private static void put(JSONObject out, String key, double value) {
        out.put(key, new JSONNumber(value));
    }
    private static void put(JSONObject out, String key, String value) {
        out.put(key, new JSONString(value));
    }
    private static native boolean browserClockAvailable() /*-{
        return !!($wnd.performance && typeof $wnd.performance.now === "function");
    }-*/;
    private static native double browserNowMillis() /*-{
        return $wnd.performance.now();
    }-*/;
}
