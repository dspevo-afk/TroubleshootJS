package com.lushprojects.circuitjs1.client;

import java.lang.reflect.Field;

/** Focused native lifecycle checks for the diagnostic-only solver collector. */
public final class Q30SolverWorkProfileContractTest {
    private static int assertions;

    public static void main(String[] args) throws Exception {
        Q30SolverWorkProfile work = new Q30SolverWorkProfile();
        work.reset(false);
        check(!work.isEnabled(), "disabled reset unexpectedly enabled profiling");
        work.accepted(1.0);
        check(work.acceptedSteps == 0,
            "disabled collector changed counters");

        work.reset(true);
        check(work.isEnabled(), "native monotonic profile did not enable");
        Object owner = new Object(), graph = new Object();
        work.onGraphBind(owner, graph, 40);
        work.onGraphBind(owner, graph, 40);
        check(work.graphBindings == 2 && work.graphRebindings == 1,
            "observed graph rebinding was not counted");
        work.beginOperation(3, "proof.h0.temporal", 1.0);
        work.trialAttempts += 2;
        work.nonlinearTrials += 2;
        work.stampCircuitCalls++;
        work.matrixCopySlots += 20;
        work.accepted(1.25);
        work.finishOperation(false);
        check(work.acceptedSteps == 1 && work.timeAdvanced == 0.25,
            "accepted time was not measured from the operation start");
        check(work.stampCircuitCalls == 1 && work.matrixCopySlots == 20,
            "coarse stamp/copy counters changed");
        check(work.trialAttempts == 2 && work.nonlinearTrials == 2,
            "primitive trial counters changed");
        Field active = Q30SolverWorkProfile.class.getDeclaredField("activeOperation");
        active.setAccessible(true);
        check(active.getInt(work) == -1, "completed operation retained a timer");
        work.beginOperation(2, "proof.h0.exception", 1.25);
        boolean caught = false;
        try {
            throw new IllegalStateException("fixture failure");
        } catch (IllegalStateException expected) {
            caught = true;
        } finally {
            work.finishOperation(true);
        }
        Field failures = Q30SolverWorkProfile.class.getDeclaredField("operationFailures");
        failures.setAccessible(true);
        check(caught && ((double[]) failures.get(work))[2] == 1 &&
            active.getInt(work) == -1,
            "failed operation did not close and count its timer");
        work.beginOperation(3, "proof.h0.reset", 1.25);
        work.reset(false);
        check(!work.isEnabled() && work.acceptedSteps == 0 && work.graphBindings == 0,
            "reset retained run counters or enablement");
        check(active.getInt(work) == -1, "reset retained an active operation");
        Field labels = Q30SolverWorkProfile.class.getDeclaredField("labels");
        labels.setAccessible(true);
        check(((String[]) labels.get(work))[0] == null,
            "reset retained a proof label");
        System.out.println("PASS: Q30 solver work profile contracts assertions=" + assertions);
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
}
