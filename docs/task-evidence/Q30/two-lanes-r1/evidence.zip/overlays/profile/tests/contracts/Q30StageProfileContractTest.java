package com.lushprojects.circuitjs1.client;
import java.lang.reflect.Field;
import java.util.Map;
public final class Q30StageProfileContractTest {
    static int assertions;
    static Object value(String key) throws Exception { Field f=Q30StageProfile.class.getDeclaredField(key); f.setAccessible(true); return f.get(null); }
    static void check(boolean condition) { assertions++; if(!condition) throw new AssertionError("stage profile assertion " + assertions); }
    public static void main(String[] args) throws Exception {
        Q30StageProfile.clear(); check(!Q30StageProfile.isEnabled()); check(Q30StageProfile.begin("disabled")==-1);
        Q30StageProfile.reset(true); int outer=Q30StageProfile.begin("stage.test"); int proof=Q30StageProfile.begin("proof.h2.TEST");
        check(Q30StageProfile.currentProofLabel().equals("proof.h2.TEST"));
        try { int nested=Q30StageProfile.begin("nested"); try { throw new IllegalStateException("expected"); } finally { Q30StageProfile.end(nested); } } catch(IllegalStateException expected) {}
        Q30StageProfile.end(proof); Q30StageProfile.end(outer); check(((Integer)value("depth"))==0); check(((Integer)value("mismatchedScopes"))==0);
        check(((Map<?,?>)value("timings")).size()==3);
        for(String name:(String[])value("names")) check(name==null);
        Q30StageProfile.addCount("actual",12); check(((Map<?,?>)value("counts")).size()==1);
        int first=Q30StageProfile.begin("one"); int second=Q30StageProfile.begin("two"); Q30StageProfile.end(first);check(((Integer)value("mismatchedScopes"))==1);
        Q30StageProfile.end(second); Q30StageProfile.end(first);
        Q30StageProfile.clear();check(!Q30StageProfile.isEnabled());check(((Map<?,?>)value("timings")).isEmpty());check(((Map<?,?>)value("counts")).isEmpty());
        check(((Integer)value("depth"))==0);for(String name:(String[])value("names")) check(name==null);
        System.out.println("PASS: Q30 stage profile contracts " + assertions + " assertions PASS");
    }
}
