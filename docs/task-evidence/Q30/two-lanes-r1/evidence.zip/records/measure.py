from pathlib import Path
import json,sys,subprocess,os,time
r=Path(__file__).resolve().parent.parent
label,arm,seed=sys.argv[1:4]
query='&tsjQ30WorkProfile=true' if arm=='profile' else ''
case={'name':label,'path':'circuitjs.html?tsjChallenge=led&seed=3&tsjDebug=true&tsjVerifyQ30=true&tsjQ30Coordinator=true&tsjQ30Seed='+seed+query,'stateAttribute':'data-tsj-q30-coordinator-state','expectedState':'PASS:complete','reportAttribute':'data-tsj-q30-coordinator-report','timeoutSeconds':600}
p=r/'records'/(label+'-spec.json');assert not p.exists();p.write_text(json.dumps({'cases':[case]},indent=2))
env=os.environ.copy();env['PYTHONPATH']=str(r/'runtime-packages')
start=time.monotonic()
with (r/'records'/(label+'.log')).open('w') as log:
 code=subprocess.run([sys.executable,'-B',str(r/'control/tests/browser/compiled_attribute_acceptance.py'),str(r/arm),str(r/label),str(p)],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
out={'label':label,'arm':arm,'seed':seed,'exitCode':code,'outerSeconds':time.monotonic()-start}
result=r/label/'result.json'
if result.exists():
 host=json.loads(result.read_text());out.update(outcome=host['outcome'],cleanup=host['cleanup'],inputAudit=host['inputAudit'])
reports=list((r/label/'cases').glob('*.report.json'))
if reports:
 doc=json.loads(reports[0].read_text())
 for phase in ['cold','warm']:
  out[phase]={k:doc.get(phase,{}).get(k) for k in ['elapsedMs','routingElapsedMs','proofElapsedMs','totalWork','hypothesisWork','maxAdvanceMs','maxManualUnitMs']}
(r/'records'/(label+'-summary.json')).write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
sys.exit(code)
