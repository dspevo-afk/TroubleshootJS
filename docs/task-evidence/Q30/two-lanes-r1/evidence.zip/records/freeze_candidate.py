from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent.parent
base=json.loads((r/'records/accepted-inputs.json').read_text())
files={name:hashlib.sha256((r/'candidate'/name).read_bytes()).hexdigest() for name in base['files']}
changed=[name for name,digest in files.items() if digest!=base['files'][name]]
assert set(changed)=={'src/com/lushprojects/circuitjs1/client/PcbLayerRoutingPrototype.java','tests/contracts/P07TwoLayerContractTest.java'},changed
out=r/'records/candidate-inputs.json'
assert not out.exists()
out.write_text(json.dumps({'head':base['head'],'source':'clean accepted export plus isolated primitive branch-node map experiment','files':files,'changed':changed},indent=2)+'\n')
print(json.dumps({'status':'frozen','files':len(files),'changed':changed,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
