"""Strict host/proof/parity reader for frozen plan3 Q30 runs."""
import argparse
import copy
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE / "readers"))
import check_coordinator

HEAD = "3a877723f366f0dfa51666ab4121ea82f0e82838"
LABELS = {"01-control-seed7": "control",
          "02-two-lane-profile-seed7": "profile",
          "03-control-seed7": "control",
          "04-control-seed7": "control",
          "05-candidate-seed7": "candidate",
          "06-candidate-seed7": "candidate",
          "07-control-seed7": "control"}
LIMITS = [90000, 640, 5000]
MAX_EXACT = 2**53 - 1

class Invalid(ValueError):
    pass

def need(condition, message):
    if not condition:
        raise Invalid(message)

def no_duplicate_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise Invalid("duplicate JSON key: " + key)
        obj[key] = value
    return obj

def reject_constant(value):
    raise Invalid("non-finite JSON value: " + value)

def load(path):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"),
                          object_pairs_hook=no_duplicate_keys,
                          parse_constant=reject_constant)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise Invalid("invalid/missing JSON " + path.name + ": " + str(exc)) from exc

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_sha(path):
    return sha(path.read_bytes())

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")

def integer(value, label, minimum=0, maximum=MAX_EXACT):
    need(type(value) is int and minimum <= value <= maximum,
         label + " must be an exact integer in range")
    return value

def finite(value, label):
    need(type(value) in (int, float) and math.isfinite(value) and value >= 0,
         label + " must be finite and nonnegative")
    return float(value)

def validate_manifest(doc, label):
    need(isinstance(doc, dict) and doc.get("schema") == 1 and
         doc.get("roots") == ["src", "war"] and isinstance(doc.get("files"), list),
         label + " manifest schema/roots/rows invalid")
    rows = doc["files"]
    names = []
    for row in rows:
        need(isinstance(row, dict) and set(row) == {"path", "size", "sha256"},
             label + " manifest row shape changed")
        name = row["path"]
        need(isinstance(name, str) and (name.startswith("src/") or name.startswith("war/"))
             and "\\" not in name and ".." not in Path(name).parts,
             label + " manifest path invalid")
        integer(row["size"], label + " file size")
        need(isinstance(row["sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", row["sha256"]),
             label + " file hash invalid")
        names.append(name)
    need(names == sorted(names) and len(names) == len(set(names)),
         label + " manifest paths unsorted or duplicated")
    src = [row for row in rows if row["path"].startswith("src/")]
    web = [row for row in rows if row["path"].startswith("war/")]
    need(doc.get("fileCount") == len(rows) and doc.get("sourceFileCount") == len(src)
         and doc.get("webFileCount") == len(web), label + " manifest counts differ")
    need(doc.get("sha256") == sha(canonical(rows)) and
         doc.get("sourceSha256") == sha(canonical(src)) and
         doc.get("webSha256") == sha(canonical(web)),
         label + " manifest aggregate hash mismatch")
    return src, web

def without_capture_time(value):
    result = copy.deepcopy(value)
    result.pop("capturedUtc", None)
    return result

def inputs_for(arm):
    map_name = {"control": "accepted-inputs.json",
                "profile": "profile-inputs.json",
                "candidate": "candidate-inputs.json"}[arm]
    path = HERE / map_name
    doc = load(path)
    need(doc.get("head") == HEAD and isinstance(doc.get("files"), dict),
         arm + " source map not bound to frozen base HEAD")
    for name, digest in doc["files"].items():
        need(isinstance(name, str) and isinstance(digest, str) and
             re.fullmatch(r"[0-9a-f]{64}", digest), arm + " source map contains invalid hash")
    return doc, {name: digest for name, digest in doc["files"].items()
                 if name.startswith("src/")}

def validate_common_run(run_dir, result, arm):
    source_doc, source_map = inputs_for(arm)
    before = load(run_dir / "input-manifest-before.json")
    after = load(run_dir / "input-manifest-after.json")
    src, _ = validate_manifest(before, arm + " before")
    validate_manifest(after, arm + " after")
    need(without_capture_time(before) == without_capture_time(after),
         arm + " runtime inputs changed during run")
    need({row["path"]: row["sha256"] for row in src} == source_map,
         arm + " runtime src differs from the frozen arm-specific source map")
    audit = result.get("inputAudit", {})
    need(audit.get("status") == "PASS" and
         audit.get("beforeSha256") == before["sha256"] == audit.get("afterSha256") and
         audit.get("sourceSha256Before") == before["sourceSha256"] ==
             audit.get("sourceSha256After") and
         audit.get("webSha256Before") == before["webSha256"] == audit.get("webSha256After") and
         audit.get("fileCountBefore") == before["fileCount"] == audit.get("fileCountAfter"),
         arm + " host input audit disagrees with stable manifests")
    rb = load(run_dir / "runner-before.json")
    ra = load(run_dir / "runner-after.json")
    need(rb == ra and rb.get("sha256") == audit.get("runnerBeforeSha256") ==
         audit.get("runnerAfterSha256"), arm + " runner identity changed")
    identity = load(run_dir / "identity.json")
    need(result.get("identity") == identity, arm + " host identity record differs")
    runner = identity.get("runner", {})
    integer(runner.get("pid"), arm + " runner pid", 1)
    need(isinstance(runner.get("created"), str) and
         isinstance(runner.get("executable"), str) and
         isinstance(identity.get("baseUrl"), str) and identity.get("port") is not None,
         arm + " host process/server identity incomplete")
    return before, source_doc

def check_case_errors(row, label):
    for key in ("pageErrors", "httpErrors", "consoleErrors", "attributeReadErrors",
                "listenerCleanupErrors"):
        need(row.get(key) == [], label + " reported " + key)
    need(row.get("navigationError") is None and row.get("reportJsonError") is None,
         label + " reported navigation/JSON error")

def validate_host(label, arm):
    run_dir = ROOT / label
    need(run_dir.is_dir(), "run directory missing: " + label)
    spec = load(HERE / (label + "-spec.json"))
    need(spec == load(run_dir / "spec.json"), "copied host spec differs from declaration")
    cases = spec.get("cases") if isinstance(spec, dict) else None
    need(isinstance(cases, list) and len(cases) == 1, "normal run must declare one case")
    case = cases[0]
    need(case.get("name") == label and case.get("expectedState") == "PASS:complete",
         "declared case name/state differs")
    parsed = urlsplit(case.get("path", ""))
    query = parse_qs(parsed.query, keep_blank_values=True)
    need(parsed.path == "circuitjs.html" and query.get("tsjQ30Coordinator") == ["true"] and
         query.get("tsjQ30Seed") == ["7"], "case does not request coordinator seed7")
    work = query.get("tsjQ30WorkProfile")
    need((work == ["true"]) if arm == "profile" else work is None,
         "case work-profile flag differs from declared arm")

    result = load(run_dir / "result.json")
    need(result.get("outcome") == "PASS" and result.get("caseCount") == 1 and
         result.get("errors") == [] and len(result.get("cases", [])) == 1,
         "compiled host runner did not PASS exactly one case")
    row = result["cases"][0]
    need(row.get("outcome") == "PASS" and row.get("case", {}).get("name") == label and
         row.get("case", {}).get("path") == case["path"] and
         row.get("terminalReached") is True and row.get("stateMatch") is True and
         row.get("observedState") == "PASS:complete" and row.get("reportObserved") is True and
         row.get("reportJsonValid") is True and row.get("reportMatch") is True and
         row.get("timedOut") is False, "host case did not observe declared PASS:complete")
    check_case_errors(row, label)
    cleanup = result.get("cleanup", {})
    need(cleanup.get("status") == "PASS" and cleanup.get("serverStopped") is True and
         cleanup.get("ownedSurvivors") == [] and cleanup.get("errors") == [],
         "host cleanup did not PASS with no survivors/errors")
    before, source_doc = validate_common_run(run_dir, result, arm)
    reports = sorted((run_dir / "cases").glob("*.report.json"))
    need(len(reports) == 1, "expected one raw coordinator report")
    raw = reports[0].read_bytes()
    report = load(reports[0])
    report_sha = sha(raw)
    need(row.get("reportSha256") == report_sha,
         "host-captured report SHA differs from raw bytes")
    map_name = {"control": "accepted-inputs.json",
                "profile": "profile-inputs.json",
                "candidate": "candidate-inputs.json"}[arm]
    return report, before, result, report_sha, file_sha(HERE / map_name)

def validate_profile(report, arm):
    for key in ("workProfileRequested", "stageProfileRequested"):
        if key in report:
            need(type(report[key]) is bool, "invalid profile request flag " + key)
    need(report.get("workProfileRequested", False) is (arm == "profile"),
         "workProfileRequested differs from run arm")
    need(report.get("stageProfileRequested", False) is (arm == "profile"),
         "stageProfileRequested differs from run arm")
    need(report.get("stageProfileRequested", False) is (arm == "profile"),
         "stageProfileRequested differs from run arm")
    capture_keys = ("profileCaptureFailureRequested", "profileCaptureFailureMask",
                    "profilersCleared")
    if arm == "profile":
        need(report.get("profileCaptureFailureRequested") is False and
             integer(report.get("profileCaptureFailureMask"), "capture failure mask", 0, 0) == 0 and
             report.get("profilersCleared") is True,
             "normal profile run reports capture failure or uncleared profilers")
    else:
        need(not any(key in report for key in capture_keys),
             "control report unexpectedly contains profiler-capture metadata")
    for phase in ("cold", "warm"):
        run = report[phase]
        work = run.get("solverWorkProfile")
        if arm == "profile":
            need(isinstance(work, dict) and work.get("requested") is True and
                 work.get("enabled") is True and work.get("measurementValid") is True,
                 phase + " solver work profile absent or invalid")
            for key in ("clockAnomalies", "simulationTimeAnomalies", "counterAnomalies",
                        "unbalancedOperations", "graphOverflow", "labelOverflow"):
                integer(work.get(key), phase + " work-profile " + key, 0, 0)
        else:
            need(work is None, "control report unexpectedly contains solver profile")
        stage = run.get("stageProfile")
        if report.get("stageProfileRequested", False):
            need(isinstance(stage, dict) and stage.get("protocol") == "TSJ-Q30-TWO-LANES-1"
                 and stage.get("enabled") is True and stage.get("clockAvailable") is True,
                 phase + " requested stage profile absent or disabled")
            for key in ("openScopes", "overflowScopes", "mismatchedScopes"):
                integer(stage.get(key), phase + " stage-profile " + key, 0, 0)
            need(isinstance(stage.get("timings"), list) and isinstance(stage.get("counts"), dict),
                 phase + " stage-profile timing/count shape invalid")
            for row in stage["timings"]:
                need(isinstance(row, dict) and isinstance(row.get("name"), str),
                     phase + " stage-profile timing row invalid")
                integer(row.get("calls"), phase + " stage-profile calls", 1)
                for key in ("inclusiveMs", "exclusiveMs", "maxMs"):
                    finite(row.get(key), phase + " stage-profile " + key)
        else:
            need(stage is None, phase + " stage profile exists although not requested")

def proof_projection(report):
    value = copy.deepcopy(report)
    for key in ("totalElapsedMs", "phaseElapsedMs", "workProfileRequested",
                "stageProfileRequested", "profileCaptureFailureRequested",
                "profileCaptureFailureMask", "profilersCleared"):
        value.pop(key, None)
    timings = ("elapsedMs", "wallElapsedMs", "maxAdvanceMs", "maxManualUnitMs",
               "routingElapsedMs", "proofElapsedMs", "cleanupElapsedMs",
               "stageProfile", "solverWorkProfile", "monotonicJobElapsedMs")
    for phase in ("cold", "warm"):
        run = value[phase]
        # System.identityHashCode(owner) is run-local; the independent reader
        # has already checked freshOwner, integer identity, and cold != warm.
        run.get("owner", {}).pop("ownerIdentity", None)
        for key in timings:
            run.pop(key, None)
        for stage in run.get("stages", []):
            stage.pop("elapsedMs", None)
        for timing in run.get("diagnosticWorkTimings", []):
            timing.pop("elapsedMs", None)
            timing.pop("maxUnitMs", None)
        run.get("owner", {}).get("diagnosticProof", {}).pop("elapsedMillis", None)
    return value

def diff_path(a, b, path="$"):
    if type(a) is not type(b):
        return path
    if isinstance(a, dict):
        if set(a) != set(b):
            return path + " (keys)"
        for key in sorted(a):
            found = diff_path(a[key], b[key], path + "." + key)
            if found:
                return found
    elif isinstance(a, list):
        if len(a) != len(b):
            return path + " (length)"
        for i, (x, y) in enumerate(zip(a, b)):
            found = diff_path(x, y, path + "[" + str(i) + "]")
            if found:
                return found
    elif a != b:
        return path
    return None

def next_path(path):
    if not path.exists():
        return path
    index = 2
    while True:
        candidate = path.with_name(path.stem + "-" + str(index).zfill(3) + path.suffix)
        if not candidate.exists():
            return candidate
        index += 1

def validate_scope_loss():
    run_dir = ROOT / "profile-canaries"
    spec = load(HERE / "profile-canaries.json")
    need(spec == load(run_dir / "spec.json"), "profile-canary copied spec mismatch")
    cases = spec.get("cases", [])
    need(len(cases) == 3 and cases[0].get("name") == "profile-a07" and
         cases[0].get("expectedState") == "PASS:a07" and
         cases[1].get("name") == "profile-scope-loss" and
         cases[1].get("expectedPrefix") == "FAIL:" and
         cases[2].get("name") == "profile-capture-failure" and
         cases[2].get("expectedPrefix") == "FAIL:cold",
         "profile-canary spec differs from the three declared cases")
    q2 = parse_qs(urlsplit(cases[1]["path"]).query, keep_blank_values=True)
    q3 = parse_qs(urlsplit(cases[2]["path"]).query, keep_blank_values=True)
    need(q2.get("tsjQ30CoordinatorScopeLoss") == ["true"] and
         q2.get("tsjQ30ProfileCaptureFailure") is None and
         q3.get("tsjQ30ProfileCaptureFailure") == ["true"] and
         q3.get("tsjQ30CoordinatorScopeLoss") is None,
         "scope-loss and capture-failure query flags are not isolated")
    result = load(run_dir / "result.json")
    rows = result.get("cases", [])
    need(result.get("outcome") == "PASS" and result.get("caseCount") == 3 and
         len(rows) == 3 and result.get("errors") == [],
         "profile-canary host runner did not pass all declared cases")
    for i, (row, declared) in enumerate(zip(rows, cases)):
        need(row.get("case", {}).get("name") == declared["name"] and
             row.get("case", {}).get("path") == declared["path"] and
             row.get("outcome") == "PASS" and row.get("stateMatch") is True and
             row.get("terminalReached") is True and row.get("reportObserved") is True and
             row.get("reportJsonValid") is True and row.get("reportMatch") is True and
             row.get("timedOut") is False, "host terminal mismatch for profile-canary row " + str(i))
        state = row.get("observedState")
        if i == 0:
            need(state == "PASS:a07", "A07 host case did not reach expected PASS")
        else:
            need(isinstance(state, str) and state.startswith(declared["expectedPrefix"]),
                 "negative host case did not reach only its declared FAIL prefix")
        check_case_errors(row, "profile-canary row " + str(i))
    cleanup = result.get("cleanup", {})
    need(cleanup.get("status") == "PASS" and cleanup.get("serverStopped") is True and
         cleanup.get("ownedSurvivors") == [] and cleanup.get("errors") == [],
         "profile-canary host cleanup failed")
    source_doc, source_map = inputs_for("profile")
    before = load(run_dir / "input-manifest-before.json")
    after = load(run_dir / "input-manifest-after.json")
    src, _ = validate_manifest(before, "profile-canary before")
    validate_manifest(after, "profile-canary after")
    need(without_capture_time(before) == without_capture_time(after) and
         {r["path"]: r["sha256"] for r in src} == source_map,
         "profile-canary runtime source/input manifest differs from frozen overlay")
    audit = result.get("inputAudit", {})
    need(audit.get("status") == "PASS" and
         audit.get("beforeSha256") == before["sha256"] == audit.get("afterSha256") and
         audit.get("sourceSha256Before") == before["sourceSha256"] == audit.get("sourceSha256After") and
         audit.get("webSha256Before") == before["webSha256"] == audit.get("webSha256After") and
         audit.get("fileCountBefore") == before["fileCount"] == audit.get("fileCountAfter"),
         "profile-canary host input audit mismatch")
    rb = load(run_dir / "runner-before.json")
    ra = load(run_dir / "runner-after.json")
    need(rb == ra and rb.get("sha256") == audit.get("runnerBeforeSha256") ==
         audit.get("runnerAfterSha256"), "profile-canary runner identity changed")
    need(result.get("identity") == load(run_dir / "identity.json"),
         "profile-canary host identity mismatch")
    reports = sorted((run_dir / "cases").glob("*.report.json"))
    need(len(reports) == 3, "profile-canary run must retain three raw reports")
    by_hash = {file_sha(path): path for path in reports}
    need(len(by_hash) == 3 and all(row.get("reportSha256") in by_hash for row in rows),
         "host report hashes are not uniquely bound to raw reports")

    scope_receipt = rows[1]
    scope_path = by_hash[scope_receipt["reportSha256"]]
    need(scope_path.name == "002-profile-scope-loss.report.json",
         "scope-loss host case is not bound to raw report 002")
    scope = load(scope_path)
    need(scope.get("profileCaptureFailureRequested") is False and
         integer(scope.get("profileCaptureFailureMask"), "scope-loss capture mask", 0, 0) == 0 and
         scope.get("profilersCleared") in (None, True),
         "scope-loss case unexpectedly injected profile capture failure")
    scope_doc = {"rows": [{"seed": "7", "previewSourceDigest": before["sourceSha256"],
                           "previewWebDigest": before["webSha256"], "report": scope}]}
    checked = check_coordinator.check_scope_loss_document(scope_doc, ["7"], self_test=True)
    expected = len(check_coordinator.scope_loss_canary_mutations(scope_doc))
    need(checked.get("failures") == [] and checked.get("canaries") == expected and expected > 0,
         "scope-loss independent reader/corruption canaries failed")

    capture_receipt = rows[2]
    capture_path = by_hash[capture_receipt["reportSha256"]]
    need(capture_path.name == "003-profile-capture-failure.report.json",
         "capture-failure host case is not bound to raw report 003")
    capture = load(capture_path)
    need(capture.get("profileCaptureFailureRequested") is True and
         integer(capture.get("profileCaptureFailureMask"), "capture failure mask", 3, 3) == 3 and
         capture.get("profilersCleared") is True and capture.get("status") == "FAIL" and
         capture.get("phase") == "cold" and capture.get("failurePhase") == "cold" and
         capture.get("restored") is True and capture.get("cleanupComplete") is True and
         capture.get("cleanupPending") is False and
         integer(capture.get("cleanupRetryCount"), "capture failure retries", 0, 0) == 0 and
         isinstance(capture.get("cold", {}).get("owner"), dict) and
         capture.get("cold", {}).get("cleanupComplete") is True and
         capture.get("cold", {}).get("ownerRestored") is True and
         capture.get("warm") == {"outcome": "NOT_RUN"},
         "capture-failure canary phase, metadata, or owner cleanup receipt invalid")
    evidence = {"status": "PASS", "label": "profile-canaries", "arm": "profile-canary",
                "sourceHead": HEAD, "scopeLossReportSha256": scope_receipt["reportSha256"],
                "captureFailureReportSha256": capture_receipt["reportSha256"],
                "sourceMapSha256": file_sha(HERE / "profile-inputs.json"),
                "sourceSha256": before["sourceSha256"], "webSha256": before["webSha256"],
                "hostOutcome": result["outcome"], "cleanupStatus": cleanup["status"],
                "scopeLossCanariesRejected": checked["canaries"],
                "captureFailure": {"phase": "cold", "mask": 3, "profilersCleared": True,
                                   "fullCoordinatorProof": "NOT CLAIMED"}}
    out = next_path(HERE / "profile-canaries-validation.json")
    out.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "evidence": out.name,
                      "scopeLossCanariesRejected": checked["canaries"],
                      "captureFailureMask": 3, "profilersCleared": True,
                      "captureFailureProof": "NOT CLAIMED"}, sort_keys=True))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("label", nargs="?", choices=LABELS)
    parser.add_argument("--compare", choices=LABELS)
    parser.add_argument("--scope-loss", action="store_true",
                        help="validate isolated profile scope-loss and capture-failure host canaries")
    args = parser.parse_args()
    if args.scope_loss:
        need(args.label is None and args.compare is None,
             "--scope-loss is separate and takes no normal-run label/pair")
        validate_scope_loss()
        return 0
    need(args.label is not None, "normal mode requires a run label")
    need(args.label != args.compare, "cannot compare a report to itself")
    plan = load(HERE / "plan.json")
    accepted = load(HERE / "accepted-inputs.json")
    decision = load(HERE / "decision.json")
    need(plan.get("status") == "predeclared" and plan.get("sourceHead") == HEAD ==
         accepted.get("head") and plan.get("limits") == LIMITS and
         plan.get("sequence") == list(LABELS)[:3] and plan.get("noPush") is True and
         decision.get("candidateSequence") == list(LABELS)[3:] and
         str(decision.get("status", "")).startswith("candidate selected for experiment"),
         "frozen plan3/decision run sequence or limits changed")
    arm = LABELS[args.label]
    report, manifest, host, report_sha, source_map_sha = validate_host(args.label, arm)
    validate_profile(report, arm)
    doc = {"rows": [{"seed": "7", "previewSourceDigest": manifest["sourceSha256"],
                     "previewWebDigest": manifest["webSha256"], "report": report}]}
    checked = check_coordinator.check_document(doc, ["7"], self_test=True)
    canaries = len(check_coordinator.canary_mutations(doc))
    need(checked.get("failures") == [] and checked.get("canaries") == canaries and canaries > 0,
         "independent cold/warm proof reader or corruption canaries failed")
    parity = None
    if args.compare:
        other_arm = LABELS[args.compare]
        other, other_manifest, _, other_sha, _ = validate_host(args.compare, other_arm)
        validate_profile(other, other_arm)
        other_doc = {"rows": [{"seed": "7", "previewSourceDigest": other_manifest["sourceSha256"],
                               "previewWebDigest": other_manifest["webSha256"], "report": other}]}
        other_check = check_coordinator.check_document(other_doc, ["7"], self_test=True)
        other_canaries = len(check_coordinator.canary_mutations(other_doc))
        need(other_check.get("failures") == [] and other_check.get("canaries") == other_canaries,
             "comparison report proof/corruption checks failed")
        projection = proof_projection(report)
        other_projection = proof_projection(other)
        mismatch = diff_path(projection, other_projection)
        if mismatch is not None:
            failed = {"status": "FAIL", "left": args.label, "right": args.compare,
                      "leftReportSha256": report_sha, "rightReportSha256": other_sha,
                      "mismatch": mismatch,
                      "leftValue": report["cold"]["owner"]["ownerIdentity"]
                          if mismatch == "$.cold.owner.ownerIdentity" else None,
                      "rightValue": other["cold"]["owner"]["ownerIdentity"]
                          if mismatch == "$.cold.owner.ownerIdentity" else None,
                      "reason": "cross-run owner identities differ before their narrowly authorized exclusion"}
            failed_path = next_path(HERE / (args.label + "-vs-" + args.compare + "-parity-failure.json"))
            failed_path.write_text(json.dumps(failed, sort_keys=True, indent=2) + "\n", encoding="utf-8")
            need(False, "non-timing proof parity mismatch at " + str(mismatch))
        parity = {"status": "PASS", "left": args.label, "right": args.compare,
                  "leftReportSha256": report_sha, "rightReportSha256": other_sha,
                  "projectionSha256": sha(canonical(projection)),
                  "normalizationAmendment": {
                    "kind": "cross-run opaque owner identity",
                    "source": "src/com/lushprojects/circuitjs1/client/Q30CoordinatorQualificationVerifier.java:1003",
                    "expression": "System.identityHashCode(owner)",
                    "checksBeforeProjection": [
                      "each raw report independently requires freshOwner=true and integer ownerIdentity",
                      "each raw report independently requires cold.ownerIdentity != warm.ownerIdentity",
                      "independent checker self-test rejects a cold/warm owner-identity collision"
                    ],
                    "rawReportValuesRetained": True,
                    "excludedProjectionPaths": ["cold.owner.ownerIdentity", "warm.owner.ownerIdentity"],
                    "reason": "opaque runtime object identities differ across executions and carry no canonical proof meaning"
                  },
                  "removedPaths": ["totalElapsedMs", "phaseElapsedMs",
                    "cold/warm elapsedMs, wallElapsedMs, maxAdvanceMs, maxManualUnitMs, routingElapsedMs, proofElapsedMs, cleanupElapsedMs",
                    "cold/warm stages[].elapsedMs", "cold/warm diagnosticWorkTimings[].elapsedMs/maxUnitMs",
                    "cold/warm owner.diagnosticProof.elapsedMillis", "cold/warm stageProfile",
                    "cold/warm solverWorkProfile", "cold/warm monotonicJobElapsedMs",
                    "workProfileRequested", "stageProfileRequested",
                    "profileCaptureFailureRequested", "profileCaptureFailureMask", "profilersCleared",
                    "cold.owner.ownerIdentity", "warm.owner.ownerIdentity"]}
        out = next_path(HERE / (args.label + "-vs-" + args.compare + "-parity.json"))
        out.write_text(json.dumps(parity, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    source_map_file = {"profile": "profile-inputs.json", "candidate": "candidate-inputs.json"}.get(arm, "accepted-inputs.json")
    evidence = {"status": "PASS", "label": args.label, "arm": arm, "seed": "7",
                "sourceHead": HEAD, "reportSha256": report_sha,
                "sourceMapSha256": source_map_sha,
                "runtimeManifestSha256": manifest["sha256"],
                "sourceSha256": manifest["sourceSha256"], "webSha256": manifest["webSha256"],
                "hostOutcome": host["outcome"], "cleanupStatus": host["cleanup"]["status"],
                "proofReader": {"status": "PASS", "hypotheses": 5,
                                "samplesPerHypothesis": 37, "observations": 185,
                                "hypothesisPairCount": checked["pairCount"],
                                "canariesRejected": checked["canaries"]},
                "sourceMap": source_map_file,
                "profileMetadata": {"workProfileRequested": report.get("workProfileRequested", False),
                                    "stageProfileRequested": report.get("stageProfileRequested", False),
                                    "profileCaptureFailureRequested":
                                        report.get("profileCaptureFailureRequested", False),
                                    "profileCaptureFailureMask":
                                        report.get("profileCaptureFailureMask", 0),
                                    "profilersCleared": report.get("profilersCleared")},
                "parity": parity["status"] if parity else "NOT RUN"}
    out = next_path(HERE / (args.label + "-validation.json"))
    out.write_text(json.dumps(evidence, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "evidence": out.name, "reportSha256": report_sha,
                      "sourceSha256": manifest["sourceSha256"], "webSha256": manifest["webSha256"],
                      "sourceMapSha256": source_map_sha, "proofHypotheses": 5,
                      "samplesPerHypothesis": 37, "observations": 185,
                      "hypothesisPairCount": checked["pairCount"],
                      "canariesRejected": checked["canaries"],
                      "parity": parity["status"] if parity else "NOT RUN"}, sort_keys=True))
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (Invalid, check_coordinator.ReceiptError, KeyError, TypeError, AssertionError) as exc:
        print("FAIL: " + str(exc), file=sys.stderr)
        raise SystemExit(1)
