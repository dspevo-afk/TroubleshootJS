# Q30 two-lane profile: seed-7 findings

This is a private diagnostic interpretation of one accepted plan-3 seed-7 run at source HEAD `3a87772` (33/35/37). It is not an archive or a production performance claim. No 40-package scale case is represented. The primitive branch-map experiment is a separate, still-unproven candidate; this profile does not measure it.

## Cold-run comparison

The outer run fields partition each cold run into routing, proof, and the arithmetic remainder. The remainder is not a named subsystem. Work totals were identical in all three runs (468 total / 390 hypothesis units); source and input hashes were stable within each run, and all runs passed cleanup.

| Run | Cold elapsed | Routing | Proof | Unclassified remainder | Max advance |
|---|---:|---:|---:|---:|---:|
| 01 control | 79,020 ms | 16,661 ms | 57,262 ms | 5,097 ms | 928 ms |
| 02 two-lane profile | 79,433 ms | 16,647 ms | 57,670 ms | 5,116 ms | 908 ms |
| 03 control | 76,978 ms | 16,363 ms | 55,610 ms | 5,005 ms | 892 ms |

The initial control range is 2,042 ms (three times that range is 6,126 ms). The candidate experiment separately declares rows04/07 as its surrounding controls; all control rows also enter a wider sensitivity check. The profile run is 413 ms slower than control01 and 2,455 ms slower than control03. This single profile run does not isolate profiler overhead from run-to-run variation. The cold coordinator elapsed (79,433 ms) differs by 6.8 ms from the profile's 79,439.8 ms monotonic-job timer; retain both as different boundaries.

## Lane A — solver work

The actual counters report 1,350,575 trial/nonlinear trials, 617,983 accepted steps, zero retries and convergence failures, and 3.089915 s of simulated time. There were 502 analyses/stampCircuit calls; 732,592 factor calls and the same number of solves; 75,122,038 doStep calls; 617,983 wire refreshes; and 732,592 publications. Matrix copies covered 6,900,056,544 slots (6,804,242,916 LHS and 95,813,628 RHS). Maximum observed matrix size was 88 with 247 elements.

The owned duration-advance operation is about55.15s (profile stage55,147.2ms; solver summary55,145.3ms), plus UI run123.6ms and analyze1,412.7ms at the solver operation boundary. The nested inner timers are factor21,856.1ms; matrix copy5,841.0ms; publication8,804.8ms; solve5,948.3ms; wire refresh5,855.0ms; doStep4,452.5ms; stampCircuit143.6ms. Do not add inner timers to their enclosing operations. `stampCircuit` may include **linear** factorization (`CirSim.java:2854`); all732,592 measured factors were nonlinear and occur in `runCircuitOwned` (`CirSim.java:3429`). Thus the factor total exceeding stampCircuit is expected, not an instrumentation inconsistency. Full stage-analyze timing1,417.7ms includes wrapper overhead and has a different boundary from solver-operation analyze.

The largest purpose rows were candidate healthy settle (150,105 steps; 0.750525 simulated seconds; 13,596.9 ms), repair-status settle (120,105; 0.600525 s; 11,209.9 ms), customer retest (120,000; 0.6 s; 11,192.3 ms), and input observations (120,420; 0.6021 s; 10,121.8 ms). These purpose timings sit within the phase/job instrumentation; they are not an additional bill on top of the solver and proof totals.

## Lane B — routing work

All six placement attempts were accepted. The raw canonical physical-admission report selects **P07_FULLER_TWO_LAYER, placement2**, ranked second in `[5,2,3,4,1,0]`; placement5 also routed successfully but was not selected. Full non-timing profile/control report parity passes after validating and excluding only the per-run opaque owner hashes alongside declared timing/profile metadata. Actual route geometry/context and electrical proof fields remain compared.

P07 rejected passes consumed8,811.0ms and875,841 expansions. Successful-but-unselected placement5 pass1 consumed2,931.0ms and261,310 expansions. The final selected placement2 pass1 consumed3,337.5ms and311,078 expansions. Thus1,137,151 expansions and11,742.0ms were outside the final selected successful pass. These pass-work timers include setup/publishing overhead, not only A* expansion. They describe deterministic selection cost; they do not prove those candidates may safely be skipped. The copper-blind placement access check already ran before search; the later compact-outline access result depends on actual routed bounds, so exact earlier rejection from immutable placement is not established.

| Router slice | Work and attempts | Per-net expansion leaders | Discarded-work interpretation |
|---|---|---|---|
| P05 one-face | 3,000,000 expansions over 164 net attempts; 16 reroutes; 13 rejected passes; 3 candidates started and 3 rejected. | RAIL5: 16 attempts / 931,359; CTRL_RETURN: 12 / 480,152; RAIL12: 11 / 328,468; B_SENSE: 7 / 291,890. | `discarded-expansions` is 3,000,000; `discarded-partial-net-expansions` is 1,250,430 and overlaps rejected-pass work. Do not add them. |
| P07 two-layer | 1,448,229 expansions; 3 candidates started (2 succeeded, 1 rejected), 7 passes (2 succeeded, 5 rejected); 265 successful branches and 5 rejected branches. | RAIL5: 39 branch searches / 557,458; B_COIL_LOW: 8 / 370,458; LOAD12: 10 / 126,208; A_COIL_LOW: 10 / 117,522. These 22 per-net counters sum to the total. | Raw `discarded-expansions` 1,217,703 double-counts 341,862 from failed candidate 3. Unique rejected-pass work is 875,841 of 1,448,229 total. Failed-branch count (500,000) overlaps; do not add it. |

P07's inclusive slice was 15,079.7 ms. Its recorded coarse sibling buckets were A* expansion 14,350.8 ms, branch setup 666.6 ms, net-preparation exclusive 40.8 ms, pass setup 7.4 ms, and publisher 13.0 ms (15,078.6 ms combined, subject to timer-boundary rounding). `routing.two-layer-slice` was 15,206.3 ms inclusive. P07 performed 8,027,604 best-map gets, 2,538,101 puts, 6,353,497 offers, and 225,873 stale polls. These counts motivate testing the branch-local primitive-key map; they do not establish that map operations dominate A* time. P05 A* (826.8 ms) is nested within branch-route timing (1,542.6 ms inclusive / 715.8 ms exclusive); those P05 rows also must not be summed as independent time.

## Limits and decision

The measured evidence is seed7 / plan3 only; there is no40-package scale evidence. The fresh normal-policy native suite passed325 assertions. The separate compiled normal-disabled verifier belongs to unaccepted scale source and was not imported or run. Full acceptance remains intentionally unrun; a private300-second coordinator measurement does not establish normal-player corpus admission. Preserve the normal caps of90,000ms,640units and5,000ms and normal Q30 disablement.

The next primitive-map trial remains unaccepted and must meet the predeclared paired cold-run rule, complete proof/order/route/physical-context parity, and fresh correctness/cleanup gates before any integration claim. Nothing here identifies a safely removable solver cost or justifies caching, a route shortcut, or an expected speedup.
