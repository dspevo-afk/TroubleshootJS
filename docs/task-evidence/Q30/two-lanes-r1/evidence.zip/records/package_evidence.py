"""Rebuild the task's explicitly selected evidence packet; never copies worktrees."""
from pathlib import Path
import hashlib,json,zipfile,re,sys
r=Path(__file__).resolve().parent.parent
dest=Path(sys.argv[1]);dest.mkdir(parents=True,exist_ok=True)
skip={'old-instrumentation.patch','report-before.md','profile-summary.json','initial-worktrees.json','verify_archive.py'}
selected=[]
for p in (r/'records').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and 'pre-build-repairs' not in p.parts and p.name not in skip:
  selected.append((p,p.relative_to(r).as_posix()))
for folder in sorted(r.iterdir()):
 if folder.is_dir() and (re.match(r'^\d\d-',folder.name) or folder.name in ['control-canaries','profile-canaries','candidate-canaries']):
  for p in list(folder.glob('*'))+list((folder/'cases').glob('*')):
   if p.is_file() and p.suffix in ['.json','.txt','.log']:
    selected.append((p,p.relative_to(r).as_posix()))
base=json.loads((r/'records/accepted-inputs.json').read_text())
for arm in ['profile','candidate']:
 frozen=json.loads((r/('records/'+arm+'-inputs.json')).read_text())
 for name,digest in frozen['files'].items():
  if digest!=base['files'].get(name):
   p=r/arm/name
   assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,(arm,name)
   selected.append((p,'overlays/'+arm+'/'+name))
def sanitize(data):
 text=data.decode('utf-8')
 # Match raw text and JSON-escaped Windows separators, without altering proof fields.
 text=text.replace(str(r).replace('\\','\\\\'),'<TASK>')
 text=text.replace(str(r),'<TASK>').replace(r.as_posix(),'<TASK>')
 text=re.sub(r'C:(?:\\\\|\\|/)Users(?:\\\\|\\|/)david', '<USER>',text,flags=re.I)
 # Some PowerShell failure lines wrapped inside the former temp path.
 text=text.replace('<TASK-ID>','<TASK-ID>')
 return text.encode('utf-8')
items={};manifest=[]
for p,name in sorted(selected,key=lambda x:x[1]):
 raw=p.read_bytes();clean=sanitize(raw)
 assert name not in items,name
 if p.name.endswith('.report.json') or name.startswith('overlays/'):
  assert raw==clean,('raw report unexpectedly needs sanitation',name)
 items[name]=clean
 manifest.append({'path':name,'rawSha256':hashlib.sha256(raw).hexdigest(),
  'archiveSha256':hashlib.sha256(clean).hexdigest(),'bytes':len(clean),'sanitized':raw!=clean})
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in items.items():
  entry=zipfile.ZipInfo(name,(2026,9,28,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(entry,data)
receipt={'schema':1,'sourceHead':base['head'],'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'sanitation':'Task and user absolute paths replaced with placeholders; raw proof report bytes unchanged. Raw and archived hashes retained.',
 'entries':manifest}
(dest/'archive-manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'entries':len(manifest),'zipBytes':archive.stat().st_size,'sha256':receipt['archiveSha256']}))
