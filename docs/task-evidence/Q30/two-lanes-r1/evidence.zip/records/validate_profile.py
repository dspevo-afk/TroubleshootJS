from pathlib import Path
import json,math,copy,sys

def need(x,msg):
 if not x:raise ValueError(msg)
def number(x,label):
 need(type(x) in [int,float] and math.isfinite(x) and 0<=x<2**53,label)
def validate(doc):
 need(doc['workProfileRequested'] is True and doc['stageProfileRequested'] is True,'request flags')
 for phase in ['cold','warm']:
  r=doc[phase]; p=r['solverWorkProfile'];s=r['stageProfile']
  need(p['enabled'] is True and s['enabled'] is True,'enabled')
  need(p['measurementValid'] is True,'valid measurement')
  for k in ['clockAnomalies','simulationTimeAnomalies','counterAnomalies','unbalancedOperations','graphOverflow','labelOverflow']:need(p[k]==0,phase+'.'+k)
  for k in ['openScopes','overflowScopes','mismatchedScopes']:need(s[k]==0,phase+'.'+k)
  for k in ['trialAttempts','nonlinearTrials','acceptedSteps','stepRetries','convergenceFailures','analysisCalls','stampCircuitCalls','factorCalls','solveCalls','runCalls','doStepCalls','matrixCopySlots','rhsCopySlots','lhsCopySlots']:
   number(p[k],k);need(p[k]==int(p[k]),k+' integer')
  need(p['acceptedSteps']>0 and p['factorCalls']>0,'real work')
  need(p['factorCalls']<=p['trialAttempts']+p['stampCircuitCalls'],'factor count')
  need(p['nonlinearTrials']<=p['trialAttempts'],'nonlinear subset')
  need(p['matrixCopySlots']==p['rhsCopySlots']+p['lhsCopySlots'],'copy partition')
  for name in ['matrixCopy','doStep','factor','solve','publication','wireRefresh','stampCircuit']:
   row=p[name];number(row['totalMs'],name);number(row['maxMs'],name);need(row['maxMs']<=row['totalMs']+.001,name+' max')
  need(sum(x['acceptedSteps'] for x in p['byProofLabel'])==p['acceptedSteps'],'label steps')
  need(abs(sum(x['timeAdvanced'] for x in p['byProofLabel'])-p['timeAdvanced'])<1e-6,'label time')
  need(len({x['name'] for x in s['timings']})==len(s['timings']),'unique stage names')
  for row in s['timings']:
   for k in ['calls','inclusiveMs','exclusiveMs','maxMs']:number(row[k],row['name']+k)
   need(row['calls']>0 and row['calls']==int(row['calls']),'stage calls')
   need(row['exclusiveMs']<=row['inclusiveMs']+.001 and row['maxMs']<=row['inclusiveMs']+.001,'nested timing')
  for k,v in s['counts'].items():number(v,k)
 return True

def main():
 path=Path(sys.argv[1]); doc=json.loads(path.read_text());validate(doc)
 mutations=[lambda d:d.update(workProfileRequested=False),lambda d:d['cold']['solverWorkProfile'].update(unbalancedOperations=1),lambda d:d['cold']['stageProfile'].update(openScopes=1),lambda d:d['cold']['solverWorkProfile'].update(labelOverflow=1),lambda d:d['cold']['solverWorkProfile'].update(matrixCopySlots=-1),lambda d:d['cold']['solverWorkProfile'].update(acceptedSteps=1),lambda d:d['cold']['stageProfile']['timings'][0].update(exclusiveMs=1e20)]
 mutations.extend([lambda d:d['cold']['solverWorkProfile'].update(measurementValid=False),lambda d:d['warm']['solverWorkProfile'].update(simulationTimeAnomalies=1)])
 for f in mutations:
  altered=copy.deepcopy(doc);f(altered)
  try:validate(altered)
  except (ValueError,KeyError):continue
  raise AssertionError('corruption accepted')
 print(json.dumps({'status':'PASS','metadataNegatives':len(mutations),'phases':2}))
if __name__=='__main__':main()
