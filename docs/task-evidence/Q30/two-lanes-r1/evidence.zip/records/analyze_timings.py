from pathlib import Path
import json
r=Path(__file__).resolve().parent
labels=['01-control-seed7','02-two-lane-profile-seed7','03-control-seed7','04-control-seed7','05-candidate-seed7','06-candidate-seed7','07-control-seed7']
rows=[json.loads((r/(name+'-summary.json')).read_text()) for name in labels]
assert all(x['exitCode']==0 and x['outcome']=='PASS' and x['cleanup']['status']=='PASS' and x['inputAudit']['status']=='PASS' for x in rows)
def field(i,phase='cold',key='elapsedMs'):return rows[i][phase][key]
local=abs(field(3)-field(6));all_control=[field(i) for i in [0,2,3,6]]
span=max(all_control)-min(all_control);threshold=max(1000,3*local)
savings=[field(3)-field(4),field(6)-field(5)]
out={'status':'MEASURED','sequence':labels,'localControlRangeMs':local,'allControlRangeMs':span,
 'predeclaredThresholdMs':threshold,'fullRangeSensitivityThresholdMs':max(1000,3*span),
 'pairedColdSavingsMs':savings,'predeclaredColdRulePass':all(x>threshold for x in savings),
 'savingsExceedFullControlRange':all(x>span for x in savings),
 'pairedRoutingSavingsMs':[field(3,key='routingElapsedMs')-field(4,key='routingElapsedMs'),field(6,key='routingElapsedMs')-field(5,key='routingElapsedMs')],
 'pairedProofSavingsMs':[field(3,key='proofElapsedMs')-field(4,key='proofElapsedMs'),field(6,key='proofElapsedMs')-field(5,key='proofElapsedMs')],
 'pairedWarmSavingsMs':[field(3,'warm')-field(4,'warm'),field(6,'warm')-field(5,'warm')],
 'limits':[90000,640,5000],
 'rows':[{'label':x['label'],'cold':x['cold'],'warm':x['warm'],'outerSeconds':x['outerSeconds'],'cleanupSeconds':x['cleanup']['seconds']} for x in rows]}
(r/'timing-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
