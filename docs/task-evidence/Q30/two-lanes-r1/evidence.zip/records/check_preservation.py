from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
initial=json.loads((r/'initial-worktrees.json').read_text())
roots={'q30':Path(sys.argv[1]),'desktop':Path(sys.argv[2])}
out={}
for name,root in roots.items():
 before=initial[name]
 hashes=before.get('files',before.get('hashes'))
 assert isinstance(hashes,dict),before.keys()
 changed=[]
 for relative,digest in hashes.items():
  p=root/relative
  if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:changed.append(relative)
 assert not changed,(name,changed)
 def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true',*args],cwd=root,text=True).strip()
 assert git('branch','--show-current')==before['branch']
 out[name]={'status':'PASS','preservedFileCount':len(hashes),'branch':before['branch'],
  'head':git('rev-parse','HEAD'),'initialHead':before['head'],
  'unchangedFiles':hashes,'indexTree':git('write-tree')}
(r/'preservation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({name:{k:v for k,v in row.items() if k!='unchangedFiles'} for name,row in out.items()}))
