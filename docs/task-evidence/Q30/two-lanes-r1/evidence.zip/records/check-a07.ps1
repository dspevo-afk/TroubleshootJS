param([string]$Repository,[string]$Report)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $Repository 'scripts/VerifierIsolation.psm1') -Force
$tokens=$null; $errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $Repository 'scripts/verify-a03-browser.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count -gt 0){throw 'Reader AST parse failed'}
$defs=$ast.FindAll({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst]},$false)
. ([scriptblock]::Create(($defs | ForEach-Object {$_.Extent.Text}) -join [Environment]::NewLine))
$raw=Get-Content -LiteralPath $Report -Raw -Encoding UTF8
if(-not (Test-A07Report $raw)){throw 'Positive A07 report failed'}
foreach($kind in 1..3){
 $value=$raw|ConvertFrom-Json
 if($kind -eq 1){$value.status='FAIL'}
 if($kind -eq 2){$value.cleanup='FAIL'}
 if($kind -eq 3){$value.runtimeCases[0].status='FAIL'}
 if(Test-A07Report ($value|ConvertTo-Json -Depth 100 -Compress)){throw "Negative accepted $kind"}
}
Write-Output 'PASS: exact maintained Test-A07Report with three corruption negatives'
