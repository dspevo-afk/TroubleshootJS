package com.lushprojects.circuitjs1.client;
public final class MediumBoardPhysicalPolicyContractTest {
    public static void main(String[] args) {
        long[] roots = new long[] {8L,4L,10000L,10L};
        String[] canonical = new String[] {"rb30-plan@4;seed=8;topology=RB30_CH2_SHARED_DIRECT_A_NMOS_B_BJT;support=C12:false,S5:false,S12:false,filters:0,outputIndicators:1,bleeder5:false;layout=1789953187444160285;routing=-8500271482997274880;physicalPolicy=MEDIUM_BOARD@1;fault=SENSOR_A_OPEN;packages=32;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated","rb30-plan@4;seed=4;topology=RB30_CH2_SHARED_DIRECT_A_BJT_B_NMOS;support=C12:true,S5:false,S12:false,filters:1,outputIndicators:2,bleeder5:false;layout=-7967780441668740599;routing=4321422998255155060;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=34;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated","rb30-plan@4;seed=10000;topology=RB30_CH2_SHARED_HYSTERETIC_A_NMOS_B_NMOS;support=C12:false,S5:false,S12:false,filters:1,outputIndicators:1,bleeder5:true;layout=-5582834733033270822;routing=-7232503086477951915;physicalPolicy=MEDIUM_BOARD@1;fault=RELAY_B_COIL_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated","rb30-plan@4;seed=10;topology=RB30_CH2_SEPARATE_DIRECT_A_BJT_B_NMOS;support=C12:false,S5:false,S12:false,filters:3,outputIndicators:1,bleeder5:false;layout=-5437028946546985473;routing=6161596101315970262;physicalPolicy=MEDIUM_BOARD@1;fault=DREV_OPEN;packages=36;main=12V;regulator=5V-E02;coil=5V-E03;load=isolated-12V-180ohm-per-channel;channels=2;sensors=2-E04-decisions;sensorPullDowns=RPIN_A:1000ohm(A_RAW,CTRL_RETURN),RPIN_B:1000ohm(B_RAW,CTRL_RETURN);loadReference=isolated"};
        int failed=0;
        for(int index=0;index<roots.length;index++) {
            Rb30Plan plan=Rb30Plan.resolve(roots[index]);
            if(!plan.canonical().equals(canonical[index])) throw new AssertionError("Frozen original plan identity changed: "+roots[index]);
            System.out.println("Q30_FROZEN_ROUTE_START root="+roots[index]+" canonical="+plan.canonical());
            TroubleshootBoard board=plan.board();
            MediumBoardPhysicalPolicy.Result result=new SeededPcbLayoutGenerator().generateWithPolicyResult(board,plan.layoutSeed,plan.routingSeed,new SeededPcbLayoutGenerator.AttemptObserver(){public void check(int attempt){}});
            System.out.println("Q30_FROZEN_ROUTE_RESULT root="+roots[index]+" accepted="+result.accepted()+" receipt="+result.toCanonical());
            if(result.accepted()) {
                result.getLayout().validateGeometry(board);
                new PcbTwoLayerRules(board,result.getLayout()).validate(result.getLayout());
                if(result.getLayout().getComponents().size()!=plan.physicalPackageCount() || result.getLayout().getPads().size()!=board.getPadIds().size()) throw new AssertionError("Original endpoint mapping lost");
            } else failed++;
        }
        if(failed>0) throw new AssertionError("Original frozen plans rejected: "+failed);
        System.out.println("PASS: medium physical policy contracts originalPlans=4");
    }
}
