"""Review the completed original cold corpus without launching an app or changing inputs."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

workspace = Path(__file__).resolve().parent
pointer = json.loads((workspace / 'epoch15-task-pointer.json').read_text(encoding='utf-8'))
task = Path(pointer['taskRoot'])
repo = Path(r'<repo>')
destination = task / 'cold77-audit.json'
assert not destination.exists(), 'Preserve the existing audit; use a new name for any follow-up'
started = time.monotonic()
record = {'schema': 1, 'startedUtc': datetime.now(timezone.utc).isoformat(),
          'status': 'RUNNING', 'reviewScope': 'Completed cold77 reports, exact frozen inputs, cleanup and cohort linkage',
          'files': [], 'rows': []}

def raw(path):
    data = path.read_bytes()
    record['files'].append({'path': str(path.relative_to(task)) if path.is_relative_to(task) else str(path),
                            'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)})
    return data

def doc(path):
    data = raw(path)
    return json.loads(data), data

def require(condition, message):
    if not condition:
        raise AssertionError(message)

try:
    acceptance_path = task / 'acceptance-plan.json'
    acceptance, acceptance_raw = doc(acceptance_path)
    plan, plan_raw = doc(task / 'scale-plan.json')
    snapshot, snapshot_raw = doc(task / 'isolated/source-snapshot.json')
    require(hashlib.sha256(acceptance_raw).hexdigest() == pointer['continuedPlanSha256'], 'Continued acceptance bytes changed')
    require(plan['acceptancePlanSha256'] == pointer['continuedPlanSha256'], 'Frozen plan acceptance hash changed')
    require(plan['serviceAndSensitivitySeeds'] == acceptance['serviceAndSensitivitySeeds'], 'Copied service metadata differs')
    require(len(acceptance['serviceAndSensitivitySeeds']) == 21, 'Frozen service cohort count changed')
    require(plan['sourceIdentity'] == snapshot['sourceIdentity'] == pointer['sourceIdentity'], 'Source identity changed')
    require(plan['sourceSnapshotSha256'] == hashlib.sha256(snapshot_raw).hexdigest(), 'Source snapshot bytes changed')
    require(plan['sourceFiles'] == snapshot['files'] and len(snapshot['files']) == 1354, 'Source inventory changed')
    for row in snapshot['files']:
        data = (repo / row['path']).read_bytes()
        require(len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'Consumed source changed: ' + row['path'])
    record['sourceInputsVerified'] = len(snapshot['files'])
    record['sourceIdentity'] = snapshot['sourceIdentity']
    record['acceptancePlanSha256'] = hashlib.sha256(acceptance_raw).hexdigest()
    record['frozenPlanSha256'] = hashlib.sha256(plan_raw).hexdigest()
    git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo)]
    record['observedHead'] = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
    require(subprocess.run(git + ['merge-base', '--is-ancestor', plan['baseHead'], record['observedHead']], capture_output=True).returncode == 0,
            'Current checkpoint does not descend from frozen source base')
    record['candidateBaseHead'] = plan['baseHead']
    module_path = repo / 'tests/qualification/q30-scale-acceptance/q30_scale_reader.py'
    record['readerSha256'] = hashlib.sha256(module_path.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location('epoch15_strict_reader', module_path)
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    reader.validate_plan(plan, plan_raw, acceptance_path)
    sequences = []
    directories = ['cold-pilot', 'cold-rest']
    for directory in directories:
        sequence, _ = doc(task / directory / 'sequence.json')
        require(sequence['state'] == 'COMPLETED', 'Sequence incomplete: ' + directory)
        sequences.append(sequence)
        stage, _ = doc(task / (directory + '-result.json'))
        require(stage['exitCode'] == 0, 'Stage wrapper failed: ' + directory)
    rows = [row for sequence in sequences for row in sequence['rows']]
    require(len(rows) == 77 and [row['rootSeed'] for row in rows] == plan['coldOrder'], 'Frozen order/count changed')
    require([row['index'] for row in rows] == list(range(1, 78)), 'Cold index order changed')
    by_seed = {case['seed']: case for case in plan['cases']}
    published_counts = Counter()
    for position, row in enumerate(rows):
        directory = directories[0] if position < 3 else directories[1]
        slug = f"{row['index']:03d}-seed{row['rootSeed']}"
        output = task / directory / slug
        report, report_raw = doc(output / 'cases' / ('001-cold-' + row['rootSeed'] + '.report.json'))
        host, _ = doc(output / 'result.json')
        saved_reader, _ = doc(task / directory / (slug + '-reader.json'))
        evaluated = reader.evaluate(report, report_raw, plan, plan_raw, host, acceptance_path)
        require(row['hostExitCode'] == row['readerExitCode'] == 0, 'Case process nonpass: ' + slug)
        require(row['status'] == saved_reader['status'] == evaluated['status'] == 'APP_PASS', 'Application reader nonpass: ' + slug)
        require(evaluated['host']['status'] == row['hostStatus'] == 'HOST_PASS', 'Host nonpass: ' + slug)
        require(evaluated['app'] == saved_reader['app'] and evaluated['host'] == saved_reader['host'], 'Fresh reader differs from captured result: ' + slug)
        require(evaluated['app']['metrics'] == row['metrics'], 'Sequence metrics differ: ' + slug)
        cleanup = host['cleanup']
        require(cleanup == row['cleanup'] and cleanup['status'] == 'PASS' and cleanup['serverStopped'] is True and
                not cleanup['ownedSurvivors'] and not cleanup['errors'], 'Cleanup incomplete: ' + slug)
        published = [candidate['ordinal'] for candidate in report['candidates'] if candidate.get('published') is True]
        require(len(published) == 1, 'Publication ambiguity: ' + slug)
        candidate = by_seed[row['rootSeed']]['candidates'][published[0]]
        published_counts[candidate['packages']] += 1
        record['rows'].append({'index': row['index'], 'rootSeed': row['rootSeed'], 'status': 'APP_PASS',
                               'hostStatus': 'HOST_PASS', 'metrics': row['metrics'], 'cleanup': cleanup,
                               'publishedCandidate': published[0], 'publishedPackages': candidate['packages'],
                               'publishedChannels': candidate['channels']})
    require(set(published_counts) == set(range(20, 41)), 'Published cohort does not cover every20-40 package size')
    record['count'] = 77
    record['maxElapsedMs'] = max(row['metrics']['elapsedMs'] for row in rows)
    record['worstRoots'] = [row['rootSeed'] for row in rows if row['metrics']['elapsedMs'] == record['maxElapsedMs']]
    record['minHeadroomMs'] = min(row['metrics']['headroomMs'] for row in rows)
    record['maxWork'] = max(row['metrics']['workUnits'] for row in rows)
    record['maxActiveOperationMs'] = max(row['metrics']['maxActiveOperationMs'] for row in rows)
    record['maxCoordinatorAdvanceMs'] = max(row['metrics']['maxCoordinatorAdvanceMs'] for row in rows)
    record['publishedPackageHistogram'] = dict(sorted(published_counts.items()))
    record['cleanupSecondsTotal'] = sum(row['cleanup']['seconds'] for row in rows)
    record['cleanupSecondsMaximum'] = max(row['cleanup']['seconds'] for row in rows)
    record['status'] = 'PASS'
except Exception as error:
    record['status'] = 'FAIL'
    record['error'] = str(error)
finally:
    record['finishedUtc'] = datetime.now(timezone.utc).isoformat()
    record['reviewElapsedSeconds'] = time.monotonic() - started
    destination.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in record.items() if k not in {'files', 'rows'}}, indent=2))
sys.exit(0 if record['status'] == 'PASS' else 1)
