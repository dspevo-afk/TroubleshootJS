"""Fresh compiled31 or disabled-menu check on the audited unchanged shipping build."""
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('stage', choices=['compiled31', 'disabled-menu'])
args = parser.parse_args()
host_python = r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe'
workspace = Path(__file__).resolve().parent
repo = Path(r'$REPO')
binding = json.loads((workspace / 'epoch15-task-pointer.json').read_text(encoding='utf-8'))
task = Path(binding['taskRoot'])
shipping = task / 'shipping/app'
build_receipt = task / 'shipping-build-result.json'
frozen_task = Path(r'$OS_TEMP\q30-finish-0fa2512465')
assert importlib.metadata.version('playwright') == '1.63.0', 'Use the retained pinned Playwright dependency path'
host_environment = dict(os.environ)
host_environment.update({'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONIOENCODING': 'utf-8'})
assert subprocess.check_output([host_python, '-B', '-c', "from playwright.sync_api import sync_playwright; import importlib.metadata; print(importlib.metadata.version('playwright'))"], env=host_environment, text=True).strip() == '1.63.0'
snapshot = json.loads((task / 'source-snapshot.json').read_text(encoding='utf-8'))
assert snapshot['sourceIdentity'] == binding['sourceIdentity']
assert snapshot['status'] == 'PASS' and snapshot['baseHead'] == binding['baseHead']
assert snapshot['layoutAlgorithmVersion'] == binding['layoutEpoch'] == 15
assert snapshot['q30NormalPlayerEnabled'] is False
assert len(snapshot['files']) == 1354
snapshot_paths = []
root_counts = {'src': 0, 'tests': 0, 'war': 0, 'scripts': 0}
for index, row in enumerate(snapshot['files']):
    assert isinstance(row, dict) and set(row) == {'path', 'size', 'sha256'}, 'Malformed raw source row ' + str(index)
    relative = PurePosixPath(row['path'])
    assert (not relative.is_absolute() and '\\' not in row['path'] and '..' not in relative.parts
            and ':' not in row['path'] and relative.as_posix() == row['path']), 'Unsafe raw source path: ' + str(row['path'])
    assert isinstance(row['size'], int) and not isinstance(row['size'], bool) and row['size'] >= 0
    assert re.fullmatch(r'[0-9a-f]{64}', row['sha256'])
    snapshot_paths.append(row['path'])
    assert relative.parts and relative.parts[0] in root_counts, 'Unexpected raw input root: ' + row['path']
    root_counts[relative.parts[0]] += 1
assert snapshot_paths == sorted(snapshot_paths) and len(set(snapshot_paths)) == 1354
assert root_counts == {'src': 1132, 'tests': 173, 'war': 29, 'scripts': 20}
assert not any(path.startswith('war/circuitjs1/') for path in snapshot_paths)
identity_payload = {'schema': snapshot['schema'], 'baseHead': snapshot['baseHead'], 'files': snapshot['files']}
assert hashlib.sha256(json.dumps(identity_payload, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest() == binding['sourceIdentity'], 'Source identity does not hash the exact source snapshot'
integration = json.loads((workspace / 'integration-pointer.json').read_text(encoding='utf-8'))
assert integration['status'] == 'INTEGRATED_PENDING_FRESH_GATES'
assert integration['baseHead'] == binding['baseHead'] and Path(integration['taskRoot']).resolve() == task.resolve()
assert hashlib.sha256((workspace / 'integration-pointer.json').read_bytes()).hexdigest() == binding['integrationPointerSha256']
assert binding['changedPlanFields'] == ['baseHead']
assert binding['changedSourcePaths'] == sorted(change['path'] for change in integration['changes'])
snapshot_by_path = {row['path']: row['sha256'] for row in snapshot['files']}
assert len(integration['changes']) == 5
assert binding['changedSourcePaths'] == [
    'src/com/lushprojects/circuitjs1/client/CirSim.java',
    'src/com/lushprojects/circuitjs1/client/QuickPlayDeveloperVerifier.java',
    'tests/browser/compiled_attribute_acceptance.py',
    'tests/qualification/q30-scale-acceptance/normal_screen_host.py',
    'tests/qualification/q30-scale-acceptance/overlay-manifest.json',
]
for change in integration['changes']:
    assert snapshot_by_path.get(change['path']) == change['candidateSha256'], 'Fresh source snapshot differs from integrated candidate: ' + change['path']
assert shipping.is_dir(), 'Fresh task-local shipping app is missing'
assert build_receipt.is_file(), 'Fresh shipping build receipt is missing'
build = json.loads(build_receipt.read_text(encoding='utf-8-sig'))
assert build['status'] == 'PASS' and build['head'] == binding['baseHead']
assert build['exitCode'] == 0 and build['compilationConfirmed'] is True
assert build['permutations'] == 5
assert build['consumedSourceIdentity'] == binding['sourceIdentity']
assert build['consumedInputsVerified'] == 1354
assert Path(build['app']).resolve() == shipping.resolve(), 'Build receipt does not bind the fresh shipping app'
output = task / args.stage
destination = task / (args.stage + '-stage-result.json')
log = task / (args.stage + '.log')
assert not output.exists() and not destination.exists() and not log.exists(), 'Preserve prior output'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def input_inventory():
    for row in snapshot['files']:
        for root in [repo, shipping]:
            path = root / row['path']
            assert path.stat().st_size == row['size'] and digest(path) == row['sha256'], 'Raw input changed: ' + str(path)
    compiled = shipping / 'war/circuitjs1'
    files = sorted(path for path in compiled.rglob('*') if path.is_file())
    cache_files = [path for path in files if path.name.lower().endswith('.cache.js')]
    assert len(cache_files) == 5, 'Expected exactly five compiled GWT permutations'
    assert all(re.fullmatch(r'[0-9a-fA-F]{32}\.cache\.js', path.name) for path in cache_files), 'Compiled GWT permutation names are not canonical'
    return [{'path': path.relative_to(shipping).as_posix(), 'size': path.stat().st_size, 'sha256': digest(path)} for path in files]

before = input_inventory()
catalog = (shipping / 'src/com/lushprojects/circuitjs1/client/PlayerFamilyCatalog.java').read_text(encoding='utf-8')
assert 'registerStagedFamily(new Rb30PlayerFamilyCapability(), false)' in catalog
assert 'registerStagedFamily(new Rb30PlayerFamilyCapability(), true)' not in catalog
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo)]
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
assert subprocess.run(git + ['merge-base', '--is-ancestor', binding['baseHead'], head], capture_output=True).returncode == 0
owner_query = "Get-CimInstance Win32_Process -Filter 'ProcessId=" + str(os.getpid()) + "' | Select-Object ProcessId,ParentProcessId,@{n='createdUtc';e={$_.CreationDate.ToUniversalTime().ToString('o')}},ExecutablePath,CommandLine | ConvertTo-Json -Compress"
owner_capture = subprocess.run(['powershell.exe', '-NoProfile', '-Command', owner_query], capture_output=True, text=True, timeout=20)
assert owner_capture.returncode == 0, 'Process identity query failed: ' + owner_capture.stderr
owner = json.loads(owner_capture.stdout)
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
get_current_process = kernel32.GetCurrentProcess
get_current_process.argtypes = []
get_current_process.restype = wintypes.HANDLE
query_image = kernel32.QueryFullProcessImageNameW
query_image.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
query_image.restype = wintypes.BOOL
image_buffer = ctypes.create_unicode_buffer(32768)
image_length = wintypes.DWORD(len(image_buffer))
if not query_image(get_current_process(), 0, image_buffer, ctypes.byref(image_length)):
    raise ctypes.WinError(ctypes.get_last_error())
actual_executable = Path(image_buffer.value).resolve(strict=True)
assert owner['ProcessId'] == os.getpid() and isinstance(owner.get('ExecutablePath'), str), 'Runner process identity query is incomplete'
assert os.path.samefile(owner['ExecutablePath'], actual_executable), 'CIM and Windows process-image identities differ'
assert os.path.samefile(host_python, actual_executable), 'Running process is not the pinned CPython 3.13 executable'
record = {'schema': 1, 'head': head, 'candidateBaseHead': binding['baseHead'],
          'sourceIdentity': binding['sourceIdentity'], 'stage': args.stage,
          'startedUtc': datetime.now(timezone.utc).isoformat(), 'pid': os.getpid(),
          'executable': str(actual_executable), 'reportedSysExecutable': sys.executable,
          'owner': owner, 'status': 'RUNNING', 'shippingApp': str(shipping),
          'shippingBuildReceipt': str(build_receipt),
          'shippingBuildReceiptSha256': digest(build_receipt),
          'shippingBuildStatus': build['status'],
          'shippingBuildCompilationConfirmed': build['compilationConfirmed'],
          'shippingBuildConsumedSourceIdentity': build['consumedSourceIdentity'],
          'shippingBuildConsumedInputsVerified': build['consumedInputsVerified'],
          'rawInputsVerified': len(snapshot['files']), 'compiledInputsBefore': before,
          'freshBuild': True,
          'buildDescription': 'Fresh task-local disabled final-source JDK8/GWT build; exactly five cache permutations',
          'q30NormalPlayerEnabled': False}
started = time.monotonic()

def save():
    destination.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')

save()
try:
    if args.stage == 'compiled31':
        spec_path = task / 'compiled31-spec.json'
        oracle_path = task / 'compiled31-declared-physical-rejection.json'
        spec_raw = (frozen_task / 'compiled-gate-plan/compiled-gates.json').read_bytes()
        assert hashlib.sha256(spec_raw).hexdigest() == '898145a040b8920350461961dbad85b94f2d7ef286e95a0ebd347781d291bc97'
        assert len(json.loads(spec_raw)['cases']) == 31
        for target, raw in [(spec_path, spec_raw), (oracle_path, (frozen_task / 'compiled-gate-plan/declared-physical-rejection.json').read_bytes())]:
            assert not target.exists()
            target.write_bytes(raw)
        record['specSha256'] = digest(spec_path)
        record['declaredOracleSha256'] = digest(oracle_path)
        runner = repo / 'tests/browser/compiled_attribute_acceptance.py'
        command = [host_python, '-B', '-u', str(runner), str(shipping), str(output), str(spec_path)]
    else:
        compiled_review = json.loads((task / 'compiled31-audit.json').read_text(encoding='utf-8'))
        assert compiled_review['status'] == 'PASS', 'Semantically reviewed compiled31 receipt required'
        runner = repo / 'tests/browser/quickplay_procedural_acceptance.py'
        command = [host_python, '-B', '-u', str(runner), str(shipping), str(output)]
    record.update({'runnerSha256': digest(runner), 'command': command})
    save()
    with log.open('w', encoding='utf-8') as stream:
        host = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=host_environment)
        record['hostPid'] = host.pid
        record['progressStreaming'] = True
        save()
        while host.poll() is None:
            try:
                host.wait(timeout=30)
            except subprocess.TimeoutExpired:
                progress_path = output / 'progress.json'
                try:
                    progress = json.loads(progress_path.read_text(encoding='utf-8')) if progress_path.exists() else {}
                except (OSError, json.JSONDecodeError):
                    progress = {}  # Advisory heartbeat; final receipts remain mandatory.
                print(json.dumps({'stage': args.stage, 'hostPid': host.pid,
                                  'elapsedSeconds': round(time.monotonic() - started, 3),
                                  'capturedCases': len(progress.get('cases', []))}), flush=True)
    record['exitCode'] = host.returncode
    after = input_inventory()
    record['compiledInputsAfter'] = after
    assert before == after and digest(runner) == record['runnerSha256'], 'Consumed source/build/runner changed'
    assert digest(build_receipt) == record['shippingBuildReceiptSha256'], 'Fresh shipping build receipt changed during host run'
    record['consumedInputsUnchanged'] = True
    assert host.returncode == 0, 'Host returned nonzero; preserve exact failure'
    result = json.loads((output / 'result.json').read_text(encoding='utf-8'))
    assert result['outcome'] == 'PASS' and not result['errors'], 'Host report nonpass'
    record['hostOutcome'] = result['outcome']
    record['status'] = 'COMMAND_PASS_PENDING_RECEIPT_REVIEW'
except Exception as error:
    record.update({'status': 'FAIL', 'error': str(error)})
finally:
    record['finishedUtc'] = datetime.now(timezone.utc).isoformat()
    record['elapsedSeconds'] = time.monotonic() - started
    save()
    print(json.dumps({key: value for key, value in record.items() if key not in {'compiledInputsBefore', 'compiledInputsAfter'}}), flush=True)
sys.exit(0 if record['status'] == 'COMMAND_PASS_PENDING_RECEIPT_REVIEW' else 1)
