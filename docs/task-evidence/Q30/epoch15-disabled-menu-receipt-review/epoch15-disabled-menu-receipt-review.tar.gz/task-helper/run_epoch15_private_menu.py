"""Build and qualify a private enabled-Q30 menu copy after epoch15 gates pass.

The helper copies only the 1,354 snapshot-bound src/tests/war/scripts files,
the nine hash-pinned GWT jars, and no prior build caches. It leaves the repository and
the reviewed disabled shipping build untouched. Its OS-temp copy and all raw
evidence are retained, including on failure.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import time


WORKSPACE = Path(__file__).resolve().parent
REPO = Path(r"$REPO")
EXPECTED_BASE_HEAD = None
EXPECTED_SOURCE_IDENTITY = None
EXPECTED_RAW_INPUTS = 1354
EXPECTED_RAW_ROOT_COUNTS = {"src": 1132, "tests": 173, "war": 29, "scripts": 20}
EXPECTED_COMPILED31_SPEC = "898145a040b8920350461961dbad85b94f2d7ef286e95a0ebd347781d291bc97"
EXPECTED_PRIVATE_RUNNER_SHA256 = "75e79a0ba5bcb1e3365aee413f0fd94f25d560e08e1c9cd8816896633c3e5b1a"
PRIVATE_RUNNER = Path(
    r"$OS_TEMP\q30-finish-0fa2512465"
    r"\catalog-release-patch\after\tests\browser\quickplay_procedural_acceptance.py"
)
HOST_PYTHON = Path(
    r"C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_"
    r"3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe"
)
HOST_DEPENDENCIES = Path(
    r"$OS_TEMP\q30-finish-0fa2512465\deps"
)
JAVA_HOME = Path(
    r"$OS_TEMP\q30-finish-0fa2512465"
    r"\jdk\jdk8u502-b07"
)
JDK8_BUILD_SECONDS = 900
MENU_HOST_SECONDS = 7200
TARGET_CATALOG = "src/com/lushprojects/circuitjs1/client/PlayerFamilyCatalog.java"
FALSE_REGISTRATION = b"registerStagedFamily(new Rb30PlayerFamilyCapability(), false);"
TRUE_REGISTRATION = b"registerStagedFamily(new Rb30PlayerFamilyCapability(), true);"
CURRENT_MENU_RUNNER = "tests/browser/quickplay_procedural_acceptance.py"
BUILD_SCRIPT = "scripts/build.ps1"
BUILD_ISOLATION_MODULE = "scripts/VerifierIsolation.psm1"
GWT_JARS = {
    "gwt-dev-2.7.0.jar": "c7321e367fc24e5c7ad97b74d1cf2980c45fbd7cbe1fd412f8a8ba128f685135",
    "gwt-user-2.7.0.jar": "d3721bcdd7c6855a524801212dd74548967d8fb65cbc212a20890732ff2c6948",
    "validation-api-1.0.0.GA.jar": "e459f313eeb6db2483f8ceaad39af07086361b474fa92e40f442e8de5d9895dc",
    "validation-api-1.0.0.GA-sources.jar": "a394d52a9b7fe2bb14f0718d2b3c8308ffe8f37e911956012398d55c9f9f9b54",
    "asm-5.0.3.jar": "71c4f78e437b8fdcd9cc0dfd2abdea8c089eb677005a6cff320206cc52b46cc",
    "asm-analysis-5.0.3.jar": "e8fa2a63462c96557dcd36c25525e1264b77366ff851cf0b94eb7592b290849d",
    "asm-commons-5.0.3.jar": "18c1e092230233c9d29e46f21943d769bdb48130cc279e4b0e663f423948c2da",
    "asm-tree-5.0.3.jar": "347a7a9400f9964e87c91d3980e48ee8bdc024bc3b36f7f22189c662853a51c",
    "asm-util-5.0.3.jar": "2768edbfa2681b5077f08151de586a6d66b916703cda3ab297e58b41ae8f2362",
}
MENU_FAMILIES = (
    ("LED_INDICATOR", "EASY"),
    ("DIODE_PROTECTED_INDICATOR", "EASY"),
    ("PARALLEL_DUAL_INDICATOR", "EASY"),
    ("RC_DELAY", "EASY"),
    ("NPN_LOW_SIDE_SWITCH", "EASY"),
    ("NMOS_LOW_SIDE_SWITCH", "EASY"),
    ("RELAY_OUTPUT", "EASY"),
    ("SENSOR_CONTROL", "EASY"),
    ("RB15_CONTROL", "EASY"),
    ("COMPOSED_CONTROLLED_INDICATOR", "MEDIUM"),
    ("RB30_CONTROL", "MEDIUM"),
)
EXPECTED_SCREENSHOTS = (
    "led_indicator-top.png",
    "led_indicator-bottom.png",
    "composed_controlled_indicator-top.png",
    "composed_controlled_indicator-bottom.png",
)


class GateError(RuntimeError):
    pass


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                return digest.hexdigest()
            digest.update(block)


def file_record(path, label=None):
    path = Path(path).resolve()
    return {
        "label": label or path.name,
        "path": str(path),
        "size": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def require(condition, message):
    if not condition:
        raise GateError(message)


def read_json(path, label):
    path = Path(path)
    raw = path.read_bytes()
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise GateError(label + " is invalid JSON: " + str(error))
    return value, {
        "label": label,
        "path": str(path.resolve()),
        "size": len(raw),
        "sha256": sha256(raw),
    }


def safe_snapshot_path(value):
    require(isinstance(value, str) and "\\" not in value and ":" not in value,
            "snapshot path is malformed")
    relative = PurePosixPath(value)
    require(not relative.is_absolute() and ".." not in relative.parts and
            relative.as_posix() == value and relative.parts and
            relative.parts[0] in ("src", "tests", "war", "scripts"),
            "snapshot path is outside bound src/tests/war/scripts roots: " + value)
    return relative


def is_under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (OSError, ValueError):
        return False


def json_process_identity(pid, powershell):
    query = (
        "Get-CimInstance Win32_Process -Filter 'ProcessId=" + str(int(pid)) +
        "' | Select-Object ProcessId,ParentProcessId,"
        "@{n='createdUtc';e={$_.CreationDate.ToUniversalTime().ToString('o')}},"
        "ExecutablePath,CommandLine | ConvertTo-Json -Compress"
    )
    result = subprocess.run(
        [str(powershell), "-NoProfile", "-Command", query],
        capture_output=True, text=True, timeout=20,
    )
    if result.returncode != 0:
        raise GateError("process identity query failed: " + result.stderr.strip())
    if not result.stdout.strip():
        return None
    value = json.loads(result.stdout)
    return value if isinstance(value, dict) else value[0]


def process_snapshot(powershell):
    query = (
        "Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,"
        "@{n='createdUtc';e={$_.CreationDate.ToUniversalTime().ToString('o')}},"
        "ExecutablePath,CommandLine | ConvertTo-Json -Compress"
    )
    result = subprocess.run(
        [str(powershell), "-NoProfile", "-Command", query],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        raise GateError("process-tree query failed: " + result.stderr.strip())
    if not result.stdout.strip():
        return []
    value = json.loads(result.stdout)
    return value if isinstance(value, list) else [value]


def stop_direct_child(child):
    if child.poll() is None:
        try:
            child.kill()
        except OSError:
            if child.poll() is None:
                return {"stopped": False, "error": "could not stop owned child"}
    try:
        child.wait(timeout=20)
        return {"stopped": True, "returnCode": child.returncode}
    except subprocess.TimeoutExpired:
        return {"stopped": False, "error": "owned child remained after stop"}


def descendants_of(rows, root_pid):
    owners = {int(root_pid)}
    while True:
        expanded = owners | {
            int(row["ProcessId"]) for row in rows
            if isinstance(row, dict) and row.get("ParentProcessId") is not None
            and int(row["ParentProcessId"]) in owners
            and row.get("ProcessId") is not None
        }
        if expanded == owners:
            break
        owners = expanded
    return [row for row in rows
            if isinstance(row, dict) and row.get("ProcessId") is not None
            and int(row["ProcessId"]) in owners and
            int(row["ProcessId"]) != int(root_pid)]


def stop_exact_process(powershell, process_row, expected_executable):
    """Stop one task-owned process only after a PID/time/path identity recheck."""
    pid = process_row.get("ProcessId", process_row.get("pid"))
    created = process_row.get("createdUtc", process_row.get("created"))
    executable = process_row.get("ExecutablePath", process_row.get("executable"))
    if not isinstance(pid, int) or not isinstance(created, str) or not isinstance(executable, str):
        return {"status": "BLOCKED_INVALID_IDENTITY", "pid": pid}
    if Path(executable).resolve() != Path(expected_executable).resolve():
        return {"status": "BLOCKED_EXECUTABLE_MISMATCH", "pid": pid}
    escaped_executable = executable.replace("'", "''")
    escaped_created = created.replace("'", "''")
    query = (
        "$p=Get-CimInstance Win32_Process -Filter 'ProcessId=" + str(pid) + "'; "
        "if($null -eq $p){'ALREADY_EXITED'} "
        "elseif($p.ExecutablePath -ceq '" + escaped_executable + "' -and "
        "$p.CreationDate.ToUniversalTime().ToString('o') -ceq '" + escaped_created + "') "
        "{Stop-Process -Id " + str(pid) + " -Force -ErrorAction Stop; 'STOP_REQUESTED'} "
        "else {'IDENTITY_MISMATCH'}"
    )
    result = subprocess.run(
        [str(powershell), "-NoProfile", "-Command", query],
        capture_output=True, text=True, timeout=20,
    )
    if result.returncode != 0:
        return {"status": "FAIL_STOP", "pid": pid,
                "stderr": result.stderr.strip()}
    status = result.stdout.strip()
    after = json_process_identity(pid, powershell)
    same_process_remains = (
        after is not None and after.get("createdUtc") == created and
        after.get("ExecutablePath") == executable
    )
    return {
        "status": ("FAIL_SURVIVOR" if same_process_remains else status),
        "pid": pid,
        "createdUtc": created,
        "executable": executable,
        "identityRechecked": True,
        "sameProcessRemains": same_process_remains,
    }


def terminate_java_descendants(powershell, rows):
    java_path = (JAVA_HOME / "bin" / "java.exe").resolve()
    attempts = []
    for row in rows:
        executable = row.get("ExecutablePath") if isinstance(row, dict) else None
        if isinstance(executable, str) and Path(executable).resolve() == java_path:
            attempts.append(stop_exact_process(powershell, row, java_path))
    return attempts


def terminate_owned_edges(powershell, output_dir, descendants=()):
    owned_rows = []
    owned_file = Path(output_dir) / "owned-processes.json"
    if owned_file.is_file():
        try:
            value, _ = read_json(owned_file, "timed-out host Edge ownership")
            if isinstance(value, list):
                owned_rows.extend(value)
        except (OSError, GateError):
            pass
    known = {
        row.get("pid") for row in owned_rows
        if isinstance(row, dict) and isinstance(row.get("pid"), int)
    }
    for row in descendants:
        if (isinstance(row, dict) and
                isinstance(row.get("ExecutablePath"), str) and
                row["ExecutablePath"].lower().endswith("msedge.exe") and
                row.get("ProcessId") not in known):
            owned_rows.append(row)
    attempts = []
    for row in owned_rows:
        executable = (row.get("ExecutablePath") if isinstance(row, dict)
                      else None)
        if isinstance(executable, str) and executable.lower().endswith("msedge.exe"):
            attempts.append(stop_exact_process(powershell, row, executable))
    return attempts


def load_pointer_and_snapshot(task):
    global EXPECTED_BASE_HEAD, EXPECTED_SOURCE_IDENTITY
    pointer, pointer_file = read_json(WORKSPACE / "epoch15-task-pointer.json",
                                      "epoch15 task pointer")
    require(pointer.get("schema") == 1, "epoch15 pointer schema changed")
    base_head = pointer.get("baseHead")
    source_identity = pointer.get("sourceIdentity")
    require(isinstance(base_head, str) and
            re.fullmatch(r"[0-9a-f]{40}", base_head) is not None,
            "epoch15 pointer baseHead is not lower-case 40-hex")
    require(isinstance(source_identity, str) and
            re.fullmatch(r"[0-9a-f]{64}", source_identity) is not None,
            "epoch15 pointer source identity is not lower-case SHA-256")
    require(pointer.get("layoutEpoch") == 15, "epoch15 pointer layout epoch changed")
    require(pointer.get("frozenRoots") == 77 and
            pointer.get("frozenServiceSensitivityRoots") == 21,
            "epoch15 pointer frozen cohort counts changed")
    require(pointer.get("changedPlanFields") == ["baseHead"],
            "continued plan must change only baseHead")
    task_root = Path(pointer.get("taskRoot", "")).resolve()
    require(task_root == task.resolve(), "pointer taskRoot does not match selected task")
    require(is_under(task_root, tempfile.gettempdir()),
            "task root is not under the OS temporary directory")
    integration, integration_file = read_json(
        WORKSPACE / "integration-pointer.json", "epoch15 integration pointer")
    require(integration.get("status") == "INTEGRATED_PENDING_FRESH_GATES",
            "integration pointer is not awaiting fresh gates")
    require(integration.get("baseHead") == base_head and
            Path(integration.get("taskRoot", "")).resolve() == task_root,
            "epoch15 pointer differs from the integrated candidate binding")
    require(integration_file.get("sha256") == pointer.get("integrationPointerSha256"),
            "epoch15 pointer does not bind the exact integration pointer bytes")
    changed_paths = sorted(change.get("path") for change in
                           integration.get("changes", [])
                           if isinstance(change, dict))
    require(pointer.get("changedSourcePaths") == changed_paths,
            "epoch15 pointer changed source path set differs from integration")
    require(pointer.get("previousSourceIdentity") ==
            integration.get("priorSourceIdentity"),
            "epoch15 pointer prior-source provenance differs from integration")
    bundled_plan_path = REPO / "tests/qualification/q30-scale-acceptance/acceptance-plan.json"
    continued_plan_path = task_root / "acceptance-plan.json"
    bundled_plan_raw = bundled_plan_path.read_bytes()
    continued_plan_raw = continued_plan_path.read_bytes()
    require(sha256(bundled_plan_raw) == pointer.get("originalPlanSha256"),
            "bundled acceptance plan differs from pointer originalPlanSha256")
    require(sha256(continued_plan_raw) == pointer.get("continuedPlanSha256"),
            "continued acceptance plan differs from pointer continuedPlanSha256")
    bundled_plan = json.loads(bundled_plan_raw.decode("utf-8-sig"))
    continued_plan = json.loads(continued_plan_raw.decode("utf-8-sig"))
    canonical = lambda value: json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    require(continued_plan.get("baseHead") == base_head and
            canonical({key: value for key, value in continued_plan.items()
                       if key != "baseHead"}) ==
            canonical({key: value for key, value in bundled_plan.items()
                       if key != "baseHead"}),
            "continued acceptance plan differs beyond baseHead")
    require(len(continued_plan.get("cases", [])) == 77 and
            len(continued_plan.get("coldOrder", [])) == 77 and
            len(continued_plan.get("serviceAndSensitivitySeeds", [])) == 21,
            "continued acceptance plan frozen cohort counts changed")
    require(continued_plan.get("limits") ==
            {"jobMillis": 90000, "sharedWork": 640, "activeOperationMillis": 5000},
            "continued acceptance plan limits changed")
    snapshot, snapshot_file = read_json(task_root / "source-snapshot.json",
                                        "epoch15 source snapshot")
    require(snapshot.get("status") == "PASS" and
            snapshot.get("baseHead") == base_head and
            snapshot.get("sourceIdentity") == source_identity,
            "source snapshot identity changed")
    rows = snapshot.get("files")
    require(isinstance(rows, list) and len(rows) == EXPECTED_RAW_INPUTS,
            "source snapshot must bind exactly 1,354 raw inputs")
    paths = []
    root_counts = {name: 0 for name in EXPECTED_RAW_ROOT_COUNTS}
    for index, row in enumerate(rows):
        require(isinstance(row, dict) and set(row) == {"path", "size", "sha256"},
                "source snapshot row %d has the wrong shape" % index)
        relative = safe_snapshot_path(row["path"])
        root_counts[relative.parts[0]] += 1
        require(isinstance(row["size"], int) and not isinstance(row["size"], bool)
                and row["size"] >= 0, "source snapshot row size is invalid")
        require(isinstance(row["sha256"], str) and
                re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) is not None,
                "source snapshot row SHA-256 is invalid")
        paths.append(relative.as_posix())
    require(paths == sorted(paths) and len(set(paths)) == EXPECTED_RAW_INPUTS,
            "source snapshot paths are unsorted or duplicated")
    require(root_counts == EXPECTED_RAW_ROOT_COUNTS,
            "source snapshot root counts differ: " + repr(root_counts))
    compiled_paths = [path for path in paths
                      if path.startswith("war/circuitjs1/")]
    require(not compiled_paths,
            "raw source snapshot unexpectedly binds compiled GWT output")
    require(TARGET_CATALOG in paths,
            "PlayerFamilyCatalog.java is not in the bound raw input set")
    identity_payload = {"schema": snapshot.get("schema"),
                        "baseHead": snapshot.get("baseHead"), "files": rows}
    identity_hash = sha256(json.dumps(
        identity_payload, sort_keys=True, separators=(",", ":")
    ).encode("utf-8"))
    require(identity_hash == source_identity,
            "source identity does not hash the exact base head and raw rows")
    changes = integration.get("changes")
    require(isinstance(changes, list) and len(changes) == 5,
            "integration pointer must bind exactly five reviewed source changes")
    snapshot_by_path = {row["path"]: row["sha256"] for row in rows}
    expected_changes = {
        "src/com/lushprojects/circuitjs1/client/CirSim.java",
        "src/com/lushprojects/circuitjs1/client/QuickPlayDeveloperVerifier.java",
        "tests/browser/compiled_attribute_acceptance.py",
        "tests/qualification/q30-scale-acceptance/normal_screen_host.py",
        "tests/qualification/q30-scale-acceptance/overlay-manifest.json",
    }
    require({row.get("path") for row in changes if isinstance(row, dict)} ==
            expected_changes,
            "integration pointer changed-file set differs")
    for change in changes:
        require(isinstance(change, dict) and
                snapshot_by_path.get(change.get("path")) ==
                change.get("candidateSha256"),
                "raw snapshot does not contain integrated candidate bytes: " +
                str(change.get("path") if isinstance(change, dict) else change))
    EXPECTED_BASE_HEAD = base_head
    EXPECTED_SOURCE_IDENTITY = source_identity
    return pointer, snapshot, task_root, {
        "pointer": pointer_file,
        "integration": integration_file,
        "snapshot": snapshot_file,
        "originalPlan": file_record(bundled_plan_path, "bundled acceptance plan"),
        "continuedPlan": file_record(continued_plan_path, "continued acceptance plan"),
    }


def validate_repo_inputs(snapshot):
    checked = []
    for row in snapshot["files"]:
        relative = safe_snapshot_path(row["path"])
        source = REPO.joinpath(*relative.parts)
        require(not source.is_symlink(), "raw source is a symlink: " + row["path"])
        try:
            resolved = source.resolve(strict=True)
            resolved.relative_to(REPO.resolve())
        except (OSError, ValueError):
            raise GateError("raw source is missing or escapes the worktree: " +
                            row["path"])
        require(resolved.is_file(), "raw source is not a file: " + row["path"])
        observed_size = resolved.stat().st_size
        observed_hash = sha256_file(resolved)
        require(observed_size == row["size"] and observed_hash == row["sha256"],
                "hash-bound repository input changed: " + row["path"])
        checked.append(row["path"])
    return {"count": len(checked), "sourceIdentity": EXPECTED_SOURCE_IDENTITY}


def validate_cold_gate(task):
    value, evidence = read_json(task / "cold77-audit.json", "cold77 audit")
    require(value.get("status") == "PASS", "cold77 audit is not PASS")
    require(value.get("sourceInputsVerified") == EXPECTED_RAW_INPUTS,
            "cold77 audit did not verify all raw inputs")
    require(value.get("sourceIdentity") == EXPECTED_SOURCE_IDENTITY,
            "cold77 audit source identity differs")
    require(value.get("candidateBaseHead") == EXPECTED_BASE_HEAD,
            "cold77 audit candidate base differs")
    require(value.get("count") == 77 and len(value.get("rows", [])) == 77,
            "cold77 audit does not contain all 77 roots")
    return {"status": "PASS", "evidence": evidence, "count": 77}


def validate_compiled31_gate(task):
    audit, audit_file = read_json(task / "compiled31-audit.json",
                                  "compiled31 semantic audit")
    summary = audit.get("summary", {})
    require(audit.get("status") == "PASS", "compiled31 semantic audit is not PASS")
    require(not audit.get("errors"), "compiled31 audit has reported errors")
    require(summary.get("expectedCases") == 31 and
            summary.get("observedCases") == 31 and
            summary.get("positiveD01Cases") == 20 and
            summary.get("seed35IntentionalRejection") == "PASS",
            "compiled31 semantic audit summary is incomplete")
    source_binding = summary.get("sourceBinding", {})
    require(source_binding.get("sourceIdentity") == EXPECTED_SOURCE_IDENTITY and
            source_binding.get("candidateBaseHead") == EXPECTED_BASE_HEAD,
            "compiled31 audit source binding differs")
    stage, stage_file = read_json(task / "compiled31-stage-result.json",
                                  "compiled31 host stage receipt")
    require(stage.get("schema") == 1 and stage.get("stage") == "compiled31",
            "compiled31 stage receipt schema/stage differs")
    require(stage.get("sourceIdentity") == EXPECTED_SOURCE_IDENTITY and
            stage.get("candidateBaseHead") == EXPECTED_BASE_HEAD,
            "compiled31 stage source binding differs")
    require(stage.get("status") == "COMMAND_PASS_PENDING_RECEIPT_REVIEW" and
            stage.get("exitCode") == 0 and
            stage.get("rawInputsVerified") == EXPECTED_RAW_INPUTS and
            stage.get("consumedInputsUnchanged") is True and
            stage.get("q30NormalPlayerEnabled") is False,
            "compiled31 stage receipt is not a successful disabled-source run")
    require(stage.get("specSha256") == EXPECTED_COMPILED31_SPEC,
            "compiled31 stage spec hash differs")
    audit_inputs = audit.get("inputs", {})
    bound_stage = audit_inputs.get("compiled31 source binding", {})
    require(bound_stage.get("sha256") == stage_file["sha256"],
            "compiled31 audit does not bind this stage receipt")
    return {
        "status": "PASS",
        "audit": audit_file,
        "stage": stage_file,
        "summary": summary,
    }


def validate_disabled_menu_gate(task):
    stage, stage_file = read_json(task / "disabled-menu-stage-result.json",
                                  "disabled-menu host stage receipt")
    require(stage.get("schema") == 1 and stage.get("stage") == "disabled-menu",
            "disabled-menu stage receipt schema/stage differs")
    require(stage.get("sourceIdentity") == EXPECTED_SOURCE_IDENTITY and
            stage.get("candidateBaseHead") == EXPECTED_BASE_HEAD,
            "disabled-menu stage source binding differs")
    require(stage.get("status") == "COMMAND_PASS_PENDING_RECEIPT_REVIEW" and
            stage.get("exitCode") == 0 and stage.get("hostOutcome") == "PASS" and
            stage.get("rawInputsVerified") == EXPECTED_RAW_INPUTS and
            stage.get("consumedInputsUnchanged") is True and
            stage.get("q30NormalPlayerEnabled") is False,
            "disabled-menu host stage did not pass with Q30 disabled")
    current_runner = REPO / CURRENT_MENU_RUNNER
    current_runner_hash = sha256_file(current_runner)
    require(stage.get("runnerSha256") == current_runner_hash,
            "disabled-menu stage did not use the current tracked menu runner")
    result, result_file = read_json(task / "disabled-menu" / "result.json",
                                    "disabled-menu browser result")
    require(result.get("outcome") == "PASS" and not result.get("errors"),
            "disabled-menu browser result is not PASS")
    cases = result.get("cases")
    require(isinstance(cases, list) and len(cases) == 30,
            "disabled-menu run does not contain 30 launches")
    case_pairs = [(row.get("family"), row.get("ordinal"))
                  for row in cases if isinstance(row, dict)]
    expected_pairs = [(family, ordinal) for family, _ in MENU_FAMILIES[:-1]
                      for ordinal in range(3)]
    require(case_pairs == expected_pairs and
            all(row.get("outcome") == "PASS" for row in cases),
            "disabled-menu family/ordinal cases differ or a case failed")
    replays = result.get("replays")
    require(isinstance(replays, list) and len(replays) == 2 and
            all(row.get("outcome") == "PASS" for row in replays),
            "disabled-menu replay controls did not pass")
    stale = result.get("staleReplayEpoch", {})
    require(stale.get("outcome") == "EXPECTED_REJECTED" and
            stale.get("prelaunchStateUnchanged") is True and
            stale.get("noGenerationStarted") is True,
            "disabled-menu stale replay control did not pass")
    blocked = result.get("blockedFamilyReplay", {})
    require(blocked.get("outcome") == "EXPECTED_BLOCKED" and
            blocked.get("family") == "RB30_CONTROL" and
            blocked.get("noGenerationStarted") is True,
            "disabled-menu RB30 negative control did not pass")
    cleanup = result.get("cleanup", {})
    require(cleanup.get("serverStopped") is True and
            cleanup.get("ownedSurvivors") == [],
            "disabled-menu host cleanup did not pass")
    return {
        "status": "PASS",
        "stage": stage_file,
        "result": result_file,
        "runnerSha256": current_runner_hash,
        "caseCount": len(cases),
        "replayCount": len(replays),
        "cleanup": cleanup,
    }


def copy_bound_source(snapshot, private_root):
    copied = []
    for row in snapshot["files"]:
        relative = safe_snapshot_path(row["path"])
        source = REPO.joinpath(*relative.parts)
        require(not source.is_symlink(),
                "raw source became a symlink while copying: " + row["path"])
        try:
            source = source.resolve(strict=True)
            source.relative_to(REPO.resolve())
        except (OSError, ValueError):
            raise GateError("raw source escaped the repository while copying: " +
                            row["path"])
        destination = private_root.joinpath(*relative.parts)
        require(is_under(destination, private_root),
                "source copy destination escaped its unique root")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        observed_size = destination.stat().st_size
        observed_hash = sha256_file(destination)
        require(observed_size == row["size"] and observed_hash == row["sha256"],
                "copied raw source did not match snapshot: " + row["path"])
        copied.append(row["path"])
    require(len(copied) == EXPECTED_RAW_INPUTS,
            "raw source copy did not contain exactly 1,354 files")
    require(not (private_root / ".git").exists(),
            "private source copy unexpectedly contains .git")
    return copied


def copy_build_inputs(private_root, snapshot):
    copied = []
    snapshot_by_path = {row["path"]: row for row in snapshot["files"]}
    bound_build_scripts = []
    additional_build_scripts = []
    for relative in (BUILD_SCRIPT, BUILD_ISOLATION_MODULE):
        require(relative in snapshot_by_path,
                "maintained build script is not bound by the raw source snapshot: " +
                relative)
        source = REPO / relative
        require(source.is_file() and not source.is_symlink(),
                "maintained build input is missing or a symlink: " + relative)
        destination = private_root / relative
        expected = sha256_file(source)
        if relative in snapshot_by_path:
            bound_row = snapshot_by_path[relative]
            require(bound_row["sha256"] == expected and
                    destination.is_file() and
                    sha256_file(destination) == expected,
                    "snapshot-bound build script copy hash mismatch: " + relative)
            bound_build_scripts.append(relative)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
            require(sha256_file(destination) == expected,
                    "additional maintained build script copy hash mismatch: " +
                    relative)
            additional_build_scripts.append(relative)
        copied.append(file_record(destination, relative))

    source_tools = REPO / ".tools" / "gwt-2.7.0"
    target_tools = private_root / ".tools" / "gwt-2.7.0"
    target_tools.mkdir(parents=True, exist_ok=False)
    tool_records = []
    for name, expected_hash in GWT_JARS.items():
        source = source_tools / name
        require(source.is_file() and not source.is_symlink(),
                "pinned GWT build dependency is missing: " + str(source))
        observed = sha256_file(source)
        require(observed == expected_hash,
                "pinned GWT dependency hash mismatch: " + name)
        destination = target_tools / name
        shutil.copyfile(source, destination)
        require(sha256_file(destination) == expected_hash,
                "copied GWT dependency hash mismatch: " + name)
        tool_records.append(file_record(destination, name))
    require(not (target_tools / "compile-cache").exists() and
            not (target_tools / "compile-work").exists(),
            "private build copy unexpectedly inherited GWT build caches")
    return {
        "buildScripts": copied,
        "buildScriptsBoundToSnapshot": bound_build_scripts,
        "additionalBuildScripts": additional_build_scripts,
        "pinnedGwtJars": tool_records,
    }


def copy_source_delta(snapshot, private_root):
    path = private_root / TARGET_CATALOG
    original = path.read_bytes()
    require(original.count(FALSE_REGISTRATION) == 1 and
            original.count(TRUE_REGISTRATION) == 0,
            "private catalog source does not contain one disabled registration")
    changed = original.replace(FALSE_REGISTRATION, TRUE_REGISTRATION, 1)
    require(changed != original and changed.count(TRUE_REGISTRATION) == 1,
            "private catalog toggle did not make exactly one change")
    path.write_bytes(changed)
    original_hash = sha256(original)
    updated_hash = sha256(changed)
    require(updated_hash != original_hash, "private catalog source hash did not change")

    delta = []
    for row in snapshot["files"]:
        relative = safe_snapshot_path(row["path"])
        copied = private_root.joinpath(*relative.parts)
        observed_hash = sha256_file(copied)
        expected_hash = updated_hash if row["path"] == TARGET_CATALOG else row["sha256"]
        require(observed_hash == expected_hash,
                "private source copy differs outside the single catalog toggle: " +
                row["path"])
        if row["path"] != TARGET_CATALOG:
            require(copied.stat().st_size == row["size"],
                    "private source copy size differs: " + row["path"])
        else:
            delta.append({
                "path": row["path"],
                "beforeSize": row["size"],
                "beforeSha256": row["sha256"],
                "afterSize": copied.stat().st_size,
                "afterSha256": updated_hash,
                "falseOccurrenceBefore": original.count(FALSE_REGISTRATION),
                "trueOccurrenceAfter": changed.count(TRUE_REGISTRATION),
            })
    require(len(delta) == 1 and delta[0]["path"] == TARGET_CATALOG,
            "private source delta is not exactly the catalog flag")
    return delta


def inventory_tree(root, relative_root, allow_missing=False):
    root = Path(root)
    base = root / relative_root
    if allow_missing and not base.exists() and not base.is_symlink():
        return []
    require(base.is_dir() and not base.is_symlink(),
            "compiled output root is missing or symlinked: " + str(base))
    rows = []
    for directory, subdirs, names in os.walk(base, followlinks=False):
        directory_path = Path(directory)
        for subdir in list(subdirs):
            child = directory_path / subdir
            require(not child.is_symlink(),
                    "compiled output tree contains symlink: " + str(child))
        for name in names:
            path = directory_path / name
            require(not path.is_symlink(),
                    "compiled output tree contains symlink: " + str(path))
            require(path.is_file(), "compiled output entry is not a regular file")
            rows.append({
                "path": path.relative_to(root).as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    rows.sort(key=lambda row: row["path"])
    require(bool(rows), "compiled output inventory is empty")
    return rows


def inventory_raw_source_roots(root):
    """Inventory only the four hash-bound raw roots, excluding generated GWT output."""
    root = Path(root)
    rows = []
    for root_name in ("src", "tests", "scripts", "war"):
        base = root / root_name
        require(base.is_dir() and not base.is_symlink(),
                "raw source root is missing or symlinked: " + str(base))
        for directory, subdirs, names in os.walk(base, followlinks=False):
            directory_path = Path(directory)
            retained_subdirs = []
            for subdir in subdirs:
                child = directory_path / subdir
                require(not child.is_symlink(),
                        "raw source tree contains symlink: " + str(child))
                relative = child.relative_to(root).as_posix()
                if relative == "war/circuitjs1":
                    continue
                retained_subdirs.append(subdir)
            subdirs[:] = retained_subdirs
            for name in names:
                path = directory_path / name
                require(not path.is_symlink() and path.is_file(),
                        "raw source entry is not a regular file: " + str(path))
                relative = path.relative_to(root).as_posix()
                rows.append({
                    "path": relative,
                    "size": path.stat().st_size,
                    "sha256": sha256_file(path),
                })
    rows.sort(key=lambda row: row["path"])
    return rows


def expected_raw_source_inventory(snapshot, catalog_delta):
    require(isinstance(catalog_delta, list) and len(catalog_delta) == 1 and
            catalog_delta[0].get("path") == TARGET_CATALOG,
            "raw source expectation needs exactly the private catalog toggle")
    changed = catalog_delta[0]
    rows = []
    for item in snapshot["files"]:
        rows.append({
            "path": item["path"],
            "size": (changed["afterSize"] if item["path"] == TARGET_CATALOG
                     else item["size"]),
            "sha256": (changed["afterSha256"] if item["path"] == TARGET_CATALOG
                       else item["sha256"]),
        })
    return rows


def require_inventory_matches(observed, expected, label):
    require(observed == expected,
            label + " differs from the exact snapshot-bound source inventory")
    return {
        "count": len(observed),
        "sha256": sha256(json.dumps(
            observed, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")),
    }


def validate_five_gwt_permutations(rows, label):
    cache_rows = [row for row in rows
                  if row["path"].lower().endswith(".cache.js")]
    require(len(cache_rows) == 5,
            label + " must contain exactly five GWT .cache.js permutations")
    for row in cache_rows:
        basename = PurePosixPath(row["path"]).name
        require(re.fullmatch(r"[0-9A-Fa-f]{32}\.cache\.js", basename) is not None,
                label + " has a noncanonical GWT permutation: " + basename)
    return cache_rows


def capture_runner_inventory(private_runner):
    paths = [
        (REPO / BUILD_SCRIPT, "repo build.ps1"),
        (REPO / BUILD_ISOLATION_MODULE, "repo VerifierIsolation.psm1"),
        (REPO / CURRENT_MENU_RUNNER, "tracked disabled menu runner"),
        (private_runner, "retained enabled menu runner"),
        (Path(__file__), "private menu helper"),
    ]
    records = []
    for path, label in paths:
        require(path.is_file() and not path.is_symlink(),
                "runner input is missing or symlinked: " + str(path))
        records.append(file_record(path, label))
    return records


def verify_build_support_unchanged(build_support):
    for row in (build_support["buildScripts"] + build_support["pinnedGwtJars"]):
        path = Path(row["path"])
        require(path.is_file() and path.stat().st_size == row["size"] and
                sha256_file(path) == row["sha256"],
                "private build support changed: " + row["label"])


def validate_private_menu_output(output_dir, exit_code):
    require(exit_code == 0, "private enabled-menu host returned nonzero")
    result, result_record = read_json(output_dir / "result.json",
                                      "private enabled-menu browser result")
    require(result.get("outcome") == "PASS" and not result.get("errors"),
            "private enabled-menu browser result is not PASS")
    cases = result.get("cases")
    require(isinstance(cases, list) and len(cases) == 33,
            "private enabled-menu result does not contain 33 family launches")
    expected_pairs = [(family, ordinal) for family, _ in MENU_FAMILIES
                      for ordinal in range(3)]
    pairs = [(row.get("family"), row.get("ordinal"))
             for row in cases if isinstance(row, dict)]
    require(pairs == expected_pairs and
            all(row.get("outcome") == "PASS" for row in cases),
            "private enabled-menu family/ordinal launch matrix differs or failed")
    replays = result.get("replays")
    # The pinned runner stores its Q30 replay in normalQ30Replay separately.
    require(isinstance(replays, list) and len(replays) == 2 and
            [row.get("family") for row in replays] ==
            ["RELAY_OUTPUT", "COMPOSED_CONTROLLED_INDICATOR"] and
            all(row.get("outcome") == "PASS" and row.get("isolated") is True
                for row in replays),
            "private enabled-menu replay controls did not pass")
    q30_replay = result.get("normalQ30Replay", {})
    require(q30_replay.get("family") == "RB30_CONTROL" and
            q30_replay.get("outcome") == "PASS" and
            q30_replay.get("isolated") is True,
            "private enabled-menu ordinary Q30 replay did not pass")
    stale = result.get("staleReplayEpoch", {})
    require(stale.get("outcome") == "EXPECTED_REJECTED" and
            stale.get("prelaunchStateUnchanged") is True and
            stale.get("noGenerationStarted") is True,
            "private enabled-menu stale replay negative control did not pass")
    cleanup = result.get("cleanup", {})
    require(cleanup.get("serverStopped") is True and
            cleanup.get("ownedSurvivors") == [],
            "private enabled-menu host cleanup did not pass")
    screenshot_records = []
    for name in EXPECTED_SCREENSHOTS:
        path = output_dir / name
        require(path.is_file() and path.stat().st_size > 0,
                "private enabled-menu screenshot is missing: " + name)
        screenshot_records.append(file_record(path, name))
    identity, identity_record = read_json(output_dir / "identity.json",
                                          "private enabled-menu host identity")
    owned, owned_record = read_json(output_dir / "owned-processes.json",
                                    "private enabled-menu Edge ownership")
    require(identity.get("pid") > 0 and identity.get("executable") and
            identity.get("profile") == str((output_dir / "profile").resolve()),
            "private enabled-menu host identity is incomplete")
    require(isinstance(owned, list) and bool(owned),
            "private enabled-menu Edge ownership evidence is missing")
    return {
        "result": result_record,
        "status": result["outcome"],
        "caseCount": len(cases),
        "replayCount": len(replays) + 1,
        "replayArrayCount": len(replays),
        "q30ReplayCount": 1,
        "cleanup": cleanup,
        "identity": identity_record,
        "ownedProcesses": owned_record,
        "screenshots": screenshot_records,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-root", type=Path,
                        help="epoch15 task root; defaults to the pointer-bound root")
    args = parser.parse_args()
    if os.name != "nt":
        print("BLOCKED: this helper requires the Windows JDK8/Edge host")
        return 2

    pointer_path = WORKSPACE / "epoch15-task-pointer.json"
    try:
        pointer, _ = read_json(pointer_path, "epoch15 task pointer")
        default_task = Path(pointer.get("taskRoot", ""))
    except (OSError, GateError):
        print("BLOCKED: cannot read the epoch15 task pointer")
        return 2
    task = args.task_root.resolve() if args.task_root else default_task.resolve()
    if not is_under(task, tempfile.gettempdir()):
        print("BLOCKED: task root must remain under the OS temporary directory")
        return 2

    result_path = task / "private-menu-result.json"
    build_log_path = task / "private-menu-build.log"
    host_log_path = task / "private-menu-host.log"
    output_dir = task / "private-menu-output"
    for path in (result_path, build_log_path, host_log_path, output_dir):
        if path.exists() or path.is_symlink():
            print("BLOCKED: preserving existing artifact: " + str(path))
            return 2

    record = {
        "schema": 1,
        "task": "epoch15-private-enabled-menu",
        "startedUtc": utc_now(),
        "status": "RUNNING",
        "phase": "preflight",
        "phases": [],
        "inputs": [],
        "artifacts": {
            "buildLog": str(build_log_path),
            "hostLog": str(host_log_path),
            "hostOutput": str(output_dir),
        },
        "limitations": [
            "The retained QuickPlay runner is headless automated browser input, not visible-player-input evidence."
        ],
    }

    def save():
        with result_path.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(record, stream, indent=2, ensure_ascii=False)
            stream.write("\n")

    def set_phase(name):
        record["phase"] = name
        save()

    try:
        with result_path.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(record, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
        powershell = shutil.which("powershell.exe")
        require(powershell is not None, "Windows PowerShell is unavailable")
        powershell = Path(powershell)
        record["controller"] = {
            "pid": os.getpid(),
            "executable": sys.executable,
            "identity": json_process_identity(os.getpid(), powershell),
        }

        phase_started = time.monotonic()
        pointer, snapshot, task, pointer_files = load_pointer_and_snapshot(task)
        gate_record = {
            "cold77": validate_cold_gate(task),
            "compiled31": validate_compiled31_gate(task),
            "disabledMenu": validate_disabled_menu_gate(task),
        }
        source_check = validate_repo_inputs(snapshot)
        record["inputs"].extend(pointer_files.values())
        record["gates"] = gate_record
        record["repoInputPreflight"] = source_check
        record["phase"] = "preflight"
        record["phases"].append({
            "phase": "preflight",
            "status": "PASS",
            "elapsedSeconds": round(time.monotonic() - phase_started, 3),
        })
        save()

        current_catalog = REPO / TARGET_CATALOG
        catalog_bytes = current_catalog.read_bytes()
        require(catalog_bytes.count(FALSE_REGISTRATION) == 1 and
                catalog_bytes.count(TRUE_REGISTRATION) == 0,
                "tracked Q30 catalog is not exactly disabled")
        private_runner_hash = sha256_file(PRIVATE_RUNNER)
        require(private_runner_hash == EXPECTED_PRIVATE_RUNNER_SHA256,
                "retained enabled-menu runner hash differs from reviewed three-change runner")
        current_runner_hash = sha256_file(REPO / CURRENT_MENU_RUNNER)
        stage = json.loads((task / "disabled-menu-stage-result.json").read_text(
            encoding="utf-8"))
        require(stage.get("runnerSha256") == current_runner_hash,
                "disabled-menu runner changed since its passing receipt")
        require(HOST_PYTHON.is_file(), "pinned Python 3.13 host executable is missing")
        require(JAVA_HOME.joinpath("bin", "java.exe").is_file(),
                "pinned JDK 8 java.exe is missing")
        require(HOST_DEPENDENCIES.is_dir() and not HOST_DEPENDENCIES.is_symlink(),
                "retained host dependency directory is missing or unsafe")
        host_environment = dict(os.environ)
        host_environment.update({
            "PYTHONPATH": str(HOST_DEPENDENCIES.resolve(strict=True)),
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONIOENCODING": "utf-8",
        })
        version = subprocess.run(
            [str(HOST_PYTHON), "-B", "-c",
             "import importlib.metadata, json, sys, playwright, greenlet; from pathlib import Path; "
             "from playwright.sync_api import sync_playwright; "
             "assert sys.version_info[:2] == (3, 13); "
             "assert callable(sync_playwright); "
             "dep=Path(sys.argv[1]).resolve(); "
             "assert Path(playwright.__file__).resolve().is_relative_to(dep); "
             "assert Path(greenlet.__file__).resolve().is_relative_to(dep); "
             "print(json.dumps({'python': sys.version.split()[0], "
             "'playwright': importlib.metadata.version('playwright')}))", str(HOST_DEPENDENCIES)],
            capture_output=True, text=True, timeout=30, env=host_environment,
        )
        require(version.returncode == 0,
                "pinned CPython 3.13 Playwright import preflight failed: " +
                version.stderr.strip())
        try:
            host_version = json.loads(version.stdout)
        except json.JSONDecodeError as error:
            raise GateError("pinned host version preflight returned invalid JSON: " +
                            str(error))
        require(isinstance(host_version, dict) and
                host_version.get("python", "").startswith("3.13.") and
                host_version.get("playwright") == "1.63.0",
                "pinned CPython 3.13 Playwright preflight versions differ")
        record["pythonHost"] = {
            "path": str(HOST_PYTHON),
            "version": host_version["python"],
            "playwrightVersion": host_version["playwright"],
            "dependencyPath": str(HOST_DEPENDENCIES.resolve(strict=True)),
        }
        record["javaHome"] = str(JAVA_HOME)
        record["retainedEnabledRunnerSha256"] = private_runner_hash
        record["trackedDisabledRunnerSha256"] = current_runner_hash
        record["repoRunnerInputsBefore"] = capture_runner_inventory(PRIVATE_RUNNER)
        save()

        temp_root = Path(tempfile.mkdtemp(prefix="tsj-q30-epoch15-private-menu-")).resolve()
        require(is_under(temp_root, tempfile.gettempdir()),
                "new private source root escaped OS temp")
        record["privateSourceRoot"] = str(temp_root)
        record["copyScope"] = {
            "rawSnapshotInputCount": EXPECTED_RAW_INPUTS,
            "requiredBuildScripts": [BUILD_SCRIPT, BUILD_ISOLATION_MODULE],
            "additionalPinnedGwtJarCount": len(GWT_JARS),
            "gitCopied": False,
            "priorBuildDirectoryCopied": False,
            "priorShippingAppCopied": False,
            "priorGwtCompileCacheCopied": False,
        }
        save()

        phase_started = time.monotonic()
        set_phase("copy-and-private-catalog-toggle")
        copied = copy_bound_source(snapshot, temp_root)
        build_support = copy_build_inputs(temp_root, snapshot)
        record["copyScope"]["copiedRawInputCount"] = len(copied)
        record["copyScope"]["rawSnapshotRootCounts"] = EXPECTED_RAW_ROOT_COUNTS
        record["copyScope"]["boundWarInputCount"] = EXPECTED_RAW_ROOT_COUNTS["war"]
        record["copyScope"]["compiledOutputPathsInRawSnapshot"] = 0
        record["buildSupport"] = build_support
        verify_build_support_unchanged(build_support)
        record["compiledInventoryBefore"] = inventory_tree(
            temp_root, "war/circuitjs1", allow_missing=True
        )
        require(record["compiledInventoryBefore"] == [],
                "raw source copy unexpectedly inherited compiled GWT output")
        record["compiledInventoryBeforeStatus"] = "ABSENT_IN_HASH_BOUND_RAW_SNAPSHOT"
        record["catalogSourceDelta"] = copy_source_delta(snapshot, temp_root)
        record["catalogSourceDeltaCount"] = len(record["catalogSourceDelta"])
        raw_before_build = inventory_raw_source_roots(temp_root)
        record["rawSourceInventoryBeforeBuild"] = require_inventory_matches(
            raw_before_build,
            expected_raw_source_inventory(snapshot, record["catalogSourceDelta"]),
            "pre-build raw source inventory",
        )
        record["phases"].append({
            "phase": "copy-and-private-catalog-toggle",
            "status": "PASS",
            "elapsedSeconds": round(time.monotonic() - phase_started, 3),
            "rawInputCount": len(copied),
        })
        save()

        phase_started = time.monotonic()
        set_phase("private-jdk8-gwt-build")
        build_command = [
            str(powershell), "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", str(temp_root / BUILD_SCRIPT),
            "-JavaHome", str(JAVA_HOME),
            "-Target", "Compile",
            "-Style", "OBF",
            "-ProcessTimeoutSeconds", str(JDK8_BUILD_SECONDS),
        ]
        record["buildCommand"] = build_command
        save()
        with build_log_path.open("xb") as log:
            build = subprocess.Popen(
                build_command, cwd=str(temp_root), stdout=log,
                stderr=subprocess.STDOUT, env=host_environment,
            )
            record["buildProcess"] = {"pid": build.pid, "identity": None}
            try:
                record["buildProcess"]["identity"] = json_process_identity(
                    build.pid, powershell
                )
                require(record["buildProcess"]["identity"] is not None,
                        "could not capture build PowerShell process identity")
            except Exception:
                try:
                    descendants = descendants_of(process_snapshot(powershell), build.pid)
                except Exception:
                    descendants = []
                stop_direct_child(build)
                record["buildProcess"]["capturedDescendants"] = descendants
                record["buildProcess"]["javaCleanupAttempts"] = (
                    terminate_java_descendants(powershell, descendants)
                )
                raise
            save()
            try:
                build_exit = build.wait(timeout=JDK8_BUILD_SECONDS + 120)
            except subprocess.TimeoutExpired:
                try:
                    descendants = descendants_of(process_snapshot(powershell), build.pid)
                    tree_error = None
                except Exception as error:
                    descendants = []
                    tree_error = str(error)
                stop_result = stop_direct_child(build)
                wrapper_stopped = stop_result["stopped"]
                cleanup_attempts = terminate_java_descendants(powershell, descendants)
                record["buildProcess"]["timeout"] = True
                record["buildProcess"]["wrapperStopped"] = wrapper_stopped
                record["buildProcess"]["wrapperStopResult"] = stop_result
                record["buildProcess"]["capturedDescendants"] = descendants
                record["buildProcess"]["processTreeQueryError"] = tree_error
                record["buildProcess"]["javaCleanupAttempts"] = cleanup_attempts
                record["buildExitCode"] = None
                record["status"] = "FAIL"
                record["phase"] = "build-timeout"
                record["phases"].append({
                    "phase": "private-jdk8-gwt-build",
                    "status": "FAIL",
                    "elapsedSeconds": round(time.monotonic() - phase_started, 3),
                    "exitCode": None,
                    "cleanup": {
                        "wrapperStopped": wrapper_stopped,
                        "javaAttempts": cleanup_attempts,
                    },
                })
                save()
                raise GateError("private JDK8/GWT build exceeded its external bound")
        record["buildExitCode"] = build_exit
        build_identity_after = json_process_identity(build.pid, powershell)
        original_build_identity = record["buildProcess"]["identity"]
        same_build_process_remains = (
            build_identity_after is not None and
            build_identity_after.get("createdUtc") ==
            original_build_identity.get("createdUtc") and
            build_identity_after.get("ExecutablePath") ==
            original_build_identity.get("ExecutablePath")
        )
        record["buildProcess"]["identityAfterExit"] = build_identity_after
        record["buildProcess"]["sameProcessRemainsAfterExit"] = same_build_process_remains
        require(not same_build_process_remains,
                "build PowerShell process identity remained after exit")
        record["buildLogSha256"] = sha256_file(build_log_path)
        build_log = build_log_path.read_bytes().decode("utf-8-sig")
        build_confirmed = (
            build_exit == 0 and
            "Compilation succeeded --" in build_log and
            "Linking succeeded --" in build_log and
            "BUILD_INFRASTRUCTURE:" not in build_log
        )
        require(build_confirmed,
                "private JDK8/GWT build did not confirm compile and link success")
        record["phases"].append({
            "phase": "private-jdk8-gwt-build",
            "status": "PASS",
            "elapsedSeconds": round(time.monotonic() - phase_started, 3),
            "exitCode": build_exit,
        })
        save()

        phase_started = time.monotonic()
        set_phase("post-build-source-and-compiled-audit")
        record["compiledInventoryAfter"] = inventory_tree(temp_root, "war/circuitjs1")
        verify_build_support_unchanged(build_support)
        validate_five_gwt_permutations(
            record["compiledInventoryAfter"], "private enabled GWT build"
        )
        raw_after_build = inventory_raw_source_roots(temp_root)
        record["rawSourceInventoryAfterBuild"] = require_inventory_matches(
            raw_after_build,
            expected_raw_source_inventory(snapshot, record["catalogSourceDelta"]),
            "post-build raw source inventory",
        )
        record["sourceCopyAfterBuildCount"] = record[
            "rawSourceInventoryAfterBuild"]["count"]
        record["sourceCopyAfterBuildSha256"] = record[
            "rawSourceInventoryAfterBuild"]["sha256"]
        record["phases"].append({
            "phase": "post-build-source-and-compiled-audit",
            "status": "PASS",
            "elapsedSeconds": round(time.monotonic() - phase_started, 3),
        })
        save()

        phase_started = time.monotonic()
        set_phase("private-enabled-menu-host")
        record["runnerInventoryBefore"] = capture_runner_inventory(PRIVATE_RUNNER)
        runner_before_hashes = {
            row["label"]: row["sha256"] for row in record["runnerInventoryBefore"]
        }
        require(record["runnerInventoryBefore"] ==
                record["repoRunnerInputsBefore"],
                "build/menu runner inputs changed since preflight")
        require(runner_before_hashes["retained enabled menu runner"] ==
                EXPECTED_PRIVATE_RUNNER_SHA256,
                "retained enabled-menu runner changed before host launch")
        require(runner_before_hashes["tracked disabled menu runner"] ==
                current_runner_hash,
                "tracked disabled menu runner changed since gate")
        require(not output_dir.exists() and not output_dir.is_symlink(),
                "private enabled-menu output already exists; refusing overwrite")
        with host_log_path.open("xb") as log:
            host_command = [
                str(HOST_PYTHON), "-B", "-u", str(PRIVATE_RUNNER),
                str(temp_root), str(output_dir),
            ]
            record["hostCommand"] = host_command
            save()
            host = subprocess.Popen(
                host_command, cwd=str(REPO), stdout=log,
                stderr=subprocess.STDOUT, env=host_environment,
            )
            record["hostProcess"] = {"pid": host.pid, "identity": None}
            try:
                record["hostProcess"]["identity"] = json_process_identity(
                    host.pid, powershell
                )
                require(record["hostProcess"]["identity"] is not None,
                        "could not capture CPython 3.13 host process identity")
                require(Path(record["hostProcess"]["identity"]["ExecutablePath"]).resolve()
                        == HOST_PYTHON.resolve(),
                        "menu host is not running under the pinned CPython 3.13 executable")
            except Exception:
                try:
                    descendants = descendants_of(process_snapshot(powershell), host.pid)
                except Exception:
                    descendants = []
                stop_result = stop_direct_child(host)
                record["hostProcess"]["edgeCleanupAttempts"] = terminate_owned_edges(
                    powershell, output_dir, descendants
                )
                record["hostProcess"]["wrapperStopResult"] = stop_result
                raise
            save()
            try:
                host_exit = host.wait(timeout=MENU_HOST_SECONDS)
            except subprocess.TimeoutExpired:
                try:
                    descendants = descendants_of(process_snapshot(powershell), host.pid)
                    tree_error = None
                except Exception as error:
                    descendants = []
                    tree_error = str(error)
                stop_result = stop_direct_child(host)
                wrapper_stopped = stop_result["stopped"]
                edge_attempts = terminate_owned_edges(
                    powershell, output_dir, descendants
                )
                record["hostProcess"]["timeout"] = True
                record["hostProcess"]["wrapperStopped"] = wrapper_stopped
                record["hostProcess"]["wrapperStopResult"] = stop_result
                record["hostProcess"]["capturedDescendants"] = descendants
                record["hostProcess"]["processTreeQueryError"] = tree_error
                record["hostProcess"]["edgeCleanupAttempts"] = edge_attempts
                record["hostExitCode"] = None
                record["status"] = "FAIL"
                record["phase"] = "menu-host-timeout"
                record["phases"].append({
                    "phase": "private-enabled-menu-host",
                    "status": "FAIL",
                    "elapsedSeconds": round(time.monotonic() - phase_started, 3),
                    "exitCode": None,
                    "cleanup": {
                        "wrapperStopped": wrapper_stopped,
                        "edgeAttempts": edge_attempts,
                    },
                })
                save()
                raise GateError("private enabled-menu host exceeded its two-hour bound")
        record["hostExitCode"] = host_exit
        host_identity_after = json_process_identity(host.pid, powershell)
        original_host_identity = record["hostProcess"]["identity"]
        same_host_process_remains = (
            host_identity_after is not None and
            host_identity_after.get("createdUtc") ==
            original_host_identity.get("createdUtc") and
            host_identity_after.get("ExecutablePath") ==
            original_host_identity.get("ExecutablePath")
        )
        record["hostProcess"]["identityAfterExit"] = host_identity_after
        record["hostProcess"]["sameProcessRemainsAfterExit"] = same_host_process_remains
        require(not same_host_process_remains,
                "CPython 3.13 menu host process identity remained after exit")
        require(host_exit == 0, "private enabled-menu host returned nonzero")
        record["hostResult"] = validate_private_menu_output(output_dir, host_exit)
        record["compiledInventoryAfterMenu"] = inventory_tree(
            temp_root, "war/circuitjs1"
        )
        require(record["compiledInventoryAfterMenu"] ==
                record["compiledInventoryAfter"],
                "menu host changed the fresh compiled app inventory")
        raw_after_host = inventory_raw_source_roots(temp_root)
        record["rawSourceInventoryAfterMenu"] = require_inventory_matches(
            raw_after_host,
            expected_raw_source_inventory(snapshot, record["catalogSourceDelta"]),
            "post-menu raw source inventory",
        )
        require(record["rawSourceInventoryAfterMenu"] ==
                record["rawSourceInventoryAfterBuild"],
                "menu host changed the private 1,354-input source snapshot")
        verify_build_support_unchanged(build_support)
        record["phases"].append({
            "phase": "private-enabled-menu-host",
            "status": "PASS",
            "elapsedSeconds": round(time.monotonic() - phase_started, 3),
            "exitCode": host_exit,
            "cleanupSeconds": record["hostResult"]["cleanup"].get("seconds"),
        })
        save()

        phase_started = time.monotonic()
        set_phase("final-source-runner-and-tracked-disabled-audit")
        record["runnerInventoryAfter"] = capture_runner_inventory(PRIVATE_RUNNER)
        after_hashes = {
            row["label"]: row["sha256"] for row in record["runnerInventoryAfter"]
        }
        require(after_hashes == runner_before_hashes,
                "build/menu run changed one or more runner/build inputs")
        record["repoRawInputsAfter"] = validate_repo_inputs(snapshot)
        final_catalog = (REPO / TARGET_CATALOG).read_bytes()
        require(final_catalog.count(FALSE_REGISTRATION) == 1 and
                final_catalog.count(TRUE_REGISTRATION) == 0 and
                sha256(final_catalog) == next(
                    row["sha256"] for row in snapshot["files"]
                    if row["path"] == TARGET_CATALOG
                ),
                "tracked Q30 catalog changed during private enabled-menu qualification")
        record["phases"].append({
            "phase": "final-source-runner-and-tracked-disabled-audit",
            "status": "PASS",
            "elapsedSeconds": round(time.monotonic() - phase_started, 3),
        })
        record["status"] = "PASS"
        record["phase"] = "complete"
    except Exception as error:
        if record.get("status") == "RUNNING":
            record["status"] = "FAIL"
            active = record.get("phase", "unknown")
            record["phases"].append({
                "phase": active,
                "status": "FAIL",
                "error": str(error),
            })
        record["error"] = str(error)
    finally:
        record["finishedUtc"] = utc_now()
        try:
            save()
        except Exception as error:
            print("ERROR: unable to retain final private-menu record: " + str(error),
                  file=sys.stderr)
            return 2
    print(json.dumps({
        "status": record.get("status"),
        "phase": record.get("phase"),
        "result": str(result_path),
        "privateSourceRoot": record.get("privateSourceRoot"),
        "error": record.get("error"),
    }, indent=2))
    return 0 if record.get("status") == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
