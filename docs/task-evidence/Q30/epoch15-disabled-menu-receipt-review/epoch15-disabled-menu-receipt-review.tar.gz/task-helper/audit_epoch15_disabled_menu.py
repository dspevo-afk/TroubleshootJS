#!/usr/bin/env python3
"""Review the retained disabled-menu receipts; never launches the menu runner."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import tempfile
from datetime import datetime
from pathlib import Path, PurePosixPath


REPO = Path(r"$REPO")
TASK_NAME = "q30-process-pinned-final-qualification-fcffecff8fa444889bce93725495c628"
HEAD = "d37c3b3b8581abdeaa9b88b7bfb2349cff958d31"
SOURCE = "a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51"
ORIGINAL_PLAN = "1078cb80a13e8fcde2dac6dd1188ee8fa3add3faf6b64a385ed27ed4cc19b749"
CONTINUED_PLAN = "69707f4282dd41a394c2eb6723057b32379d0743553940a2b2a11bd5221f8d48"
INTEGRATION_POINTER = "fa238faff209fdbe497c72637b3e49b6e28a482a18d6ea2123e8ad4a8f3fb9e4"
ARCHIVE_SCRIPT = "d14c811e487c0817003d5171fc0c1c53820c5d213e05a9c2c5724fb808b9fb8d"
MENU_RUNNER = "c07da2fad9cca960bc4f1efde78accf082de85c1765a3d602ba11da500dd035d"
RAW_INPUTS = 1354
RAW_COUNTS = {"src": 1132, "tests": 173, "war": 29, "scripts": 20}
MAX_RECEIPT = 16 * 1024 * 1024
MAX_TOTAL_SOURCE = 256 * 1024 * 1024
HASH = re.compile(r"[0-9a-f]{64}\Z")
CASE_LINE = re.compile(
    r"PASS ([A-Z0-9_]+) (EASY|MEDIUM) ([0-2]) "
    r"(tsj-alpha/4/(?:EASY|MEDIUM)/[A-Z0-9_]+/-?[0-9]+) ([0-9]+(?:\.[0-9]+)?)\Z"
)
DISABLED_FAMILIES = (
    ("LED_INDICATOR", "EASY"),
    ("DIODE_PROTECTED_INDICATOR", "EASY"),
    ("PARALLEL_DUAL_INDICATOR", "EASY"),
    ("RC_DELAY", "EASY"),
    ("NPN_LOW_SIDE_SWITCH", "EASY"),
    ("NMOS_LOW_SIDE_SWITCH", "EASY"),
    ("RELAY_OUTPUT", "EASY"),
    ("SENSOR_CONTROL", "EASY"),
    ("RB15_CONTROL", "EASY"),
    ("COMPOSED_CONTROLLED_INDICATOR", "MEDIUM"),
)
EXPECTED_CASES = [(family, profile, ordinal)
                  for family, profile in DISABLED_FAMILIES for ordinal in range(3)]
EXPECTED_SOURCE_PATHS = [
    "src/com/lushprojects/circuitjs1/client/CirSim.java",
    "src/com/lushprojects/circuitjs1/client/QuickPlayDeveloperVerifier.java",
    "tests/browser/compiled_attribute_acceptance.py",
    "tests/qualification/q30-scale-acceptance/normal_screen_host.py",
    "tests/qualification/q30-scale-acceptance/overlay-manifest.json",
]
MENU_IDENTITY_ROWS = {
    21016: ("disabled-menu-controller", "2026-10-02T14:59:38.366139Z"),
    7952: ("archive-wrapper", "2026-10-02T15:13:12.358173Z"),
    23948: ("disabled-menu-host", "2026-10-02T14:59:45.951552Z"),
    29360: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.601387Z"),
    12852: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.625786Z"),
    4704: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.711794Z"),
    8588: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.717559Z"),
    26588: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.743791Z"),
    26272: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.846880Z"),
    18360: ("disabled-menu-initial-edge", "2026-10-02T14:59:46.854213Z"),
}


class AuditError(RuntimeError):
    pass


def need(ok, why):
    if not ok:
        raise AuditError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def inside(path, root):
    try:
        path.resolve(strict=True).relative_to(root.resolve(strict=True))
        return True
    except (OSError, ValueError):
        return False


def decode(raw, label):
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16", errors="strict")
    return raw.decode("utf-8-sig" if raw.startswith(b"\xef\xbb\xbf") else "utf-8", errors="strict")


def pairs_unique(pairs):
    obj = {}
    for key, value in pairs:
        need(key not in obj, "duplicate JSON key")
        obj[key] = value
    return obj


def json_obj(raw, label):
    result = json.loads(decode(raw, label), object_pairs_hook=pairs_unique,
                        parse_constant=lambda x: (_ for _ in ()).throw(AuditError("non-finite JSON in " + label)))
    need(isinstance(result, dict), "expected JSON object: " + label)
    return result


class Ledger:
    """Retain artifact hashes and recheck every receipt, source, and compiled file."""
    def __init__(self):
        self.receipts = {}
        self.sources = {}
        self.evidence = []

    def read(self, path, root):
        need(inside(path, root) and not path.is_symlink(), "receipt escaped root or is a symlink: " + path.name)
        key = os.path.normcase(str(path.resolve(strict=True)))
        if key in self.receipts:
            return self.receipts[key]
        before = path.stat()
        need(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_RECEIPT,
             "receipt is not a bounded regular file: " + path.name)
        raw = path.read_bytes()
        after = path.stat()
        need(before.st_size == after.st_size == len(raw) and before.st_mtime_ns == after.st_mtime_ns,
             "receipt changed while read: " + path.name)
        self.receipts[key] = raw
        return raw

    def json(self, path, root, label):
        return json_obj(self.read(path, root), label)

    def add_evidence(self, name, path, root, kind):
        need(not any(row["name"] == name for row in self.evidence), "duplicate evidence member: " + name)
        raw = self.read(path, root)
        self.evidence.append({"name": name, "path": path, "root": root, "kind": kind,
                              "rawBytes": len(raw), "rawSha256": sha(raw)})

    def hash_source(self, path, root, size, expected):
        need(inside(path, root) and not path.is_symlink(), "source escaped root or is a symlink: " + path.name)
        before = path.stat()
        need(stat.S_ISREG(before.st_mode) and before.st_size == size,
             "source size differs from frozen inventory: " + path.name)
        h = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(block)
        after = path.stat()
        need(before.st_mtime_ns == after.st_mtime_ns and h.hexdigest() == expected,
             "raw source/compiled bytes differ from expected hash: " + path.name)
        key = os.path.normcase(str(path.resolve(strict=True)))
        self.sources[key] = (path, root, size, expected, after.st_mtime_ns)

    def recheck(self):
        for path, root, size, expected, mtime in self.sources.values():
            need(inside(path, root) and not path.is_symlink(), "source became symlink/escaped before completion")
            before = path.stat()
            h = hashlib.sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    h.update(block)
            after = path.stat()
            need(before.st_size == after.st_size == size and before.st_mtime_ns == after.st_mtime_ns == mtime and
                 h.hexdigest() == expected, "source/compiled file changed during audit: " + path.name)
        for key, raw in self.receipts.items():
            path = Path(key)
            need(path.is_file() and not path.is_symlink() and path.stat().st_size == len(raw) and
                 sha(path.read_bytes()) == sha(raw), "receipt changed during audit: " + path.name)


class AuditContext:
    def __init__(self, workspace, repo, task, ledger, summary):
        self.workspace = workspace
        self.repo = repo
        self.task = task
        self.ledger = ledger
        self.summary = summary


def normalized(path):
    return os.path.normcase(str(path.resolve(strict=True)))


def same_utc(left, right):
    return (isinstance(left, str) and isinstance(right, str) and
            datetime.fromisoformat(left.replace("Z", "+00:00")) ==
            datetime.fromisoformat(right.replace("Z", "+00:00")))


def validate_source(ctx, pointer, integration_pointer, stage, build):
    task, repo, ledger = ctx.task, ctx.repo, ctx.ledger
    audit_raw = ledger.read(task / "source-input-audit.json", task)
    source_audit = json_obj(audit_raw, "source audit")
    maintained_raw = ledger.read(task / "source-snapshot-maintained.json", task)
    maintained = json_obj(maintained_raw, "maintained source snapshot")
    snapshot_raw = ledger.read(task / "source-snapshot.json", task)
    snapshot = json_obj(snapshot_raw, "source snapshot")
    isolated_raw = ledger.read(task / "isolated" / "source-snapshot.json", task, )
    isolated = json_obj(isolated_raw, "isolated source snapshot")
    rows = snapshot.get("files")
    need(snapshot.get("status") == "PASS" and snapshot.get("baseHead") == HEAD and
         snapshot.get("sourceIdentity") == SOURCE and snapshot.get("layoutAlgorithmVersion") == 15 and
         snapshot.get("q30NormalPlayerEnabled") is False and isinstance(rows, list) and len(rows) == RAW_INPUTS,
         "source snapshot is not the reviewed disabled-Q30 1,354-input inventory")
    need(set(maintained) == {"schema", "baseHead", "files", "sourceIdentity"} and
         maintained.get("schema") == snapshot.get("schema") and maintained.get("baseHead") == HEAD and
         maintained.get("sourceIdentity") == SOURCE and maintained.get("files") == rows and
         set(isolated) == {"schema", "baseHead", "files", "sourceIdentity"} and
         isolated.get("schema") == snapshot.get("schema") and
         source_audit.get("status") == "PASS" and source_audit.get("baseHead") == HEAD and
         source_audit.get("sourceIdentity") == SOURCE and source_audit.get("inputsVerified") == RAW_INPUTS and
         source_audit.get("layoutAlgorithmVersion") == 15 and source_audit.get("q30NormalPlayerEnabled") is False and
         source_audit.get("maintainedSnapshotSha256") == sha(maintained_raw) and
         isolated.get("baseHead") == HEAD and
         isolated.get("sourceIdentity") == SOURCE and isolated.get("files") == rows,
         "maintained/isolated source snapshot and raw audit do not agree")
    payload = {"schema": snapshot["schema"], "baseHead": snapshot["baseHead"], "files": rows}
    identity_hash = sha(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"))
    need(identity_hash == SOURCE and pointer.get("sourceIdentity") == SOURCE,
         "canonical raw source identity mismatch")
    groups, total, names, by_path = {}, 0, set(), {}
    for row in rows:
        need(isinstance(row, dict) and set(row) == {"path", "size", "sha256"} and
             isinstance(row.get("path"), str) and type(row.get("size")) is int and row["size"] >= 0 and
             isinstance(row.get("sha256"), str) and HASH.fullmatch(row["sha256"]),
             "source inventory row malformed")
        rel = PurePosixPath(row["path"])
        need(not rel.is_absolute() and "\\" not in row["path"] and ".." not in rel.parts and
             ":" not in row["path"] and rel.as_posix() == row["path"] and row["path"] not in names and
             rel.parts[0] in RAW_COUNTS, "unsafe/unexpected source inventory path")
        names.add(row["path"])
        groups[rel.parts[0]] = groups.get(rel.parts[0], 0) + 1
        total += row["size"]
        by_path[row["path"]] = row
    need(rows == sorted(rows, key=lambda x: x["path"]) and groups == RAW_COUNTS and
         total <= MAX_TOTAL_SOURCE and not any(p.startswith("war/circuitjs1/") for p in names),
         "source order/group counts/size or generated-output exclusion changed")
    need(pointer.get("changedSourcePaths") == EXPECTED_SOURCE_PATHS and
         pointer.get("changedPlanFields") == ["baseHead"] and
         pointer.get("baseHead") == HEAD and pointer.get("layoutEpoch") == 15 and
         pointer.get("frozenRoots") == 77 and pointer.get("frozenServiceSensitivityRoots") == 21 and
         pointer.get("originalPlanSha256") == ORIGINAL_PLAN and
         pointer.get("continuedPlanSha256") == CONTINUED_PLAN and
         pointer.get("integrationPointerSha256") == INTEGRATION_POINTER,
         "epoch15 task pointer changed source/plan/cohort binding")
    need(integration_pointer.get("status") == "INTEGRATED_PENDING_FRESH_GATES" and
         integration_pointer.get("baseHead") == HEAD and
         integration_pointer.get("taskRoot") and normalized(Path(integration_pointer["taskRoot"])) == normalized(task),
         "integration pointer does not bind this task")
    integration = ledger.json(task / "integration.json", task, "task integration")
    need(integration.get("status") == "INTEGRATED_PENDING_FRESH_GATES" and
         integration.get("baseHead") == HEAD and integration.get("changes") == integration_pointer.get("changes"),
         "task integration record differs from integration pointer")
    for change in integration.get("changes", []):
        row = by_path.get(change.get("path"))
        need(row is not None and row["sha256"] == change.get("candidateSha256"),
             "integrated source change is not present in the raw source snapshot")
    for row in rows:
        rel = PurePosixPath(row["path"])
        ledger.hash_source(repo.joinpath(*rel.parts), repo, row["size"], row["sha256"])
        ledger.hash_source(ctx.task / "shipping" / "app" / Path(*rel.parts), ctx.task,
                           row["size"], row["sha256"])
    need(stage.get("rawInputsVerified") == RAW_INPUTS and stage.get("consumedInputsUnchanged") is True,
         "disabled-menu stage did not report its pre/post raw-input hash comparison")
    build_raw = ledger.read(task / "shipping-build-result.json", task)
    need(stage.get("shippingBuildReceiptSha256") == sha(build_raw) and
         build.get("status") == "PASS" and build.get("head") == HEAD and build.get("exitCode") == 0 and
         build.get("compilationConfirmed") is True and build.get("permutations") == 5 and
         build.get("consumedSourceIdentity") == SOURCE and build.get("consumedInputsVerified") == RAW_INPUTS and
         normalized(Path(build.get("app", ""))) == normalized(task / "shipping" / "app") and
         stage.get("shippingBuildStatus") == "PASS" and
         stage.get("shippingBuildCompilationConfirmed") is True and
         stage.get("shippingBuildConsumedSourceIdentity") == SOURCE and
         stage.get("shippingBuildConsumedInputsVerified") == RAW_INPUTS,
         "disabled menu is not bound to the fresh source-matched five-permutation GWT build")
    return {
        "sourceCount": RAW_INPUTS, "sourceIdentity": SOURCE,
        "snapshotSha256": sha(snapshot_raw), "maintainedSnapshotSha256": sha(maintained_raw),
        "isolatedSnapshotSha256": sha(isolated_raw), "sourceAuditSha256": sha(audit_raw),
        "currentRepositoryHashesRechecked": RAW_INPUTS,
        "currentShippingSourceHashesRechecked": RAW_INPUTS,
        "stageRawPrePostComparison": "consumedInputsUnchanged=true; per-file raw pre/post rows are not persisted",
        "sourceFiles": rows, "buildReceiptSha256": sha(build_raw),
    }


def validate_compiled_inventory(ctx, stage):
    task = ctx.task
    before, after = stage.get("compiledInputsBefore"), stage.get("compiledInputsAfter")
    need(isinstance(before, list) and isinstance(after, list) and len(before) == 357 and len(after) == 357,
         "compiled inventory must contain exactly 357 stage rows before and after")
    need(before == after, "compiled app hashes differ between stage before and after")
    seen, total = set(), 0
    compiled_root = task / "shipping" / "app" / "war" / "circuitjs1"
    for row in before:
        need(isinstance(row, dict) and set(row) == {"path", "size", "sha256"} and
             isinstance(row.get("path"), str) and type(row.get("size")) is int and row["size"] >= 0 and
             isinstance(row.get("sha256"), str) and HASH.fullmatch(row["sha256"]),
             "compiled inventory row malformed")
        rel = PurePosixPath(row["path"])
        need(not rel.is_absolute() and "\\" not in row["path"] and ".." not in rel.parts and
             rel.as_posix() == row["path"] and row["path"].startswith("war/circuitjs1/") and
             row["path"] not in seen, "unsafe/duplicate compiled path")
        seen.add(row["path"])
        total += row["size"]
        path = task / "shipping" / "app" / Path(*rel.parts)
        ctx.ledger.hash_source(path, task, row["size"], row["sha256"])
    need(total <= MAX_TOTAL_SOURCE, "compiled inventory exceeds bounded 256 MiB")
    cache_rows = [row for row in before if row["path"].lower().endswith(".cache.js")]
    need(len(cache_rows) == 5 and all(re.fullmatch(r"[0-9a-fA-F]{32}\.cache\.js",
                                                  PurePosixPath(row["path"]).name) for row in cache_rows),
         "compiled inventory does not preserve exactly five canonical GWT permutations")
    actual = []
    need(compiled_root.is_dir() and inside(compiled_root, task), "shipping compiled root is missing/outside task")
    for directory, subdirs, files in os.walk(compiled_root, followlinks=False):
        base = Path(directory)
        need(not base.is_symlink() and all(not (base / name).is_symlink() for name in subdirs + files),
             "symlink/reparse item found in compiled inventory")
        for name in files:
            path = base / name
            rel = path.relative_to(task / "shipping" / "app").as_posix()
            info = path.stat()
            need(stat.S_ISREG(info.st_mode), "nonregular compiled input")
            h = hashlib.sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    h.update(block)
            actual.append({"path": rel, "size": info.st_size, "sha256": h.hexdigest()})
    actual.sort(key=lambda row: row["path"])
    expected = sorted(before, key=lambda row: row["path"])
    need(actual == expected, "current shipping compiled tree differs from both stage inventories")
    catalog_rel = Path("src/com/lushprojects/circuitjs1/client/PlayerFamilyCatalog.java")
    registration_false = b"registerStagedFamily(new Rb30PlayerFamilyCapability(), false)"
    registration_true = b"registerStagedFamily(new Rb30PlayerFamilyCapability(), true)"
    repo_catalog = ctx.repo / catalog_rel
    app_catalog = task / "shipping" / "app" / catalog_rel
    repo_raw = ctx.ledger.read(repo_catalog, ctx.repo)
    app_raw = ctx.ledger.read(app_catalog, task)
    source_row = next((row for row in stage.get("sourceInventoryRows", [])
                       if row.get("path") == catalog_rel.as_posix()), None)
    del source_row
    need(registration_false in repo_raw and registration_true not in repo_raw and
         registration_false in app_raw and registration_true not in app_raw and repo_raw == app_raw,
         "tracked/shipping catalog does not keep RB30 disabled with matching source bytes")
    return {"compiledFileCount": len(before), "compiledInputSha256": sha(
                json.dumps(before, sort_keys=True, separators=(",", ":")).encode("utf-8")),
            "beforeAfterEqual": True, "currentTreeMatches": True, "canonicalGwtPermutations": 5,
            "compiledTotalBytes": total, "catalogDisabled": True,
            "catalogSha256": sha(repo_raw)}


def validate_menu_result(ctx, stage, runner_raw, tool_id, tool_exit):
    task, ledger = ctx.task, ctx.ledger
    result_path = task / "disabled-menu" / "result.json"
    result_raw = ledger.read(result_path, task)
    result = json_obj(result_raw, "disabled menu host result")
    expected_keys = {"outcome", "cases", "errors", "replays", "staleReplayEpoch", "blockedFamilyReplay", "cleanup"}
    need(set(result) == expected_keys and result.get("outcome") == "PASS" and result.get("errors") == [],
         "disabled-menu result schema/outcome/errors changed")
    cases = result.get("cases")
    need(isinstance(cases, list) and len(cases) == 30, "disabled menu does not contain exactly 30 launches")
    actual_pairs = [(row.get("family"), row.get("profile"), row.get("ordinal")) for row in cases]
    need(actual_pairs == EXPECTED_CASES, "disabled menu family/profile/ordinal matrix differs")
    by_pair, max_seconds, max_units = {}, 0.0, 0
    for row in cases:
        fam, profile, ordinal = row["family"], row["profile"], row["ordinal"]
        need(row.get("outcome") == "PASS" and row.get("screen") == "TICKET" and
             row.get("ready") is True and row.get("privateMetadataAbsent") is True and
             row.get("selectedJobBudgetMillis") == 90000 and
             type(row.get("selectedJobBudgetMillis")) is int and
             row.get("observationBoundSeconds") == 115.0 and
             type(row.get("observationBoundSeconds")) in (int, float) and
             not isinstance(row.get("observationBoundSeconds"), bool),
             "menu case failed readiness/privacy or changed its observation/job budget")
        replay = row.get("replay", "")
        need(re.fullmatch(r"tsj-alpha/4/" + re.escape(profile) + "/" + re.escape(fam) + r"/-?[0-9]+", replay),
             "menu case replay identity/profile/epoch differs")
        candidates = row.get("observedCandidates")
        need(isinstance(candidates, list) and all(type(x) is int and 0 <= x < 4 for x in candidates),
             "menu case observed-candidate list malformed")
        elapsed, seconds, units = row.get("elapsedSeconds"), row.get("seconds"), row.get("maxObservedUnits")
        need(type(elapsed) in (int, float) and not isinstance(elapsed, bool) and 0 <= elapsed <= 115 and
             type(seconds) in (int, float) and not isinstance(seconds, bool) and 0 <= seconds <= 115 and
             type(units) is int and 0 <= units <= 640,
             "menu case exceeded the unchanged observation/work bound")
        max_seconds = max(max_seconds, float(seconds))
        max_units = max(max_units, units)
        by_pair[(fam, profile, ordinal)] = row

    replays = result.get("replays")
    expected_replay_families = [("RELAY_OUTPUT", "EASY"), ("COMPOSED_CONTROLLED_INDICATOR", "MEDIUM")]
    need(isinstance(replays, list) and len(replays) == 2 and
         [(row.get("family"), row.get("profile")) for row in replays] == expected_replay_families,
         "disabled menu must retain the two original replay controls")
    for row in replays:
        family, profile = row["family"], row["profile"]
        case = by_pair[(family, profile, 2)]
        need(row.get("outcome") == "PASS" and row.get("isolated") is True and
             row.get("replay") == case.get("replay") and row.get("screen") == "TICKET" and
             row.get("ready") is True and row.get("selectedJobBudgetMillis") == 90000 and
             row.get("observationBoundSeconds") == 115.0 and
             type(row.get("maxObservedUnits")) is int and 0 <= row["maxObservedUnits"] <= 640 and
             type(row.get("seconds")) in (int, float) and row["seconds"] <= 115,
             "disabled-menu replay control failed or changed its current contract")
    stale = result.get("staleReplayEpoch", {})
    need(stale.get("replay") == "tsj-alpha/3/MEDIUM/RB30_CONTROL/13" and
         stale.get("outcome") == "EXPECTED_REJECTED" and
         stale.get("message") == "Unsupported replay identity or epoch" and
         stale.get("screen") == "MENU" and stale.get("predecessorIsolated") is True and
         stale.get("prelaunchStateUnchanged") is True and stale.get("noGenerationStarted") is True,
         "stale RB30 replay was not rejected before mutation/generation")
    blocked = result.get("blockedFamilyReplay", {})
    need(blocked.get("family") == "RB30_CONTROL" and blocked.get("replayEpoch") == "tsj-alpha/4" and
         blocked.get("outcome") == "EXPECTED_BLOCKED" and blocked.get("noGenerationStarted") is True and
         blocked.get("predecessorIsolated") is True and blocked.get("screen") == "ERROR",
         "disabled RB30 family replay negative control differs")
    cleanup = result.get("cleanup", {})
    need(set(cleanup) == {"seconds", "serverStopped", "ownedSurvivors"} and
         type(cleanup.get("seconds")) in (int, float) and not isinstance(cleanup.get("seconds"), bool) and
         cleanup.get("seconds") >= 0 and cleanup.get("serverStopped") is True and
         cleanup.get("ownedSurvivors") == [], "disabled menu host cleanup did not pass")
    log_path = task / "disabled-menu.log"
    log_raw = ledger.read(log_path, task)
    log_lines = [line for line in decode(log_raw, "disabled-menu log").splitlines() if line.strip()]
    need(len(log_lines) == 31 and log_lines[-1] == "FINISHED PASS cases 30",
         "disabled-menu log does not end with the exact 30-case terminal marker")
    log_rows = []
    for line in log_lines[:-1]:
        match = CASE_LINE.fullmatch(line)
        need(match is not None, "unexpected/error line in disabled-menu log")
        log_rows.append((match.group(1), match.group(2), int(match.group(3)), match.group(4)))
    need(log_rows == [(row["family"], row["profile"], row["ordinal"], row["replay"]) for row in cases],
         "menu stdout case rows differ from terminal result receipts")

    stage_file = task / "disabled-menu-stage-result.json"
    stage_raw = ledger.read(stage_file, task)
    need(stage.get("stage") == "disabled-menu" and stage.get("schema") == 1 and
         stage.get("head") == HEAD and stage.get("candidateBaseHead") == HEAD and
         stage.get("sourceIdentity") == SOURCE and stage.get("status") == "COMMAND_PASS_PENDING_RECEIPT_REVIEW" and
         stage.get("exitCode") == 0 and stage.get("hostOutcome") == "PASS" and
         stage.get("rawInputsVerified") == RAW_INPUTS and stage.get("consumedInputsUnchanged") is True and
         stage.get("q30NormalPlayerEnabled") is False and stage.get("freshBuild") is True and
         stage.get("progressStreaming") is True and not stage.get("error"),
         "disabled-menu stage is not a terminal source-bound PASS with Q30 disabled")
    need(tool_id == 31642 and tool_exit == 0,
         "caller did not confirm the designated terminal menu tool result")
    current_runner = ctx.repo / "tests/browser/quickplay_procedural_acceptance.py"
    runner_hash = sha(runner_raw)
    need(runner_hash == MENU_RUNNER and stage.get("runnerSha256") == MENU_RUNNER and
         stage.get("command", [None] * 6)[3] and
         normalized(Path(stage["command"][3])) == normalized(current_runner) and
         normalized(Path(stage.get("shippingApp", ""))) == normalized(task / "shipping" / "app") and
         normalized(Path(stage.get("shippingBuildReceipt", ""))) == normalized(task / "shipping-build-result.json") and
         stage.get("hostPid") == 23948 and stage.get("pid") == 21016,
         "stage command does not bind the tracked runner/current shipping app/recorded host")
    identity_path = task / "disabled-menu" / "identity.json"
    identity_raw = ledger.read(identity_path, task)
    identity = json_obj(identity_raw, "disabled menu host identity")
    need(identity.get("pid") == stage.get("hostPid") and identity.get("created") and
         identity.get("executable") and identity.get("port") and identity.get("profile") and
         normalized(Path(identity["profile"])) == normalized(task / "disabled-menu" / "profile"),
         "separate disabled-menu host identity receipt does not bind the stage host")
    owned_path = task / "disabled-menu" / "owned-processes.json"
    owned_raw = ledger.read(owned_path, task)
    owned = json.loads(decode(owned_raw, "owned process list"), object_pairs_hook=pairs_unique)
    need(isinstance(owned, list) and len(owned) == 7 and
         all(type(row.get("pid")) is int and row.get("pid") > 0 and row.get("created") and
             row.get("ExecutablePath", "").replace("\\", "/").lower().endswith("/msedge.exe") for row in owned),
         "separate menu host Edge ownership receipt is malformed")
    screenshots = ["led_indicator-top.png", "led_indicator-bottom.png",
                   "composed_controlled_indicator-top.png", "composed_controlled_indicator-bottom.png"]
    screenshot_sizes = {}
    for name in screenshots:
        path = task / "disabled-menu" / name
        need(path.is_file() and not path.is_symlink() and path.stat().st_size > 0,
             "generated screenshot evidence missing: " + name)
        screenshot_sizes[name] = path.stat().st_size
    return {
        "hostCaseOutcome": "PASS", "launchCount": 30, "familyOrdinalMatrix": actual_pairs,
        "replayCount": 2, "staleReplay": "EXPECTED_REJECTED", "disabledFamilyReplay": "EXPECTED_BLOCKED",
        "privateMetadataAbsentForAllCases": True, "runtimeErrors": 0,
        "cleanup": cleanup, "hostIdentity": {"pid": identity["pid"], "created": identity["created"],
                                               "executable": identity["executable"], "port": identity["port"]},
        "edgeOwnedCount": len(owned), "headlessRunnerSha256": runner_hash,
        "caseLogSha256": sha(log_raw), "resultSha256": sha(result_raw),
        "generatedScreenshots": screenshot_sizes, "visiblePlayerQa": "NOT_RUN",
        "stageReceiptSha256": sha(stage_raw), "stageElapsedSeconds": stage.get("elapsedSeconds"),
        "terminalToolObservation": {"toolId": tool_id, "exitCode": tool_exit,
                                    "source": "caller-supplied terminal result; not stored in stage JSON"},
        "maxObservedSeconds": max_seconds, "maxObservedUnits": max_units,
    }


def validate_process_and_archive(ctx, stage, pointer, tool_id, tool_exit):
    task, repo, ledger = ctx.task, ctx.repo, ctx.ledger
    review_path = task / "menu-archive-terminal-independent-process-review.json"
    review_raw = ledger.read(review_path, task)
    review = json_obj(review_raw, "menu/archive independent process review")
    need(review.get("status") == "PASS" and review.get("sourceIdentity") == SOURCE and
         review.get("identitiesChecked") == 10 and review.get("noTerminationPerformed") is True and
         review.get("archiveCleanupElapsedSeconds") == "NOT_RECORDED_SEPARATELY" and
         "capture was missed after exit" in review.get("scope", ""),
         "independent process review/capture limitation is missing or changed")
    rows = review.get("rows", [])
    need(len(rows) == 10 and {row.get("pid") for row in rows} == set(MENU_IDENTITY_ROWS),
         "process review does not contain the ten explicitly recorded instances")
    for row in rows:
        kind, created = MENU_IDENTITY_ROWS[row["pid"]]
        need(row.get("kind") == kind and same_utc(row.get("createdUtc"), created) and
             row.get("recordedInstanceGone") is True and type(row.get("pidCurrentlyPresent")) is bool,
             "independent process review differs from a captured process identity")
    need(tool_id == 54365 and tool_exit == 0,
         "caller did not confirm the designated terminal archive tool result")

    archive_raw = ledger.read(task / "archive-stage-result.json", task)
    archive = json_obj(archive_raw, "source archive stage")
    archive_script = repo / "docs/task-evidence/Q30/resume-20261002/archive-q30-sources.ps1"
    archive_script_raw = ledger.read(archive_script, repo)
    prepare_raw = ledger.read(task / "isolated" / "prepare-receipt.json", task)
    snapshot_raw = ledger.read(task / "source-snapshot.json", task)
    maintained_raw = ledger.read(task / "source-snapshot-maintained.json", task)
    need(archive.get("status") == "PASS" and archive.get("task") == "epoch15-source-archive" and
         archive.get("candidate") == "isolated" and archive.get("baseHead") == HEAD and
         archive.get("sourceIdentity") == SOURCE and archive.get("exitCode") == 0 and
         archive.get("archiveRunStatus") == "PASS" and archive.get("candidateStatus") == "ARCHIVED_SOURCE_ONLY" and
         archive.get("acceptanceStatus") == "NOT_ASSESSED" and
         archive.get("baselinePatchVerification") == "PASS" and
         archive.get("sourceDeltaReconstruction") == "PASS" and
         archive.get("archiveScriptExpectedSha256") == ARCHIVE_SCRIPT and
         archive.get("archiveScriptSha256") == ARCHIVE_SCRIPT and sha(archive_script_raw) == ARCHIVE_SCRIPT and
         archive.get("sourceSnapshotSha256") == sha(snapshot_raw) and
         archive.get("candidateSnapshotSha256") == sha(maintained_raw) and
         archive.get("prepareReceiptSha256") == sha(prepare_raw) and
         archive.get("originalPlanSha256") == ORIGINAL_PLAN and
         archive.get("acceptancePlanSha256") == CONTINUED_PLAN and
         archive.get("integrationPointerSha256") == INTEGRATION_POINTER and
         archive.get("commandOptions") == ["CandidateNames=isolated", "SkipProfile=true", "IncludeSourceTrees=false"],
         "source archive transport receipt is not an exact isolated source-only pass")
    archive_tool = {"toolId": tool_id, "exitCode": tool_exit,
                    "source": "caller-supplied terminal result; archive-stage receipt also has script exitCode 0"}
    prior = review.get("priorReviewAttempt", {})
    need(prior.get("status") == "FAIL" and prior.get("exitCode") == 1 and
         "schema" in prior.get("cause", "").lower(),
         "preserved pre-correction review attempt is missing")
    return {
        "processReviewStatus": "PASS", "identitiesChecked": 10, "recordedInstancesGone": 10,
        "terminationPerformed": False, "menuCleanupSeconds": review.get("menuCleanupSeconds"),
        "outerDriverCapture": "MISSED_AFTER_EXIT_NO_IDENTITY_INVENTED",
        "archiveCleanupElapsedSeconds": "NOT_RECORDED_SEPARATELY",
        "priorReviewAttempt": prior, "reviewSha256": sha(review_raw),
        "archive": {"scriptStatus": archive.get("status"), "candidateStatus": archive.get("candidateStatus"),
                    "acceptanceStatus": archive.get("acceptanceStatus"),
                    "baselinePatchVerification": archive.get("baselinePatchVerification"),
                    "sourceDeltaReconstruction": archive.get("sourceDeltaReconstruction"),
                    "elapsedSeconds": archive.get("elapsedSeconds"), "archiveManifestSha256": archive.get("archiveManifestSha256"),
                    "stageSha256": sha(archive_raw), "logSha256": sha(ledger.read(task / "archive-stage.log", task)),
                    "terminalTool": archive_tool},
    }


def add_inputs(ctx, pointer, stage):
    t, w, r, ledger = ctx.task, ctx.workspace, ctx.repo, ctx.ledger
    inputs = [
        ("workspace/epoch15-task-pointer.json", w / "epoch15-task-pointer.json", w, "json"),
        ("workspace/integration-pointer.json", w / "integration-pointer.json", w, "json"),
        ("workspace/run_epoch15_shipping_hosts.py", w / "run_epoch15_shipping_hosts.py", w, "text"),
        ("task/integration.json", t / "integration.json", t, "json"),
        ("task/source-input-audit.json", t / "source-input-audit.json", t, "json"),
        ("task/source-snapshot-maintained.json", t / "source-snapshot-maintained.json", t, "json"),
        ("task/source-snapshot.json", t / "source-snapshot.json", t, "json"),
        ("task/isolated-source-snapshot.json", t / "isolated" / "source-snapshot.json", t, "json"),
        ("task/acceptance-plan.json", t / "acceptance-plan.json", t, "json"),
        ("task/shipping-build-result.json", t / "shipping-build-result.json", t, "json"),
        ("task/shipping-build.log", t / "shipping-build.log", t, "text"),
        ("task/shipping-prepare-receipt.json", t / "shipping" / "prepare-receipt.json", t, "json"),
        ("task/disabled-menu-stage-result.json", t / "disabled-menu-stage-result.json", t, "json"),
        ("task/disabled-menu.log", t / "disabled-menu.log", t, "text"),
        ("disabled-menu/result.json", t / "disabled-menu" / "result.json", t, "json"),
        ("disabled-menu/identity.json", t / "disabled-menu" / "identity.json", t, "json"),
        ("disabled-menu/owned-processes.json", t / "disabled-menu" / "owned-processes.json", t, "json"),
        ("disabled-menu/progress.json", t / "disabled-menu" / "progress.json", t, "json"),
        ("task/menu-archive-independent-process-review.json", t / "menu-archive-terminal-independent-process-review.json", t, "json"),
        ("task/archive-stage-result.json", t / "archive-stage-result.json", t, "json"),
        ("task/archive-stage.log", t / "archive-stage.log", t, "text"),
        ("repo/quickplay_procedural_acceptance.py", r / "tests/browser/quickplay_procedural_acceptance.py", r, "text"),
        ("repo/PlayerFamilyCatalog.java", r / "src/com/lushprojects/circuitjs1/client/PlayerFamilyCatalog.java", r, "text"),
        ("repo/archive-q30-sources.ps1", r / "docs/task-evidence/Q30/resume-20261002/archive-q30-sources.ps1", r, "text"),
    ]
    for name, path, root, kind in inputs:
        ledger.add_evidence(name, path, root, kind)
    return [{"name": item["name"], "rawBytes": item["rawBytes"], "rawSha256": item["rawSha256"]}
            for item in ledger.evidence]


def audit_task(workspace, repo, menu_tool_id, menu_tool_exit, archive_tool_id, archive_tool_exit):
    workspace, repo = workspace.resolve(strict=True), repo.resolve(strict=True)
    pointer_path = workspace / "epoch15-task-pointer.json"
    pointer_raw = pointer_path.read_bytes()
    pointer = json_obj(pointer_raw, "task pointer")
    expected_task = Path(tempfile.gettempdir()) / TASK_NAME
    need(pointer.get("taskRoot") and os.path.normcase(str(Path(pointer["taskRoot"]).resolve(strict=True))) ==
         os.path.normcase(str(expected_task.resolve(strict=True))), "pointer task root does not match this task")
    task = expected_task.resolve(strict=True)
    ledger = Ledger()
    ctx = AuditContext(workspace, repo, task, ledger, {})
    pointer = ledger.json(pointer_path, workspace, "task pointer")
    ip_raw = ledger.read(workspace / "integration-pointer.json", workspace)
    ip = json_obj(ip_raw, "integration pointer")
    need(sha(ip_raw) == INTEGRATION_POINTER, "integration pointer raw hash changed")
    stage = ledger.json(task / "disabled-menu-stage-result.json", task, "disabled menu stage")
    build = ledger.json(task / "shipping-build-result.json", task, "shipping build receipt")
    runner_path = repo / "tests/browser/quickplay_procedural_acceptance.py"
    runner_raw = ledger.read(runner_path, repo)
    source_summary = validate_source(ctx, pointer, ip, stage, build)
    compiled_summary = validate_compiled_inventory(ctx, stage)
    menu_summary = validate_menu_result(ctx, stage, runner_raw, menu_tool_id, menu_tool_exit)
    process_archive_summary = validate_process_and_archive(ctx, stage, pointer,
                                                           archive_tool_id, archive_tool_exit)
    validator_path = workspace / "run_epoch15_private_menu.py"
    validator_raw = ledger.read(validator_path, workspace)
    validator_text = decode(validator_raw, validator_path.name)
    need("def validate_disabled_menu_gate(task):" in validator_text and
         "private enabled-menu host returned nonzero" in validator_text and
         "cold77" in " ".join(validator_text.split()).lower(),
         "current workspace validator source does not identify the disabled menu/private gate boundary")
    evidence = add_inputs(ctx, pointer, stage)
    ctx.summary = {
        "schema": 1,
        "receiptReview": "PASS",
        "q30Acceptance": "NOT_ESTABLISHED",
        "disabledQ30Source": True,
        "visiblePlayerQa": "NOT_RUN",
        "visibleScreenshots": "captured, preserved at task root, not inspected or packaged",
        "menu": menu_summary,
        "source": source_summary,
        "compiled": compiled_summary,
        "processAndArchive": process_archive_summary,
        "reviewedValidator": {"path": "epoch15-final/run_epoch15_private_menu.py",
                              "sha256": sha(validator_raw),
                              "disabledMenuValidator": "STATICALLY_CONSULTED_NOT_EXECUTED",
                              "privateEnabledMenuGate": "BLOCKED; not invoked because cold77 is FAIL"},
        "evidence": evidence,
    }
    ledger.recheck()
    return ctx


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--menu-tool-id", type=int, required=True)
    parser.add_argument("--menu-tool-exit-code", type=int, required=True)
    parser.add_argument("--archive-tool-id", type=int, required=True)
    parser.add_argument("--archive-tool-exit-code", type=int, required=True)
    args = parser.parse_args()
    try:
        workspace = Path(__file__).resolve(strict=True).parent
        context = audit_task(workspace, REPO, args.menu_tool_id, args.menu_tool_exit_code,
                             args.archive_tool_id, args.archive_tool_exit_code)
        print(json.dumps(context.summary, ensure_ascii=False, indent=2))
    except (AuditError, OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise SystemExit("FAIL_CLOSED: " + str(exc))


if __name__ == "__main__":
    main()
