#!/usr/bin/env python3
"""Strict readers for private Q30 D01 boundary canary receipts."""
import json
import math
import re
import sys
from pathlib import Path


TOKEN = re.compile(r"^(?:null|I[1-9][0-9]*)$")
SIGNED_LONG_MIN = -(1 << 63)
SIGNED_LONG_MAX = (1 << 63) - 1


def require(condition, message):
    if not condition:
        raise ValueError(message)


def obj(value, where):
    require(isinstance(value, dict), where + " must be an object")
    return value


def arr(value, where):
    require(isinstance(value, list), where + " must be an array")
    return value


def text(value, where, allow_empty=False):
    require(isinstance(value, str), where + " must be a string")
    require(allow_empty or bool(value), where + " must not be empty")
    return value


def boolean(value, where):
    require(type(value) is bool, where + " must be a boolean")
    return value


def integer(value, where, minimum=None):
    require(type(value) is int, where + " must be an integer")
    if minimum is not None:
        require(value >= minimum, where + " is below its minimum")
    return value


def validate_lease_close(container, where, status_key, error_key,
                         released_key, hook_key, receipt_key):
    status = text(container.get(status_key), where + "." + status_key)
    error = text(container.get(error_key), where + "." + error_key, allow_empty=True)
    require(status == "PASS", where + " lease cleanup status is not PASS")
    require(error == "", where + " lease cleanup retained a close error")
    for key in (released_key, hook_key, receipt_key):
        require(boolean(container.get(key), where + "." + key) is True,
                where + "." + key + " is not confirmed")


def identity(value, where, nullable=True):
    text(value, where)
    require(TOKEN.fullmatch(value) is not None, where + " is not a canonical identity token")
    if not nullable:
        require(value != "null", where + " cannot be null")
    return value


def signed_long(value, where, nullable=False):
    text(value, where, allow_empty=nullable)
    if nullable and value == "":
        return None
    try:
        parsed = int(value)
    except ValueError as failure:
        raise ValueError(where + " is not a signed-long decimal") from failure
    require(SIGNED_LONG_MIN <= parsed <= SIGNED_LONG_MAX and str(parsed) == value,
            where + " is not a canonical signed-long decimal")
    return parsed


def load_json(path):
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    obj(value, str(path))
    require("captureError" not in value, str(path) + " is a failed host snapshot")
    return value


def validate_element(value, index, where):
    elm = obj(value, where)
    integer(elm.get("ordinal"), where + ".ordinal", 0)
    require(elm["ordinal"] == index, where + " has a missing, duplicate, or reordered ordinal")
    identity(elm.get("identityToken"), where + ".identityToken", nullable=False)
    text(elm.get("class"), where + ".class")
    text(elm.get("dump"), where + ".dump", allow_empty=True)
    internal_count = integer(elm.get("internalNodeCount"), where + ".internalNodeCount", 0)
    posts = arr(elm.get("posts"), where + ".posts")
    internal_nodes = arr(elm.get("internalNodes"), where + ".internalNodes")
    require(len(internal_nodes) == internal_count,
            where + ".internalNodes count disagrees with internalNodeCount")
    for post_index, post_value in enumerate(posts):
        post = obj(post_value, where + ".posts[" + str(post_index) + "]")
        require(integer(post.get("ordinal"), where + ".post.ordinal", 0) == post_index,
                where + " has a missing, duplicate, or reordered post ordinal")
        integer(post.get("node"), where + ".post.node")
    for node_index, node in enumerate(internal_nodes):
        integer(node, where + ".internalNodes[" + str(node_index) + "]")
    return elm


def validate_elements(values, where):
    elements = arr(values, where)
    tokens = set()
    by_token = {}
    for index, item in enumerate(elements):
        elm = validate_element(item, index, where + "[" + str(index) + "]")
        token = elm["identityToken"]
        require(token not in tokens, where + " repeats a physical element identity")
        tokens.add(token)
        by_token[token] = {key: elm[key] for key in
                           ("class", "dump", "internalNodeCount", "posts", "internalNodes")}
    return by_token


def validate_snapshot(snapshot, expected_label=None):
    snap = obj(snapshot, "snapshot")
    require(snap.get("schema") == 2 and type(snap.get("schema")) is int,
            "snapshot schema must be 2")
    integer(snap.get("leaseId"), "snapshot.leaseId", 1)
    label = text(snap.get("label"), "snapshot.label")
    require(len(label) <= 80, "snapshot.label exceeds 80 characters")
    if expected_label is not None:
        require(label == expected_label,
                "snapshot label must be " + expected_label + ", got " + label)

    simulator = obj(snap.get("simulator"), "snapshot.simulator")
    for key in ("identityToken", "ownerToken", "controllerToken", "elmListToken"):
        identity(simulator.get(key), "snapshot.simulator." + key)
    for key in ("installationInProgress", "freshInstallationActive",
                "activeMeasurementOverlay", "generatedRuntimeSettled",
                "developerVerifierRunning", "troubleshootDebug",
                "troubleshootQ30Verification"):
        boolean(simulator.get(key), "snapshot.simulator." + key)
    require(simulator["troubleshootDebug"] is True and
            simulator["troubleshootQ30Verification"] is True,
            "snapshot was not captured inside the explicit debug Q30 scope")

    owner = obj(snap.get("owner"), "snapshot.owner")
    for key in ("identityToken", "boardToken", "componentBindingsToken",
                "connectionBindingsToken", "externalPowerBindingsToken", "faultBindingToken"):
        identity(owner.get(key), "snapshot.owner." + key)
    family = text(owner.get("family"), "snapshot.owner.family", allow_empty=True)
    seed = signed_long(owner.get("seed"), "snapshot.owner.seed", nullable=True)
    boolean(owner.get("faultApplied"), "snapshot.owner.faultApplied")
    owner_elements = validate_elements(owner.get("simulationElements"),
                                       "snapshot.owner.simulationElements")
    require(simulator["ownerToken"] == owner["identityToken"],
            "simulator and owner identity tokens disagree")
    if owner["identityToken"] == "null":
        require(family == "" and seed is None, "null owner has family/seed data")
    else:
        require(family != "" and seed is not None, "live owner lacks family or signed-long seed")
    declared_power_inputs = [
        text(input_id, "snapshot.owner.declaredPowerInputIds[]")
        for input_id in arr(owner.get("declaredPowerInputIds"),
                            "snapshot.owner.declaredPowerInputIds")
    ]
    require(declared_power_inputs == sorted(set(declared_power_inputs)),
            "board-declared power input IDs must be unique and canonically sorted")

    graph = obj(snap.get("graph"), "snapshot.graph")
    identity(graph.get("vectorToken"), "snapshot.graph.vectorToken")
    integer(graph.get("size"), "snapshot.graph.size", -1)
    graph_elements = validate_elements(graph.get("elements"), "snapshot.graph.elements")
    require(graph["size"] == len(graph["elements"]) or
            (graph["size"] == -1 and not graph["elements"]),
            "graph size disagrees with its ordered elements")
    require(simulator["elmListToken"] == graph["vectorToken"],
            "simulator and graph vector identity tokens disagree")
    for token in owner_elements.keys() & graph_elements.keys():
        require(owner_elements[token] == graph_elements[token],
                "one physical element identity has inconsistent topology/dump data")

    power = obj(snap.get("power"), "snapshot.power")
    identity(power.get("controllerToken"), "snapshot.power.controllerToken")
    identity(power.get("bindingsToken"), "snapshot.power.bindingsToken")
    if owner["identityToken"] != "null":
        require(owner["externalPowerBindingsToken"] == power["bindingsToken"],
                "owner and board-power controller binding identities disagree")
    power_state = text(power.get("state"), "snapshot.power.state")
    require(power_state in ("null", "POWERED", "UNPOWERED"),
            "snapshot.power.state is not a canonical board-power state")
    require((power["controllerToken"] == "null") == (power_state == "null"),
            "power controller identity and power state disagree")
    inputs = arr(power.get("inputs"), "snapshot.power.inputs")
    input_ids = []
    binding_state_by_token = {}
    supply_state_by_token = {}
    for index, input_value in enumerate(inputs):
        where = "snapshot.power.inputs[" + str(index) + "]"
        source = obj(input_value, where)
        input_id = text(source.get("id"), where + ".id")
        input_ids.append(input_id)
        binding_token = identity(source.get("bindingToken"), where + ".bindingToken")
        if owner["identityToken"] != "null":
            require(binding_token != "null",
                    where + " declared live-board input has no simulation binding")
        boolean(source.get("connected"), where + ".connected")
        boolean(source.get("controlled"), where + ".controlled")
        revision = integer(source.get("connectionRevision"), where + ".connectionRevision", -1)
        backing = validate_elements(source.get("backingElements"), where + ".backingElements")
        if binding_token != "null":
            require(revision >= 0, where + " has a binding without a connection revision")
            binding_state = (source["connected"], source["controlled"], revision,
                             tuple((token, value) for token, value in sorted(backing.items())))
            if binding_token in binding_state_by_token:
                require(binding_state_by_token[binding_token] == binding_state,
                        "one power binding identity has inconsistent per-input state")
            binding_state_by_token[binding_token] = binding_state
        else:
            require(revision == -1 and not source["controlled"] and not backing,
                    where + " has binding state without a binding identity")
        supply_token = identity(source.get("limitedSupplyToken"),
                                where + ".limitedSupplyToken")
        text(source.get("limitedSupplyDump"), where + ".limitedSupplyDump", allow_empty=True)
        limit = text(source.get("limitedSupplyLimitAmps"),
                     where + ".limitedSupplyLimitAmps", allow_empty=True)
        if supply_token == "null":
            require(limit == "" and source["limitedSupplyDump"] == "",
                    where + " has supply data without a supply")
        else:
            require(limit != "" and source["limitedSupplyDump"] != "",
                    where + " has a supply without its model data/current limit")
            try:
                parsed_limit = float(limit)
                require(math.isfinite(parsed_limit) and parsed_limit > 0,
                        where + " has a nonpositive or non-finite supply limit")
            except ValueError as failure:
                raise ValueError(where + " supply limit is not numeric") from failure
            supply_state = (source["limitedSupplyDump"], limit)
            if supply_token in supply_state_by_token:
                require(supply_state_by_token[supply_token] == supply_state,
                        "one limited-supply identity has inconsistent model data")
            supply_state_by_token[supply_token] = supply_state
    require(input_ids == sorted(set(input_ids)),
            "power inputs must have unique IDs in canonical sorted order")
    require(input_ids == declared_power_inputs,
            "snapshot power inputs do not match the board's declared input IDs")
    if owner["identityToken"] == "null":
        require(not declared_power_inputs, "null owner declares board power inputs")

    controller = obj(snap.get("challengeController"), "snapshot.challengeController")
    identity(controller.get("identityToken"), "snapshot.challengeController.identityToken")
    require(simulator["controllerToken"] == controller["identityToken"],
            "simulator and challenge-controller identity tokens disagree")
    for key in ("ready", "completed", "operationInProgress"):
        boolean(controller.get(key), "snapshot.challengeController." + key)

    coordinator = obj(snap.get("coordinator"), "snapshot.coordinator")
    identity(coordinator.get("identityToken"), "snapshot.coordinator.identityToken")
    identity(coordinator.get("jobToken"), "snapshot.coordinator.jobToken")
    for key in ("running", "advancing", "retainsSavedOwners"):
        boolean(coordinator.get(key), "snapshot.coordinator." + key)
    for key in ("outcome", "stage"):
        text(coordinator.get(key), "snapshot.coordinator." + key)
    integer(coordinator.get("stepCount"), "snapshot.coordinator.stepCount", -1)
    integer(coordinator.get("candidateIndex"), "snapshot.coordinator.candidateIndex", -1)
    if coordinator["jobToken"] == "null":
        require(coordinator["outcome"] == "null" and coordinator["stage"] == "null" and
                not coordinator["running"] and not coordinator["advancing"],
                "null coordinator job has active state")
    return snap


def physical_projection(snapshot):
    snap = validate_snapshot(snapshot)
    simulator = dict(snap["simulator"])
    # These are operational flags, not board state; the D01 lock and the
    # coordinator's busy transition legitimately change around the snapshots.
    simulator.pop("developerVerifierRunning")
    simulator.pop("generatedRuntimeSettled")
    return {"simulator": simulator, "owner": snap["owner"], "graph": snap["graph"],
            "power": snap["power"], "challengeController": snap["challengeController"]}


def require_same_physical(left, right, label):
    require(physical_projection(left) == physical_projection(right),
            label + " changed owner/controller/ordered graph/source state")


def require_same_lease(snapshots):
    validated = [validate_snapshot(snapshot) for snapshot in snapshots]
    lease_ids = {snapshot["leaseId"] for snapshot in validated}
    require(len(lease_ids) == 1, "snapshot evidence mixes D01 lease identities")


def check_normal_successor(report):
    report = obj(report, "D01 report")
    require(report.get("schema") == 2 and type(report.get("schema")) is int,
            "D01 report schema must be 2")
    require(report.get("status") == "FAIL", "D01 report is not the expected negative result")
    require(report.get("phase") == "DONE", "D01 did not finish its boundary stop")
    for key in ("normalAdmission", "playerPublished", "d01Admission"):
        require(report.get(key) is False, key + " must remain false")
    require(report.get("cleanupComplete") is True, "D01 route cleanup did not complete")
    require(report.get("ownerRestored") is True, "predecessor owner was not preserved at stop")
    validate_lease_close(report, "D01 report", "hostBoundaryLeaseCloseStatus",
                          "hostBoundaryLeaseCloseError", "hostBoundaryLeaseReleased",
                          "hostBoundaryWindowHookRemoved",
                          "hostBoundarySnapshotReceiptRemoved")
    require(report.get("hostBoundaryLeaseCloseReason") == "normal-successor-completion",
            "D01 closed its host snapshot lease for an unexpected reason")

    advances = obj(report.get("constructionAdvances"), "constructionAdvances")
    boundary = obj(advances.get("boundaryGuard"), "constructionAdvances.boundaryGuard")
    require(boundary.get("successorDetected") is True and
            boundary.get("successorPreserved") is True and
            boundary.get("boundaryLost") is True and
            boundary.get("statePreservedAcrossStop") is True,
            "D01 did not stop safely on the normal successor boundary")
    require(boundary.get("stopReason") == "successor-identity-changed" and
            boundary.get("constructionSessionReleased") is True,
            "D01 stopped for an unexpected reason or retained its construction session")
    require(boundary.get("verifierLockBeforeStop") is True and
            boundary.get("verifierLockAfterStop") is False and
            boundary.get("verifierLockReleased") is True,
            "D01 verifier-owned lock transition is incorrect")

    canary = obj(report.get("constructionNormalSuccessorCanary"),
                 "constructionNormalSuccessorCanary")
    validate_lease_close(canary, "constructionNormalSuccessorCanary",
                          "snapshotLeaseCloseStatus", "snapshotLeaseCloseError",
                          "snapshotLeaseReleased", "snapshotWindowHookRemoved",
                          "snapshotReceiptRemoved")
    require(canary.get("schema") == 3 and type(canary.get("schema")) is int,
            "normal-successor canary schema must be 3")
    require(canary.get("status") == "PASS", "normal-successor canary is not PASS")
    require(canary.get("query") == "tsjQ30D01ConstructionNormalSuccessor=true",
            "unexpected canary query identity")
    require(canary.get("purpose") ==
            "negative D01 boundary canary; successor uses ordinary player generation",
            "canary purpose does not preserve negative D01 semantics")
    require(canary.get("startApi") ==
            "PlayerLaunchRequest.generation -> GenerationCoordinator.start(asynchronous=true)",
            "successor did not use the ordinary generation path")
    for key, expected in (("normalMaximumJobMillis", 90000),
                          ("normalMaximumSteps", 640),
                          ("normalMaximumStepMillis", 5000)):
        require(type(canary.get(key)) is int and canary[key] == expected,
                "ordinary generation budget changed: " + key)
    require(canary.get("family") == "LED_INDICATOR" and
            canary.get("seed") == "3" and canary.get("profile") == "EASY" and
            canary.get("requestReplay") == "tsj-alpha/4/EASY/LED_INDICATOR/3",
            "successor request is not the declared exact normal player request")
    require(canary.get("startIssued") is True and canary.get("startObserved") is True and
            canary.get("stopObserved") is True and
            canary.get("physicalStateUnchangedAtStart") is True,
            "ordinary successor did not start with unchanged physical state")
    require(canary.get("completionTimeout") is not True and
            type(canary.get("snapshotLeaseTimeoutMillis")) is int and
            canary["snapshotLeaseTimeoutMillis"] == 95000 and
            type(canary.get("snapshotLeaseScopePollMillis")) is int and
            canary["snapshotLeaseScopePollMillis"] == 1000 and
            canary.get("snapshotScopeLossObserved") is False and
            canary.get("snapshotLeaseReleased") is True and
            canary.get("snapshotWindowHookRemoved") is True and
            canary.get("snapshotReceiptRemoved") is True and
            canary.get("snapshotLeaseReleasePending") is False and
            canary.get("snapshotLeaseCloseReason") == "normal-successor-completion",
            "normal-successor bridge lease was not revoked at completion")

    snapshots = [
        ("beforeStart", "before-normal-successor-start"),
        ("afterStart", "after-normal-successor-start"),
        ("beforeStop", "before-d01-boundary-stop"),
        ("afterStop", "after-d01-boundary-stop"),
        ("afterCompletion", "normal-successor-completion"),
    ]
    evidence = {}
    for key, label in snapshots:
        evidence[key] = validate_snapshot(canary.get(key), label)
    require_same_lease(list(evidence.values()))
    require(boundary.get("hostSnapshotBeforeStop") == canary["beforeStop"] and
            boundary.get("hostSnapshotAfterStop") == canary["afterStop"],
            "canary and D01 boundary snapshots do not refer to the same callback evidence")

    before_start = evidence["beforeStart"]
    after_start = evidence["afterStart"]
    require_same_physical(before_start, after_start, "ordinary coordinator start")
    require(before_start["simulator"]["developerVerifierRunning"] is True and
            after_start["simulator"]["developerVerifierRunning"] is True,
            "D01 did not own its verifier lock across the start boundary")
    before_job = before_start["coordinator"]
    after_job = after_start["coordinator"]
    require(before_job["identityToken"] == after_job["identityToken"] and
            before_job["jobToken"] != after_job["jobToken"] and
            after_job["running"] is True and after_job["outcome"] == "RUNNING",
            "successor did not create a fresh running job on the existing coordinator")

    before_stop = evidence["beforeStop"]
    after_stop = evidence["afterStop"]
    require_same_physical(before_stop, after_stop, "same-callback D01 stop")
    require(before_stop["simulator"]["developerVerifierRunning"] is True and
            after_stop["simulator"]["developerVerifierRunning"] is False,
            "D01 did not release only its own lock")
    require(before_stop["coordinator"] == after_stop["coordinator"],
            "coordinator progressed or changed during same-callback D01 stop")
    stopped_job = after_stop["coordinator"]
    require(stopped_job["running"] is True and stopped_job["outcome"] == "RUNNING" and
            stopped_job["jobToken"] == after_start["coordinator"]["jobToken"],
            "D01 cancelled or replaced the successor job at stop")

    completed = evidence["afterCompletion"]
    completed_job = completed["coordinator"]
    require(canary.get("completionObserved") is True and
            canary.get("completionValid") is True and
            canary.get("completionJobStopped") is True and
            canary.get("completionOutcome") == "PASS" and
            canary.get("completionFamily") == "LED_INDICATOR" and
            canary.get("completionSeed") == "3" and
            canary.get("completionIsCurrentOwner") is True and
            canary.get("developerVerifierReleased") is True,
            "normal successor did not complete as the exact current family/seed")
    require(completed_job["identityToken"] == after_start["coordinator"]["identityToken"] and
            completed_job["jobToken"] == after_start["coordinator"]["jobToken"] and
            completed_job["outcome"] == "PASS" and not completed_job["running"] and
            not completed_job["advancing"] and not completed_job["retainsSavedOwners"],
            "completion does not show the same coordinator job stopped with PASS")
    require(canary.get("predecessorOwnerStillCurrentAtStop") is True and
            canary.get("finalCurrentOwnerIsNormalSuccessor") is True and
            before_stop["simulator"]["ownerToken"] ==
            after_stop["simulator"]["ownerToken"],
            "report confuses D01 stop-time preservation with later publication")
    require(completed["simulator"]["ownerToken"] !=
            after_stop["simulator"]["ownerToken"] and
            completed["owner"]["family"] == "LED_INDICATOR" and
            completed["owner"]["seed"] == "3" and
            completed_job["outcome"] == "PASS" and
            completed["simulator"]["ownerToken"] == completed["owner"]["identityToken"] and
            completed["challengeController"]["ready"] is True,
            "completion snapshot does not identify the published normal successor")


def topology_projection(elements):
    return [{key: element[key] for key in
             ("ordinal", "identityToken", "class", "internalNodeCount", "posts", "internalNodes")}
            for element in elements]


def visible_power_identity_projection(snapshot):
    snap = validate_snapshot(snapshot)
    sim = snap["simulator"]
    owner = snap["owner"]
    graph = snap["graph"]
    power = snap["power"]
    inputs = []
    for item in power["inputs"]:
        inputs.append({
            "id": item["id"],
            "bindingToken": item["bindingToken"],
            "controlled": item["controlled"],
            "backingElements": topology_projection(item["backingElements"]),
            "limitedSupplyToken": item["limitedSupplyToken"],
            "limitedSupplyDump": item["limitedSupplyDump"],
            "limitedSupplyLimitAmps": item["limitedSupplyLimitAmps"],
        })
    return {
        "simulator": {key: sim[key] for key in (
            "identityToken", "ownerToken", "controllerToken", "elmListToken",
            "installationInProgress", "freshInstallationActive",
            "activeMeasurementOverlay", "troubleshootDebug",
            "troubleshootQ30Verification")},
        "owner": {key: owner[key] for key in (
            "identityToken", "family", "seed", "boardToken", "componentBindingsToken",
            "connectionBindingsToken", "externalPowerBindingsToken", "faultBindingToken",
            "faultApplied")},
        "ownerElements": topology_projection(owner["simulationElements"]),
        "declaredPowerInputIds": owner["declaredPowerInputIds"],
        "graph": {"vectorToken": graph["vectorToken"], "size": graph["size"],
                  "elements": topology_projection(graph["elements"])},
        "power": {"controllerToken": power["controllerToken"],
                  "bindingsToken": power["bindingsToken"], "inputs": inputs},
        "challengeController": snap["challengeController"]["identityToken"],
    }


def require_power_off_transition(before, after, label):
    old_power = before["power"]
    new_power = after["power"]
    require(old_power["state"] == "POWERED" and new_power["state"] == "UNPOWERED",
            label + " did not record powered-to-unpowered transition")
    old_inputs = {item["id"]: item for item in old_power["inputs"]}
    new_inputs = {item["id"]: item for item in new_power["inputs"]}
    require(old_inputs and old_inputs.keys() == new_inputs.keys(),
            label + " power input bindings are missing or changed")
    for input_id, old in old_inputs.items():
        new = new_inputs[input_id]
        require(old["connected"] is True and new["connected"] is False,
                label + " did not isolate input " + input_id)
        require(new["connectionRevision"] > old["connectionRevision"] >= 0,
                label + " revision did not record the real transition")


def check_post_stop_scope_withdrawal(report):
    report = obj(report, "D01 report")
    require(report.get("schema") == 2 and type(report.get("schema")) is int and
            report.get("status") == "FAIL" and report.get("phase") == "DONE",
            "scope-withdrawal D01 result must remain FAIL at DONE")
    for key in ("normalAdmission", "playerPublished", "d01Admission"):
        require(report.get(key) is False, key + " must remain false")
    require(report.get("cleanupComplete") is True and report.get("ownerRestored") is True,
            "D01 cleanup did not complete before scope-withdrawal observation")
    validate_lease_close(report, "D01 report", "hostBoundaryLeaseCloseStatus",
                          "hostBoundaryLeaseCloseError", "hostBoundaryLeaseReleased",
                          "hostBoundaryWindowHookRemoved",
                          "hostBoundarySnapshotReceiptRemoved")
    require(report.get("hostBoundaryLeaseCloseReason") == "debug-q30-scope-loss",
            "host lease did not close through the intended scope-loss branch")

    advances = obj(report.get("constructionAdvances"), "constructionAdvances")
    boundary = obj(advances.get("boundaryGuard"), "constructionAdvances.boundaryGuard")
    require(boundary.get("successorDetected") is True and
            boundary.get("successorPreserved") is True and
            boundary.get("boundaryLost") is True and
            boundary.get("statePreservedAcrossStop") is True and
            boundary.get("stopReason") == "successor-identity-changed" and
            boundary.get("constructionSessionReleased") is True and
            boundary.get("verifierLockBeforeStop") is True and
            boundary.get("verifierLockAfterStop") is False and
            boundary.get("verifierLockReleased") is True,
            "D01 did not safely release its session at the successor boundary")

    canary = obj(report.get("constructionPostStopScopeWithdrawalCanary"),
                 "constructionPostStopScopeWithdrawalCanary")
    validate_lease_close(canary, "scope-withdrawal canary", "snapshotLeaseCloseStatus",
                          "snapshotLeaseCloseError", "snapshotLeaseReleased",
                          "snapshotWindowHookRemoved", "snapshotReceiptRemoved")
    require(canary.get("schema") == 1 and type(canary.get("schema")) is int and
            canary.get("status") == "PASS" and
            canary.get("query") ==
                "tsjQ30D01ConstructionScopeWithdrawalAfterStop=true" and
            canary.get("purpose") ==
                "negative D01 boundary canary; injects verifier-scope withdrawal after DONE while the ordinary player successor remains running",
            "scope-withdrawal canary identity/purpose/status is invalid")
    require(canary.get("startApi") ==
            "PlayerLaunchRequest.generation -> GenerationCoordinator.start(asynchronous=true)" and
            canary.get("family") == "LED_INDICATOR" and canary.get("seed") == "3" and
            canary.get("profile") == "EASY" and
            canary.get("requestReplay") == "tsj-alpha/4/EASY/LED_INDICATOR/3",
            "successor did not use the exact ordinary LED EASY 3 path")
    for key, expected in (("normalMaximumJobMillis", 90000),
                          ("normalMaximumSteps", 640),
                          ("normalMaximumStepMillis", 5000),
                          ("snapshotLeaseTimeoutMillis", 95000)):
        require(type(canary.get(key)) is int and canary[key] == expected,
                "ordinary successor budget changed: " + key)
    require(canary.get("startIssued") is True and canary.get("startObserved") is True and
            canary.get("stopObserved") is True and
            canary.get("physicalStateUnchangedAtStart") is True,
            "ordinary successor did not start and survive D01 stop")
    require(type(canary.get("snapshotLeaseScopePollMillis")) is int and
            canary.get("snapshotLeaseScopePollMillis") == 10 and
            canary.get("scopeWithdrawalPollIsCanaryOnly") is True and
            canary.get("defaultOneSecondLatencyProven") is False,
            "canary-only poll timing was mislabeled as normal latency evidence")
    require(canary.get("phaseAtScopeWithdrawal") == "DONE" and
            canary.get("scopeWithdrawalInjectionReady") is True and
            canary.get("scopeWithdrawalInjectedAfterDone") is True and
            canary.get("q30ScopeFalseAfterInjection") is True and
            canary.get("scopeWithdrawalPollObserved") is True and
            canary.get("scopeWithdrawalObserved") is True,
            "scope loss was not deliberately injected after the DONE stop")
    require(canary.get("successorRunningAtScopeWithdrawalPoll") is True and
            canary.get("successorRunningImmediatelyBeforeLeaseClose") is True and
            canary.get("successorJobOutcomeAtLeaseClose") == "RUNNING" and
            canary.get("successorExactIdentityAtLeaseClose") is True and
            canary.get("successorStillRunningImmediatelyAfterLeaseClose") is True and
            canary.get("successorJobNotCancelledOrReplacedAtLeaseClose") is True and
            canary.get("successorCompletedBeforeScopePoll") is not True and
            canary.get("scopeWithdrawalNotRunReason") is None,
            "exact ordinary successor was not RUNNING at lease close")
    require(canary.get("predecessorPhysicalStateAtLeaseClose") is True and
            canary.get("predecessorPhysicalStateUnchangedByLeaseClose") is True and
            canary.get("powerStateAtStop") ==
                validate_snapshot(canary.get("afterStop"),
                                  "after-d01-boundary-stop")["power"]["state"],
            "lease close repowered or changed the predecessor physical state")
    require(canary.get("captureStateReleased") is True and
            canary.get("leaseDetachedFromActiveSlot") is True and
            canary.get("completionObserverDisarmed") is True and
            canary.get("completionObserverReferenceReleased") is True and
            canary.get("scopeFlagRestoredSafely") is True and
            canary.get("primitiveLeaseCloseReceiptComplete") is True,
            "lease map, DOM bridge, callback, or injected scope remained retained")
    require(canary.get("snapshotLeaseReleased") is True and
            canary.get("snapshotWindowHookRemoved") is True and
            canary.get("snapshotReceiptRemoved") is True and
            canary.get("snapshotLeaseReleasePending") is False and
            canary.get("snapshotLeaseCloseReason") == "debug-q30-scope-loss",
            "owned host bridge/DOM receipt cleanup was not proved")

    evidence = {}
    for key, label in (("beforeStart", "before-normal-successor-start"),
                       ("afterStart", "after-normal-successor-start"),
                       ("beforeStop", "before-d01-boundary-stop"),
                       ("afterStop", "after-d01-boundary-stop")):
        evidence[key] = validate_snapshot(canary.get(key), label)
    require_same_lease(list(evidence.values()))
    before_start, after_start = evidence["beforeStart"], evidence["afterStart"]
    before_stop, after_stop = evidence["beforeStop"], evidence["afterStop"]
    require(boundary.get("hostSnapshotBeforeStop") == canary["beforeStop"] and
            boundary.get("hostSnapshotAfterStop") == canary["afterStop"],
            "canary and D01 boundary snapshots disagree")
    require_same_physical(before_start, after_start, "ordinary coordinator start")
    require(before_start["coordinator"]["identityToken"] ==
            after_start["coordinator"]["identityToken"] and
            before_start["coordinator"]["jobToken"] !=
            after_start["coordinator"]["jobToken"] and
            after_start["coordinator"]["running"] is True and
            after_start["coordinator"]["outcome"] == "RUNNING",
            "successor did not create a fresh running job")
    require_same_physical(before_stop, after_stop, "same-callback D01 stop")
    require(before_stop["coordinator"] == after_stop["coordinator"] and
            after_stop["coordinator"]["running"] is True and
            after_stop["coordinator"]["outcome"] == "RUNNING",
            "successor changed while D01 stopped")
    require(canary.get("successorCoordinatorTokenAtStop") ==
            after_stop["coordinator"]["identityToken"] and
            canary.get("successorJobTokenAtStop") == after_stop["coordinator"]["jobToken"] and
            canary.get("successorCoordinatorTokenAtPoll") ==
            after_stop["coordinator"]["identityToken"] and
            canary.get("successorJobTokenAtPoll") == after_stop["coordinator"]["jobToken"],
            "final receipt does not identify the exact post-stop job")


def check_visible_power_boundary(report):
    report = obj(report, "D01 report")
    require(report.get("schema") == 2 and report.get("status") == "FAIL" and
            report.get("phase") == "DONE" and
            report.get("normalAdmission") is False and
            report.get("playerPublished") is False and
            report.get("d01Admission") is False,
            "visible-input D01 case must remain a completed negative D01 result")
    canary = obj(report.get("constructionVisiblePowerBoundaryCanary"),
                 "constructionVisiblePowerBoundaryCanary")
    require(canary.get("schema") == 1 and type(canary.get("schema")) is int and
            canary.get("query") == "tsjQ30D01VisiblePowerBoundary=true" and
            canary.get("purpose") ==
                "real Board Power input; baseline captured by D01 before user click" and
            canary.get("baselineCapturedByVerifier") is True and
            canary.get("boundaryObserved") is True and
            canary.get("status") == "BOUNDARY_RECEIPT_READY",
            "D01 did not arm and capture its visible power boundary receipt")
    before = validate_snapshot(canary.get("beforeVisiblePowerClick"),
                               "before-visible-power-click")
    require(before["simulator"]["developerVerifierRunning"] is False,
            "visible-input baseline was not captured before D01 acquired its verifier lock")
    validate_lease_close(report, "D01 report", "hostBoundaryLeaseCloseStatus",
                          "hostBoundaryLeaseCloseError", "hostBoundaryLeaseReleased",
                          "hostBoundaryWindowHookRemoved",
                          "hostBoundarySnapshotReceiptRemoved")
    require(report.get("hostBoundaryLeaseCloseReason") == "d01-boundary-stop",
            "visible-input case closed its snapshot lease for an unexpected reason")
    validate_lease_close(canary, "constructionVisiblePowerBoundaryCanary",
                          "snapshotLeaseCloseStatus", "snapshotLeaseCloseError",
                          "snapshotLeaseReleased", "snapshotWindowHookRemoved",
                          "snapshotReceiptRemoved")
    require(canary.get("snapshotLeaseCloseReason") == "d01-boundary-stop",
            "visible-input canary closed its lease for an unexpected reason")
    advances = obj(report.get("constructionAdvances"), "constructionAdvances")
    boundary = obj(advances.get("boundaryGuard"), "constructionAdvances.boundaryGuard")
    before_stop = validate_snapshot(boundary.get("hostSnapshotBeforeStop"),
                                    "before-d01-boundary-stop")
    after_stop = validate_snapshot(boundary.get("hostSnapshotAfterStop"),
                                   "after-d01-boundary-stop")
    require(canary.get("beforeD01Stop") == boundary["hostSnapshotBeforeStop"] and
            canary.get("afterD01Stop") == boundary["hostSnapshotAfterStop"] and
            canary.get("boundaryStopReason") == "construction-boundary-unavailable",
            "visible-power canary and D01 boundary evidence disagree")
    require_same_lease([before, before_stop, after_stop])
    require(visible_power_identity_projection(before) ==
            visible_power_identity_projection(before_stop),
            "visible power click changed owner/controller/list topology or source identities")
    require_power_off_transition(before, before_stop, "visible power click")
    require_same_physical(before_stop, after_stop, "same-callback D01 cleanup")
    require(before_stop["coordinator"] == after_stop["coordinator"],
            "coordinator changed during same-callback D01 cleanup")
    require(before_stop["simulator"]["developerVerifierRunning"] is True and
            after_stop["simulator"]["developerVerifierRunning"] is False,
            "D01 did not release its verifier flag after the real power input")
    require(boundary.get("successorDetected") is False and
            boundary.get("successorPreserved") is False and
            boundary.get("boundaryLost") is True and
            boundary.get("stopReason") == "construction-boundary-unavailable" and
            boundary.get("statePreservedAcrossStop") is True and
            boundary.get("constructionSessionReleased") is True and
            boundary.get("verifierLockBeforeStop") is True and
            boundary.get("verifierLockAfterStop") is False and
            report.get("cleanupComplete") is True,
            "D01 did not distinguish input-driven boundary loss from successor identity change")


def minimal_snapshot():
    element = {"ordinal": 0, "identityToken": "I7", "class": "ResistorElm",
               "dump": "R 0 0 0 0 0 0 0 0 0", "internalNodeCount": 0,
               "posts": [{"ordinal": 0, "node": 1}, {"ordinal": 1, "node": 0}],
               "internalNodes": []}
    return {
        "schema": 2, "leaseId": 1, "label": "fixture",
        "simulator": {"identityToken": "I1", "ownerToken": "null",
            "controllerToken": "null", "elmListToken": "I3",
            "installationInProgress": False, "freshInstallationActive": False,
            "activeMeasurementOverlay": False, "generatedRuntimeSettled": True,
            "developerVerifierRunning": False, "troubleshootDebug": True,
            "troubleshootQ30Verification": True},
        "owner": {"identityToken": "null", "family": "", "seed": "",
            "boardToken": "null", "componentBindingsToken": "null",
            "connectionBindingsToken": "null", "externalPowerBindingsToken": "null",
            "faultBindingToken": "null", "faultApplied": False,
            "declaredPowerInputIds": [],
            "simulationElements": []},
        "graph": {"vectorToken": "I3", "size": 1, "elements": [element]},
        "power": {"controllerToken": "null", "bindingsToken": "null",
            "state": "null", "inputs": []},
        "challengeController": {"identityToken": "null", "ready": False,
            "completed": False, "operationInProgress": False},
        "coordinator": {"identityToken": "null", "jobToken": "null",
            "running": False, "advancing": False, "retainsSavedOwners": False,
            "outcome": "null", "stage": "null", "stepCount": -1,
            "candidateIndex": -1},
    }


def minimal_post_stop_scope_withdrawal_report():
    def snapshot(label, job_token, verifier_running):
        value = minimal_snapshot()
        value["label"] = label
        value["simulator"]["developerVerifierRunning"] = verifier_running
        coordinator = value["coordinator"]
        coordinator.update({
            "identityToken": "I4", "jobToken": job_token,
            "running": job_token != "null", "advancing": False,
            "retainsSavedOwners": False,
            "outcome": "null" if job_token == "null" else "RUNNING",
            "stage": "null" if job_token == "null" else "CANDIDATES",
            "stepCount": -1 if job_token == "null" else 2,
            "candidateIndex": -1 if job_token == "null" else 0,
        })
        return value

    before_start = snapshot("before-normal-successor-start", "null", True)
    after_start = snapshot("after-normal-successor-start", "I5", True)
    before_stop = snapshot("before-d01-boundary-stop", "I5", True)
    after_stop = snapshot("after-d01-boundary-stop", "I5", False)
    close = {"status": "PASS", "error": "", "released": True,
             "hookRemoved": True, "receiptRemoved": True}
    canary = {
        "schema": 1, "status": "PASS",
        "query": "tsjQ30D01ConstructionScopeWithdrawalAfterStop=true",
        "purpose": "negative D01 boundary canary; injects verifier-scope withdrawal after DONE while the ordinary player successor remains running",
        "startApi": "PlayerLaunchRequest.generation -> GenerationCoordinator.start(asynchronous=true)",
        "normalMaximumJobMillis": 90000, "normalMaximumSteps": 640,
        "normalMaximumStepMillis": 5000, "snapshotLeaseTimeoutMillis": 95000,
        "snapshotLeaseScopePollMillis": 10, "scopeWithdrawalPollIsCanaryOnly": True,
        "defaultOneSecondLatencyProven": False,
        "family": "LED_INDICATOR", "seed": "3", "profile": "EASY",
        "requestReplay": "tsj-alpha/4/EASY/LED_INDICATOR/3",
        "startIssued": True, "startObserved": True, "stopObserved": True,
        "physicalStateUnchangedAtStart": True,
        "phaseAtScopeWithdrawal": "DONE", "scopeWithdrawalInjectionReady": True,
        "scopeWithdrawalInjectedAfterDone": True, "q30ScopeFalseAfterInjection": True,
        "scopeWithdrawalPollObserved": True, "scopeWithdrawalObserved": True,
        "successorRunningAtScopeWithdrawalPoll": True,
        "successorRunningImmediatelyBeforeLeaseClose": True,
        "successorJobOutcomeAtLeaseClose": "RUNNING",
        "successorExactIdentityAtLeaseClose": True,
        "successorStillRunningImmediatelyAfterLeaseClose": True,
        "successorJobNotCancelledOrReplacedAtLeaseClose": True,
        "successorCompletedBeforeScopePoll": False,
        "predecessorPhysicalStateAtLeaseClose": True,
        "predecessorPhysicalStateUnchangedByLeaseClose": True,
        "powerStateAtStop": "null",
        "captureStateReleased": True, "leaseDetachedFromActiveSlot": True,
        "completionObserverDisarmed": True,
        "completionObserverReferenceReleased": True,
        "scopeFlagRestoredSafely": True,
        "primitiveLeaseCloseReceiptComplete": True,
        "snapshotLeaseReleasePending": False,
        "successorCoordinatorTokenAtStop": "I4",
        "successorJobTokenAtStop": "I5",
        "successorCoordinatorTokenAtPoll": "I4",
        "successorJobTokenAtPoll": "I5",
        "beforeStart": before_start, "afterStart": after_start,
        "beforeStop": before_stop, "afterStop": after_stop,
    }
    canary.update({
        "snapshotLeaseCloseStatus": close["status"],
        "snapshotLeaseCloseError": close["error"],
        "snapshotLeaseReleased": close["released"],
        "snapshotWindowHookRemoved": close["hookRemoved"],
        "snapshotReceiptRemoved": close["receiptRemoved"],
        "snapshotLeaseCloseReason": "debug-q30-scope-loss",
    })
    boundary = {
        "successorDetected": True, "successorPreserved": True,
        "boundaryLost": True, "statePreservedAcrossStop": True,
        "stopReason": "successor-identity-changed",
        "constructionSessionReleased": True,
        "verifierLockBeforeStop": True, "verifierLockAfterStop": False,
        "verifierLockReleased": True,
        "hostSnapshotBeforeStop": before_stop,
        "hostSnapshotAfterStop": after_stop,
    }
    return {
        "schema": 2, "status": "FAIL", "phase": "DONE",
        "normalAdmission": False, "playerPublished": False, "d01Admission": False,
        "cleanupComplete": True, "ownerRestored": True,
        "hostBoundaryLeaseCloseStatus": close["status"],
        "hostBoundaryLeaseCloseError": close["error"],
        "hostBoundaryLeaseReleased": close["released"],
        "hostBoundaryWindowHookRemoved": close["hookRemoved"],
        "hostBoundarySnapshotReceiptRemoved": close["receiptRemoved"],
        "hostBoundaryLeaseCloseReason": "debug-q30-scope-loss",
        "constructionAdvances": {"boundaryGuard": boundary},
        "constructionPostStopScopeWithdrawalCanary": canary,
    }


def self_test():
    successful_close = {
        "status": "PASS", "error": "", "released": True,
        "hookRemoved": True, "receiptRemoved": True,
    }
    validate_lease_close(successful_close, "successfulClose", "status", "error",
                         "released", "hookRemoved", "receiptRemoved")
    exception_receipt = dict(successful_close)
    exception_receipt["status"] = "FAIL"
    exception_receipt["error"] = "revokeBridge threw: host denied removal"
    try:
        validate_lease_close(exception_receipt, "exceptionReceipt", "status", "error",
                             "released", "hookRemoved", "receiptRemoved")
    except ValueError:
        pass
    else:
        raise AssertionError("exception-looking cleanup receipt was accepted")
    repeated_close_failure = dict(successful_close)
    # Model a later idempotent close rewriting the visible status/booleans but
    # preserving the first failed close's error. The reader must still reject it.
    repeated_close_failure["status"] = "PASS"
    repeated_close_failure["error"] = "revokeBridge threw: host denied removal"
    try:
        validate_lease_close(repeated_close_failure, "repeatedCloseFailure",
                             "status", "error", "released", "hookRemoved",
                             "receiptRemoved")
    except ValueError:
        pass
    else:
        raise AssertionError("repeated close receipt erased the first close failure")

    fixture = minimal_snapshot()
    validate_snapshot(fixture, "fixture")
    sparse = json.loads(json.dumps(fixture))
    del sparse["graph"]["elements"][0]["internalNodeCount"]
    try:
        validate_snapshot(sparse)
    except ValueError:
        pass
    else:
        raise AssertionError("sparse graph element was accepted")
    wrong_type = json.loads(json.dumps(fixture))
    wrong_type["simulator"]["activeMeasurementOverlay"] = 0
    try:
        validate_snapshot(wrong_type)
    except ValueError:
        pass
    else:
        raise AssertionError("non-boolean simulator state was accepted")
    missing_live_binding = json.loads(json.dumps(fixture))
    missing_live_binding["simulator"]["ownerToken"] = "I2"
    missing_live_binding["simulator"]["controllerToken"] = "I4"
    missing_live_binding["owner"].update({
        "identityToken": "I2", "family": "RB30", "seed": "1",
        "boardToken": "I5", "componentBindingsToken": "I6",
        "connectionBindingsToken": "I8", "externalPowerBindingsToken": "I12",
        "faultBindingToken": "I10", "faultApplied": True,
        "declaredPowerInputIds": ["MAIN12"],
    })
    missing_live_binding["power"].update({
        "controllerToken": "I11", "bindingsToken": "I12", "state": "POWERED",
        "inputs": [{"id": "MAIN12", "bindingToken": "null",
            "connected": False, "controlled": False, "connectionRevision": -1,
            "backingElements": [], "limitedSupplyToken": "null",
            "limitedSupplyDump": "", "limitedSupplyLimitAmps": ""}],
    })
    missing_live_binding["challengeController"]["identityToken"] = "I4"
    try:
        validate_snapshot(missing_live_binding)
    except ValueError:
        pass
    else:
        raise AssertionError("live board power input without a binding was accepted")
    duplicate = json.loads(json.dumps(fixture))
    duplicate["graph"]["elements"].append(dict(duplicate["graph"]["elements"][0]))
    duplicate["graph"]["elements"][1]["ordinal"] = 1
    duplicate["graph"]["size"] = 2
    try:
        validate_snapshot(duplicate)
    except ValueError:
        pass
    else:
        raise AssertionError("duplicate physical element identity was accepted")

    post_stop_fixture = minimal_post_stop_scope_withdrawal_report()
    check_post_stop_scope_withdrawal(post_stop_fixture)
    corruptions = (
        ("admission", lambda r: r.update({"d01Admission": True})),
        ("poll", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"snapshotLeaseScopePollMillis": 1000})),
        ("outcome", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"successorJobOutcomeAtLeaseClose": "PASS"})),
        ("token", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"successorJobTokenAtPoll": "I99"})),
        ("hook", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"snapshotWindowHookRemoved": False})),
        ("dom receipt", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"snapshotReceiptRemoved": False})),
        ("capture map", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"captureStateReleased": False})),
        ("active lease", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"leaseDetachedFromActiveSlot": False})),
        ("callback disarm", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"completionObserverDisarmed": False})),
        ("callback reference", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"completionObserverReferenceReleased": False})),
        ("scope restore", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"scopeFlagRestoredSafely": False})),
        ("physical state", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"predecessorPhysicalStateUnchangedByLeaseClose": False})),
        ("close reason", lambda r: r["constructionPostStopScopeWithdrawalCanary"].update(
            {"snapshotLeaseCloseReason": "normal-successor-completion"})),
    )
    for label, corrupt in corruptions:
        candidate = json.loads(json.dumps(post_stop_fixture))
        corrupt(candidate)
        try:
            check_post_stop_scope_withdrawal(candidate)
        except ValueError:
            pass
        else:
            raise AssertionError("post-stop canary accepted corrupted " + label)


def main():
    if len(sys.argv) == 2 and sys.argv[1] == "--self-test":
        self_test()
        print("PASS: strict D01 snapshot and cleanup schemas with mutation guards")
        return 0
    if len(sys.argv) == 2:
        check_normal_successor(load_json(sys.argv[1]))
        print("PASS: Q30 D01 normal-successor negative boundary canary")
        print("D01 remains FAIL with no admission; ordinary LED_INDICATOR/EASY/3 completed")
        return 0
    if len(sys.argv) == 3 and sys.argv[1] == "--visible-power-boundary":
        check_visible_power_boundary(load_json(sys.argv[2]))
        print("PASS: real power-off receipt and same-callback D01 cleanup snapshots")
        print("A real visible browser click must be separately recorded; this reader checks receipts only")
        return 0
    if len(sys.argv) == 3 and sys.argv[1] == "--post-stop-scope-withdrawal":
        check_post_stop_scope_withdrawal(load_json(sys.argv[2]))
        print("PASS: D01 post-stop injected scope-withdrawal cleanup receipt")
        print("D01 remains FAIL with no admission; normal successor is proven RUNNING at lease close")
        return 0
    raise ValueError(
        "usage: check_d01_normal_successor_canary.py <report.json> OR "
        "check_d01_normal_successor_canary.py --visible-power-boundary "
        "<d01-report.json> OR --post-stop-scope-withdrawal <d01-report.json> OR "
        "check_d01_normal_successor_canary.py --self-test")


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, json.JSONDecodeError, ValueError, KeyError, TypeError) as failure:
        print("FAIL: " + str(failure), file=sys.stderr)
        raise SystemExit(1)
