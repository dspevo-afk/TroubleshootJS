package com.lushprojects.circuitjs1.client;

import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONBoolean;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Vector;

/**
 * Read-only D01 host-boundary evidence. The browser bridge is installed only
 * after explicit debug/Q30 admission and exposes capture(label), never mutation.
 */
final class Q30D01HostBoundarySnapshot {
    private static Lease activeLease;
    private static int nextLeaseId = 1;

    private Q30D01HostBoundarySnapshot() { }

    static synchronized Lease openReadOnlyDebugBridge(CirSim sim) {
        if (sim == null || !sim.troubleshootDebug || !sim.troubleshootQ30Verification)
            throw new IllegalStateException("D01 snapshot bridge requires explicit debug Q30 scope");
        if (activeLease != null && !activeLease.isClosed())
            throw new IllegalStateException("A previous D01 snapshot lease is still active");
        int id = nextLeaseId;
        if (id <= 0)
            throw new IllegalStateException("D01 snapshot lease identity space is exhausted");
        nextLeaseId = id == Integer.MAX_VALUE ? 0 : id + 1;
        Lease lease = new Lease(id, sim);
        activeLease = lease;
        try {
            if (com.google.gwt.core.client.GWT.isClient() && !installBridge(id))
                throw new IllegalStateException(
                    "D01 snapshot bridge hook is already owned by another operation");
        } catch (RuntimeException failure) {
            if (activeLease == lease) activeLease = null;
            lease.close();
            throw failure;
        } catch (Error failure) {
            if (activeLease == lease) activeLease = null;
            lease.close();
            throw failure;
        }
        return lease;
    }

    static final class Lease {
        private final int id;
        private final IdentityHashMap<Object, Integer> tokens =
            new IdentityHashMap<Object, Integer>();
        private int nextToken = 1;
        private CirSim sim;
        private boolean closed;
        private volatile boolean ownedWindowHookRemoved;
        private volatile boolean ownedSnapshotReceiptRemoved;
        private boolean closeCompleted;
        private String closeResult;

        private Lease(int id, CirSim sim) {
            this.id = id;
            this.sim = sim;
        }

        synchronized boolean isClosed() { return closed; }

        synchronized boolean hasExplicitScope() {
            return !closed && sim != null && sim.troubleshootDebug &&
                sim.troubleshootQ30Verification;
        }

        synchronized Snapshot capture(String label) {
            if (closed || sim == null)
                throw new IllegalStateException("D01 snapshot lease is closed");
            if (!sim.troubleshootDebug || !sim.troubleshootQ30Verification)
                throw new IllegalStateException(
                    "D01 snapshot capture requires its explicit debug Q30 scope");
            return new Snapshot(this, sim, safeLabel(label));
        }

        Snapshot captureAndPublish(String label) {
            Snapshot snapshot = capture(label);
            publishSnapshot(snapshot.json.toString());
            return snapshot;
        }

        private synchronized String token(Object value) {
            if (value == null) return "null";
            Integer token = tokens.get(value);
            if (token == null) {
                token = Integer.valueOf(nextToken++);
                tokens.put(value, token);
            }
            return "I" + token.intValue();
        }

        private String captureForHost(String label) {
            try {
                CirSim current;
                synchronized (this) {
                    current = sim;
                    if (closed || current == null || activeLease != this)
                        return captureError("debug Q30 scope or snapshot lease is not active");
                }
                if (!current.troubleshootDebug || !current.troubleshootQ30Verification) {
                    close();
                    return captureError("debug Q30 scope or snapshot lease is not active");
                }
                Snapshot snapshot = capture(label);
                String json = snapshot.json.toString();
                publishSnapshot(json);
                return json;
            } catch (Throwable failure) {
                return captureError(failure.getMessage());
            }
        }

        /** Revokes only this lease's window hook and drops every strong reference. */
        String close() {
            synchronized (this) {
                if (closeCompleted) return closeResult;
                if (closed)
                    return "D01 snapshot lease close is already in progress";
                closed = true;
            }
            String problem = null;
            if (com.google.gwt.core.client.GWT.isClient()) {
                try {
                    ownedWindowHookRemoved = revokeBridge(id);
                    if (!ownedWindowHookRemoved)
                        problem = appendCloseProblem(problem,
                            "D01 snapshot browser hook was not removed");
                } catch (Throwable failure) {
                    problem = appendCloseProblem(problem, describeCloseFailure(
                        "D01 snapshot browser hook removal threw", failure));
                }
                try {
                    ownedSnapshotReceiptRemoved = clearOwnedSnapshot(id);
                    if (!ownedSnapshotReceiptRemoved)
                        problem = appendCloseProblem(problem,
                            "D01 snapshot receipt was not removed");
                } catch (Throwable failure) {
                    problem = appendCloseProblem(problem, describeCloseFailure(
                        "D01 snapshot receipt removal threw", failure));
                }
            } else {
                // The native verifier never installed a browser hook or DOM receipt.
                ownedWindowHookRemoved = true;
                ownedSnapshotReceiptRemoved = true;
            }
            try {
                synchronized (Q30D01HostBoundarySnapshot.class) {
                    if (activeLease == this) activeLease = null;
                }
            } finally {
                synchronized (this) {
                    tokens.clear();
                    sim = null;
                }
            }
            synchronized (this) {
                closeResult = problem;
                closeCompleted = true;
            }
            return problem;
        }

        synchronized boolean wasOwnedWindowHookRemoved() { return ownedWindowHookRemoved; }
        synchronized boolean wasOwnedSnapshotReceiptRemoved() {
            return ownedSnapshotReceiptRemoved;
        }

        synchronized boolean hasReleasedCaptureState() {
            return closed && sim == null && tokens.isEmpty();
        }

        boolean isDetachedFromActiveSlot() {
            synchronized (Q30D01HostBoundarySnapshot.class) {
                return activeLease != this;
            }
        }

        private static String describeCloseFailure(String operation, Throwable failure) {
            String detail = failure.getMessage();
            return operation + (detail == null || detail.length() == 0 ?
                ": " + failure.toString() : ": " + detail);
        }

        private static String appendCloseProblem(String current, String next) {
            if (current == null || current.length() == 0) return next;
            return current + "; " + next;
        }
    }

    private static synchronized String captureForHost(int leaseId, String label) {
        Lease lease = activeLease;
        if (lease == null || lease.id != leaseId)
            return captureError("D01 snapshot lease is no longer current");
        return lease.captureForHost(label);
    }

    private static String safeLabel(String label) {
        if (label == null || label.length() == 0 || label.length() > 80)
            throw new IllegalArgumentException("D01 snapshot label must contain 1..80 characters");
        return label;
    }

    static final class Snapshot {
        final JSONObject json;
        final int leaseId;
        final String physicalSignature;
        final String stopBoundarySignature;
        final String coordinatorSignature;
        final String ownerToken;
        final String controllerToken;
        final String graphVectorToken;
        final String coordinatorToken;
        final String jobToken;
        final String family;
        final long seed;
        final String graphSignature;
        final String ownerElementsSignature;
        final String powerSignature;
        final boolean developerVerifierRunning;
        final boolean installationInProgress;
        final boolean freshInstallationActive;
        final boolean coordinatorRunning;
        final String jobOutcome;

        private Snapshot(Lease lease, CirSim sim, String label) {
            json = new JSONObject();
            leaseId = lease.id;
            put(json, "schema", 2);
            put(json, "leaseId", leaseId);
            put(json, "label", label);
            JSONObject simulator = new JSONObject();
            String simToken = lease.token(sim);
            GeneratedBoardInstance owner = sim.getGeneratedBoardInstance();
            GeneratedChallengeController controller = sim.getGeneratedChallengeController();
            Vector<CircuitElm> activeGraph = sim.elmList;
            GenerationCoordinator coordinator = sim.generationCoordinator;
            GenerationJob job = coordinator == null ? null : coordinator.getJob();
            BoardPowerController powerController = sim.getBoardPowerController();
            GeneratedExternalPowerBindings powerBindings =
                powerController == null ? null :
                    powerController.getBindingsForDeveloperVerification();

            ownerToken = lease.token(owner);
            controllerToken = lease.token(controller);
            graphVectorToken = lease.token(activeGraph);
            coordinatorToken = lease.token(coordinator);
            jobToken = lease.token(job);
            developerVerifierRunning = sim.developerVerifierRunning;
            installationInProgress = sim.generatedRuntimeInstallationInProgress;
            freshInstallationActive =
                FreshGeneratedRuntimeInstallation.isInProgress(sim);
            coordinatorRunning = coordinator != null && coordinator.isRunning();
            jobOutcome = job == null ? "null" : job.getOutcome().toString();

            put(simulator, "identityToken", simToken);
            put(simulator, "ownerToken", ownerToken);
            put(simulator, "controllerToken", controllerToken);
            put(simulator, "elmListToken", graphVectorToken);
            put(simulator, "installationInProgress", installationInProgress);
            put(simulator, "freshInstallationActive", freshInstallationActive);
            put(simulator, "activeMeasurementOverlay", sim.activeMeasurementOverlay);
            put(simulator, "generatedRuntimeSettled", sim.isGeneratedRuntimeSettled());
            put(simulator, "developerVerifierRunning", developerVerifierRunning);
            put(simulator, "troubleshootDebug", sim.troubleshootDebug);
            put(simulator, "troubleshootQ30Verification", sim.troubleshootQ30Verification);
            json.put("simulator", simulator);

            JSONObject ownerJson = new JSONObject();
            String ownerElements = "";
            family = owner == null ? "" : owner.getCircuitFamilyId();
            seed = owner == null ? 0L : owner.getSeed();
            String ownerBoardToken = owner == null ? "null" : lease.token(owner.getBoard());
            String componentBindingsToken =
                owner == null ? "null" : lease.token(owner.getComponentBindings());
            String connectionBindingsToken =
                owner == null ? "null" : lease.token(owner.getConnectionBindings());
            String ownerPowerBindingsToken =
                owner == null ? "null" : lease.token(owner.getExternalPowerBindings());
            String faultBindingToken =
                owner == null ? "null" : lease.token(owner.getFaultBinding());
            boolean faultApplied =
                owner != null && owner.getFaultBinding() != null &&
                    owner.getFaultBinding().isApplied();
            put(ownerJson, "identityToken", ownerToken);
            put(ownerJson, "family", family);
            put(ownerJson, "seed", owner == null ? "" : Long.toString(seed));
            put(ownerJson, "boardToken", ownerBoardToken);
            put(ownerJson, "componentBindingsToken", componentBindingsToken);
            put(ownerJson, "connectionBindingsToken", connectionBindingsToken);
            put(ownerJson, "externalPowerBindingsToken", ownerPowerBindingsToken);
            put(ownerJson, "faultBindingToken", faultBindingToken);
            put(ownerJson, "faultApplied", faultApplied);
            Vector<String> declaredPowerInputs = owner == null ? new Vector<String>() :
                owner.getBoard().getPowerInputIds();
            Collections.sort(declaredPowerInputs);
            JSONArray declaredPowerInputIds = new JSONArray();
            for (String inputId : declaredPowerInputs)
                declaredPowerInputIds.set(declaredPowerInputIds.size(),
                    new JSONString(inputId));
            ownerJson.put("declaredPowerInputIds", declaredPowerInputIds);
            JSONArray ownedElements = new JSONArray();
            if (owner != null) {
                Vector<CircuitElm> elements = owner.getSimulationElements();
                StringBuilder ownerSignature = new StringBuilder();
                for (int i = 0; i < elements.size(); i++) {
                    CircuitElm element = elements.get(i);
                    JSONObject entry = elementJson(lease, element, i);
                    ownedElements.set(ownedElements.size(), entry);
                    append(ownerSignature, elementSignature(lease, element, i));
                }
                ownerElements = ownerSignature.toString();
            }
            ownerJson.put("simulationElements", ownedElements);
            json.put("owner", ownerJson);

            StringBuilder graphContent = new StringBuilder();
            JSONArray graphElements = new JSONArray();
            if (activeGraph != null) {
                for (int i = 0; i < activeGraph.size(); i++) {
                    CircuitElm element = activeGraph.get(i);
                    graphElements.set(graphElements.size(), elementJson(lease, element, i));
                    append(graphContent, elementSignature(lease, element, i));
                }
            }
            JSONObject graphJson = new JSONObject();
            put(graphJson, "vectorToken", graphVectorToken);
            put(graphJson, "size", activeGraph == null ? -1 : activeGraph.size());
            graphJson.put("elements", graphElements);
            json.put("graph", graphJson);
            graphSignature = graphContent.toString();
            ownerElementsSignature = ownerElements;

            JSONObject powerJson = new JSONObject();
            String powerControllerToken = lease.token(powerController);
            String powerBindingsToken = lease.token(powerBindings);
            put(powerJson, "controllerToken", powerControllerToken);
            put(powerJson, "bindingsToken", powerBindingsToken);
            put(powerJson, "state", powerController == null ? "null" :
                powerController.getState().toString());
            JSONArray sourceInputs = new JSONArray();
            StringBuilder controls = new StringBuilder();
            Vector<String> inputIds = owner == null ? new Vector<String>() :
                owner.getBoard().getPowerInputIds();
            if (owner != null && (powerController == null || powerBindings == null ||
                    powerBindings != owner.getExternalPowerBindings()))
                throw new IllegalStateException(
                    "live board power inputs lack their declared board-power bindings");
            Collections.sort(inputIds);
            for (String inputId : inputIds) {
                JSONObject source = new JSONObject();
                ExternalPowerSimulationBinding binding = powerBindings == null ? null :
                    powerBindings.getBinding(inputId);
                if (owner != null && binding == null)
                    throw new IllegalStateException(
                        "declared live-board power input has no simulation binding: " + inputId);
                put(source, "id", inputId);
                put(source, "bindingToken", lease.token(binding));
                put(source, "connected", binding != null && binding.isConnected());
                put(source, "controlled", binding != null && binding.hasControl());
                put(source, "connectionRevision",
                    binding == null ? -1L : binding.getConnectionRevision());
                JSONArray backing = new JSONArray();
                if (binding != null) {
                    Vector<CircuitElm> backingElements = binding.getBackingElements();
                    for (int i = 0; i < backingElements.size(); i++) {
                        CircuitElm element = backingElements.get(i);
                        backing.set(backing.size(), elementJson(lease, element, i));
                    }
                }
                source.put("backingElements", backing);
                LimitedDcSupplyElm supply = binding == null ? null : binding.getLimitedSupply();
                put(source, "limitedSupplyToken", lease.token(supply));
                put(source, "limitedSupplyDump", supply == null ? "" : supply.dump());
                put(source, "limitedSupplyLimitAmps",
                    supply == null ? "" : Double.toString(supply.getLimitAmps()));
                sourceInputs.set(sourceInputs.size(), source);
                append(controls, inputId);
                append(controls, lease.token(binding));
                append(controls, binding != null && binding.isConnected() ? "connected" : "isolated");
                append(controls, binding == null ? "-1" :
                    Long.toString(binding.getConnectionRevision()));
                append(controls, supply == null ? "" : supply.dump());
                if (binding != null) {
                    Vector<CircuitElm> backingElements = binding.getBackingElements();
                    for (int i = 0; i < backingElements.size(); i++)
                        append(controls, elementSignature(lease, backingElements.get(i), i));
                }
            }
            powerJson.put("inputs", sourceInputs);
            json.put("power", powerJson);
            powerSignature = controls.toString();

            JSONObject controllerJson = new JSONObject();
            put(controllerJson, "identityToken", lease.token(controller));
            put(controllerJson, "ready", controller != null && controller.isReady());
            put(controllerJson, "completed", controller != null && controller.isCompleted());
            put(controllerJson, "operationInProgress",
                controller != null && controller.isOperationInProgress());
            json.put("challengeController", controllerJson);

            JSONObject coordinatorJson = new JSONObject();
            put(coordinatorJson, "identityToken", coordinatorToken);
            put(coordinatorJson, "jobToken", jobToken);
            put(coordinatorJson, "running", coordinator != null && coordinator.isRunning());
            put(coordinatorJson, "advancing", coordinator != null && coordinator.isAdvancing());
            put(coordinatorJson, "retainsSavedOwners",
                coordinator != null &&
                    coordinator.retainsSavedOwnersForDeveloperVerification());
            put(coordinatorJson, "outcome", job == null ? "null" : job.getOutcome().toString());
            put(coordinatorJson, "stage", job == null ? "null" : job.getStage().toString());
            put(coordinatorJson, "stepCount", job == null ? -1 : job.getStepCount());
            put(coordinatorJson, "candidateIndex",
                job == null ? -1 : job.getCandidateIndex());
            json.put("coordinator", coordinatorJson);

            StringBuilder physical = new StringBuilder();
            append(physical, simToken);
            append(physical, ownerToken);
            append(physical, family);
            append(physical, owner == null ? "" : Long.toString(seed));
            append(physical, ownerBoardToken);
            append(physical, componentBindingsToken);
            append(physical, connectionBindingsToken);
            append(physical, ownerPowerBindingsToken);
            append(physical, faultBindingToken);
            append(physical, Boolean.toString(faultApplied));
            append(physical, controllerToken);
            append(physical, Boolean.toString(controller != null && controller.isReady()));
            append(physical, Boolean.toString(controller != null && controller.isCompleted()));
            append(physical, Boolean.toString(
                controller != null && controller.isOperationInProgress()));
            append(physical, graphVectorToken);
            append(physical, Boolean.toString(installationInProgress));
            append(physical, Boolean.toString(freshInstallationActive));
            append(physical, Boolean.toString(sim.activeMeasurementOverlay));
            append(physical, Boolean.toString(sim.troubleshootDebug));
            append(physical, Boolean.toString(sim.troubleshootQ30Verification));
            append(physical, ownerElements);
            append(physical, graphSignature);
            append(physical, powerControllerToken);
            append(physical, powerBindingsToken);
            append(physical, powerController == null ? "null" :
                powerController.getState().toString());
            append(physical, controls.toString());
            physicalSignature = physical.toString();

            StringBuilder boundary = new StringBuilder(physicalSignature);
            append(boundary, Boolean.toString(sim.activeMeasurementOverlay));
            append(boundary, Boolean.toString(sim.troubleshootDebug));
            append(boundary, Boolean.toString(sim.troubleshootQ30Verification));
            append(boundary, coordinatorToken);
            append(boundary, jobToken);
            append(boundary, Boolean.toString(coordinator != null && coordinator.isRunning()));
            append(boundary, Boolean.toString(coordinator != null && coordinator.isAdvancing()));
            append(boundary, Boolean.toString(coordinator != null &&
                coordinator.retainsSavedOwnersForDeveloperVerification()));
            append(boundary, job == null ? "null" : job.getOutcome().toString());
            append(boundary, job == null ? "null" : job.getStage().toString());
            append(boundary, job == null ? "-1" :
                Integer.toString(job.getStepCount()));
            append(boundary, job == null ? "-1" :
                Integer.toString(job.getCandidateIndex()));
            stopBoundarySignature = boundary.toString();
            StringBuilder coordinatorState = new StringBuilder();
            append(coordinatorState, coordinatorToken);
            append(coordinatorState, jobToken);
            append(coordinatorState,
                Boolean.toString(coordinator != null && coordinator.isRunning()));
            append(coordinatorState,
                Boolean.toString(coordinator != null && coordinator.isAdvancing()));
            append(coordinatorState, job == null ? "null" : job.getOutcome().toString());
            append(coordinatorState, job == null ? "null" : job.getStage().toString());
            append(coordinatorState, job == null ? "-1" :
                Integer.toString(job.getStepCount()));
            append(coordinatorState, job == null ? "-1" :
                Integer.toString(job.getCandidateIndex()));
            coordinatorSignature = coordinatorState.toString();
        }

        boolean samePhysicalState(Snapshot other) {
            return other != null && leaseId == other.leaseId &&
                physicalSignature.equals(other.physicalSignature);
        }

        boolean sameStopBoundaryState(Snapshot other) {
            return other != null && leaseId == other.leaseId &&
                stopBoundarySignature.equals(other.stopBoundarySignature);
        }

        boolean sameCoordinatorState(Snapshot other) {
            return other != null && leaseId == other.leaseId &&
                coordinatorSignature.equals(other.coordinatorSignature);
        }
    }

    private static JSONObject elementJson(Lease lease, CircuitElm element, int ordinal) {
        JSONObject json = new JSONObject();
        put(json, "ordinal", ordinal);
        put(json, "identityToken", lease.token(element));
        put(json, "class", element == null ? "null" : element.getClass().getName());
        if (element == null) {
            put(json, "dump", "");
            put(json, "internalNodeCount", 0);
            json.put("posts", new JSONArray());
            json.put("internalNodes", new JSONArray());
            return json;
        }
        put(json, "dump", element.dump());
        put(json, "internalNodeCount", element.getInternalNodeCount());
        JSONArray posts = new JSONArray();
        for (int i = 0; i < element.getPostCount(); i++) {
            JSONObject post = new JSONObject();
            put(post, "ordinal", i);
            put(post, "node", element.getNode(i));
            posts.set(posts.size(), post);
        }
        json.put("posts", posts);
        JSONArray internalNodes = new JSONArray();
        for (int i = 0; i < element.getInternalNodeCount(); i++)
            internalNodes.set(internalNodes.size(),
                new JSONNumber(element.getNode(element.getPostCount() + i)));
        json.put("internalNodes", internalNodes);
        return json;
    }

    private static String elementSignature(Lease lease, CircuitElm element, int ordinal) {
        StringBuilder signature = new StringBuilder();
        append(signature, Integer.toString(ordinal));
        append(signature, lease.token(element));
        append(signature, element == null ? "null" : element.getClass().getName());
        append(signature, element == null ? "" : element.dump());
        if (element != null) {
            append(signature, Integer.toString(element.getPostCount()));
            append(signature, Integer.toString(element.getInternalNodeCount()));
            for (int i = 0; i < element.getPostCount() + element.getInternalNodeCount(); i++)
                append(signature, Integer.toString(element.getNode(i)));
        }
        return signature.toString();
    }

    private static void append(StringBuilder target, String value) {
        String item = value == null ? "" : value;
        target.append(item.length()).append(':').append(item).append(';');
    }

    private static void put(JSONObject object, String key, String value) {
        object.put(key, new JSONString(value == null ? "" : value));
    }
    private static void put(JSONObject object, String key, boolean value) {
        object.put(key, JSONBoolean.getInstance(value));
    }
    private static void put(JSONObject object, String key, int value) {
        object.put(key, new JSONNumber(value));
    }
    private static void put(JSONObject object, String key, long value) {
        object.put(key, new JSONNumber(value));
    }

    private static String captureError(String message) {
        return "{\"schema\":2,\"captureError\":\"" +
            escapeJson(message) + "\"}";
    }

    private static String escapeJson(String value) {
        if (value == null) return "snapshot failed";
        StringBuilder escaped = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (ch == '\\' || ch == '"') escaped.append('\\');
            if (ch == '\n') escaped.append("\\n");
            else if (ch == '\r') escaped.append("\\r");
            else escaped.append(ch);
        }
        return escaped.toString();
    }

    private static native boolean installBridge(int leaseId) /*-{
        if (typeof $wnd.__tsjQ30D01HostBoundary !== "undefined" &&
                $wnd.__tsjQ30D01HostBoundary !== null) return false;
        var capture = @com.lushprojects.circuitjs1.client.Q30D01HostBoundarySnapshot::captureForHost(ILjava/lang/String;);
        $wnd.__tsjQ30D01HostBoundary = {
            schema: 2,
            leaseId: leaseId,
            capture: $entry(function(label) { return capture(leaseId, label); })
        };
        return true;
    }-*/;

    private static native boolean revokeBridge(int leaseId) /*-{
        var bridge = $wnd.__tsjQ30D01HostBoundary;
        if (typeof bridge === "undefined" || bridge === null) return true;
        if (bridge.leaseId !== leaseId) return true;
        delete $wnd.__tsjQ30D01HostBoundary;
        return typeof $wnd.__tsjQ30D01HostBoundary === "undefined";
    }-*/;

    private static native boolean clearOwnedSnapshot(int leaseId) /*-{
        var root = $doc.documentElement;
        var attribute = "data-tsj-q30-d01-host-snapshot";
        var receipt = root.getAttribute(attribute);
        if (receipt === null) return true;
        var parsed;
        try { parsed = JSON.parse(receipt); }
        catch (failure) { return false; }
        if (!parsed || parsed.leaseId !== leaseId) return true;
        root.removeAttribute(attribute);
        return root.getAttribute(attribute) === null;
    }-*/;

    private static native void publishSnapshot(String snapshot) /*-{
        $doc.documentElement.setAttribute("data-tsj-q30-d01-host-snapshot", snapshot);
    }-*/;
}

