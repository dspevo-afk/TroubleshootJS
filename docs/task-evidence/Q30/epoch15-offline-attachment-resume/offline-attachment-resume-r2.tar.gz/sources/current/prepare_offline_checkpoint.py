"""Read-only source/runtime/evidence audit and fixture preparation; no Edge launch."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REPO = Path(r'<user>/.codex\worktrees\q30-multirail-qualification\TroubleshootJS')
TASK = Path(r'<user>/AppData\Local\Temp\q30-process-pinned-final-qualification-fcffecff8fa444889bce93725495c628')
DEPS = Path(r'<user>/AppData\Local\Temp\q30-finish-0fa2512465\deps')
PYTHON = Path(r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe')
PACKET = REPO / 'docs/task-evidence/Q30/epoch15-process-final-compiled31/compiled31-process-final-evidence.tar.gz'
MANIFEST = PACKET.parent / 'manifest.json'
PRIOR = Path(r'<user>/AppData\Local\Temp\q30-final-qualification-be815db03e7d4421b061ebc228a984fd\compiled31\result.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    root = Path(tempfile.mkdtemp(prefix='q30-offline-attachment-preparation-'))
    report = {'schema': 1, 'status': 'FAIL', 'scope': 'OFFLINE_ONLY_NO_BROWSER_OR_APP',
              'startedUtc': datetime.now(timezone.utc).isoformat()}
    try:
        for path in HERE.glob('*.py'):
            ast.parse(path.read_text(encoding='utf-8'), filename=path.name)
        snapshot = json.loads((TASK / 'source-snapshot-maintained.json').read_text(encoding='utf-8-sig'))
        assert snapshot['sourceIdentity'] == 'a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51'
        rows = snapshot['files']
        assert len(rows) == 1354
        mismatches = []
        for row in rows:
            path = REPO / row['path']
            if path.stat().st_size != row['size'] or sha(path) != row['sha256']:
                mismatches.append(row['path'])
        assert not mismatches, mismatches
        report.update(sourceIdentity=snapshot['sourceIdentity'], frozenInputsVerified=len(rows))
        sys.path.insert(0, str(DEPS))
        helper = HERE / 'run_attachment_scope_canaries.py'
        spec = importlib.util.spec_from_file_location('prepared_attachment_canary', helper)
        canary = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(canary)
        retained_final = canary.validate_final_packet(PACKET, MANIFEST)
        retained_failed = canary.validate_prior_failed_receipts(PRIOR)
        host = HERE / 'compiled_attribute_acceptance.py'
        host_path, host_hash, host_module, runtime = canary.load_host(host, sha(host))
        assert host_module.async_playwright is not None
        app, output, fixture_spec = canary.write_fixture(root)
        fixture = json.loads(fixture_spec.read_text(encoding='utf-8'))
        assert [case['name'] for case in fixture['cases']] == list(canary.CASE_NAMES)
        assert len(fixture['cases']) == 5
        assert all(case['timeoutSeconds'] == 20 for case in fixture['cases'])
        html = (app / 'war/circuitjs.html').read_text(encoding='utf-8')
        js = (app / 'war/circuitjs1' / canary.SCRIPT_NAME).read_text(encoding='utf-8')
        frame = (app / 'war/frame.html').read_text(encoding='utf-8')
        assert '/frame.html?attachmentCanary=iframe' in html
        assert 'mode=duplicate&request=2' in html
        assert 'mode === "iframe" ? parent.document : document' in js
        assert 'document.open();' in js and 'document.close();' in js
        assert 'parent.document.documentElement.setAttribute' in frame
        assert not output.exists(), 'preparation unexpectedly created host output'
        prior_replacement = []
        for name, expected in (
                ('q30-selected-transport-5ca6fd878a65455e8996d82681fe8aed', 'a895d139fb920bf8916113c8c6e6082dfe4a95c076818c9e7acf05c7a6bf0e69'),
                ('q30-selected-transport-cc1ff24644bc4e2a89381c39e0017530', 'd5b8b285e38e125c43b71f80d594b8d21fd2ec0b60587a093982f5c9e9cfb526')):
            case_path = Path(tempfile.gettempdir()) / name / 'host/cases/018-stale-same-url.json'
            assert sha(case_path) == expected
            case = json.loads(case_path.read_text(encoding='utf-8-sig'))
            scope = case['observation']['scopeIdentity']
            assert (scope['documentBackendBefore'], scope['documentBackendAfter']) == (57, 57)
            assert (scope['htmlBackendBefore'], scope['htmlBackendAfter']) == (59, 60)
            assert scope['pageUrlMatches'] is True and scope['documentUrlMatches'] is True
            prior_replacement.append({'casePath': str(case_path), 'sha256': expected,
                                      'document': [57, 57], 'html': [59, 60],
                                      'scope': 'HISTORICAL_EDGE_REPLACEMENT_ONLY'})
        argv = [str(PYTHON), '-B', '-u', str(helper), '--host-path', str(host_path),
                '--expected-host-sha256', host_hash, '--final-packet', str(PACKET),
                '--final-manifest', str(MANIFEST), '--prior-failed-result', str(PRIOR)]
        plan = {'schema': 1, 'status': 'PREPARED_NOT_RUN_REQUIRES_PARENT_WINDOW',
                'windowSeconds': 240, 'outerTimeoutMs': 120000, 'cleanupBudgetMs': 15000,
                'reserveSeconds': 105, 'cases': list(canary.CASE_NAMES), 'argv': argv,
                'runnerPath': str(REPO / 'docs/task-evidence/Q30/qualification-workflow/serial_runner.py'),
                'runnerSha256': '19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6',
                'requiredEnvironment': {'PYTHONPATH': str(DEPS), 'PYTHONDONTWRITEBYTECODE': '1',
                                        'PYTHONIOENCODING': 'utf-8'},
                'guardSha256': host_hash, 'canarySha256': sha(helper),
                'expected': 'CANARY_PASS_ONLY_WHEN_ATTACHED_PASS_AND_FOUR_SPECIFIC_NEGATIVES_AND_CLEANUP_PASS',
                'qualification': False, 'timingAcceptance': False, 'browserVisibleQa': False,
                'coordinateBeforeRun': True, 'autoRun': False}
        write(root / 'quiet-window-plan.json', plan)
        report.update(status='PASS_PREPARATION_ONLY', runtime=runtime,
                      selectedGuardSha256=host_hash, selectedCanarySha256=sha(helper),
                      retainedFinal={key: retained_final[key] for key in ('caseCount', 'matchingAttachments', 'cleanupStatus')},
                      retainedFailure={key: retained_failed[key] for key in ('overallOutcome', 'cleanupStatus', 'matchingAttachments')},
                      historicalReplacement=prior_replacement, fixturePreparedFiveCases=True,
                      actualEdge='NOT_RUN', q30='NOT_RUN',
                      fixtureFiles=[{'path': str(path.relative_to(root)), 'sha256': sha(path)}
                                    for path in sorted(app.rglob('*')) if path.is_file()],
                      quietWindowPlan=str(root / 'quiet-window-plan.json'))
    except Exception as error:
        report.update(errorType=type(error).__name__, error=str(error))
    finally:
        report['finishedUtc'] = datetime.now(timezone.utc).isoformat()
        write(root / 'preparation-result.json', report)
        print(json.dumps({'taskRoot': str(root), **report}, indent=2))
    return 0 if report['status'] == 'PASS_PREPARATION_ONLY' else 1


if __name__ == '__main__':
    raise SystemExit(main())
