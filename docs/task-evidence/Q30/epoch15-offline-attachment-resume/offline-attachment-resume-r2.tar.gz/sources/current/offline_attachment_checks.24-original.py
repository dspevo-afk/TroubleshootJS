"""Offline guard/receipt checks. Synthetic CDP and receipts are not Edge proof."""
import argparse
import asyncio
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import time
import types
import unittest


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def receipt(canary):
    rows = []
    for index, name in enumerate(canary.CASE_NAMES, 1):
        attached, missing = index == 1, index == 2
        doc, html = (101, 201) if index != 3 else (102, 202)
        attachment = None if missing else {
            'resourceType': 'script', 'exactPageUrl': True,
            'documentBackend': 101, 'htmlBackend': 201,
        }
        rows.append({
            'case': {'index': index, 'name': name},
            'outcome': 'PASS' if attached else 'FAIL',
            'terminalReached': True, 'stateMatch': attached, 'timedOut': False,
            'operationSeconds': 0.1,
            'observerErrors': [] if attached else [{
                'phase': 'terminal-document-scope', 'type': 'ValueError',
                'message': 'Terminal state/report lacks its exact compiled-script HTML attachment',
            }],
            'observation': {
                'transport': 'PASSIVE_CDP_DOM', 'compiledScriptsHeld': 0 if missing else 1,
                'scriptAttachment': attachment, 'terminalScopeVerified': attached,
                'scopeIdentity': {
                    'scriptAttachmentMatchesTerminalScope': attached,
                    'documentBackendAfter': doc, 'htmlBackendAfter': html,
                    'pageUrlMatches': True, 'documentUrlMatches': True,
                    'stateMatches': True, 'attributeMatches': True,
                },
            },
        })
    return {
        'caseCount': 3, 'cases': rows, 'errors': [], 'outcome': 'FAIL',
        'inputAudit': {'status': 'PASS'},
        'cleanup': {'status': 'PASS', 'serverStopped': True,
                    'ownedSurvivors': [], 'errors': [], 'seconds': 0.01},
        'identity': {'edgeProcessesBeforeCases': [
            {'ExecutablePath': 'synthetic/msedge.exe', 'pid': 123,
             'created': 'synthetic-only-never-launched'},
        ]},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--canary', type=Path, required=True)
    parser.add_argument('--guard', type=Path, required=True)
    args = parser.parse_args()
    canary, guard = load('offline_canary', args.canary), load('offline_guard', args.guard)
    root = Path(tempfile.mkdtemp(prefix='q30-offline-attachment-checks-'))
    output = root / 'synthetic-host-output'
    (output / 'cases').mkdir(parents=True)
    source_before = {str(path): digest(path) for path in (args.canary, args.guard, Path(__file__))}

    def check(value):
        for row in value['cases']:
            item = row['case']
            path = output / 'cases' / ('%03d-%s.json' % (item['index'], item['name']))
            path.write_text(json.dumps(row), encoding='utf-8')
        (output / 'result.json').write_text(json.dumps(value), encoding='utf-8')
        return canary.validate_canary_output(output, 1)

    class ReceiptChecks(unittest.TestCase):
        def test_valid_detached_document_and_html(self):
            check(receipt(canary))

        def test_valid_detached_html_with_preserved_document(self):
            value = receipt(canary)
            value['cases'][2]['observation']['scopeIdentity']['documentBackendAfter'] = 101
            check(value)

        def test_valid_detached_document_with_preserved_html(self):
            value = receipt(canary)
            value['cases'][2]['observation']['scopeIdentity']['htmlBackendAfter'] = 201
            check(value)

        def reject(self, mutate):
            value = receipt(canary)
            mutate(value)
            with self.assertRaises(ValueError):
                check(value)

        def test_reject_unchanged_detached_identity(self):
            def mutate(value):
                value['cases'][2]['observation']['scopeIdentity'].update(
                    documentBackendAfter=101, htmlBackendAfter=201)
            self.reject(mutate)

        def test_reject_positive_missing_attachment(self):
            self.reject(lambda v: v['cases'][0]['observation'].update(scriptAttachment=None))

        def test_reject_positive_duplicate_script(self):
            self.reject(lambda v: v['cases'][0]['observation'].update(compiledScriptsHeld=2))

        def test_reject_positive_wrong_html(self):
            self.reject(lambda v: v['cases'][0]['observation']['scriptAttachment'].update(htmlBackend=999))

        def test_reject_negative_wrong_url(self):
            self.reject(lambda v: v['cases'][2]['observation']['scopeIdentity'].update(pageUrlMatches=False))

        def test_reject_extra_observer_error(self):
            self.reject(lambda v: v['cases'][1]['observerErrors'].append({'phase': 'other'}))

        def test_reject_negative_timeout(self):
            self.reject(lambda v: v['cases'][1].update(timedOut=True))

        def test_reject_positive_timeout(self):
            self.reject(lambda v: v['cases'][0].update(timedOut=True))

        def test_reject_wrong_transport(self):
            self.reject(lambda v: v['cases'][0]['observation'].update(transport='OTHER'))

        def test_reject_cleanup_failure(self):
            self.reject(lambda v: v['cleanup'].update(status='FAIL'))

        def test_reject_mutated_input_audit(self):
            self.reject(lambda v: v['inputAudit'].update(status='FAIL'))

        def test_reject_non_integer_terminal_backend(self):
            self.reject(lambda v: v['cases'][2]['observation']['scopeIdentity'].update(htmlBackendAfter=True))

        def test_reject_unrecorded_edge_identity(self):
            self.reject(lambda v: v['identity'].update(edgeProcessesBeforeCases=[]))

    class ScopeChecks(unittest.TestCase):
        def verify(self, script_count=1, attachment=None, current=(101, 201)):
            url, state = 'http://127.0.0.1:1/circuitjs.html', 'PASS:synthetic'
            document = {'nodeId': 11, 'backendNodeId': current[0], 'documentURL': url,
                        'children': [{'nodeId': 21, 'backendNodeId': current[1], 'nodeName': 'HTML',
                                      'attributes': ['data-tsj-synthetic', state]}]}
            class Session:
                async def send(self, method, payload):
                    if method != 'DOM.getDocument':
                        raise AssertionError(method)
                    return copy.deepcopy({'root': document})
            errors = []
            observer = guard.HtmlAttributeObserver(types.SimpleNamespace(url=url), url,
                          'data-tsj-synthetic', time.monotonic() + 2, errors)
            observer.session = Session()
            observer.document_id, observer.html_id = 11, 21
            observer.document_backend, observer.html_backend = current
            observer.state = state
            observer.script_requests = script_count
            observer.script_attachment = attachment
            asyncio.run(observer.verify_terminal_scope(0, current[0], current[1], state, 0))
            return observer.terminal_verified, errors

        def attachment(self, **changes):
            value = {'documentBackend': 101, 'htmlBackend': 201,
                     'exactPageUrl': True, 'resourceType': 'script'}
            value.update(changes)
            return value

        def test_accept_exact_attachment(self):
            self.assertEqual(self.verify(attachment=self.attachment()), (True, []))

        def reject(self, **args):
            verified, errors = self.verify(**args)
            self.assertFalse(verified)
            self.assertEqual([e['phase'] for e in errors], ['terminal-document-scope'])

        def test_reject_absent_script(self):
            self.reject(script_count=0)

        def test_reject_duplicate_script(self):
            self.reject(script_count=2, attachment=self.attachment())

        def test_reject_html_replacement(self):
            self.reject(attachment=self.attachment(), current=(101, 202))

        def test_reject_document_replacement(self):
            self.reject(attachment=self.attachment(), current=(102, 201))

        def test_reject_both_replaced(self):
            self.reject(attachment=self.attachment(), current=(102, 202))

        def test_reject_wrong_url_attachment(self):
            self.reject(attachment=self.attachment(exactPageUrl=False))

        def test_reject_wrong_resource_type(self):
            self.reject(attachment=self.attachment(resourceType='document'))

    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (ReceiptChecks, ScopeChecks)])
    started = time.monotonic()
    with (root / 'unittest.log').open('x', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    operation = time.monotonic() - started
    source_after = {str(path): digest(path) for path in (args.canary, args.guard, Path(__file__))}
    report = {'schema': 1, 'status': 'PASS' if result.wasSuccessful() else 'FAIL',
              'scope': 'OFFLINE_SYNTHETIC_ONLY_NO_EDGE_OR_Q30', 'tests': result.testsRun,
              'failures': [test.id() for test, _ in result.failures],
              'errors': [test.id() for test, _ in result.errors], 'skips': len(result.skipped),
              'operationSeconds': operation, 'sourceBefore': source_before,
              'sourcesUnchanged': source_before == source_after,
              'finishedUtc': datetime.now(timezone.utc).isoformat()}
    if not report['sourcesUnchanged']:
        report['status'] = 'FAIL'
    write(root / 'result.json', report)
    print(json.dumps({'taskRoot': str(root), **report}, indent=2))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
