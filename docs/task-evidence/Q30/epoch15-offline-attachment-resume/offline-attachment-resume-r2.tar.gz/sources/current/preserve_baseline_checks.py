"""Recover the exact initial 24-check source from the narrow recorded edits."""
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
source = (HERE / 'offline_attachment_checks.py').read_text(encoding='utf-8')
original_receipt = '''def receipt(canary):
    rows = []
    for index, name in enumerate(canary.CASE_NAMES, 1):
        attached, missing = index == 1, index == 2
        doc, html = (101, 201) if index != 3 else (102, 202)
        attachment = None if missing else {
            'resourceType': 'script', 'exactPageUrl': True,
            'documentBackend': 101, 'htmlBackend': 201,
        }
        rows.append({
            'case': {'index': index, 'name': name},
            'outcome': 'PASS' if attached else 'FAIL',
            'terminalReached': True, 'stateMatch': attached, 'timedOut': False,
            'operationSeconds': 0.1,
            'observerErrors': [] if attached else [{
                'phase': 'terminal-document-scope', 'type': 'ValueError',
                'message': 'Terminal state/report lacks its exact compiled-script HTML attachment',
            }],
            'observation': {
                'transport': 'PASSIVE_CDP_DOM', 'compiledScriptsHeld': 0 if missing else 1,
                'scriptAttachment': attachment, 'terminalScopeVerified': attached,
                'scopeIdentity': {
                    'scriptAttachmentMatchesTerminalScope': attached,
                    'documentBackendAfter': doc, 'htmlBackendAfter': html,
                    'pageUrlMatches': True, 'documentUrlMatches': True,
                    'stateMatches': True, 'attributeMatches': True,
                },
            },
        })
    return {
        'caseCount': 3, 'cases': rows, 'errors': [], 'outcome': 'FAIL',
        'inputAudit': {'status': 'PASS'},
        'cleanup': {'status': 'PASS', 'serverStopped': True,
                    'ownedSurvivors': [], 'errors': [], 'seconds': 0.01},
        'identity': {'edgeProcessesBeforeCases': [
            {'ExecutablePath': 'synthetic/msedge.exe', 'pid': 123,
             'created': 'synthetic-only-never-launched'},
        ]},
    }
'''
start, finish = source.index('def receipt(canary):'), source.index('\n\n\ndef main():')
source = source[:start] + original_receipt.rstrip('\n') + source[finish:]
start, finish = source.index('\n        def test_reject_wrong_negative_state'), source.index('\n    class ScopeChecks')
source = source[:start] + source[finish:]
source = source.replace('current=(101, 201), current_generation=0', 'current=(101, 201)')
source = source.replace('            observer.version = current_generation\n', '')
source = source.replace("'exactPageUrl': True, 'resourceType': 'script',\n                     'generation': 0, 'mainFrameRequest': True}",
                        "'exactPageUrl': True, 'resourceType': 'script'}")
start, finish = source.index('\n        def test_reject_wrong_frame_provenance'), source.index('\n    suite =')
source = source[:start] + source[finish:]
source = source.replace('(ReceiptChecks, ScopeChecks, RouteChecks)', '(ReceiptChecks, ScopeChecks)')
raw = source.encode('utf-8')
expected = '14d028d59489e895a02b0b32eef11307ad275072c0e7a6aa8019176a93bd6016'
assert hashlib.sha256(raw).hexdigest() == expected, 'Recovered bytes differ; do not bless the source'
with (HERE / 'offline_attachment_checks.24-original.py').open('xb') as stream:
    stream.write(raw)
print('Recovered original24 source with independently recorded exact SHA256 ' + expected)
