"""Preserve the failed export, then build a separate corrected portable candidate."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

HERE = Path(__file__).resolve().parent
REPO = Path(r'<user>/.codex\worktrees\q30-multirail-qualification\TroubleshootJS')
TARGET = REPO / 'docs/task-evidence/Q30/epoch15-offline-attachment-resume'
FAILED = HERE / 'failed-export'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def clean(raw):
    text = raw.decode('utf-8-sig')
    return re.sub(r'(?i)C:[/\\]+Users[/\\]+david[/\\]+', '<user>/', text).encode('utf-8')


def main():
    manifest = json.loads((FAILED / 'manifest.json').read_text(encoding='utf-8'))
    original = FAILED / manifest['archiveName']
    assert sha(original.read_bytes()) == '038c447339ab9c5fdd31ce22687895798d352bac60a964cda994edd107eecec7'
    rows = {}
    inventory = {item['member']: dict(item) for item in manifest['files']}
    with tarfile.open(original, 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name in inventory
            raw = archive.extractfile(member).read()
            assert sha(raw) == inventory[member.name]['portableSha256']
            rows[member.name] = clean(raw)
    failure = {'schema': 1, 'status': 'FAIL_INITIAL_PORTABLE_EXPORT_PRIVACY_AUDIT',
               'operation': 'No-extraction archive member privacy check',
               'elapsed': 'NOT_RECORDED', 'auditProcessExitCode': 1,
               'failedMember': 'sources/current/package_checkpoint.py', 'personalPrefixCount': 1,
               'originalArchiveSha256': manifest['archiveSha256'],
               'preserved': 'Workspace failed-export original archive/manifest/pointer; nothing deleted',
               'correction': 'Match all escaped/ordinary case-insensitive personal path-prefix variants',
               'correctedAudit': 'PENDING_SEPARATE_AUDIT',
               'recordedUtc': datetime.now(timezone.utc).isoformat()}
    new_raw = {
        'review/export-failure.json': (json.dumps(failure, indent=2) + '\n').encode('utf-8'),
        'sources/current/rebuild_portable_packet.py': Path(__file__).read_bytes(),
    }
    for name, raw in new_raw.items():
        assert name not in rows
        rows[name] = clean(raw)
        inventory[name] = {'member': name, 'rawBytes': len(raw), 'rawSha256': sha(raw)}
    for name, data in rows.items():
        inventory[name].update(portableBytes=len(data), portableSha256=sha(data))
    archive_path = TARGET / 'offline-attachment-resume-r2.tar.gz'
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            for name in sorted(rows):
                data = rows[name]
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o600, 0
                archive.addfile(member, io.BytesIO(data))
    manifest.update(archiveName=archive_path.name, archiveBytes=archive_path.stat().st_size,
                    archiveSha256=sha(archive_path.read_bytes()), memberCount=len(rows),
                    files=[inventory[name] for name in sorted(rows)],
                    exportFailureRetained=failure)
    manifest['sources'].append({'name': Path(__file__).name, 'rawSha256': sha(Path(__file__).read_bytes())})
    (TARGET / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    readme_path = TARGET / 'README.md'
    readme = readme_path.read_text(encoding='utf-8').replace('offline-attachment-resume.tar.gz', archive_path.name)
    readme += '\nInitial portable-export privacy audit FAIL: one escaped personal path prefix\nremained in the packager source. The exact original archive/manifest/pointer\nare preserved in workspace `failed-export/`; none were deleted. A separate\ncorrected archive includes the failure receipt and awaits its own audit.\n'
    readme_path.write_text(readme, encoding='utf-8', newline='\n')
    changed_path = TARGET / 'changed-files.txt'
    changed_path.write_text(changed_path.read_text(encoding='utf-8').replace(
        'offline-attachment-resume.tar.gz', archive_path.name), encoding='utf-8', newline='\n')
    report_path = REPO / 'docs/CODEX_TASK_REPORT.md'
    report = report_path.read_text(encoding='utf-8')
    marker = 'Root75 offline owner review establishes no concrete timing cause.\n'
    assert report.count(marker) == 1
    report_path.write_text(report.replace(marker, marker +
        'Initial portable export privacy audit FAIL retained; corrected candidate\nrequires its separate packet audit before commit.\n', 1), encoding='utf-8', newline='\n')
    pointer = {'schema': 1, 'status': 'CORRECTED_PACKET_PENDING_AUDIT',
               'archiveName': archive_path.name, 'archiveSha256': manifest['archiveSha256'],
               'archiveBytes': manifest['archiveBytes'], 'members': len(rows),
               'originalArchivePreservedSha256': failure['originalArchiveSha256'],
               'guardSha256': manifest['guardSha256'], 'helperSha256': manifest['helperSha256']}
    with (HERE / 'checkpoint-revised-pointer.json').open('x', encoding='utf-8') as stream:
        json.dump(pointer, stream, indent=2)
        stream.write('\n')
    print(json.dumps(pointer, indent=2))


if __name__ == '__main__':
    main()
