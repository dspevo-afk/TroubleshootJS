"""Write the authorized docs-only checkpoint; preserve existing evidence and inputs."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
REPO = Path(r'<user>/.codex\worktrees\q30-multirail-qualification\TroubleshootJS')
BASE = '7015495007e3cffbf262afbd58410a4929a4945a'
PREFIX = 'docs/task-evidence/Q30/epoch15-offline-attachment-resume'
TARGET = REPO / PREFIX
RUNS = (
    'q30-attachment-offline-before-uj_5h0cz',
    'q30-attachment-offline-after-levozpe8',
    'q30-attachment-offline-final-1myki45p',
    'q30-attachment-offline-preparation-5mtlqh_d',
    'q30-attachment-offline-frozen-e2d7f1ji',
    'q30-attachment-offline-final-preparation-2bqa_9fr',
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def git(*args):
    return subprocess.check_output(['git', '-c', 'safe.directory=' + REPO.as_posix(),
                                   '-C', str(REPO), *args], text=True).strip()


def portable(raw):
    text = raw.decode('utf-8-sig')
    for prefix in ('<user>/', '<user>/', '<user>/'):
        text = text.replace(prefix, '<user>/')
    return text.encode('utf-8')


def write(path, text):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)


def main():
    assert git('rev-parse', 'HEAD') == BASE
    assert git('branch', '--show-current') == 'codex/q30-multirail-qualification'
    assert not git('diff', '--name-only') and not git('diff', '--cached', '--name-only')
    assert not TARGET.exists(), 'Refuse evidence overwrite'
    sources = []
    inventory = []
    rows = {}
    temp = Path(tempfile.gettempdir())

    def add(name, path):
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts and name not in rows
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        data = portable(raw)
        rows[name] = data
        inventory.append({'member': name, 'rawBytes': len(raw), 'rawSha256': sha(raw),
                          'portableBytes': len(data), 'portableSha256': sha(data)})

    final_test = final_preparation = None
    for name in RUNS:
        root = temp / name
        for filename in ('launch.json', 'launcher-result.json', 'stdout.log', 'stderr.log'):
            add('raw/' + name + '/' + filename, root / filename)
        launch = read(root / 'launcher-result.json')
        assert launch['operation']['cleanup']['cleanupVerified']
        assert launch['operation']['cleanup']['jobActiveProcesses'] == 0
        assert all(not item['readerAlive'] and item['streamClosed'] for item in launch['logs'])
        child_output = json.loads((root / 'stdout.log').read_text(encoding='utf-8-sig'))
        child_root = Path(child_output['taskRoot'])
        if 'tests' in child_output:
            for filename in ('result.json', 'unittest.log'):
                add('raw/' + child_root.name + '/' + filename, child_root / filename)
        else:
            for filename in ('preparation-result.json', 'quiet-window-plan.json', 'canary-spec.json'):
                add('raw/' + child_root.name + '/' + filename, child_root / filename)
            for path in sorted((child_root / 'fixture').rglob('*')):
                if path.is_file():
                    add('raw/' + child_root.name + '/' + path.relative_to(child_root).as_posix(), path)
        if name == RUNS[-2]:
            final_test = child_output
        if name == RUNS[-1]:
            final_preparation = child_output
    assert final_test['status'] == 'PASS' and final_test['tests'] == 38
    assert not final_test['failures'] and not final_test['errors'] and final_test['skips'] == 0
    assert final_preparation['status'] == 'PASS_PREPARATION_ONLY'
    assert final_preparation['frozenInputsVerified'] == 1354
    for filename in ('compiled_attribute_acceptance.py', 'run_attachment_scope_canaries.py',
                     'offline_attachment_checks.py', 'offline_attachment_checks.24-original.py',
                     'prepare_offline_checkpoint.py', 'preserve_baseline_checks.py', 'package_checkpoint.py'):
        path = HERE / filename
        add('sources/current/' + filename, path)
        sources.append({'name': filename, 'rawSha256': sha(path.read_bytes())})
    for filename in ('compiled_attribute_acceptance.py', 'run_attachment_scope_canaries.py'):
        add('sources/original-draft/' + filename, HERE.parent / 'review-fixes' / filename)
    for filename in ('checkpoint_notes.json', 'resource-review.json', 'resource-final-review.json'):
        add('review/' + filename, HERE / filename)
    for name in ('q30-selected-transport-5ca6fd878a65455e8996d82681fe8aed',
                 'q30-selected-transport-cc1ff24644bc4e2a89381c39e0017530'):
        for filename in ('cases/018-stale-same-url.json', 'runner-before.json', 'runner-after.json'):
            add('historical/' + name + '/' + filename, temp / name / 'host' / filename)

    guard_hash = sha((HERE / 'compiled_attribute_acceptance.py').read_bytes())
    helper_hash = sha((HERE / 'run_attachment_scope_canaries.py').read_bytes())
    assert guard_hash == final_preparation['selectedGuardSha256']
    assert helper_hash == final_preparation['selectedCanarySha256']
    for path, expected in final_test['sourceBefore'].items():
        assert sha(Path(path).read_bytes()) == expected
    TARGET.mkdir()
    archive_path = TARGET / 'offline-attachment-resume.tar.gz'
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            for name in sorted(rows):
                data = rows[name]
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o600, 0
                archive.addfile(member, io.BytesIO(data))
    manifest = {'schema': 1, 'status': 'OFFLINE_PREPARATION_ONLY_Q30_BLOCKED',
                'baseHead': BASE, 'sourceIdentity': final_preparation['sourceIdentity'],
                'frozenInputsVerified': 1354, 'guardIntegrated': False,
                'actualEdge': 'NOT_RUN', 'q30ApplicationsLaunched': 0, 'timingAcceptance': False,
                'guardSha256': guard_hash, 'helperSha256': helper_hash,
                'finalTests': 38, 'finalTestOperationSeconds': final_test['operationSeconds'],
                'outerFinalOperationMs': 268, 'outerFinalCleanupMs': 0,
                'cleanupClockLimit': '0ms recorded at observed resolution; does not prove zero cost',
                'archiveName': archive_path.name, 'archiveBytes': archive_path.stat().st_size,
                'archiveSha256': sha(archive_path.read_bytes()), 'memberCount': len(rows),
                'sources': sources, 'files': sorted(inventory, key=lambda item: item['member']),
                'createdUtc': datetime.now(timezone.utc).isoformat(),
                'resourceScope': 'Six exact offline child PIDs absent; all six owned jobs/readers cleaned',
                'quietWindowSecondsNeeded': 240, 'parentWindow': 'NOT_GRANTED',
                'authoritativeCold': '31PASS/1TIMEOUT90.221s/45NOT_RUN; unchanged90s/640/5s',
                'pushEmailDelete': 'NOT_RUN_USER_DISABLED'}
    write(TARGET / 'manifest.json', json.dumps(manifest, indent=2) + '\n')
    readme = '''# Q30 offline attachment continuation

This is an offline checkpoint from parent HEAD `7015495007e3cffbf262afbd58410a4929a4945a`.
Q30 remains **NOT ACCEPTED and disabled**. Full cold77 stays FAIL:31 PASS,
root75 TIMEOUT90.221s,45 NOT_RUN. Original77 roots/308 candidates/90s/640/5s
are unchanged. U06/U07/Q60 stay unstarted. No Edge/Q30 cases, broad tests,
timing benchmarks, build, server/model changes, push, email or evidence deletion.
Local Dots retains priority.

The original24 offline checks retained four failures and two errors: the
detached oracle rejected a change in only one backend ID, and inconsistent
timeout/transport/backend-type receipts were accepted. The initial source is
preserved byte-for-byte at its recorded hash; its reconstructed copy was checked
against that independently recorded hash. The corrected24 checks passed.
The extended final38 checks PASS with no failures/errors/skips, operation0.108s,
outer operation0.268s and cleanup0ms at recorded resolution. These use synthetic
CDP/receipt fixtures; they do not prove Edge, electrical behavior or timing.
Intermediate results remain in the packet. Final source pins are authoritative.

Two retained actual Edge replacement receipts were independently rehashed:
document backend57->57, HTML59->60, with matching URLs. This supports the
detached oracle's requirement that either identity changes. Historical receipts
prove that replacement behavior only, not the new draft's Edge behavior.

Independent read-only review found that an iframe request could be recorded
against the main document, and recorded generations were unused. The new
**workspace guard draft** now requires a main-frame request, records provenance,
and matches attachment/terminal/current generation plus both backend identities.
Route-error receipts retain a bounded diagnostic state read and actual page URL;
they remain FAIL. Terminal verification skips an already failed observer path.
The draft stays outside repository runtime/source inputs until actual canaries pass.

Five tiny HTML canaries are prepared: attached positive, absent script,
same-URL replacement, iframe-only request and duplicate request. The iframe's
fake script handles its mode without throwing if the guard is absent. Oracles
require exact actual state/URL, declared attachment errors and owned cleanup;
controlled route-abort console diagnostics are allowed only at the exact target
script URL and are retained. No unrelated errors are suppressed.

Preparation PASS: selected CPython3.13.14/Playwright1.63.0/greenlet3.5.6 imports,
Python ASTs, generated five-case files, all1,354 frozen consumed source hashes,
and118 final compiled31 packet members. Retained31 matching attachments/cleanup
PASS remain historical; the earlier31 matching attachments/FAIL_CLEANUP remains FAIL.
Repository host/app/build bytes are unchanged. No Java/GWT/full native gates reran.

Independent review covered source/fixtures, not live Edge. Actual Playwright
frame-wrapper identity, abort-console location and all five Edge cases are
NOT_RUN. The primary next window is **four minutes** for one owned Edge job:
120s outer operation,15s shared cleanup budget,105s reserve. The raw
`quiet-window-plan.json` has exact argv/environment/source pins and is not
auto-run or authorization. Coordinate with parent before launch.

Root75 source review established no cause. HEALTHY groups placement/routing,
construction and CircuitJS install/settling; HYPOTHESES is serial replay/settling/
observation/repair/retest. The failure is a truncated work prefix. A separate
seven-minute quiet diagnostic window and combined-sampler canaries remain later
prerequisites; renderer stacks/GC tracing would need its own diagnostic scope.
Cold77, enabled build/menu/replay, supported visible repair/retest and parent
acceptance review still block qualification. No timing acceptance under concurrent work.

Six exact offline child PIDs were checked absent, with job0/readers complete in
their receipts. No uncertain resources were terminated. Same four pre-existing
cache directories/seven files and sibling Desktop work are preserved.
The [archive](offline-attachment-resume.tar.gz) records raw/portable hashes in its
[manifest](manifest.json); portable copies replace personal path prefixes only.
Raw task-owned temp roots and workspace `epoch15-final/attachment-offline-resume/`
remain authoritative and restartable. Nothing was removed.
'''
    write(TARGET / 'README.md', readme)
    current = '''# Current checkpoint: Q30 blocked; offline attachment guard/canaries prepared

2026-10-03. Branch `codex/q30-multirail-qualification`; parent local HEAD
`7015495007e3cffbf262afbd58410a4929a4945a`, plus docs/evidence below.
Q30 NOT ACCEPTED and disabled. Cold77 remains31 PASS/1 TIMEOUT90.221s/45 NOT_RUN;
original77/308/90s/640/5s unchanged. U06/U07/Q60 unstarted. No push/email/deletion.
Local Dots retains priority; this continuation launched no Edge/Q30, broad tests,
timing benchmarks, build, server or model changes.

[Offline evidence](task-evidence/Q30/epoch15-offline-attachment-resume/README.md):
original24 synthetic checks retained four failures/two errors; corrected24 PASS.
Final38 PASS0.108s, outer0.268s/cleanup0ms at recorded resolution/job0/readers
complete. These are offline identity/receipt checks, not actual Edge/solver/timing.
Two hashed historical Edge receipts support replacing the detached oracle's
both-identities-change condition with either-identity-change.

Read-only review found an iframe/main-frame provenance gap and unused generation
binding. Corrected guard and five-case canary oracle remain **workspace drafts**;
the repository host/app/build is untouched. Actual Edge attached/absent/detached/
iframe/duplicate and cleanup gates NOT_RUN. Preparation PASS: selected pinned
runtime imports/ASTs/fixtures,1,354 frozen source inputs,118 final31 packet members;
historical final31 attachments/cleanup PASS and earlier FAIL_CLEANUP preserved.
Root75 offline owner review establishes no concrete timing cause.

Six exact offline child PIDs absent; all owned jobs/readers cleaned. Raw roots/
exact command plan live in workspace `epoch15-final/attachment-offline-resume/`.
Four original cache directories/seven files and sibling Desktop work preserved.
Next: parent-coordinate four minutes for one120s Edge canary job plus15s cleanup
and105s reserve. No granted window or auto-run. Later separate seven-minute
root75 diagnostic/combined-sampler gate, full cold77, enabled build/menu/replay,
supported visible repair/retest and parent acceptance review remain required.

---

'''
    report_path = REPO / 'docs/CODEX_TASK_REPORT.md'
    old = report_path.read_text(encoding='utf-8')
    assert old.startswith('# Current checkpoint: Q30 blocked; tested cleanup correction')
    old = old.replace('# Current checkpoint:', '# Historical checkpoint:', 1)
    report_path.write_text(current + old, encoding='utf-8', newline='\n')
    roadmap_path = REPO / 'docs/ROADMAP.md'
    old = roadmap_path.read_text(encoding='utf-8')
    marker = '**Q30 checkpoint (2026-10-02):**'
    assert old.count(marker) == 1
    extra = '''**Q30 offline continuation (2026-10-03):** No Edge/Q30 runs or timing benchmarks;
Local Dots retains priority. Final38 offline identity/receipt checks PASS;
new guard checks main-frame provenance and generations, and five canaries are
prepared. Guard/oracle remain workspace drafts; actual Edge NOT_RUN.
All1,354 frozen app/host inputs remain unchanged; old cold FAIL is preserved.
Next requested window: four minutes, one120s canary job/15s cleanup/105s reserve.
Root75 cause remains UNKNOWN; separate quiet diagnostics and all acceptance gates
remain pending. [Evidence](task-evidence/Q30/epoch15-offline-attachment-resume/README.md).
'''
    roadmap_path.write_text(old.replace(marker, extra + marker, 1), encoding='utf-8', newline='\n')
    changed = ['docs/CODEX_TASK_REPORT.md', 'docs/ROADMAP.md'] + [PREFIX + '/' + name for name in (
        'README.md', 'changed-files.txt', 'manifest.json', 'offline-attachment-resume.tar.gz', 'packet-audit.json')]
    write(TARGET / 'changed-files.txt', '\n'.join(changed) + '\n')
    pointer = {'schema': 1, 'status': 'DOCS_WRITTEN_PENDING_AUDIT_COMMIT', 'baseHead': BASE,
               'evidencePath': PREFIX, 'archiveSha256': manifest['archiveSha256'],
               'archiveBytes': manifest['archiveBytes'], 'members': len(rows), 'changedFiles': changed,
               'guardSha256': guard_hash, 'helperSha256': helper_hash,
               'finalPreparationRoot': str(Path(final_preparation['taskRoot'])),
               'actualEdge': 'NOT_RUN', 'quietWindowSeconds': 240}
    write(HERE / 'checkpoint-pointer.json', json.dumps(pointer, indent=2) + '\n')
    print(json.dumps(pointer, indent=2))


if __name__ == '__main__':
    main()
