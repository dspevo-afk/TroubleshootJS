"""Tiny actual Windows CPU-counter positive/negative canary; not Q30 evidence."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
import uuid

import serial_runner
from receipts import write_exclusive
import windows_cpu_sampler as counters


def main():
    work=Path(__file__).resolve().parent
    hashes={name:hashlib.sha256((work/name).read_bytes()).hexdigest()
            for name in ('serial_runner.py','windows_cpu_sampler.py',Path(__file__).name)}
    root=Path(tempfile.gettempdir())/('q30-cpu-counter-canary-'+uuid.uuid4().hex)
    root.mkdir(exist_ok=False)
    k=counters.api(); child=None; sampler=None; sampled=None; started=time.monotonic()
    proof={'schema':1,'status':'FAIL','qualification':False,'sourceHashes':hashes,'errors':[]}
    try:
        # Bounded0.15s CPU pulse and0.20s wait; one task-owned process only.
        code='import time\ntime.sleep(.20)\nt=time.perf_counter()+.15\nwhile time.perf_counter()<t: pass\n'
        exe=Path(sys.executable).resolve(strict=True)
        child=serial_runner._spawn(k,{'executable':exe},[str(exe),'-B','-c',code],root)
        proof['process']={'pid':child['pid'],'creationFileTimeTicks':child['creationTicks'],
                          'executable':child['image'],'commandSha256':child['commandSha256']}
        write_exclusive(root/'launch.json',{**proof,'status':'RUNNING'})
        sampler=counters.Sampler(k,child['job'],period_seconds=.05,maximum_samples=100)
        sampler.start()
        waited=serial_runner._wait(k,child,2000)
        sampled=sampler.stop(); sampler=None
        proof['operation']=waited
        proof['sampling']=sampled
        assert waited['reason'] is None and waited['exitCode']==0 and waited['cleanup']['cleanupVerified']
        assert sampled['status']=='PASS' and len(sampled['samples'])>=3
        assert sampled['samples'][-1]['job']['activeProcesses']==0
        assert sampled['samples'][-1]['job']['userTicks']+sampled['samples'][-1]['job']['kernelTicks']>0
        try:
            counters.job_counters(k,0)
            raise AssertionError('missing job accepted')
        except counters.CounterError:
            proof['missingJobNegative']='PASS'
        try:
            counters.job_counters(k,-1)
            raise AssertionError('invalid native job accepted')
        except OSError:
            proof['invalidNativeJobNegative']='PASS'
        previous=sampled['samples'][0]
        changed={'system':{**previous['system'],'userTicks':previous['system']['userTicks']-1},
                 'job':previous['job'],'monotonicNs':previous['monotonicNs']+1}
        try:
            counters.interval(previous,changed)
            raise AssertionError('backward counter accepted')
        except counters.CounterError:
            proof['backwardCounterNegative']='PASS'
        assert all(hashlib.sha256((work/name).read_bytes()).hexdigest()==digest for name,digest in hashes.items())
        proof['sourceInputsUnchanged']=True;proof['status']='PASS'
    except Exception as error:
        proof['errors'].append(type(error).__name__+': '+str(error))
    finally:
        if sampler is not None: proof['sampling']=sampler.stop()
        if child:
            if child['job']:
                child['job'],clean=serial_runner._stop(k,child['job'],child['proc'],True,child['pid'])
                proof['finalCleanup']=clean
                if not clean['cleanupVerified']: proof['status']='FAIL'
            for drain in child['drains']: drain.thread.join(timeout=2)
            for stream in child['files']: stream.close()
            if child['job']: k.CloseHandle(child['job'])
            k.CloseHandle(child['thread']);k.CloseHandle(child['proc'])
        proof['operationSeconds']=time.monotonic()-started
        write_exclusive(root/'canary-review.json',proof)
    print(json.dumps({'status':proof['status'],'seconds':proof['operationSeconds'],'taskRoot':str(root),
                      'errors':proof['errors'],'samples':len((proof.get('sampling') or {}).get('samples',[]))},indent=2))
    return 0 if proof['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
