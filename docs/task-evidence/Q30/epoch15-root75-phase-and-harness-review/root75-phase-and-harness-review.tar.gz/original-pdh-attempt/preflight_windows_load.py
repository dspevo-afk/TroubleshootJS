"""Small passive system-only load observation; never asserts desktop ownership."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tempfile
import time
import uuid

import windows_cpu_sampler as counters
from receipts import write_exclusive


def main():
    root=Path(tempfile.gettempdir())/('q30-passive-load-preflight-'+uuid.uuid4().hex)
    root.mkdir(exist_ok=False)
    k=counters.api();cores=int(k.GetActiveProcessorCount(0xffff))
    if int(k.GetActiveProcessorGroupCount())!=1 or not 1<=cores<=64:
        raise counters.CounterError('unsupported per-core scope')
    pdh=counters.CoreCounters(cores);rows=[];started=time.monotonic()
    try:
        for index in range(5):
            row={'utc':datetime.now(timezone.utc).isoformat(),'monotonicNs':time.monotonic_ns(),
                 'system':counters.system_counters(k),'perCore':pdh.read(),'memory':counters.memory(k)}
            if rows:
                delta={name:row['system'][name]-rows[-1]['system'][name] for name in row['system']}
                total=delta['kernelTicks']+delta['userTicks'];busy=total-delta['idleTicks']
                assert all(value>=0 for value in delta.values()) and total>0 and 0<=busy<=total
                row['systemBusyPercent']=100*busy/total
            rows.append(row)
            if index<4:time.sleep(.5)
    finally:
        pdh.close()
    loads=[row['systemBusyPercent'] for row in rows[1:]]
    percore=[row['perCore']['busyPercent'] for row in rows[1:]]
    assert all(row['perCore']['status']=='PASS' for row in rows[1:])
    mean=sum(loads)/len(loads)
    peak=max(max(values) for values in percore)
    median_core=max(sorted(values[core] for values in percore)[len(percore)//2] for core in range(cores))
    memory=max(row['memory']['loadPercent'] for row in rows)
    # Conservative launch screen, not qualification or a claim of guaranteed quiet.
    significant=mean>=20 or median_core>=70 or memory>=90
    proof={'schema':1,'status':'PASS','scope':'Passive system load only; no Q30 case launched',
           'qualification':False,'logicalProcessors':cores,'operationSeconds':time.monotonic()-started,
           'meanSystemBusyPercent':mean,'peakPerCoreBusyPercent':peak,'maxMedianCoreBusyPercent':median_core,
           'maxMemoryLoadPercent':memory,'significantContentionObserved':significant,
           'screenThresholds':{'meanSystemBusyPercent':20,'medianCoreBusyPercent':70,'memoryLoadPercent':90},
           'quietGuaranteed':False,'overlappingProjectAcknowledgements':'incomplete; resource owners remain unknown',
           'samplerSha256':hashlib.sha256(Path(counters.__file__).read_bytes()).hexdigest(),'samples':rows}
    write_exclusive(root/'load-preflight.json',proof)
    print(json.dumps({key:value for key,value in proof.items() if key!='samples'}|{'taskRoot':str(root)},indent=2))


if __name__=='__main__':main()
