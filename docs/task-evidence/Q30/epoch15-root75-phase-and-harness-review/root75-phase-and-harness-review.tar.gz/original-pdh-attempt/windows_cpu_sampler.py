"""Read-only Windows system/job CPU counters; no affinity/priority/runtime changes.

System kernel time includes idle; job totals include terminated descendants.
Contracts: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getsystemtimes
https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_accounting_information
"""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import threading
import time
from pathlib import Path

import serial_runner


class CounterError(RuntimeError):
    pass


def api():
    k = serial_runner._api()
    k.GetSystemTimes.restype = wintypes.BOOL
    k.GetSystemTimes.argtypes = [ctypes.POINTER(ctypes.c_uint64)]*3
    k.GetActiveProcessorGroupCount.restype = wintypes.WORD
    k.GetActiveProcessorGroupCount.argtypes = []
    k.GetActiveProcessorCount.restype = wintypes.DWORD
    k.GetActiveProcessorCount.argtypes = [wintypes.WORD]
    k.OpenProcess.restype = wintypes.HANDLE
    k.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    k.IsProcessInJob.restype = wintypes.BOOL
    k.IsProcessInJob.argtypes = [wintypes.HANDLE,wintypes.HANDLE,ctypes.POINTER(wintypes.BOOL)]
    k.GlobalMemoryStatusEx.restype = wintypes.BOOL
    k.GlobalMemoryStatusEx.argtypes = [ctypes.c_void_p]
    return k


class Memory(ctypes.Structure):
    _fields_=[('length',wintypes.DWORD),('loadPercent',wintypes.DWORD)]+[
        (name,ctypes.c_uint64) for name in ('totalPhysical','availablePhysical','totalPageFile',
        'availablePageFile','totalVirtual','availableVirtual','availableExtendedVirtual')]


def memory(k):
    value=Memory();value.length=ctypes.sizeof(value)
    if not k.GlobalMemoryStatusEx(ctypes.byref(value)):
        raise serial_runner._error('GlobalMemoryStatusEx')
    return {name:int(getattr(value,name)) for name in
            ('loadPercent','totalPhysical','availablePhysical','totalPageFile','availablePageFile')}


class CoreValue(ctypes.Structure):
    _fields_=[('status',wintypes.DWORD),('value',ctypes.c_double)]


class CoreCounters:
    def __init__(self,count):
        self.p=ctypes.WinDLL('pdh',use_last_error=True)
        H,D=ctypes.c_void_p,wintypes.DWORD
        for name,args in (
            ('PdhOpenQueryW',[wintypes.LPCWSTR,ctypes.c_size_t,ctypes.POINTER(H)]),
            ('PdhAddEnglishCounterW',[H,wintypes.LPCWSTR,ctypes.c_size_t,ctypes.POINTER(H)]),
            ('PdhCollectQueryData',[H]),
            ('PdhGetFormattedCounterValue',[H,D,ctypes.POINTER(D),ctypes.POINTER(CoreValue)]),
            ('PdhCloseQuery',[H])):
            fn=getattr(self.p,name);fn.restype=D;fn.argtypes=args
        self.query=H();self.counters=[]
        self._ok(self.p.PdhOpenQueryW(None,0,ctypes.byref(self.query)),'PdhOpenQueryW')
        try:
            for core in range(count):
                handle=H()
                self._ok(self.p.PdhAddEnglishCounterW(self.query,
                         r'\Processor(%d)\%% Processor Time'%core,0,ctypes.byref(handle)),
                         'PdhAddEnglishCounterW')
                self.counters.append(handle)
        except Exception:
            self.close();raise
        self.collections=0

    def _ok(self,status,phase):
        if status!=0: raise CounterError(phase+' failed '+hex(status))

    def read(self):
        self._ok(self.p.PdhCollectQueryData(self.query),'PdhCollectQueryData')
        self.collections+=1
        if self.collections==1:
            return {'status':'WARMUP','busyPercent':None}
        values=[]
        for handle in self.counters:
            value=CoreValue()
            self._ok(self.p.PdhGetFormattedCounterValue(handle,0x200,None,ctypes.byref(value)),
                     'PdhGetFormattedCounterValue')
            if value.status not in (0,1) or not 0<=value.value<=100:
                raise CounterError('invalid per-core CPU value')
            values.append(value.value)
        return {'status':'PASS','busyPercent':values}

    def close(self):
        if self.query:
            status=self.p.PdhCloseQuery(self.query);self.query=None
            self._ok(status,'PdhCloseQuery')


class JobProcessList(ctypes.Structure):
    _fields_=[('assigned',wintypes.DWORD),('count',wintypes.DWORD),
              ('pids',ctypes.c_size_t*96)]


def processes(k,job):
    values=JobProcessList()
    if not k.QueryInformationJobObject(job,3,ctypes.byref(values),ctypes.sizeof(values),None):
        raise serial_runner._error('QueryInformationJobObject process IDs')
    if values.count>96 or values.assigned>96:
        raise CounterError('owned process sampling bound exceeded')
    rows=[]
    for pid in values.pids[:values.count]:
        handle=k.OpenProcess(0x1000,False,pid)
        if not handle:
            error=ctypes.get_last_error()
            if error==87:
                rows.append({'pid':int(pid),'status':'EXITED_BEFORE_SAMPLE'});continue
            raise serial_runner._error('OpenProcess owned sample')
        try:
            member=wintypes.BOOL()
            if not k.IsProcessInJob(handle,job,ctypes.byref(member)):
                raise serial_runner._error('IsProcessInJob')
            if not member.value:
                rows.append({'pid':int(pid),'status':'NO_LONGER_IN_OWNED_JOB'});continue
            times=[serial_runner._FILETIME() for _ in range(4)]
            if not k.GetProcessTimes(handle,*(ctypes.byref(value) for value in times)):
                raise serial_runner._error('GetProcessTimes owned sample')
            def ticks(value): return (int(value.high)<<32)|int(value.low)
            name=ctypes.create_unicode_buffer(32768);length=wintypes.DWORD(32768)
            if not k.QueryFullProcessImageNameW(handle,0,name,ctypes.byref(length)):
                raise serial_runner._error('QueryFullProcessImageNameW owned sample')
            rows.append({'pid':int(pid),'status':'PASS','creationFileTimeTicks':ticks(times[0]),
                         'executable':name.value[:length.value],'imageName':Path(name.value).name,
                         'kernelTicks':ticks(times[2]),'userTicks':ticks(times[3])})
        finally:
            k.CloseHandle(handle)
    return rows


def system_counters(k):
    values = [ctypes.c_uint64() for _ in range(3)]
    if not k.GetSystemTimes(*(ctypes.byref(value) for value in values)):
        raise serial_runner._error('GetSystemTimes')
    return dict(zip(('idleTicks', 'kernelTicks', 'userTicks'), (value.value for value in values)))


def job_counters(k, job):
    if not job:
        raise CounterError('missing owned job handle')
    value = serial_runner._ACCOUNTING()
    if not k.QueryInformationJobObject(job, serial_runner.JOB_ACCOUNTING,
                ctypes.byref(value), ctypes.sizeof(value), None):
        raise serial_runner._error('QueryInformationJobObject CPU')
    result = {'userTicks':int(value.user), 'kernelTicks':int(value.kernel),
              'pageFaults':int(value.faults), 'totalProcesses':int(value.total),
              'activeProcesses':int(value.active), 'terminatedByLimit':int(value.terminated)}
    if any(value < 0 for value in result.values()):
        raise CounterError('negative job counter')
    return result


def interval(previous, current):
    old, new = previous['system'], current['system']
    deltas = {key:new[key]-old[key] for key in old}
    if any(value < 0 for value in deltas.values()):
        raise CounterError('system counter moved backward')
    total = deltas['kernelTicks'] + deltas['userTicks']
    busy = total-deltas['idleTicks']
    if busy < 0 or busy > total:
        raise CounterError('system CPU counters inconsistent')
    elapsed = current['monotonicNs']-previous['monotonicNs']
    if elapsed <= 0:
        raise CounterError('sample clock did not advance')
    old_job, new_job = previous['job'], current['job']
    cpu = (new_job['userTicks']-old_job['userTicks'] +
           new_job['kernelTicks']-old_job['kernelTicks'])
    if cpu < 0:
        raise CounterError('job CPU counter moved backward')
    return {'elapsedMs':elapsed/1_000_000, 'systemBusyPercent':100*busy/total if total else None,
            'ownedJobCpuMs':cpu/10_000, 'ownedJobCoreEquivalent':cpu*100/elapsed}


class Sampler:
    def __init__(self, k, job, *, period_seconds=0.5, maximum_samples=400):
        if not 0.05 <= period_seconds <= 1 or not 2 <= maximum_samples <= 1000:
            raise CounterError('sampling bounds unsupported')
        self.k, self.job = k, job
        groups = int(k.GetActiveProcessorGroupCount())
        processors = int(k.GetActiveProcessorCount(0xffff))
        if groups != 1 or not 1 <= processors <= 64:
            raise CounterError('system CPU sampling needs a single group with1–64 active processors')
        self.processor_groups, self.processors = groups, processors
        self.core_counters=CoreCounters(processors)
        self.period, self.maximum = period_seconds, maximum_samples
        self.rows, self.errors = [], []
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def capture(self):
        started = time.monotonic_ns()
        value = {'monotonicNs':started,
                 'utc':datetime.now(timezone.utc).isoformat(timespec='microseconds'),
                 'system':system_counters(self.k), 'job':job_counters(self.k, self.job),
                 'perCore':self.core_counters.read(),'memory':memory(self.k),
                 'ownedProcesses':processes(self.k,self.job)}
        value['readElapsedNs'] = time.monotonic_ns()-started
        if self.rows:
            value['interval'] = interval(self.rows[-1], value)
            old={(p['pid'],p['creationFileTimeTicks']):p for p in self.rows[-1]['ownedProcesses'] if p['status']=='PASS'}
            for process in value['ownedProcesses']:
                key=(process['pid'],process.get('creationFileTimeTicks'))
                if process['status']=='PASS' and key in old:
                    delta=process['userTicks']+process['kernelTicks']-old[key]['userTicks']-old[key]['kernelTicks']
                    if delta<0: raise CounterError('owned process CPU moved backward')
                    process['intervalCpuMs']=delta/10000
                    process['intervalCoreEquivalent']=delta*100/(value['monotonicNs']-self.rows[-1]['monotonicNs'])
        self.rows.append(value)

    def start(self):
        try:
            self.capture()
            self.thread.start()
        except Exception:
            self.core_counters.close();raise

    def _run(self):
        try:
            while not self.stop_event.wait(self.period):
                if len(self.rows) >= self.maximum-1:
                    raise CounterError('CPU sample bound exhausted')
                self.capture()
        except Exception as error:
            self.errors.append(type(error).__name__+': '+str(error))
            self.stop_event.set()

    def stop(self):
        self.stop_event.set()
        if self.thread.ident is not None:
            self.thread.join(timeout=2)
        if self.thread.is_alive():
            self.errors.append('sampler thread survived bounded join')
        else:
            try:
                self.capture()
            except Exception as error:
                self.errors.append(type(error).__name__+': '+str(error))
        try:
            self.core_counters.close()
        except Exception as error:
            self.errors.append(type(error).__name__+': '+str(error))
        return {'schema':1, 'status':'PASS' if not self.errors else 'FAIL',
                'processorGroups':self.processor_groups, 'logicalProcessors':self.processors,
                'periodSeconds':self.period, 'maximumSamples':self.maximum,
                'errors':self.errors, 'samples':self.rows,
                'limits':'System totals only for the observed single processor group. Owned-job CPU includes all assigned descendants and their terminated totals; it is not solver-only CPU or per-phase instruction profiling.'}
