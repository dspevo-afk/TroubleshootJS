"""Three passive PDH collections, retaining raw and formatted statuses on error.

No Q30 application or browser launch; no performance counter or host settings writes.
"""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tempfile
import time
import uuid

import windows_cpu_sampler as counters
from receipts import write_exclusive


class RawCounter(ctypes.Structure):
    _fields_ = [('status', wintypes.DWORD), ('timestampLow', wintypes.DWORD),
                ('timestampHigh', wintypes.DWORD), ('first', ctypes.c_int64),
                ('second', ctypes.c_int64), ('multiCount', wintypes.DWORD)]


def main():
    root = Path(tempfile.gettempdir()) / ('q30-pdh-raw-probe-' + uuid.uuid4().hex)
    root.mkdir(exist_ok=False)
    started = time.monotonic()
    query = None
    proof = {'schema': 1, 'status': 'FAIL', 'qualification': False, 'q30CasesLaunched': 0,
             'startedUtc': datetime.now(timezone.utc).isoformat(), 'samples': [], 'errors': [],
             'samplerSha256': hashlib.sha256(Path(counters.__file__).read_bytes()).hexdigest(),
             'rawStructSize': ctypes.sizeof(RawCounter),
             'rawStructOffsets': {name: getattr(RawCounter, name).offset for name, _ in RawCounter._fields_}}
    try:
        k = counters.api()
        count = int(k.GetActiveProcessorCount(0xffff))
        assert k.GetActiveProcessorGroupCount() == 1 and 1 <= count <= 64
        proof['logicalProcessors'] = count
        query = counters.CoreCounters(count)
        p = query.p
        p.PdhGetRawCounterValue.restype = wintypes.DWORD
        p.PdhGetRawCounterValue.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(RawCounter)]
        for index in range(3):
            t0 = time.monotonic_ns()
            collected = int(p.PdhCollectQueryData(query.query))
            row = {'index': index, 'utc': datetime.now(timezone.utc).isoformat(),
                   'monotonicNs': t0, 'collectStatus': hex(collected),
                   'system': counters.system_counters(k), 'memory': counters.memory(k), 'cores': []}
            proof['samples'].append(row)
            if collected:
                raise counters.CounterError('PdhCollectQueryData failed ' + hex(collected))
            for core, handle in enumerate(query.counters):
                raw, ctype, fmt = RawCounter(), wintypes.DWORD(), counters.CoreValue()
                raw_status = int(p.PdhGetRawCounterValue(handle, ctypes.byref(ctype), ctypes.byref(raw)))
                fmt_status = int(p.PdhGetFormattedCounterValue(handle, 0x200, None, ctypes.byref(fmt)))
                value = {'core': core, 'counterType': hex(ctype.value), 'rawCallStatus': hex(raw_status),
                         'raw': {'status': hex(raw.status), 'timestampTicks': (int(raw.timestampHigh) << 32) | int(raw.timestampLow),
                                 'first': int(raw.first), 'second': int(raw.second), 'multiCount': int(raw.multiCount)},
                         'formattedCallStatus': hex(fmt_status), 'formattedValueStatus': hex(fmt.status),
                         'formattedBusyPercent': fmt.value if not fmt_status and fmt.status in (0, 1) else None}
                row['cores'].append(value)
                if index and (raw_status or raw.status not in (0, 1) or fmt_status or fmt.status not in (0, 1)):
                    proof['errors'].append({'sample': index, 'core': core, 'rawStatus': hex(raw_status),
                                            'formattedStatus': hex(fmt_status), 'formattedValueStatus': hex(fmt.status)})
            row['readElapsedNs'] = time.monotonic_ns() - t0
            write_exclusive(root / ('sample-%02d.json' % index), row)
            if index != 2:
                time.sleep(0.5)
        proof['status'] = 'FAIL' if proof['errors'] else 'PASS_PASSIVE_PROBE_ONLY'
    except Exception as error:
        proof['errors'].append(type(error).__name__ + ': ' + str(error))
    finally:
        close_start = time.monotonic()
        if query is not None:
            try:
                query.close()
                proof['queryClosed'] = True
            except Exception as error:
                proof['errors'].append('close: ' + repr(error))
                proof['status'] = 'FAIL'
        proof['cleanupSeconds'] = time.monotonic() - close_start
        proof['operationSeconds'] = close_start - started
        proof['finishedUtc'] = datetime.now(timezone.utc).isoformat()
        write_exclusive(root / 'probe-result.json', proof)
    print(json.dumps({'status': proof['status'], 'taskRoot': str(root),
                      'samples': len(proof['samples']), 'errors': proof['errors'][:8],
                      'errorCount': len(proof['errors']), 'operationSeconds': proof['operationSeconds'],
                      'cleanupSeconds': proof['cleanupSeconds']}, indent=2))
    return 0 if proof['status'] == 'PASS_PASSIVE_PROBE_ONLY' else 1


if __name__ == '__main__':
    raise SystemExit(main())
