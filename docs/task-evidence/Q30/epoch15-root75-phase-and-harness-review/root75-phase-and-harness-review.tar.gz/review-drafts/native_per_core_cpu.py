"""Read-only, diagnostic-only per-processor CPU sampler for Windows.

This uses NtQuerySystemInformation(SystemProcessorPerformanceInformation=8).
Microsoft documents the information class and structure, but warns that the
function and returned structures are internal and may change or disappear.
This module must not be used as a shipping qualification gate or as a PASS
fallback for another counter source.

No processor affinity, priority, registry, service, performance-counter, or
runtime settings are changed. The helper bounds sample count; callers choose the
bound and scheduling.
"""

import ctypes
from ctypes import wintypes
import time


SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION = 8
ALL_PROCESSOR_GROUPS = 0xFFFF
PROCESSOR_INFORMATION_BYTES = 48
_FIELDS = ("idleTicks", "kernelTicks", "userTicks")


class CounterError(RuntimeError):
    pass


class SystemProcessorPerformanceInformation(ctypes.Structure):
    # The documented native layout is five LARGE_INTEGERs followed by ULONG.
    # Eight-byte packing gives the documented 48-byte array stride.
    _pack_ = 8
    _fields_ = [
        ("idleTime", ctypes.c_int64),
        ("kernelTime", ctypes.c_int64),
        ("userTime", ctypes.c_int64),
        ("reserved1", ctypes.c_int64 * 2),
        ("reserved2", wintypes.DWORD),
    ]


_EXPECTED_OFFSETS = (0, 8, 16, 24, 40)
_ACTUAL_OFFSETS = tuple(
    getattr(SystemProcessorPerformanceInformation, name).offset
    for name in ("idleTime", "kernelTime", "userTime", "reserved1", "reserved2")
)
if (
    ctypes.sizeof(SystemProcessorPerformanceInformation) != PROCESSOR_INFORMATION_BYTES
    or _ACTUAL_OFFSETS != _EXPECTED_OFFSETS
):
    raise RuntimeError("SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION layout is not 48-byte ABI")


class NativePerCoreCounters:
    """Bounded read-only diagnostic with a CoreCounters-like read/close API.

    read() returns raw tick snapshots and, after the first warmup snapshot,
    deltas plus an unclamped busy-percent derivation. The derivation is an
    inference for diagnostics; it is not a separately guaranteed Windows API
    contract. A failed check stores evidence in last_result and raises.
    """

    qualification_eligible = False

    def __init__(self, *, maximum_samples=400):
        if not 2 <= maximum_samples <= 1000:
            raise CounterError("sample bound must be between 2 and 1000")

        try:
            self._kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            self._kernel32.GetActiveProcessorGroupCount.restype = wintypes.WORD
            self._kernel32.GetActiveProcessorGroupCount.argtypes = []
            self._kernel32.GetActiveProcessorCount.restype = wintypes.DWORD
            self._kernel32.GetActiveProcessorCount.argtypes = [wintypes.WORD]
            self._kernel32.GetSystemTimes.restype = wintypes.BOOL
            self._kernel32.GetSystemTimes.argtypes = [
                ctypes.POINTER(wintypes.FILETIME),
                ctypes.POINTER(wintypes.FILETIME),
                ctypes.POINTER(wintypes.FILETIME),
            ]
            self._ntdll = ctypes.WinDLL("ntdll", use_last_error=True)
            self._nt_query = self._ntdll.NtQuerySystemInformation
            self._nt_query.restype = ctypes.c_long  # NTSTATUS is a signed 32-bit LONG.
            self._nt_query.argtypes = [
                wintypes.DWORD,
                ctypes.c_void_p,
                wintypes.ULONG,
                ctypes.POINTER(wintypes.ULONG),
            ]
        except (AttributeError, OSError) as error:
            raise CounterError("required Windows CPU API is unavailable: " + str(error)) from error

        self.maximum_samples = int(maximum_samples)
        self._samples = 0
        self._previous = None
        self._closed = False
        self.last_query_evidence = None
        self.last_result = None
        self.groups, self.processors = self._topology()
        if self.groups != 1 or not 1 <= self.processors <= 64:
            self.close()
            raise CounterError("diagnostic requires exactly one active group with 1-64 processors")

    @staticmethod
    def _filetime_ticks(value):
        return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)

    def _topology(self):
        groups = int(self._kernel32.GetActiveProcessorGroupCount())
        in_group_zero = int(self._kernel32.GetActiveProcessorCount(0))
        all_groups = int(self._kernel32.GetActiveProcessorCount(ALL_PROCESSOR_GROUPS))
        if in_group_zero != all_groups:
            raise CounterError("processor count changed or group enumeration is inconsistent")
        return groups, in_group_zero

    def _system_times(self):
        idle, kernel, user = (wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME())
        if not self._kernel32.GetSystemTimes(
            ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)
        ):
            code = ctypes.get_last_error()
            raise CounterError("GetSystemTimes failed " + hex(code))
        return {
            "idleTicks": self._filetime_ticks(idle),
            "kernelTicks": self._filetime_ticks(kernel),
            "userTicks": self._filetime_ticks(user),
        }

    def _query(self, system_class=SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION, *, buffer_bytes=None):
        """Read one array; optional arguments exist for the negative canary only."""
        if self._closed:
            raise CounterError("sampler is closed")

        groups, processors = self._topology()
        if groups != 1 or processors != self.processors:
            raise CounterError("processor topology changed during diagnostic")

        expected_bytes = processors * PROCESSOR_INFORMATION_BYTES
        requested_bytes = expected_bytes if buffer_bytes is None else int(buffer_bytes)
        if not 1 <= requested_bytes <= expected_bytes:
            raise CounterError("query buffer size is outside the bounded diagnostic range")

        rows_type = SystemProcessorPerformanceInformation * processors
        rows = rows_type()
        address = ctypes.cast(rows, ctypes.c_void_p)
        if requested_bytes != expected_bytes:
            # A short buffer is used only by the documented negative canary.
            short_buffer = ctypes.create_string_buffer(requested_bytes)
            address = ctypes.cast(short_buffer, ctypes.c_void_p)

        returned = wintypes.ULONG(0)
        status = int(self._nt_query(
            int(system_class), address, requested_bytes, ctypes.byref(returned)
        ))
        evidence = {
            "systemInformationClass": int(system_class),
            "ntStatus": hex(status & 0xFFFFFFFF),
            "requestedBytes": requested_bytes,
            "expectedBytes": expected_bytes,
            "returnedBytes": int(returned.value),
            "processorGroups": groups,
            "logicalProcessors": processors,
        }
        self.last_query_evidence = evidence

        if status != 0:
            message = "NtQuerySystemInformation failed " + evidence["ntStatus"]
            self.last_result = {"status": "FAIL", "query": evidence, "errors": [message]}
            raise CounterError(message)
        if returned.value != expected_bytes:
            message = "NtQuerySystemInformation returned an unexpected byte count"
            self.last_result = {"status": "FAIL", "query": evidence, "errors": [message]}
            raise CounterError(message)
        if requested_bytes != expected_bytes:
            message = "short query buffer unexpectedly reported success"
            self.last_result = {"status": "FAIL", "query": evidence, "errors": [message]}
            raise CounterError(message)

        result = []
        for index, row in enumerate(rows):
            values = {
                "arrayIndex": index,
                "idleTicks": int(row.idleTime),
                "kernelTicks": int(row.kernelTime),
                "userTicks": int(row.userTime),
            }
            if any(values[key] < 0 for key in _FIELDS):
                message = "native per-processor counter was negative"
                self.last_result = {
                    "status": "FAIL", "query": evidence,
                    "perCoreRawTicks": result + [values], "errors": [message],
                }
                raise CounterError(message)
            result.append(values)
        return result

    @staticmethod
    def _delta_rows(previous, current):
        if len(previous) != len(current):
            raise CounterError("processor count changed between native snapshots")
        deltas = []
        for old, new in zip(previous, current):
            row = {"arrayIndex": new["arrayIndex"]}
            for key in _FIELDS:
                delta = new[key] - old[key]
                if delta < 0:
                    raise CounterError("native per-processor counter moved backward")
                row[key] = delta
            deltas.append(row)
        return deltas

    @staticmethod
    def _system_delta(older, newer):
        result = {key: newer[key] - older[key] for key in _FIELDS}
        if any(value < 0 for value in result.values()):
            raise CounterError("GetSystemTimes counter moved backward")
        return result

    def _crosscheck(self, previous, current, per_core_deltas):
        # Each native query lies between its GetSystemTimes before/after reads.
        # Comparing the outer aggregate interval bounds the unaligned portions
        # by the two measured bracket widths, plus 100-ns read quantization.
        outer = self._system_delta(previous["systemBefore"], current["systemAfter"])
        previous_bracket = self._system_delta(previous["systemBefore"], previous["systemAfter"])
        current_bracket = self._system_delta(current["systemBefore"], current["systemAfter"])
        native_sums = {
            key: sum(row[key] for row in per_core_deltas) for key in _FIELDS
        }
        rows = {}
        errors = []
        tick_quantization = self.processors + 2
        for key in _FIELDS:
            tolerance = previous_bracket[key] + current_bracket[key] + tick_quantization
            difference = native_sums[key] - outer[key]
            passed = abs(difference) <= tolerance
            rows[key] = {
                "nativePerCoreSumDelta": native_sums[key],
                "aggregateOuterDelta": outer[key],
                "differenceTicks": difference,
                "toleranceTicks": tolerance,
                "withinTolerance": passed,
            }
            if not passed:
                errors.append(key + " per-core sum disagrees with aggregate bracket")
        return {
            "status": "PASS" if not errors else "FAIL",
            "categories": rows,
            "previousBracketTicks": previous_bracket,
            "currentBracketTicks": current_bracket,
            "tickQuantizationAllowance": tick_quantization,
            "errors": errors,
        }

    def _reject(self, result, message):
        result["status"] = "FAIL"
        result.setdefault("errors", []).append(message)
        self.last_result = result
        raise CounterError(message)

    def read(self):
        if self._closed:
            raise CounterError("sampler is closed")
        if self._samples >= self.maximum_samples:
            raise CounterError("diagnostic sample bound exhausted")

        sample_index = self._samples
        self._samples += 1
        started_ns = time.monotonic_ns()
        system_before = None
        try:
            system_before = self._system_times()
            query_started_ns = time.monotonic_ns()
            raw = self._query()
            query_finished_ns = time.monotonic_ns()
            system_after = self._system_times()
            finished_ns = time.monotonic_ns()
        except CounterError as error:
            if self.last_result is None or self.last_result.get("status") != "FAIL":
                self.last_result = {"status": "FAIL", "errors": [str(error)]}
            self.last_result.setdefault("sampleIndex", sample_index)
            self.last_result.setdefault("monotonicStartedNs", started_ns)
            self.last_result.setdefault("systemBefore", system_before)
            self.last_result.setdefault("query", self.last_query_evidence)
            if "raw" in locals():
                self.last_result.setdefault("perCoreRawTicks", raw)
            raise

        snapshot = {
            "sampleIndex": sample_index,
            "monotonicStartedNs": started_ns,
            "queryStartedNs": query_started_ns,
            "queryFinishedNs": query_finished_ns,
            "monotonicFinishedNs": finished_ns,
            "systemBefore": system_before,
            "systemAfter": system_after,
            "perCoreRawTicks": raw,
        }
        result = {
            "schema": 1,
            "status": "WARMUP_DIAGNOSTIC_ONLY" if self._previous is None else "PASS_DIAGNOSTIC_ONLY",
            "qualificationEligible": False,
            "api": "NtQuerySystemInformation(SystemProcessorPerformanceInformation=8)",
            "processorGroups": self.groups,
            "logicalProcessors": self.processors,
            "sampleIndex": sample_index,
            "query": self.last_query_evidence,
            "monotonicStartedNs": started_ns,
            "queryStartedNs": query_started_ns,
            "queryFinishedNs": query_finished_ns,
            "monotonicFinishedNs": finished_ns,
            "systemBefore": system_before,
            "systemAfter": system_after,
            "perCoreRawTicks": raw,
            "perCoreDeltasTicks": None,
            "busyPercent": None,
            "systemCrossCheck": None,
            "limits": (
                "Diagnostic only. Native array index is not a documented stable processor identity; "
                "class 8 may change or disappear. The busy-percent derivation is an inference, "
                "not a production contract."
            ),
            "errors": [],
        }

        if self._previous is not None:
            try:
                deltas = self._delta_rows(self._previous["perCoreRawTicks"], raw)
                percentages = []
                for row in deltas:
                    total = row["kernelTicks"] + row["userTicks"]
                    busy = total - row["idleTicks"]
                    if total <= 0:
                        raise CounterError("per-processor interval has no elapsed CPU ticks")
                    if busy < 0 or busy > total:
                        raise CounterError("per-processor busy ticks are outside the raw interval")
                    percentages.append(100.0 * busy / total)
                crosscheck = self._crosscheck(self._previous, snapshot, deltas)
            except CounterError as error:
                return self._reject(result, str(error))

            result["perCoreDeltasTicks"] = deltas
            result["busyPercent"] = percentages
            result["systemCrossCheck"] = crosscheck
            if crosscheck["errors"]:
                return self._reject(result, "; ".join(crosscheck["errors"]))

        self._previous = snapshot
        self.last_result = result
        return result

    def close(self):
        """Idempotently release Python references; no OS query handle is held."""
        if self._closed:
            return
        self._closed = True
        self._nt_query = None
        self._ntdll = None
        self._kernel32 = None


