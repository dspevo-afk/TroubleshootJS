"""Four-second passive native per-core diagnostic canary; no application workload."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time

import native_per_core_cpu as native


def write(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def main():
    source = Path(native.__file__)
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    root = Path(tempfile.mkdtemp(prefix='q30-native-cpu-canary-'))
    start = time.monotonic()
    instance = None
    proof = {'schema': 1, 'status': 'FAIL', 'qualification': False, 'q30CasesLaunched': 0,
             'browserLaunched': False, 'sourceSha256': before,
             'startedUtc': datetime.now(timezone.utc).isoformat(),
             'windowsVersion': list(sys.getwindowsversion()),
             'samples': [], 'errors': [],
             'method': 'Native class 8, diagnostic only; does not replace the failed PDH evidence'}
    try:
        instance = native.NativePerCoreCounters(maximum_samples=5)
        for index in range(5):
            row = instance.read()
            proof['samples'].append(row)
            write(root / ('sample-%02d.json' % index), row)
            assert row['query']['ntStatus'] == '0x0'
            assert row['query']['returnedBytes'] == 48 * row['logicalProcessors']
            assert row['qualificationEligible'] is False
            assert row['status'] == ('WARMUP_DIAGNOSTIC_ONLY' if index == 0 else 'PASS_DIAGNOSTIC_ONLY')
            if index:
                assert row['systemCrossCheck']['status'] == 'PASS' and not row['errors']
                assert len(row['busyPercent']) == row['logicalProcessors']
                assert all(0 <= value <= 100 for value in row['busyPercent'])
            if index != 4:
                time.sleep(1)
        try:
            instance._query(system_class=0xffffffff)
            raise AssertionError('invalid native information class was accepted')
        except native.CounterError:
            evidence = instance.last_query_evidence
            assert evidence['systemInformationClass'] == 0xffffffff and evidence['ntStatus'] != '0x0'
            proof['invalidClassNegative'] = {'status': 'PASS_REJECTION', 'evidence': evidence}
        original = proof['samples'][0]['perCoreRawTicks']
        backward = [dict(row) for row in original]
        backward[0]['userTicks'] -= 1
        try:
            instance._delta_rows(original, backward)
            raise AssertionError('backward native counter accepted')
        except native.CounterError:
            proof['backwardArithmeticNegative'] = 'PASS_REJECTION'
        proof['status'] = 'PASS_DIAGNOSTIC_ONLY'
    except BaseException as error:
        proof['errors'].append(type(error).__name__ + ': ' + str(error))
        if instance is not None:
            proof['lastResult'] = instance.last_result
    finally:
        cleanup_start = time.monotonic()
        if instance is not None:
            instance.close()
            proof['closed'] = instance._closed
        proof['operationSeconds'] = cleanup_start - start
        proof['cleanupSeconds'] = time.monotonic() - cleanup_start
        proof['sourceUnchanged'] = hashlib.sha256(source.read_bytes()).hexdigest() == before
        if not proof['sourceUnchanged']:
            proof['status'] = 'FAIL'
        proof['finishedUtc'] = datetime.now(timezone.utc).isoformat()
        proof['limits'] = 'Exact host/build observation only. API may change or disappear; array indices lack guaranteed stable processor identity. No Q30 CPU or quiet-desktop claim.'
        write(root / 'canary-result.json', proof)
    print(json.dumps({'status': proof['status'], 'taskRoot': str(root),
                      'sourceSha256': before, 'sampleCount': len(proof['samples']),
                      'operationSeconds': proof['operationSeconds'],
                      'cleanupSeconds': proof['cleanupSeconds'], 'errors': proof['errors']}, indent=2))
    return 0 if proof['status'] == 'PASS_DIAGNOSTIC_ONLY' else 1


if __name__ == '__main__':
    raise SystemExit(main())
