# Native per-core CPU diagnostic canary draft

**Status:** draft only; not run. This is an isolated, passive diagnostic for
native_per_core_cpu.py. It is not a shipping gate, a qualification fallback,
or evidence that Q30 launched or met a contention limit.

## Boundaries

- Do not launch Q30, a browser, a stress process, or a child workload.
- Do not change processor affinity, priority, power plans, registry values,
  performance-counter settings, services, or system runtime settings.
- Use one active processor group with 1–64 active logical processors only.
  The helper rejects topology changes and mismatched response lengths.
- Keep one owner for the diagnostic instance. Call close() in finally.
  The helper performs no persistent writes and holds no native query handle.

## Positive passive canary

1. Record the Windows build, active group/processor counts, candidate source
   hash, UTC start/end, and exact command used. Run from an isolated shell
   with no Q30 workload.
2. Instantiate NativePerCoreCounters(maximum_samples=5). Capture five
   read() results one second apart, then call close() in finally. Preserve each
   full result and last_result on error.
3. Expect the first result to be WARMUP_DIAGNOSTIC_ONLY, followed by four
   PASS_DIAGNOSTIC_ONLY samples. Every native call must have NTSTATUS zero,
   and returnedBytes must equal 48 * logicalProcessors. Counts must stay
   unchanged; raw counters and deltas must be nonnegative; each interval must
   have a positive denominator; and computed busy percentages must already be
   within 0–100 without clamping.
4. Require the sum of each per-processor idle/kernel/user delta to agree with
   the bracketing GetSystemTimes outer delta within the measured previous and
   current bracket widths plus the recorded one-tick-per-processor and two
   aggregate-read quantization allowance. Any mismatch, error, missing sample,
   or cleanup uncertainty is FAIL/BLOCKED, never PASS.

## Negative API canary

Run separately from the positive canary, still without Q30 or other workload.
After confirming the dynamically linked function is present, call the helper's
private _query(system_class=0xFFFFFFFF) once. Require a nonzero NTSTATUS to
raise CounterError, preserve the returned class/status/length evidence, and
produce no busy percentage. If the call returns success or the helper accepts
it as a sample, mark the canary FAIL. This invalid-class call is read-only; do
not retry other classes or alter host configuration.

## Contract limits and interpretation

Microsoft documents class 8 as an array of
SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION records and documents the record's
48-byte layout and 100-nanosecond time fields. Microsoft also warns that
NtQuerySystemInformation and its returned structures may change or disappear,
calls them internal, and directs applications to alternate APIs. The array
records have no processor identity field or documented stable index mapping.
GetSystemTimes is the supported alternative but reports aggregate processor
times (or a processor-group aggregate on larger systems), so it cannot validate
per-core attribution by itself.

The reported percentage uses
100 * (deltaKernel + deltaUser - deltaIdle) / (deltaKernel + deltaUser) with
no clamping. Treat this as a diagnostic inference only. A passing canary proves
only that this read path behaved consistently on this exact Windows build and
host during the recorded interval. It does not make class 8 a stable contract,
does not establish Q30 process CPU, and must not convert a failed PDH preflight
into a qualification PASS.

