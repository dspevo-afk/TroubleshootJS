import json,pathlib,sys
path=pathlib.Path(sys.argv[1]); seed=sys.argv[2]
value={"schema":1,"rootSeed":seed,"sourceIdentity":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
"baseHead":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","planSha256":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
"limits":{"jobMillis":90000,"sharedWork":640,"activeOperationMillis":5000},
"application":{"status":"PASS","elapsedMs":81000,"workUnits":620,"maxActiveOperationMs":4000,"maxCoordinatorAdvanceMs":4500},
"host":{"status":"PASS","observationElapsedMs":100,"deadlineMs":150000,"exitCode":0,"terminal":True},
"cleanup":{"status":"PASS","elapsedMs":100,"elapsedLimitations":None,"serverStopped":True,"ownedSurvivors":[]},
"operation":{"elapsedMs":81000,"elapsedLimitations":None},"sourceInputsUnchanged":True}
path.write_text(json.dumps(value),encoding="utf-8")
print("held-pipe-test-output",flush=True)
