from pathlib import Path
p=Path('<REPO_ROOT>/docs/CODEX_TASK_REPORT.md')
t=p.read_text(encoding='utf-8');a,b=t.split('# Historical checkpoint: CPU profile secured; publication measured; LU guard ready',1)
a=a.replace('prepared from documentation HEAD `fc8ebd8`\n(`Record Q30 cold CPU profile`)','prepared from documentation HEAD `144b382`\n(`Record inconclusive Q30 LU guard experiment`)')
needle='Scale remains NOT ACCEPTED.'
block='''Next measured candidate: P07 static via legality memo, overlay SHA-256
`93da7656198ed962c6ec83d1d5f271004a85dc3bf972a3a0479c8a28ed6ef658`.
Independent source reviews found the per-Search static/live split and checked-int
key sound. Fresh R3 uncached reference/candidate native checks PASS (31.323 /
48.905 s); all 1,540,386 oracle bytes match, including an asymmetric same-cell
net-switch witness, repeated cache hits, both live copper faces, holes, via cap,
route fingerprints and work. Existing P07/resumption/physical/budget/policy checks
remain. Earlier noncontrastive test coverage and source-preparation newline
assertion corrections are retained; no application failure was hidden.
Actual GWT5 PASS (79.627 s), compiled A07/disabled-normal PASS (5.879 s; cleanup
0.937 s), three reader negatives and five-permutation memo mechanism inspection
PASS. A test-only R3 edit leaves all 1,525 compiled runtime inputs byte-identical;
that explicit audit bounds GWT/canary reuse. Cold timing is NOT RUN yet. This
source remains isolated and is NOT INTEGRATED. The original production clocks,
limits, acceptance corpus, solver and proof behavior are unchanged.

'''
assert a.count(needle)==1;a=a.replace(needle,block+needle)
a=a.replace('Next: audit the publication packet and review the P07 static-via memo proposal\nagainst an independent uncached oracle before measuring it.','Next: audit the publication packet and run the predeclared P07 cold comparison\nafter freezing its complete execution binding.')
p.write_bytes((a+'# Historical checkpoint: CPU profile secured; publication measured; LU guard ready'+b).replace('\n','\r\n').encode())
print('Current checkpoint updated; historical handoff preserved.')
