from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
s=Path(__file__).resolve().parent
repo=Path('<REPO_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
prep=s/'p07-static-via-r1-preparation';draft=s/'scratch/p07-static-via-r1-draft'
raw=(prep/'source-audit.json').read_bytes();assert sha(raw)=='34b2b0814ad03f2efff492fd71239987d416173b057337ed2afaf536581e7232'
audit=json.loads(raw);path='tests/contracts/P07StaticViaLegalityOracleContractTest.java'
oracle=(draft/path).read_bytes();assert sha(oracle)=='7c624a5bf047885b2a6c1f985bc6fd5045345fb19dbdc56c1fa09bb101c49dd3'
for arm in ['control','candidate']:
    for e in audit['armInputs'][arm]:
        current=(prep/arm/e['path']).read_bytes();assert (len(current),sha(current))==(e['bytes'],e['sha256']),arm+e['path']
    (prep/arm/path).write_bytes(oracle)
    record=next(e for e in audit['armInputs'][arm] if e['path']==path);record.update(bytes=len(oracle),sha256=sha(oracle))
audit['status']='SOURCE_ORACLE_R3_PREPARED_NOT_VALIDATED';audit['priorSourceAuditSha256']=sha(raw);audit['oracleSha256']=sha(oracle)
audit['testOnlyRevision']={'changedPath':path,'purpose':'independent A/B/A barrier requires true/false/true; existing oracle cases retained','productionSourcesChanged':False}
canary=json.loads((s/'p07-static-via-r1-canaries/result.json').read_bytes())
spec=importlib.util.spec_from_file_location('runtime_boundary',repo/'tests/browser/compiled_attribute_acceptance.py');host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
now=host.capture_input_manifest(prep/'candidate')
assert now['sha256']==canary['inputAudit']['beforeSha256']=='b892062e26eeab733cf5d03d271cf43d77edd71e8d235c8c235396cf6112a34e' and now['fileCount']==1525
audit['gwtCanaryReuseBoundary']={'status':'PASS_UNCHANGED_RUNTIME_ONLY','runtimeSha256':now['sha256'],'runtimeFiles':now['fileCount'],'reason':'Only tests/contracts oracle changed. All source/static-web/generated production runtime files remain byte-identical to actual GWT5 and compiled canary input manifest. New native reference/candidate executions still required.'}
out=prep/'source-audit-r3.json';assert not out.exists();out.write_bytes((json.dumps(audit,indent=2)+'\n').encode())
script=(s/'native-p07-static-via.ps1').read_bytes().replace(b'p07-static-via-r1-uncached-oracle.txt',b'p07-static-via-r3-uncached-oracle.txt')
driver=s/'native-p07-static-via-r3.ps1';assert not driver.exists();driver.write_bytes(script)
manifest=draft/'source-manifest.json';old=manifest.read_bytes();backup=draft/'source-manifest.pre-oracle-r3.json';assert not backup.exists();backup.write_bytes(old)
m=json.loads(old);review=json.loads((draft/'oracle-review-r3.json').read_bytes())
m['additional_native_contract']['sha256']=review['oracle_sha256'];m['additional_native_contract']['diff_sha256']=review['oracle_diff']['sha256'];m['oracleReviewR3Sha256']=sha((draft/'oracle-review-r3.json').read_bytes());manifest.write_bytes((json.dumps(m,indent=2)+'\n').encode())
readme=draft/'README.md';t=readme.read_text().replace('70975b3f7717082465e8d3c2ffd91ec572778802de58796e661d868c17504e27',review['oracle_diff']['sha256'])
t+='\nR3 adds a barrier-domain same-cell PRIMARY/SECONDARY/PRIMARY witness with explicit true/false/true requirements. R2 passed native comparison, but its noncontrastive true/true/true case did not falsify a missing net reset. The production overlay and all compiled runtime inputs are unchanged; both native oracle arms will be rerun. Prior reports and source are retained.\n';readme.write_bytes(t.encode())
print(json.dumps({'status':audit['status'],'sourceAuditSha256':sha(out.read_bytes()),'runtimeReuseBoundary':audit['gwtCanaryReuseBoundary']}))
