from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
repo=Path('<REPO_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['p07-static-via-r3-reference-native.json','p07-static-via-r3-candidate-native6.json','p07-static-via-r1-gwt5.json','p07-static-via-r1-canaries-summary.json']:
    value=json.loads((s/name).read_bytes());assert value['status']=='PASS' and value['exitCode']==0
inspection=s/'p07-static-via-r1-compiled-inspection/root-review.json'
assert json.loads(inspection.read_bytes())['status']=='PASS_COMPILED_MEMO_MECHANISM_ONLY'
assert 'three negative corruption canaries' in (s/'p07-static-via-r1-a07-reader.log').read_text()
oracle=(s/'p07-static-via-r3-uncached-oracle.txt').read_bytes()
assert b'BARRIER_NET_SWITCH|PRIMARY|SECONDARY|300|300|B:true|B:false|B:true|true|true|true\n' in oracle
canary=json.loads((s/'p07-static-via-r1-canaries/result.json').read_bytes())
assert canary['outcome']=='PASS' and canary['cleanup']['status']=='PASS'
cpuplan=json.loads((s/'cpu-profile-10ms-r1-measurement-plan.json').read_bytes())
rows=[('control','10014',40),('candidate','10014',40),('candidate','10014',40),('control','10014',40),
      ('candidate','7',37),('control','7',37),('control','10387',20),('candidate','10387',20)]
plan={'schema':1,'status':'PREDECLARED','purpose':'PRIVATE_P07_STATIC_VIA_MEMO_TRIAL','productionAcceptance':False,
 'sourceAuditSha256':sha((s/'p07-static-via-r1-preparation/source-audit-r3.json').read_bytes()),
 'source':{'control':'scratch/pivot-lower-fusion-r2-preparation/candidate','candidate':'p07-static-via-r1-preparation/candidate'},
 'runtime':{'control':{'sha256':cpuplan['runtimeSha256'],'fileCount':cpuplan['runtimeFiles']},
            'candidate':{'sha256':canary['inputAudit']['beforeSha256'],'fileCount':canary['inputAudit']['fileCountBefore']}},
 'sequence':[{'label':'p07-static-via-r1-%02d-%s-%s'%(i+1,arm,seed),'arm':arm,'seed':seed,'packages':size} for i,(arm,seed,size) in enumerate(rows)],
 'continuationAfterFirstPair':'Continue only with full parity, a positive cold-total gain and at least2percent routing reduction. Otherwise stop with remaining6rows NOT_RUN. This is an experiment resource rule, not a production acceptance threshold.',
 'continuationAfterRepeatedPair':'Minimum paired cold gain must exceed the larger within-arm cold range, and minimum paired routing gain must exceed the larger within-arm routing range. Otherwise stop before smaller-scale checks. Bounded repeated-seed evidence only.',
 'clockBoundary':'Unmodified coordinator cold/proof/routing fields use its existing System.currentTimeMillis-based clock. Host duration uses time.monotonic and retains a wall-minus-monotonic drift check. These fields are not represented as an exact monotonic cold partition; the separately recorded stage profile uses performance.now. No production clock or deadline changes.',
 'requirements':['New owned browser every row; original private cold cache protocol, all proofs, exact non-timing parity and strict negative readers.',
  'No profile query or application clocks added. All consumed source/build inputs unchanged before and after each row.',
  'Reuse GWT5/compiled canaries only under the audited1525-file identical-runtime boundary after the test-only oracle R3 revision.',
  'Preserve all static/live physical checks, ordering, expansion/work counts, signed-long replay, graphs, electrical proofs, cache ownership and cleanup.',
  'No full acceptance matrix, scale completion or normal admission from private results.'],
 'interpretation':'CPU identifies repeated via/rule scans; only immutable per-Search/per-net/per-cell answers are cached. Full-grid clearing and allocation remain measured costs. No predicted savings.',
 'normalLimits':{'maxJobMillis':90000,'maxJobSteps':640,'maxUnitMillis':5000},
 'oracleSha256':sha(oracle),'compiledReviewSha256':sha(inspection.read_bytes())}
planpath=s/'p07-static-via-r1-measurement-plan.json';assert not planpath.exists()
planpath.write_bytes((json.dumps(plan,indent=2)+'\n').encode())
files=['p07-static-via-r1-measurement-plan.json','p07-static-via-r1-preparation/source-audit-r3.json','run_timing.py',
 'validate_current_q30_timing_pair.py','p07-static-via-r3-reference-native.json','p07-static-via-r3-candidate-native6.json','p07-static-via-r1-gwt5.json',
 'p07-static-via-r1-canaries/result.json','p07-static-via-r1-canaries-summary.json','p07-static-via-r1-a07-reader.log',
 'p07-static-via-r1-compiled-inspection/root-review.json','p07-static-via-r3-uncached-oracle.txt',
 'scratch/p07-map-cpu-context.md','scratch/p07-static-via-r1-independent-review.md','scratch/p07-static-via-r2-independent-review.md']
repo_files=['tests/browser/compiled_attribute_acceptance.py','docs/task-evidence/Q30/scale-plan-4/check_coordinator.py','docs/task-evidence/Q30/scale-plan-4/check_d01.py']
def entries(root,paths):return [{'path':p,'sha256':sha((root/p).read_bytes())} for p in paths]
binding={'status':'FROZEN_READY_FOR_FOCUSED_TRIAL','driverSha256':sha((s/'run_p07_static_via_r1_sequence_root.py').read_bytes()),
 'files':entries(s,files),'repoFiles':entries(repo,repo_files),'scope':'Private matched cold experiment only; no production acceptance.'}
out=s/'p07-static-via-r1-execution-binding.json';assert not out.exists();out.write_bytes((json.dumps(binding,indent=2)+'\n').encode())
print(json.dumps({'planSha256':sha(planpath.read_bytes()),'bindingSha256':sha(out.read_bytes()),'driverSha256':binding['driverSha256']}))
