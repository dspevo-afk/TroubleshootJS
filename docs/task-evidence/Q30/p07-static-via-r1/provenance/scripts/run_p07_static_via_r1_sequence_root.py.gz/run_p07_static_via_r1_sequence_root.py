from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
s=Path(__file__).resolve().parent
repo=Path('<REPO_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
bindingraw=(s/'p07-static-via-r1-execution-binding.json').read_bytes();binding=json.loads(bindingraw)
assert binding['status']=='FROZEN_READY_FOR_FOCUSED_TRIAL'
assert sha(Path(__file__).read_bytes())==binding['driverSha256']
plan=json.loads((s/'p07-static-via-r1-measurement-plan.json').read_bytes())
auditraw=(s/'p07-static-via-r1-preparation/source-audit-r3.json').read_bytes();assert sha(auditraw)==plan['sourceAuditSha256']
audit=json.loads(auditraw)
spec=importlib.util.spec_from_file_location('p07_via_runtime_auditor',repo/'tests/browser/compiled_attribute_acceptance.py')
host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
out=s/'p07-static-via-r1-sequence-result.json';assert not out.exists()
result={'status':'RUNNING','bindingSha256':sha(bindingraw),'rows':[],'pairs':[],'notRun':[r['label'] for r in plan['sequence']]}
def save():out.write_bytes((json.dumps(result,indent=2)+'\n').encode())
def unchanged():
    for e in binding['files']:assert sha((s/e['path']).read_bytes())==e['sha256'],e['path']
    for e in binding['repoFiles']:assert sha((repo/e['path']).read_bytes())==e['sha256'],e['path']
    for arm in ['control','candidate']:
        source=s/plan['source'][arm]
        for e in (audit['originalMeasuredInputs'] if arm=='control' else audit['armInputs'][arm]):
            raw=(source/e['path']).read_bytes();assert (len(raw),sha(raw))==(e['bytes'],e['sha256']),arm+':'+e['path']
        current=host.capture_input_manifest(source)
        assert all(current[k]==v for k,v in plan['runtime'][arm].items()),arm
save()
try:
    for index,row in enumerate(plan['sequence']):
        unchanged();label=row['label'];arm=row['arm']
        for f in [s/label,s/(label+'-summary.json'),s/(label+'-spec.json')]:assert not f.exists(),f
        result['activeRow']=row;result['notRun'].remove(label);save();print('START '+label,flush=True)
        args=[sys.executable,'-B',str(s/'run_timing.py'),str(repo),str(s),str(s/plan['source'][arm]),label,row['seed']]
        proc=subprocess.run(args,capture_output=True,text=True);assert proc.returncode==0,proc.stdout[-2200:]+proc.stderr[-2200:]
        summary=json.loads((s/(label+'-summary.json')).read_bytes());result['rows'].append(summary);result.pop('activeRow');save()
        receipt=json.loads((s/label/'result.json').read_bytes())
        assert summary['exitCode']==0 and summary['runnerOutcome']=='PASS' and receipt['cleanup']['status']=='PASS'
        assert receipt['cleanup']['errors']==[] and receipt['cleanup']['ownedSurvivors']==[]
        assert receipt['inputAudit']['beforeSha256']==receipt['inputAudit']['afterSha256']==plan['runtime'][arm]['sha256']
        query='circuitjs.html?tsjChallenge=led&seed=3&tsjDebug=true&tsjVerifyQ30=true&tsjQ30Coordinator=true&tsjQ30Seed='+row['seed']
        assert receipt['cases'][0]['case']['path']==query
        unchanged();print(json.dumps({'label':label,'cold':summary['cold'],'hostSeconds':summary['hostMonotonicSeconds'],'cleanupSeconds':receipt['cleanup']['seconds']}),flush=True)
        if index%2==1:
            pair_index=index//2;tag='p07-static-via-r1-pair-'+str(pair_index+1)
            a,b=plan['sequence'][index-1:index+1]
            candidate=a if a['arm']=='candidate' else b;control=a if a['arm']=='control' else b
            checked=subprocess.run([sys.executable,'-B',str(s/'validate_current_q30_timing_pair.py'),str(s),str(repo),candidate['label'],control['label'],row['seed'],'--tag',tag],capture_output=True,text=True)
            (s/(tag+'.log')).write_bytes((checked.stdout+checked.stderr).encode())
            assert checked.returncode==0,checked.stdout[-1800:]+checked.stderr[-1800:]
            cr=next(x for x in result['rows'] if x['label']==control['label'])['cold'];ca=next(x for x in result['rows'] if x['label']==candidate['label'])['cold']
            gain=cr['elapsedMs']-ca['elapsedMs'];proof_gain=cr['proofElapsedMs']-ca['proofElapsedMs'];route_gain=cr['routingElapsedMs']-ca['routingElapsedMs']
            result['pairs'].append({'status':'PASS','log':tag+'.log','coldGainMs':gain,'proofGainMs':proof_gain,'routeGainMs':route_gain});save()
            if index==1 and (gain<=0 or route_gain<cr['routingElapsedMs']*.02):
                result['status']='STOPPED_INCONCLUSIVE_FIRST_PAIR_RULE';save();break
            if index==3:
                controls=[result['rows'][i]['cold']['elapsedMs'] for i in [0,3]]
                candidates=[result['rows'][i]['cold']['elapsedMs'] for i in [1,2]]
                spread=max(max(controls)-min(controls),max(candidates)-min(candidates))
                route_controls=[result['rows'][i]['cold']['routingElapsedMs'] for i in [0,3]]
                route_candidates=[result['rows'][i]['cold']['routingElapsedMs'] for i in [1,2]]
                route_spread=max(max(route_controls)-min(route_controls),max(route_candidates)-min(route_candidates))
                result['repeatColdRangeMs']=spread;result['repeatRouteRangeMs']=route_spread
                if min(p['coldGainMs'] for p in result['pairs'])<=spread or min(p['routeGainMs'] for p in result['pairs'])<=route_spread:
                    result['status']='STOPPED_INCONCLUSIVE_REPEAT_RULE';save();break
    else:
        result['status']='FOCUSED_FOUR_PAIRS_PASS_PENDING_ROOT_REVIEW';save()
except BaseException as error:
    if 'activeRow' in result:result['failedRow']=result.pop('activeRow')
    result['status']='STOPPED_FAILURE';result['failure']=str(error);save();raise
