from pathlib import Path
import hashlib,json,sys
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
base=s/'scratch/pivot-lower-fusion-r2-preparation'
auditraw=(base/'source-audit.json').read_bytes()
assert sha(auditraw)=='0d27e176dc46afb4db91316570f4674e52b51ce2b462c64f6b6a37b98cbec197'
records=json.loads(auditraw)['armInputs']['candidate'];assert len(records)==1340
original=base/'candidate'
draft=s/'scratch/p07-static-via-r1-draft'
sourcepath='src/com/lushprojects/circuitjs1/client/PcbLayerRoutingPrototype.java'
testpath='tests/contracts/P07StaticViaLegalityOracleContractTest.java'
scriptpath='scripts/verify-current-contracts.ps1'
overlay=(draft/'PcbLayerRoutingPrototype.java').read_bytes()
assert sha(overlay)=='93da7656198ed962c6ec83d1d5f271004a85dc3bf972a3a0479c8a28ed6ef658'
oracle=(draft/testpath).read_bytes()
assert len(sys.argv)==2 and sha(oracle)==sys.argv[1]
assert b'PASS: P07_STATIC_VIA_ORACLE_R1' in oracle
driver=(original/scriptpath).read_text(encoding='utf-8')
needle="    [string[]]$Suite = @(),"
assert driver.count(needle)==1
driver=driver.replace(needle,needle+"\n    [ValidateSet('capture','compare','')][string]$P07OracleMode = '',\n    [string]$P07OraclePath = '',")
needle="        @{ Name = 'P07TwoLayerContractTest'; Marker = 'P07 two-layer contracts ' },"
assert driver.count(needle)==1
driver=driver.replace(needle,"        @{ Name = 'P07StaticViaLegalityOracleContractTest'; Marker = 'P07_STATIC_VIA_ORACLE_R1' },\n"+needle)
needle="        if ($testClass -eq 'A03IdentityContractTest') {"
assert driver.count(needle)==1
driver=driver.replace(needle,"""        if ($testClass -eq 'P07StaticViaLegalityOracleContractTest') {
            if (-not $P07OracleMode -or -not [IO.Path]::IsPathRooted($P07OraclePath)) {
                throw 'P07 oracle requires explicit capture/compare mode and absolute evidence path.'
            }
            $testArguments += ('--' + $P07OracleMode + '=' + $P07OraclePath)
        }
"""+needle)
driverraw=driver.encode('utf-8')
prep=s/'p07-static-via-r1-preparation';assert not prep.exists()
prep.mkdir();inputs={}
for arm in ['control','candidate']:
    target=prep/arm;target.mkdir()
    for e in records:
        raw=(original/e['path']).read_bytes()
        assert (len(raw),sha(raw))==(e['bytes'],e['sha256']),e['path']
        if e['path']==scriptpath:raw=driverraw
        elif arm=='candidate' and e['path']==sourcepath:raw=overlay
        out=target/e['path'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
    (target/testpath).write_bytes(oracle)
    entries=[]
    for path in sorted([e['path'] for e in records]+[testpath]):
        raw=(target/path).read_bytes();entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
    inputs[arm]=entries
assert len(inputs['control'])==len(inputs['candidate'])==1341
differences=[a['path'] for a,b in zip(inputs['candidate'],inputs['control']) if a!=b]
assert differences==[sourcepath]
receipt={'status':'SOURCE_ONLY_PREPARED_NOT_VALIDATED','baselineAuditSha256':sha(auditraw),
 'originalMeasuredSource':'scratch/pivot-lower-fusion-r2-preparation/candidate',
 'generatedWarCopied':False,'oracleSha256':sha(oracle),'overlaySha256':sha(overlay),
 'betweenArmChangedInputs':differences,'sharedHarnessChanges':[scriptpath,testpath],
 'baselineInputCount':len(records),'originalMeasuredInputs':records,'armInputs':inputs}
(prep/'source-audit.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({'status':receipt['status'],'sourceAuditSha256':sha((prep/'source-audit.json').read_bytes()),'candidateInputs':1341,'betweenArmChangedInputs':differences,'sharedHarnessChanges':receipt['sharedHarnessChanges']}))
