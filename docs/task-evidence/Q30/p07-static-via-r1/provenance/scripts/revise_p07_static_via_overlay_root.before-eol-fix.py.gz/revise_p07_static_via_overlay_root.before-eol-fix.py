from pathlib import Path
import difflib,gzip,hashlib,json
s=Path(__file__).resolve().parent
d=s/'scratch/p07-static-via-r1-draft'
sha=lambda b:hashlib.sha256(b).hexdigest()
p=d/'PcbLayerRoutingPrototype.java';old=p.read_bytes()
assert sha(old)=='4b66e36260ecf703069e5f90097e18bc10726911e13911a69668906b0161f574'
for name in ['PcbLayerRoutingPrototype.java','source-manifest.json','exact-diff.patch.gz','README.md']:
    target=d/(name+'.pre-root-int-review');assert not target.exists();target.write_bytes((d/name).read_bytes())
text=old.decode()
text=text.replace('viaStaticMemo=new byte[cells];','viaStaticMemo=new byte[policy.transitions==0?0:cells];')
before='''            long dx=(long)x-minX,dy=(long)y-minY;
            if(dx<0 || dy<0 || dx%GRID!=0 || dy%GRID!=0) return -1;
            long gx=dx/GRID,gy=dy/GRID;
            if(gx>=width || gy>=height) return -1;
            return (int)(gy*width+gx);'''
after='''            if(x<minX || y<minY) return -1;
            int dx=x-minX,dy=y-minY;
            // Nonnegative mathematical differences that overflow int become
            // negative. Any valid grid difference fits the bounded cell grid.
            if(dx<0 || dy<0 || dx%GRID!=0 || dy%GRID!=0) return -1;
            int gx=dx/GRID,gy=dy/GRID;
            if(gx>=width || gy>=height) return -1;
            return gy*width+gx;'''
assert text.count(before)==1
text=text.replace(before,after);p.write_bytes(text.encode())
baseline=(s/'scratch/pivot-lower-fusion-r2-preparation/candidate/src/com/lushprojects/circuitjs1/client/PcbLayerRoutingPrototype.java').read_bytes()
assert sha(baseline)=='5996f040f1243039b56e3e5cbff9fc904a902af0c5d9da9a507a84b2b0a4db7f'
diff=''.join(difflib.unified_diff(baseline.decode().splitlines(True),text.splitlines(True),fromfile='a/PcbLayerRoutingPrototype.java',tofile='b/PcbLayerRoutingPrototype.java',n=5)).replace('\r\n','\n').encode()
(d/'exact-diff.patch.gz').write_bytes(gzip.compress(diff,mtime=0))
manifest=json.loads((d/'source-manifest.json').read_bytes())
manifest['overlay']['sha256']=sha(p.read_bytes())
manifest['overlay']['memo_capacity']='one byte per validated cell, at most MAX_CELLS; empty array for transitions=0'
manifest['diff']['sha256']=sha((d/'exact-diff.patch.gz').read_bytes())
manifest['rootSourceReview']={'status':'SOURCE_REVISED_NOT_EXECUTED','priorOverlaySha256':sha(old),'change':'Guarded primitive-int indexing avoids emulated longs; no per-cell memo allocation when transitions=0. Full-grid clear remains bounded and its runtime effect remains to be measured.','independentReviewSha256':sha((s/'scratch/p07-static-via-r1-independent-review.md').read_bytes())}
(d/'source-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
readme=(d/'README.md').read_text().replace('22fee1692ff106abbce9a74f32327232964f9e741514023e9a230ccf33edfeab',manifest['diff']['sha256'])
readme=readme.replace('The cell conversion uses checked `long` coordinates','The cell conversion uses guarded primitive `int` coordinates (reject coordinates before the origin, negative overflowed differences, misalignment and out-of-bounds cells)')
readme+='\nRoot source review revision: the original long-key overlay, manifest, README and diff are preserved with `.pre-root-int-review` suffixes. The guarded integer form has the same valid-cell domain because `MAX_CELLS` bounds each dimension and the final product; transitions-zero policies allocate an empty memo. No tests or timing have yet validated this revision.\n'
(d/'README.md').write_bytes(readme.encode())
print(json.dumps({'overlaySha256':manifest['overlay']['sha256'],'diffSha256':manifest['diff']['sha256'],'reviewSha256':manifest['rootSourceReview']['independentReviewSha256']}))
