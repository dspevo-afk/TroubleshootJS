from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
p=s/'p07-static-via-r1-compiled-inspection'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(p/'result.json').read_bytes();assert sha(raw)=='9d6b2587572c555aaead5db4f89838a2da894902fa9d16e9f227686d017eb747'
d=json.loads(raw);assert len(d['rows'])==5
normalized_keys=set();records=[]
for row in d['rows']:
    bodies={}
    for name,e in row['bodies'].items():
        b=(p/e['path']).read_bytes();assert sha(b)==e['sha256'];bodies[name]=b.decode()
    key=bodies['$viaMemoCell']
    assert row['calledSymbols']['$viaMemoCell']==[]
    normalized_keys.add(key.replace('function '+row['names']['$viaMemoCell']+'(','function KEY(',1))
    face=[x['jsName'] for x in row['calledSymbols']['$viaFits'] if x['className']=='com.lushprojects.circuitjs1.client.PcbNetRouter$Router' and x['memberName']=='$freeLayerCell']
    assert len(face)==1
    body=bodies['$viaFits'];call=face[0]
    assert body.count(call+'(')==2
    live='if(!'+call+'(a.k[0],c,d,b)||!'+call+'(a.k[1],c,d,b))return false;'
    assert live in body
    assert body.index('if(t==1)return false;')<body.index(live)<body.index('if(t==3)return false;')
    assert body.count('a.I[j]=')==5
    assert any(x['className']=='java.util.Arrays' and x['memberName']=='fill' for x in row['calledSymbols']['$viaStaticState'])
    assert any(x['className']=='java.lang.String' and x['memberName']=='$equals' for x in row['calledSymbols']['$viaStaticState'])
    records.append({'strongName':row['strongName'],'keyBodySha256':row['bodies']['$viaMemoCell']['sha256'],'liveFaceCalls':2,'memoReadWriteObserved':True})
assert len(normalized_keys)==1
key=next(iter(normalized_keys))
assert 'if(b<a.p||c<a.q)return -1;' in key and 'if(d<0||e<0||d%10!=0||e%10!=0)return -1;' in key
assert 'if(f>=a.L||g>=a.n)return -1;return g*a.L+f}' in key
result={'status':'PASS_COMPILED_MEMO_MECHANISM_ONLY','extractionSha256':sha(raw),'permutations':records,'normalizedKey':key,'limits':'Five decoded permutations inspected without JavaScript execution. Static memo and unchanged live face short-circuit observed; key has primitive arithmetic and no emulated-long helpers. Existing long helpers in live hole bounds remain. No runtime savings or qualification claim.'}
out=p/'root-review.json';assert not out.exists();out.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({'status':result['status'],'sha256':sha(out.read_bytes()),'permutations':len(records)}))
