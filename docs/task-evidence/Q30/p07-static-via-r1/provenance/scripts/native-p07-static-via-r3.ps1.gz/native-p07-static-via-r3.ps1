param([Parameter(Mandatory=$true)][string]$SourceRoot,[Parameter(Mandatory=$true)][string]$Label,[Parameter(Mandatory=$true)][ValidateSet('capture','compare')][string]$Mode)
$ErrorActionPreference='Stop'
$q30Suites=if($Mode -eq 'capture'){@('P07StaticViaLegalityOracleContractTest')}else{@('P07StaticViaLegalityOracleContractTest','P07TwoLayerContractTest','PcbLayerRoutingResumptionContractTest','MediumBoardPhysicalPolicyContractTest','Q30GenerationMeasurementBudgetContractTest','Q30NormalExecutionPolicyContractTest')}
$q30Watch=[Diagnostics.Stopwatch]::StartNew()
Push-Location -LiteralPath $SourceRoot
try {
  & ./scripts/verify-current-contracts.ps1 -JavaHome '<PRIVATE_PATH> -Suite $q30Suites -P07OracleMode $Mode -P07OraclePath (Join-Path $PSScriptRoot 'p07-static-via-r3-uncached-oracle.txt') -ReceiptOutputPath (Join-Path $PSScriptRoot ($Label+'-receipt.txt')) *> (Join-Path $PSScriptRoot ($Label+'.log'))
  $q30Exit=$LASTEXITCODE
} finally { Pop-Location }
$q30Watch.Stop()
[ordered]@{status=$(if($q30Exit -eq 0){'PASS'}else{'FAIL'});exitCode=$q30Exit;elapsedSeconds=$q30Watch.Elapsed.TotalSeconds;phase='focused uncached predicate/full-route oracle and applicable routing/physical/resumption/budget contracts including maintained cleanup';mode=$Mode;suites=$q30Suites} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.json'))
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.json'))
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.log')) -Tail 16
exit $q30Exit
