from pathlib import Path
import csv,hashlib,importlib.util,json,re
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
path=s/'cpu-profile-10ms-r1-draft/cpu_profile_10ms.py'
assert sha(path.read_bytes())=='1197d7f81653361a91f30ae561fc3e928f96446b6d658c6625e317bb3573c43b'
spec=importlib.util.spec_from_file_location('cpu_decoder_only',path)
decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
root=s/'p07-static-via-r1-preparation/candidate'
out=s/'p07-static-via-r1-compiled-inspection';assert not out.exists();out.mkdir()
rows=[]
for file in sorted((root/'war/WEB-INF/deploy/circuitjs1/symbolMaps').glob('*.symbolMap')):
    strong=file.stem
    with file.open(encoding='utf8',newline='') as stream:
        symbols=list(csv.DictReader((l for l in stream if not l.startswith('#')),fieldnames=decoder.GWT_SYMBOL_FIELDS))
    methods=['$viaFits','$viaMemoCell','$viaStaticState']
    selected=[x for x in symbols if x['className']=='com.lushprojects.circuitjs1.client.PcbLayerRoutingPrototype$Search' and x['memberName'] in methods]
    assert len(selected)==3
    names={x['memberName']:x['jsName'] for x in selected}
    evidence,cache,payload=decoder._read_gwt_download_payload(root,strong)
    code=payload.decode();bodies={};called={}
    for member,name in names.items():
        start=code.index('function '+name+'(');end=code.index('\nfunction ',start);body=code[start:end]
        target=strong+'-'+member[1:]+'.js';(out/target).write_bytes(body.encode());bodies[member]={'path':target,'sha256':sha(body.encode())}
        calls=set(re.findall(r'\b([A-Za-z_$][\w$]*)\(',body))-{name,'if','for','while'}
        called[member]=[{k:x[k] for k in ['jsName','className','memberName']} for x in symbols if x['jsName'] in calls]
    rows.append({'strongName':strong,'names':names,'bundle':evidence,'symbolMapSha256':sha(file.read_bytes()),'bodies':bodies,'calledSymbols':called})
assert len(rows)==5
result={'status':'EXTRACTED_PENDING_ROOT_MECHANISM_REVIEW','rows':rows,'limits':'Exact decoded method extraction and symbol attribution only; no execution or runtime benefit claim.'}
(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'status':result['status'],'permutations':len(rows),'firstStrongName':rows[0]['strongName'],'resultSha256':sha((out/'result.json').read_bytes())}))
for e in rows[0]['bodies'].values():print((out/e['path']).read_text())
