package com.lushprojects.circuitjs1.client;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Vector;

/**
 * Two-variant oracle for the P07 static via-legality memo.
 *
 * Compile this same class once with the frozen source and once with the draft
 * overlay.  The frozen run captures the uncached Search.viaFits output; the
 * overlay run compares its reflection-driven output byte-for-byte.
 */
public final class P07StaticViaLegalityOracleContractTest {
    private static final String HEADER = "P07_STATIC_VIA_ORACLE_R1";
    private static final PcbLayerRoutingPrototype.Policy[] GRID_POLICIES = {
        PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER,
        PcbLayerRoutingPrototype.Policy.FULLER_TWO_LAYER
    };

    public static void main(String[] args) throws Exception {
        String capture = option(args,"--capture=");
        String compare = option(args,"--compare=");
        if ((capture == null) == (compare == null))
            throw new IllegalArgumentException("Use exactly one of --capture=PATH or --compare=PATH");
        String actual = report();
        if (capture != null) {
            Path path = Paths.get(capture);
            Path parent = path.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(path,actual.getBytes(StandardCharsets.UTF_8));
            System.out.println("PASS: P07_STATIC_VIA_ORACLE_R1 captured uncached/reference report path=" + path +
                " bytes=" + actual.getBytes(StandardCharsets.UTF_8).length);
        } else {
            String expected = new String(Files.readAllBytes(Paths.get(compare)),StandardCharsets.UTF_8);
            require(expected.equals(actual),firstDifference(expected,actual));
            System.out.println("PASS: P07_STATIC_VIA_ORACLE_R1 static-via overlay matches frozen oracle bytes=" +
                actual.getBytes(StandardCharsets.UTF_8).length);
        }
    }

    private static String option(String[] args,String prefix) {
        for (String arg:args) if (arg.startsWith(prefix)) return arg.substring(prefix.length());
        return null;
    }

    private static String report() throws Exception {
        StringBuilder result = new StringBuilder();
        result.append(HEADER).append('\n');
        gridPredicateRecords(result);
        netSwitchRecords(result);
        barrierNetSwitchRecords(result);
        boundaryRecords(result);
        mutationRecords(result);
        routeRecords(result);
        return result.toString();
    }

    /** Calls the real Search.viaFits for every validated cell and exact board net. */
    private static void gridPredicateRecords(StringBuilder result) throws Exception {
        for (boolean linked:new boolean[] {false,true}) {
            for (PcbLayerRoutingPrototype.Policy policy:GRID_POLICIES) {
                P06FactoryLinkFixtures.Fixture fixture=fixture(linked);
                SearchAccess search=new SearchAccess(fixture,policy);
                int trueCount=0;
                Vector<String> nets=fixture.board.getNetIds();
                for (String net:nets) {
                    for (int cell=0;cell<search.cells;cell++) {
                        int x=search.x(cell),y=search.y(cell);
                        CallResult value=search.viaFits(net,x,y);
                        CallResult repeat=search.viaFits(net,x,y);
                        require(value.text.equals(repeat.text),
                            "same cell/net repeat changed result fixture="+linked+" policy="+
                            policy+" net="+net+" cell="+cell);
                        require(value.isBoolean(),
                            "valid cell/net returned non-boolean fixture="+linked+" policy="+
                            policy+" net="+net+" cell="+cell+" result="+value.text);
                        if (value.isTrue()) trueCount++;
                        line(result,"CELL",linked,policy.name(),net,cell,x,y,value.text,repeat.text);
                    }
                }
                line(result,"CELL_SUMMARY",linked,policy.name(),nets.size(),search.cells,trueCount);
            }
        }
    }

    /** Exercises A/B/A net switching with equal-valued, distinct String objects. */
    private static void netSwitchRecords(StringBuilder result) throws Exception {
        P06FactoryLinkFixtures.Fixture fixture=fixture(true);
        SearchAccess search=new SearchAccess(fixture,PcbLayerRoutingPrototype.Policy.FULLER_TWO_LAYER);
        Vector<String> nets=fixture.board.getNetIds();
        if (nets.size()<2) throw new AssertionError("P07 fixture needs two exact nets for memo reset");
        String first=nets.get(0),second=nets.get(1);
        Witness witness=firstTrue(search,first);
        if (witness==null) throw new AssertionError("No via witness for net switching");
        String firstCopy=new String(first),secondCopy=new String(second),againCopy=new String(first);
        require(firstCopy!=first && firstCopy.equals(first) &&
            secondCopy!=second && secondCopy.equals(second),
            "A/B/A net-switch witness must use equal-valued distinct String objects");
        CallResult a=search.viaFits(firstCopy,witness.x,witness.y);
        CallResult b=search.viaFits(secondCopy,witness.x,witness.y);
        CallResult again=search.viaFits(againCopy,witness.x,witness.y);
        line(result,"NET_SWITCH",first,second,witness.x,witness.y,a.text,b.text,again.text,
            firstCopy!=first,secondCopy!=second);
    }

    /** Uses the P07 isolation-barrier geometry to make the B net reject at A's cell. */
    private static void barrierNetSwitchRecords(StringBuilder result) throws Exception {
        BarrierFixture fixture=barrierFixture();
        SearchAccess search=new SearchAccess(fixture.board,fixture.layout,
            PcbLayerRoutingPrototype.Policy.RESTRICTED_TWO_LAYER);
        String first=fixture.board.getNet("PRIMARY").getId();
        String second=fixture.board.getNet("SECONDARY").getId();
        String firstCopy=new String(first),secondCopy=new String(second),againCopy=new String(first);
        require(firstCopy!=first && firstCopy.equals(first) &&
            secondCopy!=second && secondCopy.equals(second) &&
            againCopy!=first && againCopy.equals(first),
            "barrier A/B/A witness must use equal-valued distinct String objects");
        int x=300,y=300;
        CallResult a=search.viaFits(firstCopy,x,y);
        CallResult b=search.viaFits(secondCopy,x,y);
        CallResult again=search.viaFits(againCopy,x,y);
        require(a.isTrue() && b.isFalse() && again.isTrue(),
            "barrier A/B/A witness must be B:true/B:false/B:true at one grid cell: "+
            a.text+"/"+b.text+"/"+again.text);
        line(result,"BARRIER_NET_SWITCH",first,second,x,y,a.text,b.text,again.text,
            firstCopy!=first,secondCopy!=second,againCopy!=first);
    }

    /** Exercises non-grid and extreme integer coordinates through the uncached fallback. */
    private static void boundaryRecords(StringBuilder result) throws Exception {
        P06FactoryLinkFixtures.Fixture fixture=fixture(true);
        SearchAccess search=new SearchAccess(fixture,PcbLayerRoutingPrototype.Policy.FULLER_TWO_LAYER);
        String net=fixture.board.getNetIds().get(0);
        Witness witness=firstTrue(search,net);
        if (witness==null) throw new AssertionError("No via witness for coordinate boundaries");
        int[][] points={
            {witness.x+1,witness.y}, {witness.x,witness.y+1},
            {witness.x+PcbLayerRoutingPrototype.GRID,witness.y},
            {witness.x-PcbLayerRoutingPrototype.GRID,witness.y},
            {Integer.MIN_VALUE,Integer.MIN_VALUE},
            {Integer.MAX_VALUE,Integer.MAX_VALUE},
            {Integer.MIN_VALUE,witness.y}, {Integer.MAX_VALUE,witness.y}
        };
        for (int[] point:points)
            line(result,"BOUNDARY",net,point[0],point[1],search.viaFits(net,point[0],point[1]).text);
    }

    /**
     * Checks live face occupancy, current-hole clearance, via count, and the
     * prior-hole same-net/foreign-net coincidence guard after a static pass.
     */
    private static void mutationRecords(StringBuilder result) throws Exception {
        final boolean linked=true;
        final PcbLayerRoutingPrototype.Policy policy=PcbLayerRoutingPrototype.Policy.FULLER_TWO_LAYER;
        P06FactoryLinkFixtures.Fixture witnessFixture=fixture(linked);
        SearchAccess witnessSearch=new SearchAccess(witnessFixture,policy);
        String net=witnessFixture.board.getNetIds().get(0);
        Witness witness=firstTrue(witnessSearch,net);
        if (witness==null) throw new AssertionError("No static-pass witness for live mutation checks");
        String foreign=otherNet(witnessFixture.board.getNetIds(),net);

        P06FactoryLinkFixtures.Fixture face0Fixture=fixture(linked);
        SearchAccess face0Search=new SearchAccess(face0Fixture,policy);
        CallResult face0Before=face0Search.viaFits(new String(net),witness.x,witness.y);
        require(face0Before.isTrue(),"face-0 occupancy needs a cached static pass");
        face0Search.occupyFace(0,witness.x,witness.y,foreign);
        CallResult face0After=face0Search.viaFits(new String(net),witness.x,witness.y);
        require(face0After.isFalse(),"foreign face-0 occupancy must return B:false after cached pass");
        line(result,"MUTATION",linked,policy.name(),"occupancy-face0",net,foreign,witness.x,witness.y,
            face0Before.text,face0After.text);

        P06FactoryLinkFixtures.Fixture face1Fixture=fixture(linked);
        SearchAccess face1Search=new SearchAccess(face1Fixture,policy);
        CallResult face1Before=face1Search.viaFits(new String(net),witness.x,witness.y);
        require(face1Before.isTrue(),"face-1 occupancy needs a cached static pass");
        face1Search.occupyFace(1,witness.x,witness.y,foreign);
        CallResult face1After=face1Search.viaFits(new String(net),witness.x,witness.y);
        require(face1After.isFalse(),"foreign face-1 occupancy must return B:false after cached pass");
        line(result,"MUTATION",linked,policy.name(),"occupancy-face1",net,foreign,witness.x,witness.y,
            face1Before.text,face1After.text);
        line(result,"MUTATION_OCCUPANCY_BOTH",linked,policy.name(),net,foreign,witness.x,witness.y,
            face0Before.text,face0After.text,face1Before.text,face1After.text);

        HoleMutation hole=findHoleMutation(linked,policy,net,foreign,witness);
        line(result,"MUTATION",linked,policy.name(),"hole-clearance",net,foreign,
            hole.x,hole.y,hole.holeX,hole.holeY,hole.before.text,hole.after.text);

        P06FactoryLinkFixtures.Fixture sameFixture=fixture(linked);
        SearchAccess sameSearch=new SearchAccess(sameFixture,policy);
        sameFixture.layout.addHole(PcbTwoLayerRules.via("oracle-same-net-hole",net,witness.x,witness.y));
        CallResult same=sameSearch.viaFits(new String(net),witness.x,witness.y);
        require(same.isTrue(),"same-net prior-hole coincidence must return B:true");
        P06FactoryLinkFixtures.Fixture wrongFixture=fixture(linked);
        SearchAccess wrongSearch=new SearchAccess(wrongFixture,policy);
        wrongFixture.layout.addHole(PcbTwoLayerRules.via("oracle-foreign-hole",foreign,witness.x,witness.y));
        CallResult wrong=wrongSearch.viaFits(new String(net),witness.x,witness.y);
        require(wrong.isFalse(),"foreign prior-hole coincidence must return B:false");
        line(result,"PRIOR_HOLE",net,foreign,witness.x,witness.y,same.text,wrong.text);

        P06FactoryLinkFixtures.Fixture cappedFixture=fixture(linked);
        SearchAccess cappedSearch=new SearchAccess(cappedFixture,policy);
        CallResult capBefore=cappedSearch.viaFits(new String(net),witness.x,witness.y);
        require(capBefore.isTrue(),"via-limit mutation needs a cached static pass");
        for (int index=0;index<policy.vias;index++)
            cappedFixture.layout.addHole(PcbTwoLayerRules.via("oracle-cap-"+index,foreign,
                witness.x+(index+1)*PcbLayerRoutingPrototype.GRID,witness.y+1000));
        CallResult capped=cappedSearch.viaFits(new String(net),witness.x,witness.y);
        require(capped.isFalse(),"via count must return B:false after cached pass");
        line(result,"VIA_LIMIT",policy.name(),net,policy.vias,capBefore.text,capped.text);
    }

    private static HoleMutation findHoleMutation(boolean linked,
            PcbLayerRoutingPrototype.Policy policy,String net,String foreign,Witness witness) throws Exception {
        int[][] deltas={
            {PcbLayerRoutingPrototype.GRID,0}, {-PcbLayerRoutingPrototype.GRID,0},
            {0,PcbLayerRoutingPrototype.GRID}, {0,-PcbLayerRoutingPrototype.GRID}
        };
        for (int[] delta:deltas) {
            int hx=witness.x+delta[0],hy=witness.y+delta[1];
            P06FactoryLinkFixtures.Fixture fixture=fixture(linked);
            SearchAccess search=new SearchAccess(fixture,policy);
            CallResult before=search.viaFits(new String(net),witness.x,witness.y);
            if (!before.isTrue()) continue;
            fixture.layout.addHole(PcbTwoLayerRules.via("oracle-clearance-hole",foreign,hx,hy));
            CallResult after=search.viaFits(new String(net),witness.x,witness.y);
            if (after.isFalse()) return new HoleMutation(witness.x,witness.y,hx,hy,before,after);
        }
        throw new AssertionError("No adjacent live-hole clearance witness after cached pass");
    }

    /** Compares final route identity, result accounting, and typed rejection. */
    private static void routeRecords(StringBuilder result) {
        for (boolean linked:new boolean[] {false,true}) {
            for (PcbLayerRoutingPrototype.Policy policy:PcbLayerRoutingPrototype.Policy.values()) {
                P06FactoryLinkFixtures.Fixture fixture=fixture(linked);
                String before=fixture.layout.geometryFingerprint();
                PcbLayerRoutingPrototype.Result route=PcbLayerRoutingPrototype.route(
                    fixture.board,fixture.layout,policy,P06FactoryLinkFixtures.OBSERVER);
                String after=fixture.layout.geometryFingerprint();
                require(before.equals(after),"route mutated source placement linked="+linked+" policy="+policy);
                String routed=route.accepted()?route.layout.geometryFingerprint():"";
                line(result,"ROUTE",linked,policy.name(),route.outcome,route.accepted(),
                    route.expansions,route.orderings,route.vias,route.links,before,after,routed);
            }
        }
    }

    private static P06FactoryLinkFixtures.Fixture fixture(boolean linked) {
        return new P06FactoryLinkFixtures.Fixture(true,0,0,!linked);
    }

    private static BarrierFixture barrierFixture() {
        TroubleshootBoard board=new TroubleshootBoard("P07_ORACLE_ISOLATION");
        board.addNet(new BoardNet("PRIMARY")); board.addNet(new BoardNet("SECONDARY"));
        PcbBoardLayout layout=new PcbBoardLayout(1100,650,
            new Rectangle(100,100,600,400),new Rectangle(820,120,200,400));
        addBarrierPoint(board,layout,"P1","PRIMARY",170,200);
        addBarrierPoint(board,layout,"P2","PRIMARY",270,200);
        addBarrierPoint(board,layout,"S1","SECONDARY",530,200);
        addBarrierPoint(board,layout,"S2","SECONDARY",630,200);
        Vector<PcbPlacementConstraints.Part> parts=new Vector<PcbPlacementConstraints.Part>();
        for(String id:board.getComponentIds()) {
            String domain=id.startsWith("P")?"PRIMARY":"SECONDARY";
            parts.add(new PcbPlacementConstraints.Part(id,domain,domain,domain,
                PcbPlacementConstraints.Anchor.NONE,20));
        }
        Vector<PcbPlacementConstraints.Barrier> barriers=
            new Vector<PcbPlacementConstraints.Barrier>();
        barriers.add(new PcbPlacementConstraints.Barrier("PRIMARY","SECONDARY",80));
        board.setPlacementConstraints(new PcbPlacementConstraints(parts,barriers));
        board.validate();
        return new BarrierFixture(board,layout);
    }

    private static void addBarrierPoint(TroubleshootBoard board,PcbBoardLayout layout,
            String id,String net,int x,int y) {
        PhysicalPackage physical=P06FactoryLinkFixtures.TEST_POINT;
        BoardComponent component=new BoardComponent(id,"STRUCTURAL",physical);
        board.addComponent(component);
        board.addPad(new BoardPad(id+".1",id,"1",net));
        PcbPackagePose reference=new PcbPackagePose(100,100,PcbRotation.DEG_0,
            PcbBoardSide.BOTTOM);
        Point local=physical.getGeometry().placedAt(reference).getPadPoint(0);
        PcbPackagePose pose=new PcbPackagePose(100+x-local.x,100+y-local.y,
            PcbRotation.DEG_0,PcbBoardSide.BOTTOM);
        PcbFootprint footprint=PcbFootprint.fromPhysicalPackage(component,pose,
            physical.getGeometry());
        layout.addComponent(footprint.getPlacement());
        for(PcbPadPlacement pad:footprint.getPads()) layout.addPad(pad);
    }

    private static Witness firstTrue(SearchAccess search,String net) throws Exception {
        for (int cell=0;cell<search.cells;cell++) {
            int x=search.x(cell),y=search.y(cell);
            if (search.viaFits(net,x,y).isTrue()) return new Witness(net,cell,x,y);
        }
        return null;
    }

    private static String otherNet(Vector<String> nets,String net) {
        for (String candidate:nets) if (!net.equals(candidate)) return candidate;
        throw new AssertionError("Fixture needs a foreign net");
    }

    private static void line(StringBuilder result,Object... values) {
        for (int i=0;i<values.length;i++) {
            if (i>0) result.append('|');
            result.append(escape(String.valueOf(values[i])));
        }
        result.append('\n');
    }

    private static String escape(String value) {
        return value.replace("\\","\\\\").replace("|","\\p").replace("\r","\\r").replace("\n","\\n");
    }

    private static String firstDifference(String expected,String actual) {
        int index=0,limit=Math.min(expected.length(),actual.length());
        while (index<limit && expected.charAt(index)==actual.charAt(index)) index++;
        int line=1;
        for (int i=0;i<index;i++) if (expected.charAt(i)=='\n') line++;
        int from=Math.max(0,index-100),to=Math.min(actual.length(),index+180);
        return "P07 static-via oracle mismatch at line "+line+" offset "+index+
            " expected="+quote(expected.substring(from,Math.min(expected.length(),index+180)))+
            " actual="+quote(actual.substring(from,to));
    }

    private static String quote(String value) { return "["+escape(value)+"]"; }

    private static void require(boolean condition,String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static final class Witness {
        final String net; final int cell,x,y;
        Witness(String net,int cell,int x,int y) { this.net=net; this.cell=cell; this.x=x; this.y=y; }
    }

    private static final class HoleMutation {
        final int x,y,holeX,holeY; final CallResult before,after;
        HoleMutation(int x,int y,int holeX,int holeY,CallResult before,CallResult after) {
            this.x=x; this.y=y; this.holeX=holeX; this.holeY=holeY;
            this.before=before; this.after=after;
        }
    }

    private static final class BarrierFixture {
        final TroubleshootBoard board;
        final PcbBoardLayout layout;
        BarrierFixture(TroubleshootBoard board,PcbBoardLayout layout) {
            this.board=board; this.layout=layout;
        }
    }

    private static final class CallResult {
        final String text;
        private CallResult(String text) { this.text=text; }
        boolean isTrue() { return "B:true".equals(text); }
        boolean isFalse() { return "B:false".equals(text); }
        boolean isBoolean() { return isTrue() || isFalse(); }
        static CallResult value(boolean value) { return new CallResult("B:"+value); }
        static CallResult failure(Throwable failure) {
            Throwable cause=failure;
            if (failure instanceof InvocationTargetException &&
                    ((InvocationTargetException)failure).getCause()!=null)
                cause=((InvocationTargetException)failure).getCause();
            return new CallResult("E:"+cause.getClass().getName()+":"+String.valueOf(cause.getMessage()));
        }
    }

    private static final class SearchAccess {
        final Object search;
        final Method viaFitsMethod,xMethod;
        final Method yMethod;
        final Field facesField;
        final int cells;
        SearchAccess(P06FactoryLinkFixtures.Fixture fixture,
                PcbLayerRoutingPrototype.Policy policy) throws Exception {
            this(fixture.board,fixture.layout,policy);
        }
        SearchAccess(TroubleshootBoard board,PcbBoardLayout layout,
                PcbLayerRoutingPrototype.Policy policy) throws Exception {
            Class<?> searchType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$Search");
            Class<?> budgetType=Class.forName(PcbLayerRoutingPrototype.class.getName()+"$Budget");
            Constructor<?> budgetConstructor=budgetType.getDeclaredConstructor(int.class);
            budgetConstructor.setAccessible(true);
            Object budget=budgetConstructor.newInstance(PcbLayerRoutingPrototype.MAX_EXPANSIONS);
            Constructor<?> searchConstructor=searchType.getDeclaredConstructor(
                TroubleshootBoard.class,PcbBoardLayout.class,PcbLayerRoutingPrototype.Policy.class,
                SeededPcbLayoutGenerator.AttemptObserver.class,budgetType,int.class);
            searchConstructor.setAccessible(true);
            search=searchConstructor.newInstance(board,layout,policy,
                P06FactoryLinkFixtures.OBSERVER,budget,0);
            viaFitsMethod=searchType.getDeclaredMethod("viaFits",String.class,int.class,int.class);
            viaFitsMethod.setAccessible(true);
            xMethod=searchType.getDeclaredMethod("x",int.class); xMethod.setAccessible(true);
            yMethod=searchType.getDeclaredMethod("y",int.class); yMethod.setAccessible(true);
            Field cellsField=searchType.getDeclaredField("cells"); cellsField.setAccessible(true);
            cells=cellsField.getInt(search);
            facesField=searchType.getDeclaredField("faces"); facesField.setAccessible(true);
        }
        int x(int cell) throws Exception { return ((Integer)xMethod.invoke(search,cell)).intValue(); }
        int y(int cell) throws Exception { return ((Integer)yMethod.invoke(search,cell)).intValue(); }
        CallResult viaFits(String net,int x,int y) {
            try { return CallResult.value(((Boolean)viaFitsMethod.invoke(search,net,x,y)).booleanValue()); }
            catch (Throwable failure) { return CallResult.failure(failure); }
        }
        void occupyFace(int faceIndex,int x,int y,String net) throws Exception {
            Object[] faces=(Object[])facesField.get(search);
            if (faceIndex<0 || faceIndex>=faces.length)
                throw new AssertionError("P07 fixture missing face index "+faceIndex);
            Object face=faces[faceIndex];
            Method occupy=face.getClass().getDeclaredMethod("occupyLayerPath",Vector.class,String.class);
            occupy.setAccessible(true);
            Vector<Point> path=new Vector<Point>(); path.add(new Point(x,y));
            occupy.invoke(face,path,net);
        }
    }

    private P07StaticViaLegalityOracleContractTest() { }
}
