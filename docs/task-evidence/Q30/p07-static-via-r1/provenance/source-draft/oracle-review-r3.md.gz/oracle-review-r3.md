# P07 oracle review r3

R3 adds one independent net-key witness to the R2 oracle. It follows the `P07TwoLayerContractTest.barriers` construction: four test-point components, `PRIMARY` and `SECONDARY` domains, and an 80-unit isolation barrier. The oracle creates a reflection `Search` over that arbitrary board/layout, then evaluates coordinate `(300,300)` three times with equal-valued distinct `String` objects: `PRIMARY`, `SECONDARY`, `PRIMARY`. It requires exactly `B:true`, `B:false`, `B:true` and records the complete sequence. The same report is used by frozen capture and candidate compare, so root’s maintained driver checks both implementations.

The coordinate is inside the primary domain and outside component clearances, while the barrier rules reject secondary copper at that same land. This makes a stale primary static memo observable as a false candidate result. Existing R2 grid repeats, Boolean validation, live mutation checks, route fingerprint assertion, boundary records, and PASS marker remain unchanged.

R2 oracle, diff, JSON receipt, and notes were copied before the R3 edit with hashes recorded in `oracle-review-r3.json`. The current overlay, README, source manifest, and prepared fixtures were not edited. This leaf performed source and hash checks only; Java, build, browser, and fixture execution remain root-owned.
