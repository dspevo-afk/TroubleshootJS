# P07 oracle review r2

The only production-side behavior under review is the existing static-via overlay. This handoff repairs the independent reflection oracle and its standalone review diff. The overlay source, `README.md`, and `source-manifest.json` were left untouched.

The exact test class is `com.lushprojects.circuitjs1.client.P07StaticViaLegalityOracleContractTest`. Its capture and compare branches both emit `PASS: P07_STATIC_VIA_ORACLE_R1` only after the report is written or matches byte-for-byte. Root should run the maintained frozen capture and overlay compare driver; this leaf did not execute Java, build, browser, or fixture workloads.

The grid loop now evaluates every exact net/cell twice and requires equal serialized results. A valid grid coordinate must produce `B:true` or `B:false`; non-grid and integer-extreme records remain available for baseline exception parity. Net switching retains equal-valued distinct `String` objects and the A/B/A sequence.

Mutation coverage now uses fresh searches for face 0 and face 1 independently. Each requires a Boolean true result before foreign occupancy and exactly `B:false` afterward, with both pairs captured. Same-net prior-hole coincidence requires `B:true`, foreign-net coincidence requires `B:false`, and live-hole/via-limit rejections require `B:false` rather than accepting any non-true value. Route records assert that the input geometry fingerprint is unchanged while retaining the recorded fingerprints.

The previous oracle and diff were copied before repair as `.pre-root-review` artifacts. `oracle-review-r2.json` records their hashes and the new LF-normalized diff hashes. The observed overlay SHA was recorded for handoff only; it was not changed here.
