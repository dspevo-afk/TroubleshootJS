# P07 map/index CPU context census

This is a read-only census of the completed
`cpu-10ms-r1-02-profile-10014` run (Q30 seed `10014`).  No host, browser,
build, test, new profile, or source edit was performed.  The raw V8 profile is
902,402 bytes with SHA-256
`829e1a8ef12c856761d83a3bbf404f867e98d8b555bb223aaed752e12d1aa142`.  The
exact decoded source payload is
`b10cd75edabbfd0954b3e96eecad14c15c56285454b5725db13318eb630daa5c`, and the
validated symbol map is
`99a7c9a7e85070aee5dabe44a4621ea489f40c5e259a861d8e8397fdb2e58018`.

The predeclared `map-index-typed-heap` bucket contains 317 uniquely mapped
direct samples totaling 2,874,846 us (2.874846 s).  I recomputed those rows
from all raw `samples[i]`/`timeDeltas[i]` pairs and the exact symbol map rather
than using the attribution method-list cap.  The profile has 10,488 paired
samples over 101.619144 s; the nominal 10 ms interval is dynamic (5 us minimum,
10,250 us median, 10,589 us interpolated p95/10,590 us nearest observed, and
14,948 us maximum).

## Disjoint ancestry assignment

Each map-bucket sample is assigned once using this priority: P05
`PcbNetRouter` ancestry, P07 `PcbLayerRoutingPrototype$Search` ancestry with
no P05 ancestor, solver ancestry with neither routing owner, other Pcb
index/conductor ancestry, then other/none.  This keeps nested P07/P05 calls
from being counted twice.

| Disjoint context | Samples | Direct map-bucket delta |
| --- | ---: | ---: |
| P07 Search/BranchSearch, no `PcbNetRouter` ancestor | 235 | 2.395968 s |
| P05 `PcbNetRouter` ancestry | 9 | 0.082809 s |
| Solver ancestry, no P07/P05 owner | 32 | 0.219681 s |
| Other Pcb index/conductor ancestry | 10 | 0.103143 s |
| Other/none | 31 | 0.073245 s |
| **Total** | **317** | **2.874846 s** |

Within the disjoint P07 rows, the nearest proven P07 context is:

| Nearest P07 context | Samples | Direct map-bucket delta |
| --- | ---: | ---: |
| `Search::$offer` | 81 | 0.821398 s |
| `Search$BranchSearch::$advanceOne` | 17 | 0.175184 s |
| `Search$BranchSearch::$offerStep` | 25 | 0.247502 s |
| `Search::$viaFits` | 78 | 0.803709 s |
| `Search::$pathViaFits` | 34 | 0.348175 s |
| **P07 total** | **235** | **2.395968 s** |

Eight of the nine P05 rows (0.082803 s) also have a P07
`BranchSearch::$offerStep` ancestor because that P07 step calls a face-router
permission check; they are assigned to P05 above.  The remaining P05 row is
6 us in `InternalPreconditions::checkElementIndex` under conductor validation.
This overlap is disclosed rather than added to both owner totals.

## Proven P07 owners and operations

The accepted fusion-R2 fixture at
`scratch/pivot-lower-fusion-r2-preparation/candidate/src/...` identifies the
P07 state map as `HashMap<Integer,Node> best` at
`PcbLayerRoutingPrototype.java:340`.  Its stale-pop check is `best.get` at
line 364, and `Search.offer` performs `best.get`/`best.put` at lines 483--486.
The raw map-helper self samples under those two exact operations are:

- `Search::$offer`: 81 samples / 0.821398 s, covering the `best.get`/`best.put`
  path (`InternalJsHashCodeMap` chain/entry helpers and related hash checks).
- `BranchSearch::$advanceOne`: 17 samples / 0.175184 s, covering the stale
  `best.get(current.key)` check.

Together the directly attributable `best`-map helper context is 98 samples /
0.996582 s.  The accepted P07 source has no `bestCosts` or `visited` table in
this class.  The separate P05 `PcbNetRouter` fixture uses primitive
`double[] bestCost` and `int[] previous` at lines 397--398; its map-bucket
contribution here is only 0.082809 s and includes the nested permission path.

P07's `PcbTwoLayerRules` owns `TreeMap` fields at lines 10 and 31.  The P07
`offerStep`, `viaFits`, and `pathViaFits` context rows include TreeMap and
collection/hash helpers, but the profile does not identify which individual
TreeMap instance or call site supplied each helper sample.  `PcbSpatialIndex`
is only 2 direct samples / 0.020587 s in the other-Pcb bucket, under conductor
and routing-geometry validation rather than a P07 Search ancestor.

## Bounded primitive-table assessment

The broad P07 map/index ancestry (2.395968 s) is larger than the direct
`Search::$viaFits` total of 1.088520 s, and the separate
`nativeArraySplice` copy helper carries 72 samples / 0.740060 s of P07 routing
ancestry (0.976841 s direct across all callers).  A bounded primitive table is
therefore a plausible focused experiment for the proven `best` state map, but
the exact `best`-map helper context is only 0.996582 s: it is below `viaFits`
alone and well below the combined via/copy context comparison (1.828580 s).
The remaining P07 map-bucket time is rule-map, collection, and ancestry context
that such a table would not automatically address.  These are sampled CPU
rankings, not wall-time or allocation estimates, and do not predict a speedup.

Ambiguous frames are never assigned to these owners: the full attribution
reports 45 ambiguous samples (37 in the paired ambiguous bucket), 424
unproven/unmapped samples, and 10,019 mapped direct samples.  Aggregate node
children remain context rather than a self-time filter.  This is one profile
with a warm-boundary tail; profiler overhead, allocation volume, and retained
heap are unmeasured.
