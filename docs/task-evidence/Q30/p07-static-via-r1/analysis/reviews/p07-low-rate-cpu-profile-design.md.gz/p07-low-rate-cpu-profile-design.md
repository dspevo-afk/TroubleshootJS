# P07 low-rate CDP CPU-profile design

Scope is diagnosis of the current plan-4 candidate’s measured P07 residual
(P07 21.1392 s; child goals 0.7606 s, lower bound 0.4294 s, setup 0.0081 s,
geometry/rules/quality 0.0173 s, leaving 19.9238 s), with no Java instrumentation,
per-node timers, workload edits, or acceptance-budget changes. The existing
route/LU evidence establishes the stage seam. The old `cpu_profile_root.py`
procedure used the maintained Edge/Playwright host, an ephemeral localhost
server, CDP `Profiler`/`Debugger`, exact input manifests, and owned-process
cleanup. Its 1 ms Q30 run produced 66,468 samples and 63,554 exact mapped GWT
samples; a short A07 run had no unique mapped sample, so attribution is a
quality gate, not an assumption.

Use a temporary sibling of the current `tests/browser/compiled_attribute_acceptance.py`
with one case only: the same plan-4 candidate, signed seed, URL/spec, and
input-map SHA `0d27e176dc46afb4db91316570f4674e52b51ce2b462c64f6b6a37b98cbec197`.
The OFF row is the unchanged maintained runner; the ON row attaches CDP to its
page, enables `Debugger` and `Profiler`, sets `setSamplingInterval` to 10,000
microseconds, then starts immediately before the existing `page.goto`. Stop on
the same host-observed `RUNNING:warm` state, recording the 200 ms poll window
and stop-dispatch tail, then call `Profiler.stop`. Save the sanitized profile,
raw profile hash, script-provenance record, and source-map artifacts. Disable
the profiler/debugger, detach CDP, close Edge, stop the server, and require the
existing manifest-before/after and process-survivor checks to PASS.

Attribute only samples whose hashed GWT cache URL, or whose `Debugger.scriptParsed`
source bytes, exactly match the decoded `.cache.js` payload and a validated
symbol-map row. Aggregate mutually exclusive leaf samples by predeclared
source-owner buckets: routing geometry/ancestry, map/index/typed-heap work,
publisher, and browser `(garbage collector)`, `(idle)`, or `(program)` frames;
retain raw stacks for context. This can rank mapped execution and visible GC
CPU. It cannot measure allocations/retained heap, scheduler wait, exact wall
percentages, or causality for unmapped/ambiguous generated functions.

Predeclare OFF/ON parity: same report state, proof/work counts, request,
source/web manifests, and cleanup/no survivors. A timing delta is overhead
evidence only; it is not a deadline result. Do not claim a category when
provenance or aligned samples fail. Repeat as one counterbalanced OFF/ON pair
if host drift obscures the delta; use the profile only to select the next
measured owner after the already-accepted typed-heap work.
