# P07 static-via memo R2 review

**PASS for the two frozen root changes; no new correctness regression found.** Compared with the previously reviewed memo overlay SHA-256 `4b66e36260ecf703069e5f90097e18bc10726911e13911a69668906b0161f574`, the R2-only delta is the bounded integer grid-key helper and a zero-length memo for `transitions==0`. The full diff from fusion R2 baseline source audit `0d27e176dc46afb4db91316570f4674e52b51ce2b462c64f6b6a37b98cbec197` also includes the per-Search via memo and static/dynamic predicate split reviewed in R1. R2 source SHA-256: `93da7656198ed962c6ec83d1d5f271004a85dc3bf972a3a0479c8a28ed6ef658`.

The int helper preserves the prior long calculation: negative differences reject; a nonnegative mathematical difference that overflows `int` wraps negative and rejects; any valid delta is `< GRID * dimension`, and `width*height<=MAX_CELLS` bounds the flattened index. The zero-length array is not indexed under zero-transition policies because `viaFits` returns before key lookup. Positive-transition policies retain the full memo.

This is a source review only. No tests or gates were run; the oracle worker is addressing cache-hit, both-face occupancy, and exception assertions. The earlier review’s performance caveats remain: per-net full-array clearing and memo allocation for positive-transition searches still need cost evidence.
