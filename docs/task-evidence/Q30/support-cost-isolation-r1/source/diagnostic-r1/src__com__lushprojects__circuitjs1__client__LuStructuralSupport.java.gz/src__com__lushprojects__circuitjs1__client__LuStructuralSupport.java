package com.lushprojects.circuitjs1.client;

/**
 * Monotone structural support for one nonlinear-owned LU analysis.
 * The owner stores identities and support only; it never writes matrix values.
 */
final class LuStructuralSupport {
    // Private diagnostic recorder; null in every ordinary simulation.
    private final Q30SupportCostProfile cost;
    private final double[][] matrix;
    private final double[][] original;
    private final int n;
    private final Object mapping;
    private final boolean[] seenCoordinates;
    private final int[] parent;
    private final int[] rootLabels;
    private final int[] componentSizes;
    private final int[] rowCounts;
    private final int[] columnCounts;
    private final int[] head;
    private final int[] tail;
    private final int[] next;
    private int componentCount;
    private boolean valid = true;
    private boolean initializing = true;

    private LuStructuralSupport(double[][] matrix, double[][] original, int n,
            Object mapping, Q30SupportCostProfile cost) {
        this.cost = cost;
        this.matrix = matrix;
        this.original = original;
        this.n = n;
        this.mapping = mapping;
        seenCoordinates = new boolean[n * n];
        int vertices = n * 2;
        parent = new int[vertices];
        rootLabels = new int[vertices];
        componentSizes = new int[vertices];
        rowCounts = new int[vertices];
        columnCounts = new int[vertices];
        head = new int[vertices];
        tail = new int[vertices];
        next = new int[vertices];
        componentCount = vertices;
        if (cost != null) cost.supportAllocatedSlots += n * n + vertices * 8;
        for (int vertex = 0; vertex < vertices; vertex++) {
            parent[vertex] = vertex;
            rootLabels[vertex] = vertex;
            componentSizes[vertex] = 1;
            head[vertex] = vertex;
            tail[vertex] = vertex;
            next[vertex] = -1;
            if (vertex < n) rowCounts[vertex] = 1;
            else columnCounts[vertex] = 1;
        }
        for (int row = 0; row < n; row++) {
            for (int column = 0; column < n; column++) {
                if (cost != null) cost.supportInitialScannedSlots++;
                if (original[row][column] != 0.0) {
                    if (cost != null) cost.supportInitialCoordinates++;
                    seenCoordinates[row * n + column] = true;
                    union(row, n + column);
                }
            }
        }
        initializing = false;
    }

    static LuStructuralSupport create(double[][] matrix, double[][] original,
            int n, Object mapping, Q30SupportCostProfile cost) {
        if (n < 2 || n > 512 || !hasActivePrefix(matrix, n) ||
                !hasActivePrefix(original, n)) return null;
        for (int row = 0; row < n; row++) {
            for (int prior = 0; prior < row; prior++)
                if (matrix[row] == matrix[prior]) return null;
            for (int column = 0; column < n; column++) {
                if (cost != null) cost.supportCreateScannedSlots++;
                double value = original[row][column];
                if (!SolverExecutionBoundary.finite(value) ||
                        matrix[row][column] != value) return null;
            }
        }
        return new LuStructuralSupport(matrix, original, n, mapping, cost);
    }

    static LuStructuralSupport create(double[][] matrix, double[][] original,
            int n, Object mapping) {
        return create(matrix, original, n, mapping, null);
    }

    boolean hasSeenCoordinateForProfile(int row, int column) {
        return row >= 0 && row < n && column >= 0 && column < n &&
            seenCoordinates[row * n + column];
    }

    boolean validForProfile() { return valid; }

    private static boolean hasActivePrefix(double[][] values, int n) {
        if (values == null || values.length < n) return false;
        for (int row = 0; row < n; row++)
            if (values[row] == null || values[row].length < n) return false;
        return true;
    }

    /** Records a successfully mapped matrix coordinate, even for a zero stamp. */
    void recordStamp(int row, int column) {
        if (cost != null) cost.supportStampCalls++;
        if (!valid) return;
        if (row < 0 || row >= n || column < 0 || column >= n) {
            invalidate();
            return;
        }
        int coordinate = row * n + column;
        if (seenCoordinates[coordinate]) {
            if (cost != null) cost.supportExistingCoordinates++;
            return;
        }
        if (cost != null) cost.supportNewCoordinates++;
        seenCoordinates[coordinate] = true;
        union(row, n + column);
    }

    boolean matches(double[][] currentMatrix, double[][] currentOriginal,
            int currentN, Object currentMapping) {
        return valid && currentMatrix == matrix && currentOriginal == original &&
                currentN == n && currentMapping == mapping &&
                hasActivePrefix(currentMatrix, n) && hasActivePrefix(currentOriginal, n);
    }

    void invalidate() {
        if (cost != null && !cost.isFrozen() && valid) cost.supportInvalidations++;
        valid = false;
    }

    boolean hasSingleComponent() {
        return valid && componentCount == 1;
    }

    boolean prepareDomains(Domains domains, double[][] currentMatrix,
            double[][] currentOriginal, int currentN, Object currentMapping) {
        if (cost != null) cost.domainAttempts++;
        if (domains == null) return false;
        domains.clear();
        if (!matches(currentMatrix, currentOriginal, currentN, currentMapping) ||
                componentCount <= 1 || !isBalanced()) return false;

        boolean complete = false;
        try {
            domains.ensureCapacity(n, cost);
            for (int group = 0; group < rootLabels.length; group++) {
                int rows = rowCounts[group];
                int columns = columnCounts[group];
                if (rows == 0 && columns == 0) continue;
                if (rows <= 0 || columns != rows) return false;
                domains.ensureRowCapacity(group, rows, cost);
                domains.ensureColumnCapacity(group, columns, cost);
            }
            for (int row = 0; row < n; row++) {
                int group = rootLabels[row];
                int slot = domains.counts[group]++;
                domains.rowGroups[row] = group;
                domains.rowSlots[row] = slot;
                domains.rowIndexes[group][slot] = row;
                domains.rowReferences[group][slot] = currentMatrix[row];
                if (cost != null) cost.domainCopiedSlots++;
            }
            for (int column = 0; column < n; column++) {
                int group = rootLabels[n + column];
                int slot = domains.columnCounts[group]++;
                domains.columnGroups[column] = group;
                domains.columns[group][slot] = column;
                if (cost != null) cost.domainCopiedSlots++;
            }
            for (int group = 0; group < rootLabels.length; group++) {
                if (domains.counts[group] != rowCounts[group] ||
                        domains.columnCounts[group] != columnCounts[group]) return false;
            }
            domains.active = true;
            if (cost != null) {
                cost.domainSuccesses++;
                if (cost.lastDomainPartitionEpoch == cost.supportPartitionEpoch)
                    cost.domainUnchangedPartition++;
                else cost.domainChangedPartition++;
                cost.lastDomainPartitionEpoch = cost.supportPartitionEpoch;
            }
            complete = true;
            return true;
        } finally {
            if (!complete) domains.clear();
        }
    }

    private boolean isBalanced() {
        int roots = 0;
        for (int vertex = 0; vertex < rootLabels.length; vertex++) {
            if (rootLabels[vertex] != vertex) continue;
            roots++;
            if (componentSizes[vertex] <= 0 || rowCounts[vertex] <= 0 ||
                    rowCounts[vertex] != columnCounts[vertex]) return false;
        }
        return roots == componentCount && roots > 1;
    }

    private void union(int left, int right) {
        int leftRoot = find(left);
        int rightRoot = find(right);
        if (leftRoot == rightRoot) {
            if (cost != null && !initializing) cost.supportSamePartitionCoordinates++;
            return;
        }
        if (cost != null) {
            cost.supportNewUnions++;
            if (initializing) cost.supportInitialUnions++;
            else cost.supportDynamicUnions++;
            cost.supportPartitionEpoch++;
        }
        int large = leftRoot;
        int small = rightRoot;
        if (componentSizes[large] < componentSizes[small]) {
            large = rightRoot;
            small = leftRoot;
        }
        int vertex = head[small];
        while (vertex >= 0) {
            if (cost != null) cost.supportRelabeledVertices++;
            rootLabels[vertex] = large;
            parent[vertex] = large;
            vertex = next[vertex];
        }
        next[tail[large]] = head[small];
        tail[large] = tail[small];
        parent[small] = large;
        componentSizes[large] += componentSizes[small];
        rowCounts[large] += rowCounts[small];
        columnCounts[large] += columnCounts[small];
        componentSizes[small] = 0;
        rowCounts[small] = 0;
        columnCounts[small] = 0;
        head[small] = -1;
        tail[small] = -1;
        componentCount--;
    }

    private int find(int vertex) {
        int root = parent[vertex];
        while (root != parent[root]) root = parent[root];
        int current = vertex;
        while (parent[current] != root) {
            int nextParent = parent[current];
            parent[current] = root;
            current = nextParent;
        }
        return root;
    }

    // Package-visible oracle seam; labels are compared only for equivalence.
    int componentLabelForChecks(int vertex) {
        if (!valid || vertex < 0 || vertex >= rootLabels.length) return -1;
        return rootLabels[vertex];
    }

    /** Reusable per-factor row/column membership scratch, never an owner token. */
    static final class Domains {
        int[][] rowIndexes;
        int[][] columns;
        double[][][] rowReferences;
        int[] counts;
        int[] starts;
        int[] columnCounts;
        int[] columnGroups;
        int[] rowGroups;
        int[] rowSlots;
        boolean active;
        private int capacityN;
        private int liveN;

        private void ensureCapacity(int n, Q30SupportCostProfile cost) {
            int groups = n * 2;
            if (capacityN != n || rowIndexes == null || rowIndexes.length != groups) {
                rowIndexes = new int[groups][];
                columns = new int[groups][];
                rowReferences = new double[groups][][];
                counts = new int[groups];
                starts = new int[groups];
                columnCounts = new int[groups];
                columnGroups = new int[n];
                rowGroups = new int[n];
                rowSlots = new int[n];
                capacityN = n;
                if (cost != null) cost.domainAllocatedSlots += groups * 6 + n * 3;
            }
            liveN = n;
        }

        private void ensureRowCapacity(int group, int required, Q30SupportCostProfile cost) {
            if (rowIndexes[group] == null || rowIndexes[group].length < required) {
                rowIndexes[group] = new int[required];
                if (cost != null) cost.domainAllocatedSlots += required;
            }
            if (rowReferences[group] == null || rowReferences[group].length < required) {
                rowReferences[group] = new double[required][];
                if (cost != null) cost.domainAllocatedSlots += required;
            }
        }

        private void ensureColumnCapacity(int group, int required, Q30SupportCostProfile cost) {
            if (columns[group] == null || columns[group].length < required) {
                columns[group] = new int[required];
                if (cost != null) cost.domainAllocatedSlots += required;
            }
        }

        /** Called after the caller has swapped matrix[left] and matrix[right]. */
        void swap(int left, int right) {
            if (!active || left < 0 || right < 0 || left >= liveN || right >= liveN) {
                clear();
                return;
            }
            if (left == right) return;
            int leftGroup = rowGroups[left];
            int rightGroup = rowGroups[right];
            int leftSlot = rowSlots[left];
            int rightSlot = rowSlots[right];
            if (leftGroup < 0 || rightGroup < 0 || leftSlot < starts[leftGroup] ||
                    rightSlot < starts[rightGroup] || leftSlot >= counts[leftGroup] ||
                    rightSlot >= counts[rightGroup]) {
                clear();
                return;
            }
            double[] leftReference = rowReferences[leftGroup][leftSlot];
            double[] rightReference = rowReferences[rightGroup][rightSlot];
            if (leftReference == null || rightReference == null ||
                    rowIndexes[leftGroup][leftSlot] != left ||
                    rowIndexes[rightGroup][rightSlot] != right) {
                clear();
                return;
            }
            if (leftGroup == rightGroup) {
                rowReferences[leftGroup][leftSlot] = rightReference;
                rowReferences[leftGroup][rightSlot] = leftReference;
                return;
            }
            rowIndexes[leftGroup][leftSlot] = right;
            rowReferences[leftGroup][leftSlot] = leftReference;
            rowIndexes[rightGroup][rightSlot] = left;
            rowReferences[rightGroup][rightSlot] = rightReference;
            rowGroups[left] = rightGroup;
            rowGroups[right] = leftGroup;
            rowSlots[right] = leftSlot;
            rowSlots[left] = rightSlot;
            resort(leftGroup, leftSlot);
            resort(rightGroup, rightSlot);
        }

        private void resort(int group, int originalSlot) {
            int slot = originalSlot;
            int start = starts[group];
            int end = counts[group];
            while (slot > start && rowIndexes[group][slot] < rowIndexes[group][slot - 1]) {
                swapSlots(group, slot, slot - 1);
                slot--;
            }
            while (slot + 1 < end && rowIndexes[group][slot] > rowIndexes[group][slot + 1]) {
                swapSlots(group, slot, slot + 1);
                slot++;
            }
        }

        private void swapSlots(int group, int first, int second) {
            int firstIndex = rowIndexes[group][first];
            int secondIndex = rowIndexes[group][second];
            rowIndexes[group][first] = secondIndex;
            rowIndexes[group][second] = firstIndex;
            double[] firstReference = rowReferences[group][first];
            rowReferences[group][first] = rowReferences[group][second];
            rowReferences[group][second] = firstReference;
            rowSlots[firstIndex] = second;
            rowSlots[secondIndex] = first;
        }

        void finishPivot(int k) {
            if (!active || k < 0 || k >= liveN) {
                clear();
                return;
            }
            int group = columnGroups[k];
            if (group < 0 || group >= counts.length || rowGroups[k] != group ||
                    starts[group] >= counts[group] ||
                    rowIndexes[group][starts[group]] != k ||
                    rowSlots[k] != starts[group] ||
                    starts[group] >= columnCounts[group] ||
                    columns[group][starts[group]] != k ||
                    rowReferences[group][starts[group]] == null) {
                clear();
                return;
            }
            rowReferences[group][starts[group]] = null;
            starts[group]++;
            rowSlots[k] = -1;
        }

        void clear() {
            // reset and preparation also clear; an empty workspace owns no rows.
            if (liveN == 0) {
                active = false;
                return;
            }
            if (rowReferences != null) {
                for (int group = 0; group < rowReferences.length; group++) {
                    double[][] references = rowReferences[group];
                    if (references == null) continue;
                    for (int slot = 0; slot < references.length; slot++)
                        references[slot] = null;
                }
            }
            zero(counts);
            zero(starts);
            zero(columnCounts);
            fillMinusOne(columnGroups);
            fillMinusOne(rowGroups);
            fillMinusOne(rowSlots);
            active = false;
            liveN = 0;
        }

        boolean allReferencesNullForChecks() {
            if (rowReferences == null) return true;
            for (int group = 0; group < rowReferences.length; group++) {
                double[][] references = rowReferences[group];
                if (references == null) continue;
                for (int slot = 0; slot < references.length; slot++)
                    if (references[slot] != null) return false;
            }
            return true;
        }

        boolean allCountsZeroForChecks() {
            return !active && liveN == 0 && allZero(counts) && allZero(starts) && allZero(columnCounts);
        }

        private static void zero(int[] values) {
            if (values == null) return;
            for (int index = 0; index < values.length; index++) values[index] = 0;
        }

        private static void fillMinusOne(int[] values) {
            if (values == null) return;
            for (int index = 0; index < values.length; index++) values[index] = -1;
        }

        private static boolean allZero(int[] values) {
            if (values == null) return true;
            for (int index = 0; index < values.length; index++)
                if (values[index] != 0) return false;
            return true;
        }
    }
}
