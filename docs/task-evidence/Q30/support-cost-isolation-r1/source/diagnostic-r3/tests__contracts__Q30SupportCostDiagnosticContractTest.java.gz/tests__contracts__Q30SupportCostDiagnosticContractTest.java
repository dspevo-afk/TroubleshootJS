package com.lushprojects.circuitjs1.client;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Native parity and counter checks for the private Q30 support ablation. */
public final class Q30SupportCostDiagnosticContractTest {
    private static int assertions;

    public static void main(String[] args) throws Exception {
        Method factor = CirSim.class.getDeclaredMethod("lu_factorNonlinearOwned",
            double[][].class, int.class, int[].class,
            CirSim.LuFactorizationWorkspace.class, LuStructuralSupport.class,
            double[][].class, Object.class, boolean.class,
            Q30SupportCostProfile.class);
        factor.setAccessible(true);
        Method oracle = LuFactorizationChecks.class.getDeclaredMethod("originalFactor",
            double[][].class, int.class, int[].class);
        oracle.setAccessible(true);
        double[][] fixture = {
            { 4, 1, 0, 0 }, { 2, 3, 0, 0 },
            { 0, 0, 5, 2 }, { 0, 0, 1, 6 }
        };
        double[][] expected = copy(fixture);
        int[] expectedPivot = new int[4];
        check(invoke(oracle, expected, 4, expectedPivot), "oracle rejected fixture");
        for (int mode = 0; mode < 3; mode++) {
            double[][] actual = copy(fixture);
            double[][] original = copy(fixture);
            int[] pivot = new int[4];
            Object mapping = new Object();
            LuStructuralSupport support = mode == 0 ? null :
                LuStructuralSupport.create(actual, original, 4, mapping);
            check(mode == 0 || support != null, "support construction failed");
            boolean restricted = mode == 2;
            check(invoke(factor, actual, 4, pivot, new CirSim.LuFactorizationWorkspace(),
                support, original, mapping, restricted, null),
                "mode rejected fixture " + mode);
            for (int row = 0; row < 4; row++) {
                check(pivot[row] == expectedPivot[row], "pivot differs in mode " + mode);
                for (int col = 0; col < 4; col++)
                    check(Double.doubleToLongBits(actual[row][col]) ==
                        Double.doubleToLongBits(expected[row][col]),
                        "factor differs in mode " + mode + " at " + row + "," + col);
            }
        }
        double[][] dynamic = copy(fixture);
        double[][] original = copy(fixture);
        Q30SupportCostProfile cost = new Q30SupportCostProfile("track");
        LuStructuralSupport support = LuStructuralSupport.create(dynamic, original,
            4, new Object(), cost);
        check(support != null, "profiled support construction failed");
        double initialUnions = cost.supportInitialUnions;
        support.recordStamp(0, 0);
        check(cost.supportExistingCoordinates == 1, "existing coordinate was missed");
        support.recordStamp(0, 2);
        check(cost.supportNewCoordinates == 1, "new coordinate was missed");
        check(cost.supportDynamicUnions == 1 && cost.supportNewUnions == initialUnions + 1,
            "new partition union was missed");
        support.recordStamp(1, 2);
        check(cost.supportNewCoordinates == 2 && cost.supportSamePartitionCoordinates == 1,
            "new coordinate within an existing partition was missed");
        support.invalidate();
        check(cost.supportInvalidations == 1, "invalidation was missed");
        System.out.println("PASS: Q30 support cost diagnostic contracts assertions=" + assertions);
    }

    private static boolean invoke(Method method, Object... args) throws Exception {
        try { return ((Boolean) method.invoke(null, args)).booleanValue(); }
        catch (InvocationTargetException problem) {
            throw new AssertionError("factor raised an exception", problem.getCause());
        }
    }

    private static double[][] copy(double[][] source) {
        double[][] out = new double[source.length][];
        for (int i = 0; i < source.length; i++) out[i] = source[i].clone();
        return out;
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
}
