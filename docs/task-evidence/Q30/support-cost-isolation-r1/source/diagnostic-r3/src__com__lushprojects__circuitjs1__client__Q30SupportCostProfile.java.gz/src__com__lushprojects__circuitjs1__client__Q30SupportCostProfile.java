package com.lushprojects.circuitjs1.client;

import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/** Private, opt-in Q30 diagnostic counters. Never consulted by electrical code. */
final class Q30SupportCostProfile {
    static final int SAMPLE_STRIDE = 65536;
    private static final int TYPE_LIMIT = 2048;
    private static final double MAX_EXACT_INTEGER = 9007199254740991.0;
    final String mode;
    double analyzeCalls, factorCalls, solveCalls, trialAttempts, acceptedSteps;
    double retrySteps, runCalls, circuitStamps, matrixStampCalls;
    double supportCreates, supportCreateScannedSlots, supportInitialScannedSlots;
    double supportAllocatedSlots, supportInitialCoordinates, supportStampCalls;
    double supportExistingCoordinates, supportNewCoordinates, supportNewUnions;
    double supportInitialUnions, supportDynamicUnions;
    double supportSamePartitionCoordinates, supportRelabeledVertices;
    double supportInvalidations, supportInvalidationCalls;
    double supportInvalidationsAnalyze, supportInvalidationsStamp;
    double supportInvalidationsRun, supportInvalidationsCreate, supportInvalidationsStop;
    double supportInvalidationsOther;
    double supportPartitionEpoch, lastDomainPartitionEpoch = -1;
    double domainAttempts, domainSuccesses, domainUnchangedPartition;
    double domainChangedPartition, domainAllocatedSlots, domainCopiedSlots;
    double luInputScannedSlots, luPivotScannedSlots, luUpdatedSlots;
    double lowerReferenceInsertions, lowerReferenceClearedSlots;
    double lowerReferenceAllocatedSlots, upperColumnAllocatedSlots;
    double matrixCopiedSlots, rightSideCopiedSlots;
    double factorsAtUnchangedPartition, factorsAtChangedPartition;
    double factorsWithoutStructuralSupport;
    double analyzeMillis, factorMillis, solveMillis, runMillis;
    double createMillis, domainMillis, stampCircuitMillis;
    double maxAnalyzeMillis, maxFactorMillis, maxSolveMillis, maxRunMillis;
    double maxCreateMillis, maxDomainMillis, maxStampCircuitMillis;
    double maxSampleMicros, sampleCalibrationMicros, sampleCumulativeMicros;
    double clockAnomalies, counterErrors;
    double sampleCount;
    final double[] sampleBins = new double[6];
    final double[] stampsByType = new double[TYPE_LIMIT];
    final double[] newCoordinatesByType = new double[TYPE_LIMIT];
    double outOfRangeTypeStamps;
    int activeDumpType = -1;
    private boolean frozen;

    Q30SupportCostProfile(String mode) { this.mode = mode; }

    static native double now() /*-{
        return $wnd.performance.now();
    }-*/;

    double elapsedSince(double began) {
        double elapsed = now() - began;
        if (!finite(elapsed) || elapsed < 0) {
            clockAnomalies++;
            return 0;
        }
        return elapsed;
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    double beginStampSample() {
        if ((matrixStampCalls % SAMPLE_STRIDE) != 0) return -1;
        double first = now();
        double second = now();
        double calibration = (second - first) * 1000;
        if (!finite(calibration) || calibration < 0) clockAnomalies++;
        else sampleCalibrationMicros += calibration;
        return now();
    }

    void endStampSample(double began) {
        if (began < 0) return;
        double micros = (now() - began) * 1000;
        if (!finite(micros) || micros < 0) {
            clockAnomalies++;
            return;
        }
        sampleCount++;
        sampleCumulativeMicros += micros;
        if (micros > maxSampleMicros) maxSampleMicros = micros;
        int bin = micros < 1 ? 0 : micros < 4 ? 1 : micros < 16 ? 2 :
            micros < 64 ? 3 : micros < 256 ? 4 : 5;
        sampleBins[bin]++;
    }

    void stampType(boolean newCoordinate) {
        if (activeDumpType >= 0 && activeDumpType < TYPE_LIMIT) {
            stampsByType[activeDumpType]++;
            if (newCoordinate) newCoordinatesByType[activeDumpType]++;
        } else outOfRangeTypeStamps++;
    }

    void freeze() {
        if (frozen) return;
        double[] counts = {
            analyzeCalls, factorCalls, solveCalls, trialAttempts, acceptedSteps,
            retrySteps, runCalls, circuitStamps, matrixStampCalls, supportCreates,
            supportCreateScannedSlots, supportInitialScannedSlots, supportAllocatedSlots,
            supportInitialCoordinates, supportStampCalls, supportExistingCoordinates,
            supportNewCoordinates, supportNewUnions, supportInitialUnions,
            supportDynamicUnions, supportSamePartitionCoordinates,
            supportRelabeledVertices, supportInvalidations, supportInvalidationCalls,
            supportInvalidationsAnalyze,
            supportInvalidationsStamp, supportInvalidationsRun,
            supportInvalidationsCreate, supportInvalidationsStop,
            supportInvalidationsOther, supportPartitionEpoch,
            domainAttempts, domainSuccesses, domainUnchangedPartition,
            domainChangedPartition, domainAllocatedSlots, domainCopiedSlots,
            luInputScannedSlots, luPivotScannedSlots, luUpdatedSlots,
            lowerReferenceInsertions, lowerReferenceClearedSlots,
            lowerReferenceAllocatedSlots, upperColumnAllocatedSlots,
            matrixCopiedSlots, rightSideCopiedSlots, factorsAtUnchangedPartition,
            factorsAtChangedPartition, factorsWithoutStructuralSupport,
            sampleCount, outOfRangeTypeStamps
        };
        for (double count : counts) checkCount(count);
        for (double count : sampleBins) checkCount(count);
        for (double count : stampsByType) checkCount(count);
        for (double count : newCoordinatesByType) checkCount(count);
        frozen = true;
    }

    private void checkCount(double value) {
        if (!finite(value) || value < 0 || value > MAX_EXACT_INTEGER ||
                Math.floor(value) != value) counterErrors++;
    }

    boolean hasErrors() { return clockAnomalies != 0 || counterErrors != 0; }
    boolean isFrozen() { return frozen; }

    JSONObject toJson() {
        JSONObject out = new JSONObject();
        put(out, "mode", mode);
        put(out, "clock", "performance.now");
        put(out, "clockAnomalies", clockAnomalies);
        put(out, "counterErrors", counterErrors);
        put(out, "measurementValid", !hasErrors());
        put(out, "frozenBeforeCleanup", frozen);
        put(out, "analyzeCalls", analyzeCalls);
        put(out, "factorCalls", factorCalls);
        put(out, "solveCalls", solveCalls);
        put(out, "trialAttempts", trialAttempts);
        put(out, "acceptedSteps", acceptedSteps);
        put(out, "retrySteps", retrySteps);
        put(out, "runCalls", runCalls);
        put(out, "circuitStamps", circuitStamps);
        put(out, "matrixStampCalls", matrixStampCalls);
        put(out, "analyzeMillis", analyzeMillis);
        put(out, "factorMillis", factorMillis);
        put(out, "solveMillis", solveMillis);
        put(out, "runMillis", runMillis);
        put(out, "createMillis", createMillis);
        put(out, "domainMillis", domainMillis);
        put(out, "stampCircuitMillis", stampCircuitMillis);
        put(out, "maxAnalyzeMillis", maxAnalyzeMillis);
        put(out, "maxFactorMillis", maxFactorMillis);
        put(out, "maxSolveMillis", maxSolveMillis);
        put(out, "maxRunMillis", maxRunMillis);
        put(out, "maxCreateMillis", maxCreateMillis);
        put(out, "maxDomainMillis", maxDomainMillis);
        put(out, "maxStampCircuitMillis", maxStampCircuitMillis);
        put(out, "supportCreates", supportCreates);
        put(out, "supportCreateScannedSlots", supportCreateScannedSlots);
        put(out, "supportInitialScannedSlots", supportInitialScannedSlots);
        put(out, "supportAllocatedSlots", supportAllocatedSlots);
        put(out, "supportInitialCoordinates", supportInitialCoordinates);
        put(out, "supportStampCalls", supportStampCalls);
        put(out, "supportExistingCoordinates", supportExistingCoordinates);
        put(out, "supportNewCoordinates", supportNewCoordinates);
        put(out, "supportNewUnions", supportNewUnions);
        put(out, "supportInitialUnions", supportInitialUnions);
        put(out, "supportDynamicUnions", supportDynamicUnions);
        put(out, "supportSamePartitionCoordinates", supportSamePartitionCoordinates);
        put(out, "supportRelabeledVertices", supportRelabeledVertices);
        put(out, "supportInvalidations", supportInvalidations);
        put(out, "supportInvalidationCalls", supportInvalidationCalls);
        put(out, "supportInvalidationsAnalyze", supportInvalidationsAnalyze);
        put(out, "supportInvalidationsStamp", supportInvalidationsStamp);
        put(out, "supportInvalidationsRun", supportInvalidationsRun);
        put(out, "supportInvalidationsCreate", supportInvalidationsCreate);
        put(out, "supportInvalidationsStop", supportInvalidationsStop);
        put(out, "supportInvalidationsOther", supportInvalidationsOther);
        put(out, "domainAttempts", domainAttempts);
        put(out, "domainSuccesses", domainSuccesses);
        put(out, "domainUnchangedPartition", domainUnchangedPartition);
        put(out, "domainChangedPartition", domainChangedPartition);
        put(out, "domainAllocatedSlots", domainAllocatedSlots);
        put(out, "domainCopiedSlots", domainCopiedSlots);
        put(out, "luInputScannedSlots", luInputScannedSlots);
        put(out, "luPivotScannedSlots", luPivotScannedSlots);
        put(out, "luUpdatedSlots", luUpdatedSlots);
        put(out, "lowerReferenceInsertions", lowerReferenceInsertions);
        put(out, "lowerReferenceClearedSlots", lowerReferenceClearedSlots);
        put(out, "lowerReferenceAllocatedSlots", lowerReferenceAllocatedSlots);
        put(out, "upperColumnAllocatedSlots", upperColumnAllocatedSlots);
        put(out, "matrixCopiedSlots", matrixCopiedSlots);
        put(out, "rightSideCopiedSlots", rightSideCopiedSlots);
        put(out, "factorsAtUnchangedPartition", factorsAtUnchangedPartition);
        put(out, "factorsAtChangedPartition", factorsAtChangedPartition);
        put(out, "factorsWithoutStructuralSupport", factorsWithoutStructuralSupport);
        put(out, "stampSampleStride", SAMPLE_STRIDE);
        put(out, "stampSampleCount", sampleCount);
        put(out, "stampSampleMaxMicros", maxSampleMicros);
        put(out, "stampSampleCumulativeMicros", sampleCumulativeMicros);
        put(out, "stampSampleCalibrationTotalMicros", sampleCalibrationMicros);
        put(out, "stampSampleCalibrationMeanMicros",
            sampleCount == 0 ? 0 : sampleCalibrationMicros / sampleCount);
        JSONArray bins = new JSONArray();
        for (int i = 0; i < sampleBins.length; i++) bins.set(i, new JSONNumber(sampleBins[i]));
        out.put("stampSampleBinsLt1Lt4Lt16Lt64Lt256AndAbove", bins);
        JSONArray types = new JSONArray();
        for (int type = 0; type < TYPE_LIMIT; type++) {
            if (stampsByType[type] == 0) continue;
            JSONObject row = new JSONObject();
            put(row, "dumpType", type);
            put(row, "stamps", stampsByType[type]);
            put(row, "newCoordinates", newCoordinatesByType[type]);
            types.set(types.size(), row);
        }
        out.put("stampsByDumpType", types);
        put(out, "outOfRangeTypeStamps", outOfRangeTypeStamps);
        return out;
    }

    private static void put(JSONObject out, String key, String value) {
        out.put(key, new JSONString(value));
    }
    private static void put(JSONObject out, String key, boolean value) {
        out.put(key, com.google.gwt.json.client.JSONBoolean.getInstance(value));
    }
    private static void put(JSONObject out, String key, double value) {
        out.put(key, new JSONNumber(value));
    }
}
