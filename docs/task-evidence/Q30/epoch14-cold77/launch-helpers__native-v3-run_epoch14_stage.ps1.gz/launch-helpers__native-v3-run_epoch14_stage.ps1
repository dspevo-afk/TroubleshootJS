param([Parameter(Mandatory=$true)][ValidateSet('cold-pilot','cold-rest','native-full','native-append')][string]$Batch,
    [string]$PreparedTag='isolated-readerfix',[string]$CanaryTag='compiled-canaries-readerfix',
    [string]$PlanName='scale-plan-readerfix.json')
$ErrorActionPreference='Stop'
$binding=Get-Content -LiteralPath '<workspace>\epoch14-task-pointer.json' -Raw | ConvertFrom-Json
$taskRoot=$binding.taskRoot
$repoRoot='<repo>'
$retainedRoot='%USERPROFILE%\AppData\Local\Temp\q30-finish-0fa2512465'
$head=& git -C $repoRoot rev-parse HEAD
if($head -ne $binding.baseHead){
    & git -C $repoRoot merge-base --is-ancestor $binding.baseHead $head
    if($LASTEXITCODE -ne 0){throw 'Frozen source HEAD is not an ancestor of current checkpoint'}
}
$snapshot=Get-Content -LiteralPath (Join-Path $taskRoot 'isolated-readerfix\source-snapshot.json') -Raw | ConvertFrom-Json
foreach($row in $snapshot.files){
    $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $repoRoot $row.path)).Hash.ToLowerInvariant()
    if($actual -ne $row.sha256){throw ('Consumed source input changed: '+$row.path)}
}
$plan=Get-Content -LiteralPath (Join-Path $taskRoot 'acceptance-plan.json') -Raw | ConvertFrom-Json
$acceptanceHash=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $taskRoot 'acceptance-plan.json')).Hash.ToLowerInvariant()
if($acceptanceHash -ne $binding.continuedPlanSha256){throw 'Frozen acceptance plan bytes changed'}
if($plan.cases.Count -ne 77 -or $plan.serviceAndSensitivitySeeds.Count -ne 21){throw 'Frozen cohort counts changed'}
$isCold=$Batch.StartsWith('cold-')
if(-not $isCold){
    $coldAudit=Get-Content -LiteralPath (Join-Path $taskRoot 'cold77-audit.json') -Raw | ConvertFrom-Json
    $frozenHash=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $taskRoot $PlanName)).Hash.ToLowerInvariant()
    if($coldAudit.status -ne 'PASS' -or $coldAudit.count -ne 77 -or $coldAudit.acceptancePlanSha256 -ne $acceptanceHash -or $coldAudit.frozenPlanSha256 -ne $frozenHash -or $coldAudit.sourceIdentity -ne $snapshot.sourceIdentity){throw 'Completed cold77 audit does not bind these exact inputs'}
}
$tag=if($isCold){$Batch+'-readerfix'}else{$Batch}
$log=Join-Path $taskRoot ($tag+'.log')
$result=Join-Path $taskRoot ($tag+'-result.json')
if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $result)){throw 'Stage output exists'}
$self=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID)
$ownership=Join-Path $taskRoot ($tag+'-ownership.json')
if(Test-Path -LiteralPath $ownership){throw 'Ownership receipt already exists'}
@{schema=1;pid=$PID;createdUtc=$self.CreationDate.ToUniversalTime().ToString('o');executable=$self.ExecutablePath;command=$self.CommandLine;taskRoot=$taskRoot;batch=$Batch} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $ownership
$started=[DateTime]::UtcNow
$timer=[Diagnostics.Stopwatch]::StartNew()
$sourceFiles=@('src/com/lushprojects/circuitjs1/client/PcbLayerRoutingPrototype.java','src/com/lushprojects/circuitjs1/client/PcbNetRouter.java','src/com/lushprojects/circuitjs1/client/SeededPcbLayoutGenerator.java') | ForEach-Object {@{path=$_;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $repoRoot $_)).Hash.ToLowerInvariant()}}
try {
    if($isCold){
        $pinned=Get-Content -LiteralPath (Join-Path $taskRoot ($CanaryTag+'-stage-result.json')) -Raw | ConvertFrom-Json
        if($pinned.status -ne 'PASS' -or $pinned.playwrightVersion -ne '1.63.0'){throw 'Pinned runtime canaries did not pass'}
        $env:PYTHONPATH=Join-Path $retainedRoot 'deps'
        $first=if($Batch -eq 'cold-pilot'){0}else{3}
        $count=if($Batch -eq 'cold-pilot'){3}else{74}
        & python '<workspace>\run_epoch14_cold_sequence.py' $repoRoot (Join-Path $taskRoot $PreparedTag) (Join-Path $taskRoot $PlanName) (Join-Path $taskRoot 'acceptance-plan.json') (Join-Path $taskRoot $tag) --start $first --count $count *> $log
        $code=$LASTEXITCODE
    } else {
        $suiteNames=@([regex]::Matches([IO.File]::ReadAllText((Join-Path $repoRoot 'scripts\verify-current-contracts.ps1')), "@\{ Name = '([^']+)'; Marker = ") | ForEach-Object {$_.Groups[1].Value})
        if($suiteNames.Count -ne 82){throw 'Maintained native suite count changed'}
        $nativeArgs=@{
            JavaHome=(Join-Path $retainedRoot 'jdk\jdk8u502-b07')
            PythonExe='%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
            ReceiptOutputPath=(Join-Path $taskRoot ($Batch+'.txt'))
            Q30ServiceSeeds=[long[]]@($plan.serviceAndSensitivitySeeds | ForEach-Object {[long]::Parse($_)})
            Q30SensitivitySeeds=[long[]]@($plan.serviceAndSensitivitySeeds | ForEach-Object {[long]::Parse($_)})
            Q30CorpusSeeds=[long[]]@($plan.cases[0..50] | ForEach-Object {[long]::Parse($_.seed)})
        }
        if($Batch -eq 'native-append'){
            $nativeArgs.Suite=@('Q30NormalCorpusContractTest')
            $nativeArgs.Q30CorpusSeeds=[long[]]@($plan.cases[51..76] | ForEach-Object {[long]::Parse($_.seed)})
        }
        & (Join-Path $repoRoot 'scripts\verify-current-contracts.ps1') @nativeArgs *> $log
        $code=$LASTEXITCODE
    }
    if($null -eq $code){$code=0}
} catch {
    $_ | Out-String | Add-Content -LiteralPath $log
    $code=1
}
$timer.Stop()
$record=@{schema=1;batch=$Batch;head=$binding.baseHead;observedCheckpointHead=$head;consumedSourceIdentity=$snapshot.sourceIdentity;consumedInputsVerified=$snapshot.files.Count;startedUtc=$started.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');elapsedSeconds=$timer.Elapsed.TotalSeconds;exitCode=$code;status=if($code -eq 0){'COMMAND_PASS_PENDING_RECEIPT_REVIEW'}else{'FAIL'};sourceFiles=$sourceFiles}
$record.acceptancePlanSha256=$acceptanceHash
if(-not $isCold){$record.frozenPlanSha256=$frozenHash;$record.cold77AuditSha256=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $taskRoot 'cold77-audit.json')).Hash.ToLowerInvariant()}
if($isCold){$record.runtime='Playwright1.63.0; fresh real Edge profile per cold case';$record.sequence=($tag+'/sequence.json')}
else{$record.serviceSeeds=@($nativeArgs.Q30ServiceSeeds | ForEach-Object {$_.ToString()});$record.sensitivitySeeds=@($nativeArgs.Q30SensitivitySeeds | ForEach-Object {$_.ToString()});$record.corpusSeeds=@($nativeArgs.Q30CorpusSeeds | ForEach-Object {$_.ToString()});$record.suiteCount=if($Batch -eq 'native-full'){82}else{1}}
$record | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $result
Get-Content -LiteralPath $log -Tail 9
exit $code
