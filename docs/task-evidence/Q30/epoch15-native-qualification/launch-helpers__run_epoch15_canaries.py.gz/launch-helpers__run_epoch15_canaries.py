import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

workspace=Path(r'<workspace>')
repo=Path(r'<repo>')
binding=json.loads((workspace/'epoch15-task-pointer.json').read_text())
task=Path(binding['taskRoot'])
parser=argparse.ArgumentParser()
parser.add_argument('--tag',default='compiled-canaries')
parser.add_argument('--plan-name',default='scale-plan.json')
parser.add_argument('--dependency-path',type=Path)
parser.add_argument('--prepared-directory',default='isolated')
args=parser.parse_args()
prepared=task/args.prepared_directory
child_env=dict(os.environ)
if args.dependency_path:
    child_env['PYTHONPATH']=str(args.dependency_path)
dependency_version=subprocess.check_output([sys.executable,'-c',"import importlib.metadata; print(importlib.metadata.version('playwright'))"],env=child_env,text=True).strip()
if args.dependency_path: assert dependency_version=='1.63.0'
build=json.loads((task/(args.prepared_directory+'-build-result.json')).read_text(encoding='utf-8-sig'))
assert build['status']=='PASS'
spec=task/(args.tag+'-spec.json')
host_output=task/args.tag
assert not spec.exists() and not host_output.exists()
cases=[]
for mode in ['manifest-export','unauthorized','cancel','scope-loss']:
    cases.append({'name':mode,'path':'circuitjs.html?lang=en&tsjNormalMode='+mode+'&tsjNormalSeed=10387',
                  'stateAttribute':'data-tsj-q30-normal-state','reportAttribute':'data-tsj-q30-normal-report',
                  'timeoutSeconds':150,'expectedPrefix':'SCREEN_DONE','terminalPrefixes':['SCREEN_DONE']})
spec.write_text(json.dumps({'cases':cases},indent=2)+'\n')
record={'schema':1,'startedUtc':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),
        'executable':sys.executable,'head':binding['baseHead'],'stage':'COMPILED_CANARIES_AND_MANIFEST_FREEZE','status':'RUNNING','playwrightVersion':dependency_version}
result_path=task/(args.tag+'-stage-result.json')
def save(): result_path.write_text(json.dumps(record,indent=2)+'\n')
save()
started=time.monotonic()
command=[sys.executable,str(prepared/'host/normal_screen_host.py'),str(prepared/'app'),str(host_output),str(spec)]
record['hostCommand']=command
with (task/(args.tag+'-host.log')).open('w') as log:
    host=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=child_env)
record['hostExitCode']=host.returncode
save()
assert host.returncode==0,'Host failure; preserved compiled-canaries-host.log'
host_result=json.loads((host_output/'result.json').read_text())
assert host_result['outcome']=='PASS' and host_result['cleanup']['status']=='PASS'
for index,mode in enumerate(['unauthorized','cancel','scope-loss'],2):
    report=json.loads((host_output/'cases'/f'{index:03d}-{mode}.report.json').read_text())
    assert report['classification']=='CANARY_PASS', (mode, report.get('classification'))
    assert report.get('cleanupComplete') is True, mode
record['canaries']='PASS: unauthorized/cancel/scope-loss; application and host cleanup'
freeze=[sys.executable,str(repo/'tests/qualification/q30-scale-acceptance/freeze_plan.py'),str(repo),
        str(prepared/'prepare-receipt.json'),str(host_output/'cases/001-manifest-export.report.json'),
        str(prepared/'app'),str(task/args.plan_name),'--manifest-export-host-record',str(host_output/'result.json'),
        '--acceptance-plan',str(task/'acceptance-plan.json')]
record['freezeCommand']=freeze
with (task/(args.tag+'-manifest-freeze.log')).open('w') as log:
    freeze_result=subprocess.run(freeze,stdout=log,stderr=subprocess.STDOUT,env=child_env)
record['freezeExitCode']=freeze_result.returncode
save()
assert freeze_result.returncode==0,'Manifest freezing failure; preserved manifest-freeze.log'
plan=json.loads((task/args.plan_name).read_text())
assert len(plan['cases'])==77 and sum(len(row['candidates']) for row in plan['cases'])==308
record.update({'status':'PASS','finishedUtc':datetime.now(timezone.utc).isoformat(),
               'elapsedSeconds':time.monotonic()-started,'sourceIdentity':plan['sourceIdentity'],
               'roots':77,'candidateManifests':308,'cleanupSeconds':host_result['cleanup']['seconds']})
save()
print(json.dumps(record),flush=True)
