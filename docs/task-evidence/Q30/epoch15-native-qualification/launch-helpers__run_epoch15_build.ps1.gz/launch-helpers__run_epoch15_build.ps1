param([ValidateSet('isolated','isolated-readerfix')][string]$Tag='isolated')
$ErrorActionPreference='Stop'
$binding=Get-Content -LiteralPath '<workspace>\epoch15-task-pointer.json' -Raw | ConvertFrom-Json
$taskRoot=$binding.taskRoot
$app=Join-Path $taskRoot ($Tag+'\app')
$log=Join-Path $taskRoot ($Tag+'-build.log')
$result=Join-Path $taskRoot ($Tag+'-build-result.json')
if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $result)){throw 'Build output exists'}
$self=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID)
@{schema=1;pid=$PID;createdUtc=$self.CreationDate.ToUniversalTime().ToString('o');executable=$self.ExecutablePath;command=$self.CommandLine;taskRoot=$taskRoot;app=$app} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $taskRoot ($Tag+'-build-ownership.json'))
$started=[DateTime]::UtcNow
$timer=[Diagnostics.Stopwatch]::StartNew()
Push-Location -LiteralPath $app
try {
    & .\scripts\build.ps1 -JavaHome '<os-temp>\q30-finish-0fa2512465\jdk\jdk8u502-b07' *> $log
    $ok=$?
    $code=$LASTEXITCODE
    if($null -eq $code){$code=if($ok){0}else{1}}
} finally {Pop-Location}
$timer.Stop()
$content=Get-Content -LiteralPath $log -Raw
$confirmed=$content.Contains('Compilation succeeded --') -and $content.Contains('Linking succeeded --') -and -not $content.Contains('BUILD_INFRASTRUCTURE:')
@{schema=1;head=$binding.baseHead;startedUtc=$started.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');elapsedSeconds=$timer.Elapsed.TotalSeconds;exitCode=$code;compilationConfirmed=$confirmed;status=if($code -eq 0 -and $confirmed){'PASS'}else{'FAIL'};scope='Fresh reviewed layout15 isolated qualification app; shipped Q30 catalog disabled';prepareReceipt=($Tag+'/prepare-receipt.json')} | ConvertTo-Json | Set-Content -LiteralPath $result
Get-Content -LiteralPath $log -Tail 7
if($code -eq 0 -and -not $confirmed){exit 1}
exit $code
