param([ValidateSet('native-full','native-append')][string]$Batch='native-full')
$ErrorActionPreference='Stop'
$binding=Get-Content -LiteralPath '<workspace>\epoch15-task-pointer.json' -Raw | ConvertFrom-Json
$task=$binding.taskRoot
$destination=Join-Path $task ($Batch+'-cleanup-review.json')
if(Test-Path -LiteralPath $destination){throw 'Preserve prior cleanup review'}
$owner=Get-Content -LiteralPath (Join-Path $task ($Batch+'-ownership.json')) -Raw | ConvertFrom-Json
$actual=Get-CimInstance Win32_Process -Filter ('ProcessId='+$owner.pid)
$sameInstance=$false
if($null -ne $actual){$sameInstance=$actual.CreationDate.ToUniversalTime().Ticks -eq ([DateTime]$owner.createdUtc).ToUniversalTime().Ticks}
$scratch=@()
if(Test-Path -LiteralPath (Join-Path $task ($Batch+'-live-children.json'))){
    $children=Get-Content -LiteralPath (Join-Path $task ($Batch+'-live-children.json')) -Raw | ConvertFrom-Json
    foreach($child in $children.rows){
        $match=[regex]::Match($child.CommandLine,'(?<path>[A-Za-z]:\\[^";]*\\TroubleshootJS-current-contracts-[0-9a-f]{32})\\classes')
        if(-not $match.Success){throw 'Recorded unique verifier scratch path not found'}
        $scratchPath=$match.Groups['path'].Value
        $resolved=[IO.Path]::GetFullPath($scratchPath)
        $tempRoot=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
        if(-not $resolved.StartsWith($tempRoot,[StringComparison]::OrdinalIgnoreCase)){throw 'Recorded scratch path outside OS temp'}
        $survivors=@(Get-CimInstance Win32_Process -Filter "Name='java.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.Contains($scratchPath)})
        $scratch+=@{path=$scratchPath;exists=(Test-Path -LiteralPath $scratchPath);liveJvmCount=$survivors.Count;liveJvms=@($survivors | Select-Object ProcessId,ParentProcessId,@{n='createdUtc';e={$_.CreationDate.ToUniversalTime().ToString('o')}},ExecutablePath,CommandLine)}
    }
}
$badScratch=@($scratch | Where-Object {$_.exists -or $_.liveJvmCount -ne 0})
$record=@{schema=1;batch=$Batch;observedUtc=[DateTime]::UtcNow.ToString('o');recordedWrapperPid=$owner.pid;recordedWrapperCreationUtc=$owner.createdUtc;recordedWrapperInstanceGone=(-not $sameInstance);pidCurrentlyPresent=($null -ne $actual);noTerminationPerformed=$true;scratch=$scratch;status=if(-not $sameInstance -and $badScratch.Count -eq 0){'PASS'}else{'FAIL'};limit=if($scratch.Count -eq 0){'Wrapper absence independent; maintained log must confirm JVM/scratch cleanup'}else{'Captured unique scratch and all matching JVMs independently absent'}}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $destination
'Cleanup review '+$record.status+'; wrapper instance gone='+$record.recordedWrapperInstanceGone+'; scratch failures='+$badScratch.Count
if($record.status -ne 'PASS'){exit 1}
