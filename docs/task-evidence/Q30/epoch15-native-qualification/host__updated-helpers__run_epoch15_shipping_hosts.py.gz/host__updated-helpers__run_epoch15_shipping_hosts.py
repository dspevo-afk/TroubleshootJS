"""Fresh compiled31 or disabled-menu check on the audited unchanged shipping build."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('stage', choices=['compiled31', 'disabled-menu'])
args = parser.parse_args()
host_python = r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe'
workspace = Path(__file__).resolve().parent
repo = Path(r'<repo>')
binding = json.loads((workspace / 'epoch15-task-pointer.json').read_text(encoding='utf-8'))
task = Path(binding['taskRoot'])
shipping = Path(r'<os-temp>\q30-original-route-9e830ef8cad64a8681a600e116414df6\shipping-epoch15\app')
old_task = Path(r'<os-temp>\q30-finish-0fa2512465')
assert importlib.metadata.version('playwright') == '1.63.0', 'Use the retained pinned Playwright dependency path'
host_environment = dict(os.environ)
host_environment.update({'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONIOENCODING': 'utf-8'})
assert subprocess.check_output([host_python, '-B', '-c', "from playwright.sync_api import sync_playwright; import importlib.metadata; print(importlib.metadata.version('playwright'))"], env=host_environment, text=True).strip() == '1.63.0'
snapshot = json.loads((task / 'source-snapshot.json').read_text(encoding='utf-8'))
assert snapshot['sourceIdentity'] == binding['sourceIdentity']
assert len(snapshot['files']) == 1354
build = json.loads((shipping.parent.parent / 'final-build-result.json').read_text(encoding='utf-8-sig'))
assert build['exitCode'] == 0 and build['confirmed'] is True, 'Reviewed final-source disabled build missing'
audit = json.loads((task / 'shipping-build-reuse.json').read_text(encoding='utf-8'))
assert audit['status'] == 'PASS'
assert hashlib.sha256((shipping.parent.parent / 'final-build-result.json').read_bytes()).hexdigest() == audit['priorBuildResultSha256'], 'Build receipt changed after reviewed reuse audit'
output = task / args.stage
destination = task / (args.stage + '-stage-result.json')
log = task / (args.stage + '.log')
assert not output.exists() and not destination.exists() and not log.exists(), 'Preserve prior output'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def input_inventory():
    for row in snapshot['files']:
        for root in [repo, shipping]:
            path = root / row['path']
            assert path.stat().st_size == row['size'] and digest(path) == row['sha256'], 'Raw input changed: ' + str(path)
    compiled = shipping / 'war/circuitjs1'
    files = sorted(path for path in compiled.rglob('*') if path.is_file())
    assert files and any(path.name.endswith('.cache.js') for path in files), 'Compiled permutations missing'
    return [{'path': path.relative_to(shipping).as_posix(), 'size': path.stat().st_size, 'sha256': digest(path)} for path in files]

before = input_inventory()
catalog = (shipping / 'src/com/lushprojects/circuitjs1/client/PlayerFamilyCatalog.java').read_text(encoding='utf-8')
assert 'registerStagedFamily(new Rb30PlayerFamilyCapability(), false)' in catalog
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo)]
head = subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip()
assert subprocess.run(git + ['merge-base', '--is-ancestor', binding['baseHead'], head], capture_output=True).returncode == 0
owner_query = "Get-CimInstance Win32_Process -Filter 'ProcessId=" + str(os.getpid()) + "' | Select-Object ProcessId,ParentProcessId,@{n='createdUtc';e={$_.CreationDate.ToUniversalTime().ToString('o')}},ExecutablePath,CommandLine | ConvertTo-Json -Compress"
owner_capture = subprocess.run(['powershell.exe', '-NoProfile', '-Command', owner_query], capture_output=True, text=True, timeout=20)
assert owner_capture.returncode == 0, 'Process identity query failed: ' + owner_capture.stderr
owner = json.loads(owner_capture.stdout)
assert owner['ProcessId'] == os.getpid() and owner['ExecutablePath'].lower() == sys.executable.lower(), 'Runner process identity mismatch'
record = {'schema': 1, 'head': head, 'candidateBaseHead': binding['baseHead'],
          'sourceIdentity': binding['sourceIdentity'], 'stage': args.stage,
          'startedUtc': datetime.now(timezone.utc).isoformat(), 'pid': os.getpid(),
          'executable': sys.executable, 'owner': owner, 'status': 'RUNNING', 'shippingApp': str(shipping),
          'rawInputsVerified': len(snapshot['files']), 'compiledInputsBefore': before,
          'buildReuse': 'All reviewed raw inputs unchanged; disabled five-permutation final-source JDK8/GWT build',
          'q30NormalPlayerEnabled': False}
started = time.monotonic()

def save():
    destination.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')

save()
try:
    if args.stage == 'compiled31':
        spec_path = task / 'compiled31-spec.json'
        oracle_path = task / 'compiled31-declared-physical-rejection.json'
        spec_raw = (old_task / 'compiled-gate-plan/compiled-gates.json').read_bytes()
        assert hashlib.sha256(spec_raw).hexdigest() == '898145a040b8920350461961dbad85b94f2d7ef286e95a0ebd347781d291bc97'
        assert len(json.loads(spec_raw)['cases']) == 31
        for target, raw in [(spec_path, spec_raw), (oracle_path, (old_task / 'compiled-gate-plan/declared-physical-rejection.json').read_bytes())]:
            assert not target.exists()
            target.write_bytes(raw)
        record['specSha256'] = digest(spec_path)
        record['declaredOracleSha256'] = digest(oracle_path)
        runner = repo / 'tests/browser/compiled_attribute_acceptance.py'
        command = [host_python, '-B', '-u', str(runner), str(shipping), str(output), str(spec_path)]
    else:
        compiled_review = json.loads((task / 'compiled31-audit.json').read_text(encoding='utf-8'))
        assert compiled_review['status'] == 'PASS', 'Semantically reviewed compiled31 receipt required'
        runner = repo / 'tests/browser/quickplay_procedural_acceptance.py'
        command = [host_python, '-B', '-u', str(runner), str(shipping), str(output)]
    record.update({'runnerSha256': digest(runner), 'command': command})
    save()
    with log.open('w', encoding='utf-8') as stream:
        host = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, env=host_environment)
    record['exitCode'] = host.returncode
    after = input_inventory()
    record['compiledInputsAfter'] = after
    assert before == after and digest(runner) == record['runnerSha256'], 'Consumed source/build/runner changed'
    record['consumedInputsUnchanged'] = True
    assert host.returncode == 0, 'Host returned nonzero; preserve exact failure'
    result = json.loads((output / 'result.json').read_text(encoding='utf-8'))
    assert result['outcome'] == 'PASS' and not result['errors'], 'Host report nonpass'
    record['hostOutcome'] = result['outcome']
    record['status'] = 'COMMAND_PASS_PENDING_RECEIPT_REVIEW'
except Exception as error:
    record.update({'status': 'FAIL', 'error': str(error)})
finally:
    record['finishedUtc'] = datetime.now(timezone.utc).isoformat()
    record['elapsedSeconds'] = time.monotonic() - started
    save()
    print(json.dumps({key: value for key, value in record.items() if key not in {'compiledInputsBefore', 'compiledInputsAfter'}}), flush=True)
sys.exit(0 if record['status'] == 'COMMAND_PASS_PENDING_RECEIPT_REVIEW' else 1)
