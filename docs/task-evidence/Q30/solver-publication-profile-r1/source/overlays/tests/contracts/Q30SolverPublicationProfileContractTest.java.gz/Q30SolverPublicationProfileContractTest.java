package com.lushprojects.circuitjs1.client;

/**
 * JVM-native contract for the private Q30 solver-publication sampler.
 *
 * <p>The clock is injected so these checks do not invoke browser JSNI or
 * construct any GWT JSON.  The expected selection counts are independent of
 * the production solver and verify the one-based 512/1024 boundaries for
 * every phase.</p>
 */
public final class Q30SolverPublicationProfileContractTest {
    private static int assertions;

    private Q30SolverPublicationProfileContractTest() { }

    public static void main(String[] args) {
        int count = run();
        System.out.println("PASS: Q30 solver publication profile contracts assertions=" + count);
    }

    public static int run() {
        assertions = 0;
        verifyIndependent512And1024Selection();
        verifyAcceptedSpanExcludesImmediateWireWindow();
        verifyMultiplePauseAccountingAndIllegalFinalization();
        verifyFiniteZeroBackwardNonfiniteAndThrowClocks();
        verifyExceptionFinallyAndFailureCounters();
        verifyFreezeAndNoAliases();
        verifyColdWarmIsolation();
        verifyUnknownPathInvalidation();
        return assertions;
    }

    private static void verifyIndependent512And1024Selection() {
        int[] phases = {
            Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE,
            Q30SolverPublicationProfile.ROLLBACK_VOLTAGE_PUBLICATION,
            Q30SolverPublicationProfile.WIRE_REFRESH_IMMEDIATE_ACCEPTED_STEP,
            Q30SolverPublicationProfile.WIRE_REFRESH_DELAYED_OWNED_ACCEPTED_STEP,
            Q30SolverPublicationProfile.WIRE_REFRESH_DEFERRED_UI_BATCH,
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING
        };
        for (int phase : phases) {
            Q30SolverPublicationProfile profile =
                new Q30SolverPublicationProfile(new SequenceClock(0, 1, 2, 3));
            for (int call = 0; call < 1024; call++) {
                Q30SolverPublicationProfile.Sample sample = profile.begin(phase);
                if (sample != null) sample.finish(true);
            }
            Q30SolverPublicationProfile.Snapshot snapshot = profile.freeze();
            check(snapshot.isValid(), "finite independent phase became invalid " + phase);
            check(snapshot.isFrozen(), "independent phase was not frozen " + phase);
            check(snapshot.eligible(phase) == 1024,
                "phase eligible count did not reach 1024 " + phase);
            check(snapshot.selected(phase) == 2,
                "phase selected count did not hit 512/1024 " + phase);
            check(snapshot.completed(phase) == 2,
                "phase completed count did not match selected count " + phase);
            check(snapshot.failed(phase) == 0,
                "finite phase recorded a failed selected operation " + phase);
            check(snapshot.rawDurationCount(phase) == 2,
                "finite phase did not retain both bounded raw samples " + phase);
        }
    }

    private static void verifyAcceptedSpanExcludesImmediateWireWindow() {
        Q30SolverPublicationProfile profile =
            new Q30SolverPublicationProfile(new SequenceClock(0, 10, 30, 40));
        Q30SolverPublicationProfile.Sample sample = null;
        for (int call = 0; call < 511; call++)
            check(profile.begin(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == null,
                "accepted span selected before the 512th call");
        sample = profile.begin(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING);
        check(sample != null, "accepted span did not select its 512th call");
        sample.pause();
        sample.resume();
        sample.finish(true);
        Q30SolverPublicationProfile.Snapshot snapshot = profile.freeze();
        check(snapshot.isValid(), "accepted pause/resume fixture became invalid");
        check(snapshot.elapsedMillis(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == 20,
            "accepted span included the paused immediate-wire interval");
        check(snapshot.zeroDurationCount(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == 0,
            "accepted finite span was incorrectly zero duration");
    }

    private static void verifyMultiplePauseAccountingAndIllegalFinalization() {
        Q30SolverPublicationProfile onePause =
            new Q30SolverPublicationProfile(new SequenceClock(0, 5, 15, 20));
        for (int call = 0; call < 511; call++)
            check(onePause.begin(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == null,
                "one-pause fixture selected before its 512th call");
        Q30SolverPublicationProfile.Sample onePauseSample = onePause.begin(
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING);
        check(onePauseSample != null, "one-pause fixture did not select its operation");
        onePauseSample.pause();
        onePauseSample.resume();
        onePauseSample.finish(true);
        Q30SolverPublicationProfile.Snapshot onePauseSnapshot = onePause.freeze();
        check(onePauseSnapshot.isValid(), "one-pause fixture became invalid");
        check(onePauseSnapshot.elapsedMillis(
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == 10,
            "one-pause fixture included its ten-millisecond pause");

        Q30SolverPublicationProfile multiplePauses =
            new Q30SolverPublicationProfile(new SequenceClock(0, 3, 14, 21, 34, 36));
        for (int call = 0; call < 511; call++)
            check(multiplePauses.begin(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == null,
                "multiple-pause fixture selected before its 512th call");
        Q30SolverPublicationProfile.Sample multiplePauseSample = multiplePauses.begin(
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING);
        check(multiplePauseSample != null, "multiple-pause fixture did not select its operation");
        multiplePauseSample.pause();
        multiplePauseSample.resume();
        multiplePauseSample.pause();
        multiplePauseSample.resume();
        multiplePauseSample.finish(true);
        Q30SolverPublicationProfile.Snapshot multiplePauseSnapshot = multiplePauses.freeze();
        check(multiplePauseSnapshot.isValid(), "multiple-pause fixture became invalid");
        check(multiplePauseSnapshot.elapsedMillis(
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == 12,
            "multiple-pause fixture did not retain three active spans");

        Q30SolverPublicationProfile illegalFinish =
            new Q30SolverPublicationProfile(new SequenceClock(0, 5, 9));
        for (int call = 0; call < 511; call++)
            illegalFinish.begin(Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING);
        Q30SolverPublicationProfile.Sample paused = illegalFinish.begin(
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING);
        check(paused != null, "illegal-finish fixture did not select its operation");
        paused.pause();
        paused.finish(true);
        paused.finish(false);
        Q30SolverPublicationProfile.Snapshot illegalFinishSnapshot = illegalFinish.freeze();
        check(!illegalFinishSnapshot.isValid(),
            "finish while paused and duplicate finish were accepted");
        check(illegalFinishSnapshot.lateErrors() >= 2,
            "illegal finish operations were not counted as lifecycle errors");
        check(illegalFinishSnapshot.openSamples() == 0,
            "illegal finish fixture retained an open sample");
        check(illegalFinishSnapshot.rawDurationCount(
            Q30SolverPublicationProfile.ACCEPTED_STEP_BOOKKEEPING) == 0,
            "illegal finish fixture published a partial duration");
    }

    private static void verifyFiniteZeroBackwardNonfiniteAndThrowClocks() {
        Q30SolverPublicationProfile finite =
            new Q30SolverPublicationProfile(new SequenceClock(4, 9));
        completeSelected(finite, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot finiteSnapshot = finite.freeze();
        check(finiteSnapshot.isValid(), "finite clock fixture was rejected");
        check(finiteSnapshot.elapsedMillis(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 5,
            "finite clock duration was not retained");

        Q30SolverPublicationProfile zero =
            new Q30SolverPublicationProfile(new SequenceClock(7, 7));
        completeSelected(zero, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot zeroSnapshot = zero.freeze();
        check(zeroSnapshot.isValid(), "zero-duration clock fixture was rejected");
        check(zeroSnapshot.zeroDurationCount(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 1,
            "zero-duration sample was not counted");
        check(zeroSnapshot.elapsedMillis(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 0,
            "zero-duration sample acquired a nonzero duration");

        Q30SolverPublicationProfile backward =
            new Q30SolverPublicationProfile(new SequenceClock(9, 8));
        completeSelected(backward, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot backwardSnapshot = backward.freeze();
        check(!backwardSnapshot.isValid(), "backward clock was accepted as physical timing");
        check(backwardSnapshot.timerErrors() == 1,
            "backward clock did not record one timer error");

        Q30SolverPublicationProfile nonfinite =
            new Q30SolverPublicationProfile(new SequenceClock(Double.NaN, 8));
        completeSelected(nonfinite, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot nonfiniteSnapshot = nonfinite.freeze();
        check(!nonfiniteSnapshot.isValid(), "nonfinite clock was accepted as timing");
        check(nonfiniteSnapshot.timerErrors() == 1,
            "nonfinite clock did not record one timer error");

        Q30SolverPublicationProfile throwing =
            new Q30SolverPublicationProfile(new ThrowingClock());
        completeSelected(throwing, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot throwingSnapshot = throwing.freeze();
        check(!throwingSnapshot.isValid(), "throwing clock was accepted as timing");
        check(throwingSnapshot.timerErrors() == 1,
            "throwing clock did not record one timer error");

        Q30SolverPublicationProfile acrossSamples =
            new Q30SolverPublicationProfile(new SequenceClock(4, 9, 8, 10));
        completeSelected(acrossSamples, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        completeSelected(acrossSamples, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot acrossSamplesSnapshot = acrossSamples.freeze();
        check(!acrossSamplesSnapshot.isValid(),
            "backwards clock between selected operations was accepted");
        check(acrossSamplesSnapshot.timerErrors() == 1,
            "backwards clock between selected operations was not counted once");
    }

    private static void verifyExceptionFinallyAndFailureCounters() {
        Q30SolverPublicationProfile profile =
            new Q30SolverPublicationProfile(new SequenceClock(1, 2, 3, 4));
        for (int call = 0; call < 511; call++)
            profile.begin(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        Q30SolverPublicationProfile.Sample failed =
            profile.begin(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        check(failed != null, "failure fixture did not select the 512th operation");
        try {
            throw new IllegalStateException("fixture operation failure");
        } catch (IllegalStateException expected) {
            // The physical exception is handled by the fixture; the finally
            // path below is the contract under test.
        } finally {
            failed.finish(false);
        }
        for (int call = 0; call < 511; call++)
            profile.begin(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        Q30SolverPublicationProfile.Sample completed =
            profile.begin(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        check(completed != null, "second failure fixture did not select 1024th operation");
        completed.finish(true);
        Q30SolverPublicationProfile.Snapshot snapshot = profile.freeze();
        check(snapshot.isValid(), "exception-finally fixture became invalid");
        check(snapshot.selected(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 2,
            "exception-finally fixture selected count changed");
        check(snapshot.completed(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 1,
            "exception-finally fixture lost completed count");
        check(snapshot.failed(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 1,
            "exception-finally fixture lost failed count");
        check(snapshot.openSamples() == 0, "exception-finally fixture retained an open sample");
    }

    private static void verifyFreezeAndNoAliases() {
        Q30SolverPublicationProfile openProfile =
            new Q30SolverPublicationProfile(new SequenceClock(1, 2));
        for (int call = 0; call < 511; call++) openProfile.begin(
            Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        Q30SolverPublicationProfile.Sample openSample = openProfile.begin(
            Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        check(openSample != null, "open-sample fixture did not select the 512th call");
        Q30SolverPublicationProfile.Snapshot openSnapshot = openProfile.freeze();
        check(!openSnapshot.isValid() && openSnapshot.openSamples() == 1,
            "freeze accepted an open selected sample");
        openSample.finish(false);

        Q30SolverPublicationProfile profile =
            new Q30SolverPublicationProfile(new SequenceClock(2, 5));
        completeSelected(profile, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot first = profile.freeze();
        double[] detached = first.rawDurations(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE);
        check(detached.length == 1 && detached[0] == 3,
            "frozen sample was not copied into its value snapshot");
        detached[0] = 9000;
        check(first.rawDurations(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE)[0] == 3,
            "raw duration accessor exposed a mutable alias");
        check(profile.begin(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == null,
            "frozen profile accepted a late operation");
        Q30SolverPublicationProfile.Snapshot late = profile.freeze();
        check(!late.isValid() && late.lateErrors() >= 2,
            "freeze/late operation errors were not rejected");
        check(first.isValid(), "first frozen snapshot changed after a late operation");
    }

    private static void verifyColdWarmIsolation() {
        Q30SolverPublicationProfile cold =
            new Q30SolverPublicationProfile(new SequenceClock(10, 14));
        completeSelected(cold, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot coldSnapshot = cold.freeze();

        Q30SolverPublicationProfile warm =
            new Q30SolverPublicationProfile(new SequenceClock(30, 45));
        completeSelected(warm, Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE, true);
        Q30SolverPublicationProfile.Snapshot warmSnapshot = warm.freeze();

        check(cold != warm, "cold and warm runs reused the profile object");
        check(coldSnapshot.rawDurations(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE)[0] == 4,
            "cold profile was changed by the warm run");
        check(warmSnapshot.rawDurations(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE)[0] == 15,
            "warm profile did not retain its own timing");
        check(coldSnapshot.eligible(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 512 &&
                warmSnapshot.eligible(Q30SolverPublicationProfile.APPLY_SOLVED_RIGHT_SIDE) == 512,
            "cold/warm eligible counters were not isolated");
    }

    private static void verifyUnknownPathInvalidation() {
        Q30SolverPublicationProfile profile =
            new Q30SolverPublicationProfile(new SequenceClock(0, 1));
        check(profile.begin(12345) == null, "unknown phase unexpectedly returned a sample");
        Q30SolverPublicationProfile.Snapshot snapshot = profile.freeze();
        check(!snapshot.isValid(), "unknown phase was not invalidated");
        check(snapshot.unknownPathErrors() == 1,
            "unknown phase error count was not retained");
    }

    private static void completeSelected(Q30SolverPublicationProfile profile,
            int phase, boolean completed) {
        for (int call = 0; call < 511; call++) profile.begin(phase);
        Q30SolverPublicationProfile.Sample sample = profile.begin(phase);
        check(sample != null, "expected selected sample at 512 for phase " + phase);
        sample.finish(completed);
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private static final class SequenceClock implements Q30SolverPublicationProfile.Clock {
        private final double[] values;
        private int index;

        SequenceClock(double... values) {
            if (values == null || values.length == 0)
                throw new IllegalArgumentException("empty clock fixture");
            this.values = values.clone();
        }

        @Override public double now() {
            if (index >= values.length) return values[values.length - 1];
            return values[index++];
        }
    }

    private static final class ThrowingClock implements Q30SolverPublicationProfile.Clock {
        @Override public double now() {
            throw new IllegalStateException("fixture clock failure");
        }
    }
}
