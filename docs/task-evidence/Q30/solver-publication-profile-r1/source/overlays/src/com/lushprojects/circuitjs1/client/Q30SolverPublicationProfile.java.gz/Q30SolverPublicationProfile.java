package com.lushprojects.circuitjs1.client;

import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONBoolean;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Bounded, debug-only timing state for the Q30 solver publication probe.
 *
 * <p>This object contains counters and fixed-size timing samples only.  It has
 * no reference to a simulator, graph, element, node, or generation owner.  A
 * verifier owns one instance for one cold or warm run and freezes it before it
 * publishes the value-only snapshot.</p>
 */
final class Q30SolverPublicationProfile {
    static final int SAMPLE_INTERVAL = 512;
    static final int MAX_RAW_DURATIONS = 64;

    static final int APPLY_SOLVED_RIGHT_SIDE = 0;
    static final int ROLLBACK_VOLTAGE_PUBLICATION = 1;
    static final int WIRE_REFRESH_IMMEDIATE_ACCEPTED_STEP = 2;
    static final int WIRE_REFRESH_DELAYED_OWNED_ACCEPTED_STEP = 3;
    static final int WIRE_REFRESH_DEFERRED_UI_BATCH = 4;
    static final int ACCEPTED_STEP_BOOKKEEPING = 5;
    private static final int PHASE_COUNT = 6;

    private static final String[] PHASE_NAMES = {
        "applySolvedRightSide",
        "rollbackVoltagePublication",
        "wireRefreshImmediateAcceptedStep",
        "wireRefreshDelayedOwnedAcceptedStep",
        "wireRefreshDeferredUiBatch",
        "acceptedStepBookkeeping"
    };

    interface Clock {
        double now();
    }

    private static final Clock BROWSER_CLOCK = new Clock() {
        @Override public double now() {
            return browserPerformanceNow();
        }
    };

    private final Clock clock;
    private final Phase[] phases = new Phase[PHASE_COUNT];
    private boolean frozen;
    private boolean invalid;
    private boolean clockObserved;
    private boolean hasLastClockReading;
    private double lastClockReading;
    private long timerErrors;
    private long lateErrors;
    private long unknownPathErrors;
    private int openSamples;

    Q30SolverPublicationProfile() {
        this(BROWSER_CLOCK);
    }

    Q30SolverPublicationProfile(Clock clock) {
        if (clock == null) throw new IllegalArgumentException("null publication profile clock");
        this.clock = clock;
        for (int index = 0; index < PHASE_COUNT; index++)
            phases[index] = new Phase(PHASE_NAMES[index]);
    }

    /**
     * Begins one eligible operation.  Null means that this operation was not
     * selected for timing; the caller must keep the physical operation on its
     * original path in that case.
     */
    Sample begin(int phaseId) {
        if (phaseId < 0 || phaseId >= PHASE_COUNT) {
            unknownPathErrors = incrementError(unknownPathErrors);
            invalid = true;
            return null;
        }
        if (frozen) {
            lateErrors = incrementError(lateErrors);
            invalid = true;
            return null;
        }
        Phase phase = phases[phaseId];
        phase.eligible++;
        if (phase.eligible <= 0) {
            invalid = true;
            phase.counterOverflow = true;
            return null;
        }
        if (phase.eligible % SAMPLE_INTERVAL != 0)
            return null;
        phase.selected++;
        openSamples++;
        return new Sample(this, phase);
    }

    /**
     * Freezes this run and returns a detached value snapshot.  A second freeze
     * is recorded as a late lifecycle error and produces a fresh detached
     * snapshot containing that invalid state.
     */
    Snapshot freeze() {
        if (frozen) {
            lateErrors = incrementError(lateErrors);
            invalid = true;
        } else {
            frozen = true;
            if (openSamples != 0) {
                lateErrors = incrementError(lateErrors);
                invalid = true;
            }
        }
        return new Snapshot(this);
    }

    private double read(Phase phase, Sample sample) {
        clockObserved = true;
        final double value;
        try {
            value = clock.now();
        } catch (Throwable problem) {
            timerErrors = incrementError(timerErrors);
            phase.timerErrors = incrementError(phase.timerErrors);
            invalid = true;
            if (sample != null) sample.clockInvalid = true;
            return Double.NaN;
        }
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            timerErrors = incrementError(timerErrors);
            phase.timerErrors = incrementError(phase.timerErrors);
            invalid = true;
            if (sample != null) sample.clockInvalid = true;
            return Double.NaN;
        }
        if (hasLastClockReading && value < lastClockReading) {
            markBackward(phase, sample);
            return Double.NaN;
        }
        hasLastClockReading = true;
        lastClockReading = value;
        return value;
    }

    private void markLate(Sample sample) {
        lateErrors = incrementError(lateErrors);
        invalid = true;
        if (sample != null) sample.clockInvalid = true;
    }

    private void markBackward(Phase phase, Sample sample) {
        timerErrors = incrementError(timerErrors);
        phase.timerErrors = incrementError(phase.timerErrors);
        invalid = true;
        if (sample != null) sample.clockInvalid = true;
    }

    private static long incrementError(long value) {
        return value == Long.MAX_VALUE ? value : value + 1;
    }

    private void finish(Sample sample, boolean operationCompleted) {
        if (sample.finished) {
            markLate(sample);
            return;
        }
        sample.finished = true;
        if (openSamples > 0) openSamples--;
        if (frozen) {
            markLate(sample);
            return;
        }
        if (operationCompleted) sample.phase.completed++;
        else sample.phase.failed++;
        if (sample.paused) {
            markLate(sample);
            return;
        }
        if (sample.clockInvalid ||
                Double.isNaN(sample.started) || Double.isInfinite(sample.started))
            return;
        double ended = read(sample.phase, sample);
        if (sample.clockInvalid || Double.isNaN(ended)) return;
        if (ended < sample.last) {
            markBackward(sample.phase, sample);
            return;
        }
        double elapsed = ended - sample.started - sample.excludedMillis;
        if (Double.isNaN(elapsed) || Double.isInfinite(elapsed) || elapsed < 0) {
            markBackward(sample.phase, sample);
            return;
        }
        sample.phase.elapsedMillis += elapsed;
        if (elapsed == 0) sample.phase.zeroDurationCount++;
        if (sample.phase.rawDurationCount < MAX_RAW_DURATIONS) {
            sample.phase.rawDurations[(int)sample.phase.rawDurationCount++] = elapsed;
        } else {
            sample.phase.rawDurationsDropped++;
        }
    }

    private void pause(Sample sample) {
        if (sample.finished || sample.paused) {
            markLate(sample);
            return;
        }
        if (frozen) {
            markLate(sample);
            return;
        }
        if (!sample.clockInvalid) {
            double point = read(sample.phase, sample);
            if (!sample.clockInvalid) {
                if (point < sample.last) markBackward(sample.phase, sample);
                else {
                    sample.pausedAt = point;
                    sample.last = point;
                }
            }
        }
        sample.paused = true;
    }

    private void resume(Sample sample) {
        if (sample.finished || !sample.paused) {
            markLate(sample);
            return;
        }
        if (frozen) {
            markLate(sample);
            return;
        }
        if (!sample.clockInvalid) {
            double point = read(sample.phase, sample);
            if (!sample.clockInvalid) {
                if (point < sample.last) markBackward(sample.phase, sample);
                else {
                    double pausedMillis = point - sample.pausedAt;
                    if (Double.isNaN(pausedMillis) || Double.isInfinite(pausedMillis) ||
                            pausedMillis < 0) {
                        markBackward(sample.phase, sample);
                    } else {
                        sample.excludedMillis += pausedMillis;
                        sample.last = point;
                    }
                }
            }
        }
        sample.paused = false;
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    private String clockName() {
        if (!clockObserved) return "not-observed";
        return invalid ? "invalid" : "performance.now";
    }

    private static native double browserPerformanceNow() /*-{
        if (typeof performance === "undefined" || performance === null ||
                typeof performance.now !== "function") return NaN;
        return performance.now();
    }-*/;

    /** One selected whole-operation timing span. */
    static final class Sample {
        private final Q30SolverPublicationProfile owner;
        private final Phase phase;
        private final double started;
        private double last;
        private double pausedAt;
        private double excludedMillis;
        private boolean paused;
        private boolean clockInvalid;
        private boolean finished;

        private Sample(Q30SolverPublicationProfile owner, Phase phase) {
            this.owner = owner;
            this.phase = phase;
            this.started = owner.read(phase, this);
            this.last = started;
            this.clockInvalid = !finite(started);
        }

        void pause() {
            owner.pause(this);
        }

        void resume() {
            owner.resume(this);
        }

        void finish(boolean operationCompleted) {
            owner.finish(this, operationCompleted);
        }
    }

    private static final class Phase {
        private final String name;
        private long eligible;
        private long selected;
        private long completed;
        private long failed;
        private long zeroDurationCount;
        private long timerErrors;
        private long rawDurationCount;
        private long rawDurationsDropped;
        private double elapsedMillis;
        private boolean counterOverflow;
        private final double[] rawDurations = new double[MAX_RAW_DURATIONS];

        Phase(String name) {
            this.name = name;
        }
    }

    /** Detached, immutable value state suitable for verifier publication. */
    static final class Snapshot {
        private final boolean valid;
        private final boolean frozen;
        private final String clock;
        private final long timerErrors;
        private final long lateErrors;
        private final long unknownPathErrors;
        private final int openSamples;
        private final PhaseSnapshot[] phases;

        private Snapshot(Q30SolverPublicationProfile source) {
            valid = !source.invalid;
            frozen = source.frozen;
            clock = source.clockName();
            timerErrors = source.timerErrors;
            lateErrors = source.lateErrors;
            unknownPathErrors = source.unknownPathErrors;
            openSamples = source.openSamples;
            phases = new PhaseSnapshot[PHASE_COUNT];
            for (int index = 0; index < PHASE_COUNT; index++)
                phases[index] = new PhaseSnapshot(source.phases[index]);
        }

        boolean isValid() { return valid; }
        boolean isFrozen() { return frozen; }
        String clock() { return clock; }
        long timerErrors() { return timerErrors; }
        long lateErrors() { return lateErrors; }
        long unknownPathErrors() { return unknownPathErrors; }
        int openSamples() { return openSamples; }
        long eligible(int phaseId) { return phase(phaseId).eligible; }
        long selected(int phaseId) { return phase(phaseId).selected; }
        long completed(int phaseId) { return phase(phaseId).completed; }
        long failed(int phaseId) { return phase(phaseId).failed; }
        long zeroDurationCount(int phaseId) { return phase(phaseId).zeroDurationCount; }
        long timerErrors(int phaseId) { return phase(phaseId).timerErrors; }
        long rawDurationCount(int phaseId) { return phase(phaseId).rawDurationCount; }
        long rawDurationsDropped(int phaseId) { return phase(phaseId).rawDurationsDropped; }
        double elapsedMillis(int phaseId) { return phase(phaseId).elapsedMillis; }

        /** Returns a copy so callers cannot mutate the frozen snapshot. */
        double[] rawDurations(int phaseId) {
            PhaseSnapshot value = phase(phaseId);
            double[] result = new double[(int)value.rawDurationCount];
            for (int index = 0; index < result.length; index++)
                result[index] = value.rawDurations[index];
            return result;
        }

        private PhaseSnapshot phase(int phaseId) {
            if (phaseId < 0 || phaseId >= PHASE_COUNT)
                throw new IllegalArgumentException("unknown publication profile phase");
            return phases[phaseId];
        }

        /** GWT-only report conversion; native contracts intentionally do not call it. */
        JSONObject toJson() {
            JSONObject result = new JSONObject();
            result.put("sampleInterval", new JSONNumber(SAMPLE_INTERVAL));
            result.put("valid", JSONBoolean.getInstance(valid));
            result.put("frozen", JSONBoolean.getInstance(frozen));
            result.put("clock", new JSONString(clock));
            result.put("timerErrors", new JSONNumber(timerErrors));
            result.put("lateErrors", new JSONNumber(lateErrors));
            result.put("unknownPathErrors", new JSONNumber(unknownPathErrors));
            result.put("openSamples", new JSONNumber(openSamples));
            long eligible = 0, selected = 0, completed = 0, failed = 0;
            double elapsed = 0;
            JSONArray values = new JSONArray();
            for (int index = 0; index < phases.length; index++) {
                PhaseSnapshot phase = phases[index];
                eligible += phase.eligible;
                selected += phase.selected;
                completed += phase.completed;
                failed += phase.failed;
                elapsed += phase.elapsedMillis;
                values.set(values.size(), phase.toJson());
            }
            result.put("eligible", new JSONNumber(eligible));
            result.put("selected", new JSONNumber(selected));
            result.put("completed", new JSONNumber(completed));
            result.put("failed", new JSONNumber(failed));
            result.put("sampledElapsedMs", new JSONNumber(elapsed));
            result.put("phases", values);
            return result;
        }
    }

    private static final class PhaseSnapshot {
        private final String name;
        private final long eligible;
        private final long selected;
        private final long completed;
        private final long failed;
        private final long zeroDurationCount;
        private final long timerErrors;
        private final long rawDurationCount;
        private final long rawDurationsDropped;
        private final double elapsedMillis;
        private final boolean counterOverflow;
        private final double[] rawDurations;

        PhaseSnapshot(Phase source) {
            name = source.name;
            eligible = source.eligible;
            selected = source.selected;
            completed = source.completed;
            failed = source.failed;
            zeroDurationCount = source.zeroDurationCount;
            timerErrors = source.timerErrors;
            rawDurationCount = source.rawDurationCount;
            rawDurationsDropped = source.rawDurationsDropped;
            elapsedMillis = source.elapsedMillis;
            counterOverflow = source.counterOverflow;
            rawDurations = new double[MAX_RAW_DURATIONS];
            for (int index = 0; index < rawDurations.length; index++)
                rawDurations[index] = source.rawDurations[index];
        }

        JSONObject toJson() {
            JSONObject result = new JSONObject();
            result.put("name", new JSONString(name));
            result.put("eligible", new JSONNumber(eligible));
            result.put("selected", new JSONNumber(selected));
            result.put("completed", new JSONNumber(completed));
            result.put("failed", new JSONNumber(failed));
            result.put("elapsedMs", new JSONNumber(elapsedMillis));
            result.put("zeroDurationCount", new JSONNumber(zeroDurationCount));
            result.put("timerErrors", new JSONNumber(timerErrors));
            result.put("rawDurationCount", new JSONNumber(rawDurationCount));
            result.put("rawDurationsDropped", new JSONNumber(rawDurationsDropped));
            result.put("counterOverflow", JSONBoolean.getInstance(counterOverflow));
            JSONArray raw = new JSONArray();
            for (int index = 0; index < rawDurationCount; index++)
                raw.set(raw.size(), new JSONNumber(rawDurations[index]));
            result.put("rawDurationsMs", raw);
            return result;
        }
    }
}
