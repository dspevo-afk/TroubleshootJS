from pathlib import Path
import json,subprocess,sys,time,os,datetime,shutil
recovery=Path(__file__).resolve().parent
repo=Path(r'<Q30_REPO>')
root=Path(sys.argv[1]);label=sys.argv[2];arm=sys.argv[3];profile=sys.argv[4]=='on'
source=root/arm;out=root/label;assert not out.exists()
query='&tsjQ30TrackingProfile=true' if profile else ''
case={'name':label,'path':'circuitjs.html?tsjChallenge=led&seed=3&tsjDebug=true&tsjVerifyQ30=true&tsjQ30Coordinator=true&tsjQ30Seed=10014'+query,'stateAttribute':'data-tsj-q30-coordinator-state','expectedState':'PASS:complete','reportAttribute':'data-tsj-q30-coordinator-report','timeoutSeconds':600}
spec=recovery/(label+'-spec.json');assert not spec.exists();spec.write_text(json.dumps({'cases':[case]},indent=2)+'\n')
def host():
 cmd=r'''$p=Get-CimInstance Win32_Processor | Select-Object Name,CurrentClockSpeed,MaxClockSpeed,LoadPercentage; $rows=Get-Process | ForEach-Object { try { [pscustomobject]@{name=$_.ProcessName;pid=$_.Id;started=$_.StartTime.ToUniversalTime().ToString('o');cpu=$_.CPU;workingSet=$_.WorkingSet64} } catch {} }; [ordered]@{utc=[DateTime]::UtcNow.ToString('o');processors=@($p);processes=@($rows)} | ConvertTo-Json -Depth 5 -Compress'''
 return json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',cmd],text=True))
before=host();(recovery/(label+'-host-before.json')).write_text(json.dumps(before,indent=2)+'\n')
started=time.monotonic();wall=time.time();env=os.environ.copy();env['PYTHONPATH']=str(root/'runtime-packages')
with (recovery/(label+'.log')).open('w',encoding='utf-8') as log:
 result=subprocess.run([sys.executable,'-B',str(repo/'tests/browser/compiled_attribute_acceptance.py'),str(source),str(out),str(spec)],stdout=log,stderr=subprocess.STDOUT,env=env)
summary={'label':label,'seed':'10014','arm':arm,'profile':profile,'exitCode':result.returncode,'hostMonotonicSeconds':time.monotonic()-started}
summary['wallMinusMonotonicSeconds']=time.time()-wall-summary['hostMonotonicSeconds'];after=host()
(recovery/(label+'-host-after.json')).write_text(json.dumps(after,indent=2)+'\n')
bmap={(p['pid'],p['started']):p for p in before['processes']}
deltas=[]
for p in after['processes']:
 prior=bmap.get((p['pid'],p['started']))
 if prior and isinstance(p['cpu'],(int,float)) and isinstance(prior['cpu'],(int,float)):
  deltas.append({'name':p['name'],'pid':p['pid'],'cpuSecondsDelta':p['cpu']-prior['cpu'],'workingSetBytes':p['workingSet']})
summary['competingProcesses']=sorted(deltas,key=lambda p:-p['cpuSecondsDelta'])[:20]
summary['cpuFrequencyLimit']='WMI nominal/current endpoint reading only; turbo, throttling and temperature not observed; ended processes absent from CPU deltas'
if (out/'result.json').exists():
 runner=json.loads((out/'result.json').read_text());summary['runnerOutcome']=runner['outcome'];summary['cleanup']=runner['cleanup'];summary['inputAudit']=runner['inputAudit']
 shutil.copy2(out/'result.json',recovery/(label+'-host-result.json'))
reports=list((out/'cases').glob('*.report.json')) if (out/'cases').exists() else []
if reports:
 raw=reports[0].read_bytes();(recovery/(label+'-raw-report.json')).write_bytes(raw);report=json.loads(raw)
 for phase in ['cold','warm']:
  if phase in report:
   row=report[phase];summary[phase]={k:row.get(k) for k in ['elapsedMs','proofElapsedMs','routingElapsedMs','totalWork','hypothesisWork','cleanupComplete']}
(recovery/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
sys.exit(result.returncode)
