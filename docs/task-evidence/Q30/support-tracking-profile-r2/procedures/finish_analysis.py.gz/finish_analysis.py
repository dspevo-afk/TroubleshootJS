from pathlib import Path
import csv, gzip, hashlib, json, sys

rec = Path(__file__).parent
scratch = Path(sys.argv[1])
repo = Path(sys.argv[2])
labels = ['01-control', '02-prototype-off', '03-profile-on', '04-prototype-off-r2',
          '05-profile-on-r2', '06-profile-on-r2', '07-prototype-off-r2', '08-control-r2']
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_text())
def write(name, obj):
    (rec / name).write_text(json.dumps(obj, indent=2) + '\n')

reference = (rec / (labels[0] + '-proof-projection.json')).read_bytes()
parity = []
rows = []
for label in labels:
    projection = (rec / (label + '-proof-projection.json')).read_bytes()
    assert projection == reference, label
    s = read(rec / (label + '-summary.json'))
    v = read(rec / (label + '-validation.json'))
    h = read(rec / (label + '-host-result.json'))
    assert s['exitCode'] == 0 and s['runnerOutcome'] == 'PASS'
    assert s['cleanup']['status'] == s['inputAudit']['status'] == v['status'] == 'PASS'
    parity.append({'label': label, 'projectionSha256': sha(projection),
                   'rawReportSha256': v['rawReportSha256'], 'strictCorruptionsRejected': 43})
    rows.append({'label': label, 'arm': s['arm'], 'profile': s['profile'],
                 'coldMs': s['cold']['elapsedMs'], 'proofMs': s['cold']['proofElapsedMs'],
                 'routingMs': s['cold']['routingElapsedMs'], 'warmMs': s['warm']['elapsedMs'],
                 'warmRoutingMs': s['warm']['routingElapsedMs'],
                 'caseMonotonicSeconds': h['cases'][0]['operationSeconds'],
                 'cleanupSeconds': s['cleanup']['seconds'],
                 'outerMonotonicSeconds': s['hostMonotonicSeconds'],
                 'wallMinusMonotonicSeconds': s['wallMinusMonotonicSeconds'],
                 'coldWorkUnits': s['cold']['totalWork'], 'coldHypothesisWorkUnits': s['cold']['hypothesisWork']})
write('parity.json', {'status': 'PASS', 'reference': labels[0], 'rows': parity,
      'excluded': ['only declared timing paths from unchanged prior pair reader',
                   'trackingProfileRequested', 'cold.trackingProfile', 'warm.trackingProfile'],
      'scope': 'full cold/warm report equality after only the listed exclusions; raw reports retained'})
with (rec / 'timings.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
by = {r['label']: r for r in rows}
pairs = []
for off, on in [('04-prototype-off-r2','05-profile-on-r2'), ('07-prototype-off-r2','06-profile-on-r2')]:
    pairs.append({'off': off, 'on': on, 'onMinusOffMs': {k: by[on][k]-by[off][k]
                  for k in ['coldMs','proofMs','routingMs','warmMs']}})
write('analysis.json', {'status': 'BLOCKED', 'rows': rows, 'finalOnOffPairs': pairs,
      'controlColdRangeMs': abs(by['08-control-r2']['coldMs']-by['01-control']['coldMs']),
      'prototypeOffColdRangeMs': abs(by['07-prototype-off-r2']['coldMs']-by['04-prototype-off-r2']['coldMs']),
      'profileOnColdRangeMs': abs(by['06-profile-on-r2']['coldMs']-by['05-profile-on-r2']['coldMs']),
      'limits': ['observed deltas, not a causal or confidence-interval estimate',
                 'one representative seed; private extended policy; no normal-player acceptance',
                 'intervening builds between first control and final comparison',
                 'dormant instrumentation code-shape overhead not isolated',
                 'WMI nominal clock only, no temperature/throttling measurement',
                 'OS caches uncontrolled; fresh browser per row; ended competing processes unobserved']})
profiles = []
for label in ['03-profile-on','05-profile-on-r2','06-profile-on-r2']:
    raw = read(rec / (label + '-raw-report.json'))
    for phase in ['cold','warm']:
        profile = raw[phase]['trackingProfile']
        for name, c in profile['categories'].items():
            profiles.append(dict(label=label, phase=phase, category=name, **c))
fields = ['label','phase','category'] + sorted(set().union(*(set(r) for r in profiles)) - {'label','phase','category'})
with (rec / 'profiles.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(profiles)

initial = read(rec / 'recovery-worktree-state.json')
preserved = {}
for key, folder in [('desktop', Path(r'<DESKTOP_REPO>')), ('q30', repo)]:
    state = initial[key]
    changed = [p for p, h in state['files'].items() if not (folder/p).is_file() or sha((folder/p).read_bytes()) != h]
    assert not changed, (key, changed)
    preserved[key] = {'status': 'PASS', 'branch': state['branch'], 'head': state['head'],
                      'preexistingChangedFilesAudited': len(state['files']), 'changedOrMissing': changed}
write('preservation.json', preserved)
baseline = read(scratch / 'baseline-source-audit.json')
final = read(rec / 'instrumented-source-audit.json')
fixture_audit = {}
for arm, records in [('control',baseline['armInputs']['control']), ('candidate',final['inputs'])]:
    assert all(sha((scratch/arm/e['path']).read_bytes()) == e['sha256'] for e in records)
    fixture_audit[arm] = {'status':'PASS','sourceInputs':len(records)}
for label in ['04-prototype-off-r2','05-profile-on-r2','06-profile-on-r2','07-prototype-off-r2']:
    assert read(rec/(label+'-summary.json'))['inputAudit']['beforeSha256'] == read(rec/'04-prototype-off-r2-summary.json')['inputAudit']['beforeSha256']
assert read(rec/'01-control-summary.json')['inputAudit']['beforeSha256'] == read(rec/'08-control-r2-summary.json')['inputAudit']['beforeSha256']
runner = repo / 'tests/browser/compiled_attribute_acceptance.py'
assert sha(runner.read_bytes()) == read(rec/'01-control-summary.json')['inputAudit']['runnerBeforeSha256']
fixture_audit['runner'] = {'status':'PASS','sha256':sha(runner.read_bytes())}
write('final-fixtures.json', fixture_audit)
print(json.dumps({'parity':'PASS','preservation':preserved,'fixtures':fixture_audit,'analysis':read(rec/'analysis.json')},indent=2))
