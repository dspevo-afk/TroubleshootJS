from pathlib import Path
import json,sys,importlib.util,copy,math,hashlib
root=Path(sys.argv[1]);rec=Path(__file__).parent;repo=Path(r'<Q30_REPO>');label=sys.argv[2]
sys.path.insert(0,str(repo/'docs/task-evidence/Q30/scale-plan-4'));import check_coordinator as reader
spec=importlib.util.spec_from_file_location('pair',repo/'docs/task-evidence/Q30/live-lu-support-r1/procedures/validate_current_q30_timing_pair.py');pair=importlib.util.module_from_spec(spec);spec.loader.exec_module(pair)
report=json.loads((rec/(label+'-raw-report.json')).read_text());raw=copy.deepcopy(report)
host=json.loads((root/label/'result.json').read_text());assert host['outcome']=='PASS' and host['cleanup']['status']=='PASS' and host['inputAudit']['status']=='PASS'
manifest=json.loads((root/label/'input-manifest-before.json').read_text())
profiles={}
for phase in ['cold','warm']:
 p=report[phase].pop('trackingProfile',None)
 if p and p['enabled']:
  assert p['clock']=='performance.now' and p['clockErrors']==0 and p['unmatchedEnds']==0 and p['openScopes']==0 and p['timingScopesBalanced']
  assert math.isfinite(p['runElapsedMs']) and p['runElapsedMs']>0
  for name,m in p['categories'].items():
   for k in ['totalCalls','timedCalls','timedStarts','openScopes','samplePeriod','measuredMs','meanMeasuredMs','maxMeasuredMs','estimatedTotalMs','workCount']:
    assert isinstance(m[k],(int,float)) and math.isfinite(m[k]) and m[k]>=0,(name,k)
   assert m['timedCalls']==m['timedStarts'] and m['openScopes']==0 and m['timedCalls']<=m['totalCalls']
   assert m['maxMeasuredMs']<=m['measuredMs']+1e-6
   if m['timedCalls']:
    assert math.isclose(m['meanMeasuredMs'],m['measuredMs']/m['timedCalls'],abs_tol=1e-8)
    assert math.isclose(m['estimatedTotalMs'],m['measuredMs']*m['totalCalls']/m['timedCalls'],abs_tol=1e-6)
   if m['timingCoverage']=='all':assert m['timedCalls']==m['totalCalls']
  profiles[phase]=p
 elif p:
  assert not p['enabled'] and not p['categories'] and p['runElapsedMs']==0
report.pop('trackingProfileRequested',None)
wrapper={'rows':[{'seed':'10014','previewSourceDigest':manifest['sourceSha256'],'previewWebDigest':manifest['webSha256'],'report':report}]}
checked=reader.check_document(wrapper,['10014'],self_test=True)
projected,removed=pair.remove_declared_timings(report)
(rec/(label+'-proof-projection.json')).write_text(json.dumps(projected,sort_keys=True)+'\n')
receipt={'status':'PASS','label':label,'strictReader':checked,'removedTimings':removed,'removedProfileMetadata':['trackingProfileRequested','cold.trackingProfile','warm.trackingProfile'],'rawReportSha256':hashlib.sha256((rec/(label+'-raw-report.json')).read_bytes()).hexdigest(),'profilePhases':list(profiles)}
(rec/(label+'-validation.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'PASS','label':label,'profilePhases':list(profiles),'strictCanaries':checked.get('canaries')}))
