from pathlib import Path
import hashlib,json,gzip,difflib,sys
root=Path(sys.argv[1]);rec=Path(__file__).parent
baseline=json.loads((root/'baseline-source-audit.json').read_text())
paths=[e['path'] for e in baseline['armInputs']['candidate']]+['src/com/lushprojects/circuitjs1/client/Q30TrackingProfile.java']
sha=lambda b:hashlib.sha256(b).hexdigest();records=[];changed=[]
old={e['path']:e for e in baseline['armInputs']['candidate']}
for rel in paths:
 raw=(root/'candidate'/rel).read_bytes();e={'path':rel,'bytes':len(raw),'sha256':sha(raw)};records.append(e)
 if rel not in old or old[rel]['sha256']!=e['sha256']:changed.append(rel)
(rec/'instrumented-source-audit.json').write_text(json.dumps({'baseCandidateAudit':'ce1b55ca0b463746b19976871a5be1401972c294bf0cc881070bdd36284b7ba4','inputs':records,'changed':changed},indent=2)+'\n')
print(json.dumps({'inputCount':len(records),'changed':changed}))
