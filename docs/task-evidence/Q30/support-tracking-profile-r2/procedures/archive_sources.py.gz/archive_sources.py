from pathlib import Path
import gzip,json,hashlib,sys
root=Path(sys.argv[1]);rec=Path(__file__).parent;repo=Path(r'<Q30_REPO>')
packet=repo/'docs/task-evidence/Q30/support-tracking-profile-r2';(packet/'source').mkdir(parents=True,exist_ok=True)
audit=json.loads((rec/'instrumented-source-audit.json').read_text());records=[]
for rel in audit['changed']:
 data=(root/'candidate'/rel).read_bytes();expected=next(r for r in audit['inputs'] if r['path']==rel);assert hashlib.sha256(data).hexdigest()==expected['sha256']
 target=packet/'source'/(rel.replace('/','__')+'.gz');target.write_bytes(gzip.compress(data,mtime=0));records.append({'path':rel,'stored':target.relative_to(packet).as_posix(),'sha256':expected['sha256'],'bytes':len(data)})
(packet/'source/overlays.json').write_text(json.dumps({'base':'live-lu-support-r1/source/overlay-map.json','appliesAfterExactLiveSupportPrototype':True,'inputs':1344,'finalOverlays':records},indent=2)+'\n')
(packet/'source/final-inputs.json.gz').write_bytes(gzip.compress((rec/'instrumented-source-audit.json').read_bytes(),mtime=0))
for name in ['pre-fix-source-audit.json','Q30CoordinatorQualificationVerifier.pre-lifecycle-fix.java.gz','CirSim.java.pre-stamp-sampling.gz']:
 data=(rec/name).read_bytes();target=packet/'source'/name
 if not name.endswith('.gz'):target=Path(str(target)+'.gz');data=gzip.compress(data,mtime=0)
 target.write_bytes(data)
print('ARCHIVED_SOURCE_OVERLAYS',len(records))
