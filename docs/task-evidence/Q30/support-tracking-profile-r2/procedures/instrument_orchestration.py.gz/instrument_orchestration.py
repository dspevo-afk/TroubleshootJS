from pathlib import Path
import json,sys
base=Path(sys.argv[1])/'src/com/lushprojects/circuitjs1/client';changes=[]
def wrap(file,signature,expr,sampled=False):
 p=base/file;s=p.read_text();assert s.count(signature)==1,(file,signature)
 left=s.index('{',s.index(signature));depth=1;i=left+1;state='code'
 while depth:
  c=s[i];n=s[i:i+2]
  if state=='line':
   if c=='\n':state='code'
  elif state=='comment':
   if n=='*/':state='code';i+=1
  elif state in ('string','char'):
   if c=='\\':i+=1
   elif c==('"' if state=='string' else "'"):state='code'
  else:
   if n=='//':state='line';i+=1
   elif n=='/*':state='comment';i+=1
   elif c=='"':state='string'
   elif c=="'":state='char'
   elif c=='{':depth+=1
   elif c=='}':depth-=1
  i+=1
 right=i-1;begin='beginSampled' if sampled else 'begin';body=s[left+1:right]
 s=s[:left+1]+'\n        String q30Scope = '+expr+';\n        double q30Began = Q30TrackingProfile.'+begin+'(q30Scope);\n        try {'+body+'\n        } finally { Q30TrackingProfile.end(q30Scope, q30Began); }\n    '+s[right:]
 p.write_text(s,encoding='utf-8',newline='\n');changes.append({'file':file,'signature':signature,'category':expr,'sampled':sampled})
wrap('GenerationRequest.java','Prepared resolve(PlanCache cache)','"plan.resolve"')
for name in ['resolve','healthy','physical']:wrap('GenerationCoordinator.java','public String '+name+'(','"generation.'+name+'"')
wrap('GenerationCoordinator.java','public boolean proveNext()','"generation.proof"')
wrap('GeneratedDiagnosticProofService.java','boolean step()','"proof.unit." + nextUnit.name()')
wrap('GeneratedDiagnosticProofService.java','private void runReplayAndInstall()','"proof.replayInstall"')
wrap('GeneratedDiagnosticObservationExecutor.java','private void executeStep(GeneratedDiagnosticProgram.Step step)','"observation." + step.kind.name()')
wrap('GeneratedRuntimeDeveloperSettlement.java','static boolean stepTemporalPreparation(','"settle.temporalPreparation"')
wrap('GeneratedRuntimeDeveloperSettlement.java','static void settleHealthy(','"settle.healthy"')
wrap('GeneratedRuntimeDeveloperSettlement.java','static void settle(CirSim sim, GeneratedBoardInstance expectedOwner, String label)','"settle.runtime"')
wrap('CircuitSolverExecutor.java','void advanceFor(Object permit, double duration)','"solver.advanceDuration"')
wrap('CircuitSolverExecutor.java','private void check(Operation operation, double now)','"solver.guard"',True)
wrap('GeneratedExternalPowerBindings.java','boolean isCurrent()','"source.controlCurrentness"',True)
wrap('GeneratedExternalPowerBindings.java','String controlSignature()','"source.controlSignature"')
wrap('GeneratedExternalPowerBindings.java','void setConnected(boolean connected)','"source.setConnected"')
wrap('GeneratedExternalPowerBindings.java','void restore(GeneratedExternalPowerBindings target)','"source.restoreControls"')
wrap('GeneratedDiagnosticContextKey.java','static GeneratedDiagnosticContextKey capture(','"proof.contextCapture"')
wrap('Rb30Generator.java','Candidate construct(Rb30Plan plan, String requestedFaultId)','"construction.electrical"')
wrap('Task41SimulationSnapshot.java','void restore(CirSim sim)','"snapshot.restore"')
(Path(__file__).parent/'orchestration-instrumentation.json').write_text(json.dumps(changes,indent=2)+'\n')
print('instrumented',len(changes),'methods')
