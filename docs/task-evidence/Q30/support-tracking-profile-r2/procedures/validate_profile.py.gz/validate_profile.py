"""Independent schema/consistency reader for temporary Q30 tracking profiles.

No simulator imports or execution. Invoke with a compiled cold/warm report JSON
to validate both nested trackingProfile objects, or --self-test for negative
reader canaries. The report input is read only.
"""

import argparse
import copy
import json
import math
from pathlib import Path

MAX_EXACT = 9007199254740991
TOLERANCE = 1e-9


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value, label, *, integral=False, max_value=None):
    require(type(value) in (int, float), f"{label}: expected number")
    require(math.isfinite(value) and value >= 0, f"{label}: expected finite nonnegative number")
    if integral:
        require(value == math.floor(value) and value <= MAX_EXACT,
                f"{label}: expected exact nonnegative integer")
    if max_value is not None:
        require(value <= max_value, f"{label}: above allowed maximum")
    return value


def close(actual, expected, label):
    require(math.isclose(actual, expected, rel_tol=TOLERANCE, abs_tol=TOLERANCE),
            f"{label}: inconsistent calculated value")


def validate_profile(profile):
    """Return a compact summary; raise ValueError on malformed/inconsistent data."""
    require(type(profile) is dict, "profile: expected object")
    enabled = profile.get("enabled")
    require(type(enabled) is bool, "profile.enabled: expected Boolean")
    require(profile.get("clock") == "performance.now", "profile.clock: unexpected clock")
    require(profile.get("durationSemantics") == "inclusive; nested categories overlap",
            "profile.durationSemantics: overlap disclosure missing")
    require(type(profile.get("sampleSemantics")) is str and
            "64th attempt" in profile["sampleSemantics"] and
            "timed maximum is observed only" in profile["sampleSemantics"],
            "profile.sampleSemantics: sample disclosure missing")
    require(profile.get("estimatedTotalSemantics") ==
            "sample mean times exact call count; estimate, not measured total",
            "profile.estimatedTotalSemantics: estimate disclosure missing")
    run_elapsed = number(profile.get("runElapsedMs"), "profile.runElapsedMs")
    unmatched = number(profile.get("unmatchedEnds"), "profile.unmatchedEnds", integral=True)
    clock_errors = number(profile.get("clockErrors"), "profile.clockErrors", integral=True)
    open_scopes = number(profile.get("openScopes"), "profile.openScopes", integral=True)
    require(unmatched == 0 and clock_errors == 0 and open_scopes == 0,
            "profile: unmatched/open timing scopes or clock errors")
    require(profile.get("timingScopesBalanced") is True,
            "profile.timingScopesBalanced: expected true")
    categories = profile.get("categories")
    estimates = profile.get("sampledEstimatesMs")
    require(type(categories) is dict and type(estimates) is dict,
            "profile: categories and estimates must be objects")
    if not enabled:
        require(run_elapsed == 0 and not categories and not estimates,
                "profile: OFF run retained timer data")
        return {"enabled": False, "categoryCount": 0, "runElapsedMs": 0}

    sampled_names = set()
    total_open = 0
    for name, row in categories.items():
        require(type(name) is str and name, "category: empty name")
        require(type(row) is dict, f"{name}: expected object")
        calls = number(row.get("totalCalls"), f"{name}.totalCalls", integral=True)
        timed = number(row.get("timedCalls"), f"{name}.timedCalls", integral=True)
        starts = number(row.get("timedStarts"), f"{name}.timedStarts", integral=True)
        opened = number(row.get("openScopes"), f"{name}.openScopes", integral=True)
        period = number(row.get("samplePeriod"), f"{name}.samplePeriod", integral=True)
        work = number(row.get("workCount"), f"{name}.workCount", integral=True)
        measured = number(row.get("measuredMs"), f"{name}.measuredMs")
        mean = number(row.get("meanMeasuredMs"), f"{name}.meanMeasuredMs")
        maximum = number(row.get("maxMeasuredMs"), f"{name}.maxMeasuredMs")
        estimate = number(row.get("estimatedTotalMs"), f"{name}.estimatedTotalMs")
        mode = row.get("sampleMode")
        require(mode in ("all", "kernel-step", "call-period"),
                f"{name}.sampleMode: unexpected value")
        require(period >= 1 and (mode != "kernel-step" or period == 64),
                f"{name}.samplePeriod: invalid period")
        require(timed <= starts <= calls and opened == starts - timed,
                f"{name}: timing call/scope counts inconsistent")
        require(maximum <= measured + TOLERANCE,
                f"{name}.maxMeasuredMs: exceeds measured sum")
        close(mean, measured / timed if timed else 0, f"{name}.meanMeasuredMs")
        close(estimate, measured * calls / timed if timed else 0,
              f"{name}.estimatedTotalMs")
        coverage = "untimed" if timed == 0 else "all" if timed == calls else "sampled"
        require(row.get("timingCoverage") == coverage,
                f"{name}.timingCoverage: inconsistent")
        if timed == 0:
            require(measured == mean == maximum == estimate == 0,
                    f"{name}: untimed category contains measured duration")
        if mode == "all":
            require(period == 1, f"{name}: exact mode with sample period")
        total_open += opened
        if coverage == "sampled":
            sampled_names.add(name)
            close(number(estimates.get(name), f"sampledEstimatesMs.{name}"), estimate,
                  f"sampledEstimatesMs.{name}")
    require(total_open == open_scopes, "profile.openScopes: category sum mismatch")
    require(set(estimates) == sampled_names,
            "profile.sampledEstimatesMs: names differ from sampled categories")
    stamp = categories.get("support.runtimeStampTracking")
    if stamp is not None and stamp["sampleMode"] == "call-period":
        require(stamp["samplePeriod"] == 4096,
                "support.runtimeStampTracking: unexpected call stride")
        calibration = categories.get("support.stampTimerCalibration")
        require(type(calibration) is dict and calibration["sampleMode"] == "all" and
                calibration["totalCalls"] == stamp["timedCalls"] and
                calibration["timedCalls"] == stamp["timedCalls"],
                "support.stampTimerCalibration: selected-call pairing mismatch")
    elif stamp is not None:
        require(stamp["sampleMode"] == "kernel-step" and stamp["samplePeriod"] == 64,
                "support.runtimeStampTracking: unknown sampling mode")

    def work(name):
        return categories.get(name, {}).get("workCount")

    def calls(name):
        return categories.get(name, {}).get("totalCalls")

    attempts = work("solver.stepAttempts")
    accepted = work("solver.acceptedSteps")
    if attempts is not None and accepted is not None:
        require(accepted <= attempts, "solver: accepted steps exceed attempts")
    trials = work("solver.trials")
    resets = calls("solver.matrixRhsReset")
    do_steps = calls("solver.elementDoStep")
    if trials is not None and resets is not None:
        require(resets == trials, "solver: RHS/matrix reset calls differ from trials")
    if trials is not None and do_steps is not None:
        require(do_steps == trials, "solver: doStep loop calls differ from trials")
    factors = calls("solver.factor")
    solves = calls("solver.solve")
    if factors is not None and solves is not None:
        require(factors <= solves, "solver: nonlinear factors exceed solves")
    return {
        "enabled": True,
        "categoryCount": len(categories),
        "sampledCategoryCount": len(sampled_names),
        "runElapsedMs": run_elapsed,
        "stepAttempts": attempts,
        "acceptedSteps": accepted,
        "trials": trials,
    }


def validate_report(report):
    require(type(report) is dict, "report: expected object")
    result = {}
    for name in ("cold", "warm"):
        run = report.get(name)
        require(type(run) is dict, f"report.{name}: expected object")
        result[name] = validate_profile(run.get("trackingProfile"))
    return result


def negative_tests(report):
    """Mutate copies; the raw report and its parsed object stay unchanged."""
    validate_report(report)
    bad = []
    def corrupt(label, change):
        copy_report = copy.deepcopy(report)
        change(copy_report["cold"]["trackingProfile"])
        try:
            validate_report(copy_report)
        except ValueError:
            bad.append(label)
        else:
            raise AssertionError(f"negative reader accepted {label}")

    corrupt("missing-count", lambda p: next(iter(p["categories"].values())).pop("totalCalls"))
    corrupt("inflated-estimate", lambda p: next(iter(p["categories"].values())).__setitem__(
        "estimatedTotalMs", 1e30))
    corrupt("open-scope", lambda p: p.__setitem__("openScopes", 1))
    corrupt("wrong-clock", lambda p: p.__setitem__("clock", "Date.now"))
    corrupt("unbalanced", lambda p: p.__setitem__("timingScopesBalanced", False))
    corrupt("negative-duration", lambda p: p.__setitem__("runElapsedMs", -1))
    corrupt("nan-duration", lambda p: p.__setitem__("runElapsedMs", float("nan")))
    corrupt("bad-sample-semantics", lambda p: p.__setitem__("sampleSemantics", "exact"))
    corrupt("hidden-overlap", lambda p: p.__setitem__("durationSemantics", "disjoint"))
    corrupt("clock-error", lambda p: p.__setitem__("clockErrors", 1))
    return bad


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path, help="raw Q30 cold/warm report JSON")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    with args.report.open("r", encoding="utf-8") as stream:
        report = json.load(stream, parse_constant=lambda value: (_ for _ in ()).throw(
            ValueError(f"invalid JSON number: {value}")))
    result = {"runs": validate_report(report)}
    if args.self_test:
        result["rejectedCorruptions"] = negative_tests(report)
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
