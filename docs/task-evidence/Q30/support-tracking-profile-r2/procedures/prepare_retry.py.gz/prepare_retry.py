from pathlib import Path
import gzip,json,hashlib,sys,subprocess
root=Path(sys.argv[1]);assert (root/'owner.txt').is_file()
repo=Path(r'<Q30_REPO>')
packet=repo/'docs/task-evidence/Q30/live-lu-support-r1'
audit=json.loads(gzip.decompress((packet/'source/source-audit.json.gz').read_bytes()))
sha=lambda b:hashlib.sha256(b).hexdigest()
overlays={e['path']:gzip.decompress((packet/e['storedAt']).read_bytes()) for e in json.loads((packet/'source/overlay-map.json').read_text())['exactFinalOverlays']}
for arm in ['control','candidate']:
    for e in audit['armInputs'][arm]:
        raw=overlays[e['path']] if arm=='candidate' and e['path'] in overlays else (repo/e['path']).read_bytes()
        assert (len(raw),sha(raw))==(e['bytes'],e['sha256']),e['path']
        p=root/arm/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    print('VERIFIED',arm,len(audit['armInputs'][arm]))
(root/'baseline-source-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
state={}
for label,tree in [('desktop',Path(r'<DESKTOP_REPO>')),('q30',repo)]:
    run=lambda *a:subprocess.check_output(['git','-C',str(tree),*a],stderr=subprocess.DEVNULL)
    paths=set(run('diff','--name-only','-z').decode().split('\0')+run('ls-files','--others','--exclude-standard','-z').decode().split('\0'))-{''}
    state[label]={'head':run('rev-parse','HEAD').decode().strip(),'branch':run('branch','--show-current').decode().strip(),'status':run('status','--short').decode(),'files':{f:sha((tree/f).read_bytes()) for f in sorted(paths) if (tree/f).is_file()}}
(Path(__file__).parent/'recovery-worktree-state.json').write_text(json.dumps(state,indent=2)+'\n')
