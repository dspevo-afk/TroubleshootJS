package com.lushprojects.circuitjs1.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import java.util.LinkedHashMap;
import java.util.Map;

/** Temporary, private Q30 measurement collector. All durations are inclusive. */
final class Q30TrackingProfile {
    private static final double OFF = Double.NaN;
    private static boolean enabled;
    private static final Map<String, Metric> metrics = new LinkedHashMap<String, Metric>();
    private static double unmatchedEnds;
    private static double clockErrors;
    private static double kernelStepAttempts;
    private static double runStartedAt;
    private static boolean kernelSampleActive;
    private static final int KERNEL_SAMPLE_PERIOD = 64;
    private static final double MAX_EXACT_COUNT = 9007199254740991d;

    private Q30TrackingProfile() { }

    static void startRun(boolean requested) {
        enabled = false;
        metrics.clear();
        unmatchedEnds = 0;
        clockErrors = 0;
        kernelStepAttempts = 0;
        runStartedAt = Double.NaN;
        kernelSampleActive = false;
        if (requested) {
            runStartedAt = now();
            enabled = true;
        }
    }

    static boolean enabled() { return enabled; }

    static void beginKernelStep() {
        if (!enabled) return;
        if (kernelStepAttempts >= MAX_EXACT_COUNT)
            throw new IllegalStateException("Q30 profile step count exceeded exact range");
        kernelSampleActive = kernelStepAttempts++ % KERNEL_SAMPLE_PERIOD == 0;
        count("solver.stepAttempts", 1);
    }

    static void endKernelStep() { kernelSampleActive = false; }

    static boolean isKernelSampleActive() { return kernelSampleActive; }

    static double beginSampled(String name) {
        if (!enabled) return OFF;
        Metric metric = metric(name);
        incrementCalls(metric);
        metric.samplePeriod = KERNEL_SAMPLE_PERIOD;
        metric.sampleMode = "kernel-step";
        if (!kernelSampleActive) return OFF;
        metric.activeStarts++;
        metric.timedStarts++;
        return now();
    }

    static double begin(String name) {
        if (!enabled) return OFF;
        Metric metric = metric(name);
        incrementCalls(metric);
        metric.activeStarts++;
        metric.timedStarts++;
        return now();
    }

    static double beginSampled(String name, int period) {
        if (!enabled) return OFF;
        if (period < 1) throw new IllegalArgumentException("Invalid Q30 profile period");
        Metric metric = metric(name);
        incrementCalls(metric);
        metric.samplePeriod = period;
        metric.sampleMode = "call-period";
        if ((metric.totalCalls - 1) % period != 0) return OFF;
        metric.activeStarts++;
        metric.timedStarts++;
        return now();
    }

    static void count(String name, double amount) {
        if (!enabled) return;
        if (amount != 1 && (amount < 0 || amount != Math.floor(amount) ||
                Double.isInfinite(amount) || Double.isNaN(amount)))
            throw new IllegalArgumentException("Invalid Q30 profile work count");
        Metric metric = metric(name);
        if (metric.workCount > MAX_EXACT_COUNT - amount)
            throw new IllegalStateException("Q30 profile work count exceeded exact range");
        metric.workCount += amount;
    }

    static void end(String name, double startedAt) {
        if (!enabled || Double.isNaN(startedAt)) return;
        Metric metric = metrics.get(name);
        if (metric == null || metric.activeStarts == 0) {
            unmatchedEnds++;
            return;
        }
        metric.activeStarts--;
        double elapsed = now() - startedAt;
        if (elapsed < 0 || Double.isNaN(elapsed) || Double.isInfinite(elapsed)) {
            clockErrors++;
            throw new IllegalStateException("Invalid Q30 monotonic profile duration");
        }
        metric.timedCalls++;
        metric.measuredMs += elapsed;
        if (elapsed > metric.maxMeasuredMs) metric.maxMeasuredMs = elapsed;
    }

    static JSONObject snapshot() {
        JSONObject result = new JSONObject();
        result.put("enabled", com.google.gwt.json.client.JSONBoolean.getInstance(enabled));
        result.put("clock", new JSONString("performance.now"));
        result.put("durationSemantics", new JSONString("inclusive; nested categories overlap"));
        result.put("sampleSemantics", new JSONString("kernel step: first and every 64th attempt; call period: first and every period; timed maximum is observed only"));
        result.put("unmatchedEnds", new JSONNumber(unmatchedEnds));
        result.put("clockErrors", new JSONNumber(clockErrors));
        result.put("runElapsedMs", new JSONNumber(enabled ? now() - runStartedAt : 0));
        JSONObject categories = new JSONObject();
        JSONObject sampledEstimates = new JSONObject();
        double unmatchedStarts = 0;
        for (Map.Entry<String, Metric> entry : metrics.entrySet()) {
            Metric metric = entry.getValue();
            unmatchedStarts += metric.activeStarts;
            JSONObject row = new JSONObject();
            row.put("totalCalls", new JSONNumber(metric.totalCalls));
            row.put("timedCalls", new JSONNumber(metric.timedCalls));
            row.put("timedStarts", new JSONNumber(metric.timedStarts));
            row.put("openScopes", new JSONNumber(metric.activeStarts));
            row.put("samplePeriod", new JSONNumber(metric.samplePeriod));
            row.put("sampleMode", new JSONString(metric.sampleMode));
            row.put("measuredMs", new JSONNumber(metric.measuredMs));
            row.put("meanMeasuredMs", new JSONNumber(metric.timedCalls == 0 ? 0 :
                metric.measuredMs / metric.timedCalls));
            row.put("maxMeasuredMs", new JSONNumber(metric.maxMeasuredMs));
            row.put("estimatedTotalMs", new JSONNumber(metric.timedCalls == 0 ? 0 :
                metric.measuredMs * metric.totalCalls / metric.timedCalls));
            row.put("workCount", new JSONNumber(metric.workCount));
            row.put("timingCoverage", new JSONString(metric.timedCalls == 0 ? "untimed" :
                metric.timedCalls == metric.totalCalls ? "all" : "sampled"));
            if (metric.timedCalls > 0 && metric.timedCalls < metric.totalCalls)
                sampledEstimates.put(entry.getKey(),
                    new JSONNumber(metric.measuredMs * metric.totalCalls / metric.timedCalls));
            categories.put(entry.getKey(), row);
        }
        result.put("categories", categories);
        result.put("sampledEstimatesMs", sampledEstimates);
        result.put("openScopes", new JSONNumber(unmatchedStarts));
        result.put("timingScopesBalanced", com.google.gwt.json.client.JSONBoolean.getInstance(
            unmatchedStarts == 0 && unmatchedEnds == 0));
        result.put("estimatedTotalSemantics", new JSONString("sample mean times exact call count; estimate, not measured total"));
        return result;
    }

    private static Metric metric(String name) {
        Metric found = metrics.get(name);
        if (found == null) {
            found = new Metric();
            metrics.put(name, found);
        }
        return found;
    }

    private static void incrementCalls(Metric metric) {
        if (metric.totalCalls >= MAX_EXACT_COUNT)
            throw new IllegalStateException("Q30 profile call count exceeded exact range");
        metric.totalCalls++;
    }

    private static double now() {
        if (!GWT.isScript())
            throw new IllegalStateException("Q30 tracking profile requires browser performance.now");
        double value = performanceNow();
        if (Double.isNaN(value) || Double.isInfinite(value))
            throw new IllegalStateException("Q30 tracking profile requires browser performance.now");
        return value;
    }

    private static native double performanceNow() /*-{
        return ($wnd.performance && typeof $wnd.performance.now === 'function') ?
            $wnd.performance.now() : NaN;
    }-*/;

    private static final class Metric {
        double totalCalls;
        double timedCalls;
        double workCount;
        int samplePeriod = 1;
        String sampleMode = "all";
        double activeStarts;
        double timedStarts;
        double measuredMs;
        double maxMeasuredMs;
    }
}
