from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
root=s/'live-lu-support-r1-preparation/candidate'
rel='src/com/lushprojects/circuitjs1/client/'
p=root/(rel+'CirSim.java');raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='c0b9d9bc7ff72d0e5021500c331e40dfcd03974ee3517c39d757d05302b1cfc3'
newline='\r\n' if b'\r\n' in raw else '\n';text=raw.decode('utf-8').replace('\r\n','\n')
def replace(old,new):
    global text
    assert text.count(old)==1, (old[:100],text.count(old))
    text=text.replace(old,new)
replace('    private final LuFactorizationWorkspace luFactorizationWorkspace =',
'''    // Conservative support belongs to one successful nonlinear analysis.
    // Snapshot restoration invalidates it; it is never copied between graphs.
    private LuStructuralSupport luStructuralSupport;

    void invalidateLuStructuralSupport() {
        if (luStructuralSupport != null) luStructuralSupport.invalidate();
        luStructuralSupport = null;
    }

    private final LuFactorizationWorkspace luFactorizationWorkspace =''')
replace('''    void analyzeCircuitOwned(SolverExecutionBoundary.Operation operation) {
        solverExecutor.check(operation);''',
'''    void analyzeCircuitOwned(SolverExecutionBoundary.Operation operation) {
        solverExecutor.check(operation);
        invalidateLuStructuralSupport();''')
replace('    void stampCircuit() {','''    void stampCircuit() {
        invalidateLuStructuralSupport();''')
replace('\trequireFiniteMatrix();\n\t\n\t// if a matrix is linear',
'''\trequireFiniteMatrix();
        if (circuitNonLinear) {
            luStructuralSupport = LuStructuralSupport.create(circuitMatrix,
                    origMatrix, circuitMatrixSize, circuitRowInfo);
            if (luStructuralSupport != null && luStructuralSupport.hasSingleComponent())
                invalidateLuStructuralSupport();
        }
\t
\t// if a matrix is linear''')
replace('    void stop(String s, CircuitElm ce) {','''    void stop(String s, CircuitElm ce) {
        invalidateLuStructuralSupport();''')
replace('\t    circuitMatrix[i][j] += x;','''\t    circuitMatrix[i][j] += x;
            if (luStructuralSupport != null) {
                // Include zero and cancelling stamps: support only coarsens.
                luStructuralSupport.recordStamp(i, j);
                if (luStructuralSupport.hasSingleComponent())
                    invalidateLuStructuralSupport();
            }''')
replace('\tif (circuitMatrix == null || elmList.size() == 0) {',
'''\tif (circuitMatrix == null || elmList.size() == 0) {
            invalidateLuStructuralSupport();''')
replace('''\t\t    if (!lu_factorNonlinearOwned(circuitMatrix, circuitMatrixSize,
\t\t\t  circuitPermute, luFactorizationWorkspace)) {''',
'''\t\t    if (!lu_factorNonlinearOwned(circuitMatrix, circuitMatrixSize,
                          circuitPermute, luFactorizationWorkspace, luStructuralSupport,
                          origMatrix, circuitRowInfo)) {''')
replace('''        private int activeSize;

        private void reset(int size) {''',
'''        private int activeSize;
        private final LuStructuralSupport.Domains domains = new LuStructuralSupport.Domains();

        private void reset(int size) {''')
replace('''        private void clear() {
            clearPivot();
            activeSize = 0;
        }''',
'''        private void clear() {
            clearPivot();
            domains.clear();
            activeSize = 0;
        }''')
replace('''            return lowerRowCount == 0 && upperColumnCount == 0 && activeSize == 0;''',
'''            return lowerRowCount == 0 && upperColumnCount == 0 && activeSize == 0
                    && domains.allCountsZeroForChecks();''')
replace('''            return true;
        }
    }

    // factors a matrix''',
'''            return domains.allReferencesNullForChecks();
        }
    }

    // factors a matrix''')
replace('''    private static boolean lu_factorNonlinearOwned(double a[][], int n, int ipvt[],
            LuFactorizationWorkspace workspace) {
        if (workspace == null)''',
'''    private static boolean lu_factorNonlinearOwned(double a[][], int n, int ipvt[],
            LuFactorizationWorkspace workspace) {
        return lu_factorNonlinearOwned(a, n, ipvt, workspace, null, null, null);
    }

    private static boolean lu_factorNonlinearOwned(double a[][], int n, int ipvt[],
            LuFactorizationWorkspace workspace, LuStructuralSupport support,
            double[][] original, Object mapping) {
        if (workspace == null)''')
replace('''                    }
                }
                if (row_all_zeros) return false;
            }
            return lu_factorAfterInputScan(a, n, ipvt, workspace);''',
'''                    }
                }
                if (row_all_zeros) return false;
            }
            if (support != null)
                support.prepareDomains(workspace.domains, a, original, n, mapping);
            return lu_factorAfterInputScan(a, n, ipvt, workspace);''')
replace('''        int i, j, k;
        // Apply each pivot''',
'''        int i, j, k;
        LuStructuralSupport.Domains domains = workspace.domains;
        boolean restricted = domains.active;
        // Apply each pivot''')
old='''            for (i = k; i != n; i++) {
                double q = a[i][k];
                double x = Math.abs(q);
                int candidateLowerSlot = -1;
                if (i > k && q != 0) {
                    candidateLowerSlot = workspace.lowerRowCount;
                    workspace.appendLowerRow(a[i]);
                }
                if (x >= largest) {
                    largest = x;
                    largestRow = i;
                    selectedLowerSlot = candidateLowerSlot;
                }
            }'''
new='''            if (restricted) {
                int group = domains.columnGroups[k];
                int[] indexes = domains.rowIndexes[group];
                double[][] references = domains.rowReferences[group];
                for (int slot = domains.starts[group]; slot < domains.counts[group]; slot++) {
                    i = indexes[slot];
                    double[] row = references[slot];
                    double q = row[k];
                    double x = Math.abs(q);
                    int candidateLowerSlot = -1;
                    if (i > k && q != 0) {
                        candidateLowerSlot = workspace.lowerRowCount;
                        workspace.appendLowerRow(row);
                    }
                    if (x >= largest) {
                        largest = x;
                        largestRow = i;
                        selectedLowerSlot = candidateLowerSlot;
                    }
                }
                // An omitted zero can tie a zero maximum. Preserve the full
                // later-row tie and sentinel path for the rest of this factor.
                if (largest == 0) {
                    workspace.clearPivot();
                    domains.clear();
                    restricted = false;
                    largestRow = selectedLowerSlot = -1;
                }
            }
            if (!restricted) {
'''+''.join('    '+line+'\n' for line in old.splitlines()).rstrip()+'\n            }'
replace(old,new)
replace('''                a[k] = row;
                if (selectedLowerSlot >= 0) {''',
'''                a[k] = row;
                if (restricted) domains.swap(k, largestRow);
                if (selectedLowerSlot >= 0) {''')
replace('''                double[] pivotRow = a[k];
                for (j = k+1; j != n; j++)
                    if (pivotRow[j] != 0) workspace.appendUpperColumn(j);''',
'''                double[] pivotRow = a[k];
                if (restricted) {
                    int group = domains.columnGroups[k];
                    int[] indexes = domains.columns[group];
                    for (int slot = domains.starts[group] + 1; slot < domains.columnCounts[group]; slot++) {
                        j = indexes[slot];
                        if (pivotRow[j] != 0) workspace.appendUpperColumn(j);
                    }
                } else {
                    for (j = k+1; j != n; j++)
                        if (pivotRow[j] != 0) workspace.appendUpperColumn(j);
                }''')
replace('''                workspace.clearPivot();
            }
        }
        return true;''',
'''                workspace.clearPivot();
            }
            if (restricted) domains.finishPivot(k);
        }
        return true;''')
p.write_bytes(text.replace('\n',newline).encode('utf-8'))
p=root/(rel+'Task41SimulationSnapshot.java');raw=p.read_bytes()
old=b'    private void restoreGraphAndRuntimeState(CirSim sim) {'
assert raw.count(old)==1
nl=b'\r\n' if b'\r\n' in raw else b'\n'
p.write_bytes(raw.replace(old,old+nl+b'        sim.invalidateLuStructuralSupport();'))
print(json.dumps({'status':'ISOLATED_WIRING_ONLY_NOT_VALIDATED','changes':['CirSim.java','Task41SimulationSnapshot.java']}))
