# Kernel equivalence obligations for a possible live-support prototype

No implementation or performance acceptance yet. Supplements root-live-lu-prototype-notes.md.

If the certified bipartite superset is sound for the exact current finite matrix, fill from a nonzero pivot stays inside its component: both nonzero lower and upper operands belong to that component. The current kernel already updates only nonzero lower/upper products; omitted cross-component scan cells are zero and must remain untouched (including signed-zero bits).

Keep global k order. Enumerate current component rows in ascending global row index. Positive local maximum gives exactly the global >= tie winner, because omitted zeros cannot tie a positive magnitude. If maximum is zero/there is no local row, clear any scan scratch, perform the original full scan, and disable all restrictions for the remaining factor before a sentinel could connect groups. Full-scan fallback retains the last-zero tie and 1e-18 behavior. Do not use sample absence of sentinel as a guarantee.

Track row references AND global positions under every actual swap. Within-component swaps exchange cached references at fixed positions; cross-component swaps move membership while preserving sorted global positions. Reset membership from the logically restored matrix at every factor. The original lowerRows selected-slot replacement/removal remains unchanged: when row k belongs to another component it is certified zero in column k, so its replacement is removed exactly as in the original kernel. Same-group swaps retain the existing nonzero replacement rule. Preserve scaling/underflow compaction and upper/update order.

Column membership does not permute. After a positive selected pivot, scanning only same-component columns j>k is valid under the same support proof. The complete numerical update loop and all finite guards remain verbatim.

Reject certificate use for aliased working rows, incompatible shape, unknown writer/owner/restoration state, unbalanced component support, or invalid finite-input provenance. Existing full kernel remains the fallback; this must not change its behavior on general or pathological independent arrays.

All retained row references in new grouping scratch must be cleared in finally, including construction/failure paths. Extend workspace cleanup checks to the new scratch; do not weaken existing allCountsZero/allRowReferencesNull assertions. Live owner certificates must not be copied into snapshots or survive a graph replacement.

This establishes a conditional proof obligation, not that current owners satisfy it or that tracking/list overhead pays off.

