# Live LU support r1 root wiring review

Scope: read-only review of the prepared candidate diffs for `CirSim.java` and `Task41SimulationSnapshot.java`, `wire_live_lu_support_r1_root.py`, and `root-live-lu-kernel-obligations.md`. I did not inspect the in-progress `LuStructuralSupport` draft or run checks.

Verdict: **conditional GO for the bounded prototype**, assuming the tracker API satisfies the kernel note’s sorted-membership, per-factor rebind/reset, shape/alias rejection, and non-sharing requirements. I found no pivot-loop correctness defect in the reviewed wiring itself. The one stamp-hook exception-order condition below should be made explicit or adjusted before relying on exact failure behavior.

## Findings

1. **Stamp hook is before the matrix cell write** (`CirSim.java:3224-3231`). For valid mapped cells, recording `(i,j)` first is conservative, includes zero/cancelled writes, and tracks an overflowed accumulated cell before `requireFiniteStamp` throws. But it lets `recordStamp` / `hasSingleComponent` run before the existing array write. If a mapping or matrix shape is invalid, this can throw or mutate/invalidate support before the original `circuitMatrix[i][j] += x` failure. Require these tracker calls to be non-throwing for all inputs reaching this point, or move them after the cell addition and before the accumulated-value finite check. That order still records an overflowed write and preserves the original cell-access exception path.

2. **Analysis and restore ownership are correctly guarded.** `analyzeCircuitOwned` performs `solverExecutor.check(operation)` before invalidating (`:2746-2749`), so a rejected/foreign operation cannot clear a successor’s certificate. `stampCircuit` invalidates before replacing matrices and only creates support after simplify/final-matrix finite validation (`:2817`, `:2852+`, `:2958-2965`); `stop` and the empty/missing-matrix return invalidate too (`:3117+`, `:3309+`). The factor receives the support together with current `origMatrix` and `circuitRowInfo` (`:3412-3414`).

3. **Task 41’s invalidate-only restore is safe.** The one invalidation in `restoreGraphAndRuntimeState` (`Task41SimulationSnapshot.java:586`) precedes reassignment of captured matrix references and restoration of their contents. Transactional and best-effort restoration both pass through this method. The snapshot does not retain or reinstall a mutable support object; the restored solver uses fallback until a fresh analysis publishes a certificate.

4. **The kernel wiring preserves the specified global behavior, conditionally on `Domains` invariants.** The zero-maximum path clears scan scratch, runs the original complete `i=k..n` scan with `largest` still zero, and disables restrictions for the rest of that factor (`CirSim.java:8144-8153`). That preserves the later-row all-zero tie and prevents a `1e-18` sentinel from being followed by restricted scans. The positive path keeps `k` global, uses the existing `>=` comparator, updates domains on row swaps, and leaves lower-row scaling plus the numeric update loop unchanged (`:8124-8143`, `:8170-8189`, `:8191-8245`).

5. **The corrected upper-column start is valid under the stated invariant.** With sorted component columns and `starts[group]` equal to prior global pivots in that group, `columns[group][starts[group]] == k`; starting at `starts[group] + 1` enumerates later same-component columns in ascending order and avoids rescanning the processed prefix (`:8217-8227`). Row-domain scans likewise require sorted current global positions, with the first `starts[group]` entries corresponding to consumed pivots after every cross-component swap. `prepareDomains` must rebuild row references from the current `a` positions at each factor: prior LU swaps permute `circuitMatrix` row references, while the next trial restores row *contents by index* from `origMatrix` (`:3357-3360`). Reusing cached row-object/component positions across factors would be incorrect.

6. **Cleanup plumbing is present.** Workspace clear resets `domains`, and the existing `finally` cleanup remains around factorization; the workspace inspection predicates now include domain counts and references. The tracker must make `clear()` null every retained row reference on normal, zero-fallback, and exceptional paths. The four-argument private overload remains and delegates with no certificate, preserving the existing reflection test entry point and full-kernel behavior.

## Performance risks (not timing claims)

The existing all-zero-row preflight remains `O(n²)` for every factor. Support seeding costs `O(n²)` once per successful nonlinear analysis; mapped-stamp unions should be amortized `O(α(n))`, and domain preparation should use the certificate rather than rescan the matrix. The `hasSingleComponent()` check occurs after each mapped stamp, so the tracker should maintain that count incrementally (`O(1)` query) rather than recount vertices. The corrected upper-column start avoids a repeated per-pivot prefix walk. Even if the measured outside-domain fractions are large, the monotonic per-analysis union may merge transiently connected groups and actual work reduction remains unmeasured.

This review establishes only conditional wiring feasibility. It does not establish tracker implementation correctness, numerical parity, or performance.

### Resolution addendum (source-only)

Root moved the support hook to after `circuitMatrix[i][j] += x` and before `requireFiniteStamp(circuitMatrix[i][j])` in the final candidate `CirSim.java:3224-3231`. The original mapped-cell access now fails before tracker work, while a valid cell that overflows is recorded before the accumulated-value finite guard. This resolves finding 1 for the reviewed ordering. No checks or runtime validation were run.
