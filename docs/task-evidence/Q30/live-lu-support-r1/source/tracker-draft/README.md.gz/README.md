# Live LU structural support draft

This folder contains the bounded, generic source prototype for monotone support tracking and its native structural oracle. It does not contain LU kernel changes or simulator lifecycle wiring. The owner contract review authorized a prototype only; it did not accept an optimization or establish a runtime win.

`LuStructuralSupport.create` accepts only a finite, shape-valid active prefix whose working values equal the original values and whose working row arrays are distinct. The returned owner binds the working matrix, original matrix, dimension, and mapping identities. Call `recordStamp` for every successfully mapped matrix coordinate, including zero and cancelling stamps. RHS-only writes do not add coordinates. Invalid coordinates or explicit invalidation permanently disable this owner.

`prepareDomains` clears reusable scratch first, then succeeds only for a matching owner with more than one balanced bipartite component. Its rows and columns are sorted by global index. After the caller swaps the matrix row arrays, `Domains.swap` updates cached row membership; `finishPivot(k)` verifies and consumes the matching row and column at the active prefix. Clear domains in the factor `finally` path so no matrix row references survive factor exit. Rebuild membership after restoring the working matrix for each factor. The helper never writes matrix values and does not replace the existing full-scan fallback.

`tests/contracts/LuStructuralSupportContractTest.java` supplies an independent BFS partition oracle, creation and identity rejection cases, balanced/unbalanced/single-component cases, and manual within/cross-group swap schedules. The required result marker is `PASS: LU structural support contracts assertions=<count>`. The root owns registering and running the maintained gate; this leaf assignment did not execute tests, hosts, or builds.

The supplied census indicates roughly 35–36% of sampled pivot/lower/upper candidate domains lie outside current components. Those domains overlap. This is opportunity only; this draft makes no saved-time claim, parity claim, or optimization-acceptance claim.
