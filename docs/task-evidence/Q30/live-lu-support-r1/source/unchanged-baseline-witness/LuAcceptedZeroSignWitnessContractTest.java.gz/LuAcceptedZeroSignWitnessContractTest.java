package com.lushprojects.circuitjs1.client;
import java.lang.reflect.Method;
public final class LuAcceptedZeroSignWitnessContractTest {
    public static void main(String[] args) throws Exception {
        double[][] full = {{5,0,1,0},{0,4,0,1},{5,0,2,0},{0,1,0,3}};
        double[][] historical = new double[4][];
        for (int i=0;i<4;i++) historical[i]=full[i].clone();
        int[] actualPivots = new int[4], historicalPivots = new int[4];
        Method original = LuFactorizationChecks.class.getDeclaredMethod("originalFactor", double[][].class, int.class, int[].class);
        original.setAccessible(true);
        require(CirSim.lu_factor(full,4,actualPivots), "accepted full LU rejected");
        require(((Boolean)original.invoke(null,historical,Integer.valueOf(4),historicalPivots)).booleanValue(), "historical LU rejected");
        int differences=0, assertions=2;
        for(int i=0;i<4;i++) {
            require(actualPivots[i]==historicalPivots[i], "pivot disagreement");assertions++;
            for(int j=0;j<4;j++) {
                long a=Double.doubleToRawLongBits(full[i][j]);
                long b=Double.doubleToRawLongBits(historical[i][j]);
                if(a!=b) {
                    differences++;
                    require(i==3 && j==2 && a==0L && b==Long.MIN_VALUE, "unexpected factor difference");
                }
                require(full[i][j]==historical[i][j], "numeric factor differs");assertions++;
            }
        }
        require(differences==1,"expected one independently derived signed-zero difference");assertions++;
        System.out.println("WITNESS: unchanged accepted full LU [3][2] rawBits=0; historical Crout rawBits=8000000000000000; pivots and all numerical factors equal");
        System.out.println("PASS: LU accepted zero-sign oracle witness assertions="+assertions);
    }
    private static void require(boolean value,String message) {if(!value)throw new AssertionError(message);}
}
