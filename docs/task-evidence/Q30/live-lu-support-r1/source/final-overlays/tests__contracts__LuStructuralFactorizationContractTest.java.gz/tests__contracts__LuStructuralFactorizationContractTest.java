package com.lushprojects.circuitjs1.client;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Numeric and certificate-boundary contracts for live structural LU pruning. */
public final class LuStructuralFactorizationContractTest {
    private static final int PIVOT_TAIL = 0x5a17c0de;
    private static Method ownedFactor;
    private static Method supportCreate;
    private static Method supportMatches;
    private static Method supportRecordStamp;
    private static Method supportInvalidate;
    private static Method originalFactor;
    private static Method originalSolve;
    private static Class<?> supportType;
    private static int assertions;

    static {
        try {
            supportType = LuStructuralSupport.class;
            ownedFactor = CirSim.class.getDeclaredMethod("lu_factorNonlinearOwned",
                    double[][].class, int.class, int[].class,
                    CirSim.LuFactorizationWorkspace.class, supportType,
                    double[][].class, Object.class);
            supportCreate = supportType.getDeclaredMethod("create",
                    double[][].class, double[][].class, int.class, Object.class);
            supportMatches = supportType.getDeclaredMethod("matches",
                    double[][].class, double[][].class, int.class, Object.class);
            supportRecordStamp = supportType.getDeclaredMethod("recordStamp",
                    int.class, int.class);
            supportInvalidate = supportType.getDeclaredMethod("invalidate");
            originalFactor = LuFactorizationChecks.class.getDeclaredMethod("originalFactor",
                    double[][].class, int.class, int[].class);
            originalSolve = LuFactorizationChecks.class.getDeclaredMethod("originalSolve",
                    double[][].class, int.class, int[].class, double[].class);
            accessible(ownedFactor);
            accessible(supportCreate);
            accessible(supportMatches);
            accessible(supportRecordStamp);
            accessible(supportInvalidate);
            accessible(originalFactor);
            accessible(originalSolve);
        } catch (Exception failure) {
            throw new ExceptionInInitializerError(failure);
        }
    }

    public static void main(String[] args) {
        System.out.println("PASS: LU structural factorization contracts assertions=" + run());
    }

    public static int run() {
        assertions = 0;
        CirSim.LuFactorizationWorkspace workspace =
                new CirSim.LuFactorizationWorkspace();

        interleavedAsymmetricAndAnalytic(workspace);
        equalPositiveTieAndCrossPositionPivots(workspace);
        zeroLocalPivotFallsBackToGlobalTie(workspace);
        initialZeroRowAndDimensionTails(workspace);
        signedZeroAndUnderflow(workspace);
        finiteOverflowFailures(workspace);
        dynamicStampAndRestoredMatrix(workspace);
        invalidCertificatesFallBack(workspace);
        aliasedRowsFallBack(workspace);
        deterministicPermutedBlocks(workspace);
        workspaceClear(workspace, "final reuse state");
        return assertions;
    }

    private static void interleavedAsymmetricAndAnalytic(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] matrix = {
            { 0, 2, 3 },
            { 5, 0, 0 },
            { 0, 7, 11 }
        };
        double[] rhs = { 18, 10, 65 };
        Comparison result = compareFresh(matrix, matrix, 3, rhs, workspace,
                "interleaved asymmetric components", true);
        check(result.accepted, "interleaved fixture was rejected");
        check(result.pivots[0] == 1 && result.pivots[1] == 2 &&
                result.pivots[2] == 2,
                "interleaved fixture pivot sequence changed");
        assertVectorNear(result.solution, new double[] { 2, 3, 4 },
                "interleaved analytic solution", 1e-12);
        assertResidual(matrix, result.solution, rhs,
                "interleaved analytic residual", 1e-12);
        independentOracle(matrix, rhs, result, "interleaved asymmetric components");
    }

    private static void equalPositiveTieAndCrossPositionPivots(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] tied = {
            { 5, 0, 1, 0 },
            { 0, 4, 0, 1 },
            { 5, 0, 2, 0 },
            { 0, 1, 0, 3 }
        };
        double[] tieRhs = { 8, 12, 11, 14 };
        Comparison tieResult = compareFresh(tied, tied, 4, tieRhs, workspace,
                "equal positive tie within one component", true);
        check(tieResult.pivots[0] == 2,
                "equal positive component pivot did not select the later row");
        independentOracle(tied, tieRhs, tieResult, "equal positive tie");

        double[][] crossPosition = {
            { 1, 0, 2, 0 },
            { 0, 2, 0, 1 },
            { 8, 0, 3, 0 },
            { 0, 7, 0, 6 }
        };
        double[] rhs = { 7, 8, 17, 38 };
        Comparison crossResult = compareFresh(crossPosition, crossPosition, 4,
                rhs, workspace, "multi-block cross-position pivots", true);
        check(crossResult.pivots[0] == 2 && crossResult.pivots[1] == 3 &&
                crossResult.pivots[2] == 2 && crossResult.pivots[3] == 3,
                "interleaved blocks did not retain global pivot positions");
        assertVectorNear(crossResult.solution, new double[] { 1, 2, 3, 4 },
                "cross-position analytic solution", 1e-12);
        assertResidual(crossPosition, crossResult.solution, rhs,
                "cross-position analytic residual", 1e-12);
        rowObjectPermutationParity(crossPosition, 4, workspace);

        double[][] oldRowZero = {
            { 0, 0, 1, 0 },
            { 0, 4, 0, 1 },
            { 3, 0, 4, 0 },
            { 0, 1, 0, 3 }
        };
        Comparison zeroResult = compareFresh(oldRowZero, oldRowZero, 4, null,
                workspace, "pivot swap with old row-k zero", true);
        check(zeroResult.pivots[0] == 2,
                "old-row-k-zero fixture missed its first pivot");

        double[][] oldRowNonzero = {
            { 1, 0, 2, 0 },
            { 0, 4, 0, 1 },
            { 5, 0, 3, 0 },
            { 0, 1, 0, 3 }
        };
        Comparison nonzeroResult = compareFresh(oldRowNonzero, oldRowNonzero, 4,
                null, workspace, "pivot swap with old row-k nonzero", true);
        check(nonzeroResult.pivots[0] == 2,
                "old-row-k-nonzero fixture missed its first pivot");
    }

    private static void zeroLocalPivotFallsBackToGlobalTie(
            CirSim.LuFactorizationWorkspace workspace) {
        // Both 2x2 support components are balanced and every input row is
        // nonzero. The first component becomes singular at global column 2;
        // the full scan's >= tie selects the last remaining row, which belongs
        // to the other component and receives the historical tiny sentinel.
        double[][] matrix = {
            { 1, 0, 2, 0 },
            { 0, 3, 0, 1 },
            { 2, 0, 4, 0 },
            { 0, 1, 0, 3 }
        };
        Comparison result = compareFresh(matrix, matrix, 4, null, workspace,
                "balanced singular block and global zero tie", true);
        check(result.accepted, "singular-block sentinel fixture was rejected");
        check(result.pivots[0] == 2 && result.pivots[1] == 1 &&
                result.pivots[2] == 3 && result.pivots[3] == 3,
                "singular-block global tie pivot sequence changed");
        check(sameBits(result.factors[2][2], 1e-18),
                "zero pivot did not retain the historical tiny sentinel");
    }

    private static void initialZeroRowAndDimensionTails(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] zeroRow = {
            { 1, 0, 2 },
            { 0, 0, 0 },
            { 0, 3, 4 }
        };
        Comparison rejected = compareFresh(zeroRow, zeroRow, 3, null, workspace,
                "initial zero row", false);
        check(!rejected.accepted, "initial zero row was not rejected");
        assertMatrixBits(zeroRow, rejected.factors, "zero-row input changed");

        double[][] empty = new double[0][0];
        comparePrepared(empty, empty, 0, null, null, new Object(), null,
                workspace, "zero dimension");

        double[][] one = { { 7, 81 }, { 91, 92 } };
        compareFresh(one, one, 1, null, workspace, "one dimension with tail", false);

        double[][] padded = {
            { 2, 0, 123, -0.0 },
            { 0, 3, 456, 789 },
            { 111, 222, 333, 444 },
            { 555, 666, 777, 888 }
        };
        compareFresh(padded, padded, 2, null, workspace,
                "prefix dimension preserves matrix and pivot tails", false);
    }

    private static void signedZeroAndUnderflow(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] matrix = {
            { 1.0e308, -0.0, 1, 0 },
            { 0, 4, 0, -0.0 },
            { Double.MIN_VALUE, 0, 2, 0 },
            { -0.0, 1, 0, 3 }
        };
        Comparison result = compareFresh(matrix, matrix, 4,
                new double[] { 1, 2, 3, 4 }, workspace,
                "signed zero and underflow-created multiplier", false);
        check(result.accepted, "signed-zero underflow fixture was rejected");
        check(result.factors[2][0] == 0.0,
                "underflow fixture did not create a zero multiplier");
    }

    private static void finiteOverflowFailures(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] reciprocalOverflow = {
            { Double.MIN_VALUE, 0, 1, 0 },
            { 0, 4, 0, 1 },
            { Double.MIN_VALUE, 0, 2, 0 },
            { 0, 1, 0, 3 }
        };
        requireNumericalFailureParity(reciprocalOverflow, 4, workspace,
                "finite reciprocal overflow");

        double[][] updateOverflow = {
            { 1, 0, Double.MAX_VALUE, 0 },
            { 0, 4, 0, 1 },
            { 1, 0, -Double.MAX_VALUE, 0 },
            { 0, 1, 0, 3 }
        };
        requireNumericalFailureParity(updateOverflow, 4, workspace,
                "finite upper-update overflow");
    }

    private static void dynamicStampAndRestoredMatrix(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] base = {
            { 1, 0, 2, 0 },
            { 0, 2, 0, 1 },
            { 8, 0, 3, 0 },
            { 0, 7, 0, 6 }
        };

        double[][] actual = copyRows(base);
        double[][] original = copyRows(base);
        Object mapping = new Object();
        Object support = createSupport(actual, original, 4, mapping);
        check(support != null && matches(support, actual, original, 4, mapping),
                "fresh balanced support certificate did not match");
        recordStamp(support, 0, 1);
        actual[0][1] = 0.25; // Matrix mutation is independent of the stamp record.
        check(matches(support, actual, original, 4, mapping),
                "recorded new edge invalidated its support certificate");
        comparePrepared(actual, original, 4, null, support, mapping, null,
                workspace, "new cross-component stamped edge");

        // A mapped coordinate remains structural when stamps cancel to zero.
        actual = copyRows(base);
        original = copyRows(base);
        mapping = new Object();
        support = createSupport(actual, original, 4, mapping);
        recordStamp(support, 0, 1);
        actual[0][1] += 3.0;
        recordStamp(support, 0, 1);
        actual[0][1] -= 3.0;
        recordStamp(support, 0, 3); // A mapped zero-valued coordinate is support too.
        check(actual[0][1] == 0.0 && actual[0][3] == 0.0,
                "cancelled or zero-valued stamp fixture is not zero");
        check(matches(support, actual, original, 4, mapping),
                "zero/cancel stamps did not remain in the certificate");
        comparePrepared(actual, original, 4, null, support, mapping, null,
                workspace, "zero and cancelled stamp coordinates");

        actual = copyRows(base);
        original = copyRows(base);
        mapping = new Object();
        support = createSupport(actual, original, 4, mapping);
        Comparison first = comparePrepared(actual, original, 4, null, support,
                mapping, null, workspace, "first factor before logical restore");
        check(first.accepted, "first restored-matrix factor failed");
        double[][] rowReferencesBeforeRestore = actual.clone();
        restoreMatrix(actual, original);
        for (int i = 0; i < actual.length; i++)
            check(actual[i] == rowReferencesBeforeRestore[i],
                    "logical restore replaced a permuted row object at " + i);
        assertMatrixBits(original, actual, "logical restore did not restore original values");
        check(matches(support, actual, original, 4, mapping),
                "row swaps invalidated support after restoring the original matrix");
        Comparison second = comparePrepared(actual, original, 4, null, support,
                mapping, null, workspace, "factor after restoring original values");
        check(second.accepted, "factor after logical restore failed");
    }

    private static void invalidCertificatesFallBack(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] base = {
            { 1, 0, 2, 0 },
            { 0, 2, 0, 1 },
            { 8, 0, 3, 0 },
            { 0, 7, 0, 6 }
        };

        double[][] actual = copyRows(base);
        double[][] original = copyRows(base);
        Object mapping = new Object();
        Object support = createSupport(actual, original, 4, mapping);
        invalidate(support);
        check(!matches(support, actual, original, 4, mapping),
                "invalidated certificate still matched");
        comparePrepared(actual, original, 4, null, support, mapping, null,
                workspace, "invalidated certificate falls back");

        actual = copyRows(base);
        original = copyRows(base);
        Object certifiedMapping = new Object();
        support = createSupport(actual, original, 4, certifiedMapping);
        Object wrongMapping = new Object();
        check(!matches(support, actual, original, 4, wrongMapping),
                "certificate accepted a different mapping identity");
        comparePrepared(actual, original, 4, null, support, certifiedMapping,
                wrongMapping, workspace, "wrong mapping falls back");

        double[][] certified = copyRows(base);
        double[][] certifiedOriginal = copyRows(base);
        Object sameMapping = new Object();
        support = createSupport(certified, certifiedOriginal, 4, sameMapping);
        double[][] replacement = copyRows(base);
        double[][] replacementOriginal = copyRows(base);
        replacement[0][1] = 0.5;
        replacementOriginal[0][1] = 0.5;
        check(!matches(support, replacement, replacementOriginal, 4, sameMapping),
                "certificate accepted replacement matrix arrays");
        comparePrepared(replacement, replacementOriginal, 4, null, support,
                sameMapping, null, workspace, "wrong matrix arrays fall back");
    }

    private static void aliasedRowsFallBack(
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] aliased = {
            { 1, 0, 2, 0 },
            { 0, 2, 0, 1 },
            { 8, 0, 3, 0 },
            { 0, 7, 0, 6 }
        };
        aliased[2] = aliased[0];
        double[][] actual = copyRows(aliased);
        double[][] original = copyRows(aliased);
        Object mapping = new Object();
        Object support = null;
        boolean rejected = false;
        try {
            support = createSupport(actual, original, 4, mapping);
        } catch (IllegalArgumentException expected) {
            rejected = true;
        }
        check(rejected || support == null ||
                !matches(support, actual, original, 4, mapping),
                "aliased working rows were accepted as a live support certificate");
        comparePrepared(actual, original, 4, null, support, mapping, null,
                workspace, "aliased working rows use full fallback");
    }

    private static void deterministicPermutedBlocks(
            CirSim.LuFactorizationWorkspace workspace) {
        final int n = 8;
        for (int trial = 0; trial < 10; trial++) {
            double[][] logical = new double[n][n];
            double[] logicalSolution = new double[n];
            for (int i = 0; i < n; i++)
                logicalSolution[i] = ((i * 3 + trial) % 7) - 3;

            for (int block = 0; block < n / 2; block++) {
                int i = block * 2;
                logical[i][i] = 12 + trial + 2 * block;
                logical[i][i + 1] = ((trial + block) & 1) == 0 ? -2 : 3;
                logical[i + 1][i] = 1 + ((trial + 2 * block) % 4);
                logical[i + 1][i + 1] = 17 + trial + block;
            }
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    if (logical[i][j] == 0.0 &&
                            ((i * 13 + j * 7 + trial) & 1) == 0)
                        logical[i][j] = -0.0;

            int rowShift = trial % n;
            int colShift = (3 * trial + 1) % n;
            boolean reverseRows = (trial & 1) != 0;
            boolean reverseColumns = (trial & 2) != 0;
            double[][] permuted = new double[n][n];
            double[] rhs = new double[n];
            double[] expectedSolution = new double[n];
            for (int i = 0; i < n; i++) {
                int row = permutation(i, n, rowShift, reverseRows);
                int col = permutation(i, n, colShift, reverseColumns);
                expectedSolution[col] = logicalSolution[i];
                for (int j = 0; j < n; j++) {
                    int targetColumn = permutation(j, n, colShift, reverseColumns);
                    permuted[row][targetColumn] = logical[i][j];
                    rhs[row] += logical[i][j] * logicalSolution[j];
                }
            }

            Comparison result = compareFresh(permuted, permuted, n, rhs,
                    workspace, "permuted block corpus " + trial, false);
            check(result.accepted, "permuted block corpus was rejected at " + trial);
            assertVectorNear(result.solution, expectedSolution,
                    "permuted block solution " + trial, 1e-10);
            assertResidual(permuted, result.solution, rhs,
                    "permuted block residual " + trial, 1e-10);
        }
    }

    private static int permutation(int index, int size, int shift, boolean reverse) {
        int value = reverse ? size - 1 - index : index;
        return (value + shift) % size;
    }

    private static Comparison compareFresh(double[][] matrix, double[][] original,
            int n, double[] rhs, CirSim.LuFactorizationWorkspace workspace,
            String label, boolean checkIndependent) {
        double[][] actual = copyRows(matrix);
        double[][] supportOriginal = copyRows(original);
        Object mapping = new Object();
        Object support = n >= 2 ? createSupport(actual, supportOriginal, n, mapping) : null;
        boolean allRowsNonzero = true;
        for (int i = 0; i < n; i++) {
            boolean rowNonzero = false;
            for (int j = 0; j < n; j++)
                if (actual[i][j] != 0.0) { rowNonzero = true; break; }
            if (!rowNonzero) { allRowsNonzero = false; break; }
        }
        if (n >= 2 && allRowsNonzero) {
            check(matches(support, actual, supportOriginal, n, mapping),
                    label + ": fresh support was not bound to this factor");
            LuStructuralSupport.Domains eligibility = new LuStructuralSupport.Domains();
            check(((LuStructuralSupport)support).prepareDomains(eligibility, actual,
                    supportOriginal, n, mapping) && eligibility.active,
                    label + ": balanced multi-domain support was not eligible");
            eligibility.clear();
            check(eligibility.allCountsZeroForChecks() && eligibility.allReferencesNullForChecks(),
                    label + ": eligibility probe retained scratch");
        }
        Comparison result = comparePrepared(actual, supportOriginal, n, rhs,
                support, mapping, null, workspace, label);
        if (checkIndependent && result.accepted)
            independentOracle(matrix, rhs, result, label);
        return result;
    }

    private static Comparison comparePrepared(double[][] actual, double[][] original,
            int n, double[] rhs, Object support, Object mapping,
            Object invocationMapping, CirSim.LuFactorizationWorkspace workspace,
            String label) {
        double[][] before = copyRows(actual);
        double[][] expected = copyRows(before);
        int[] expectedPivots = pivots(n);
        int[] actualPivots = pivots(n);
        boolean expectedResult = CirSim.lu_factor(expected, n, expectedPivots, workspace);
        workspaceClear(workspace, label + " full path");
        Object effectiveMapping = invocationMapping == null ? mapping : invocationMapping;
        boolean actualResult = invokeOwnedFactor(actual, n, actualPivots, workspace,
                support, original, effectiveMapping);
        check(actualResult == expectedResult, label + ": success result differs from full LU");
        assertMatrixBits(expected, actual, label + ": factor matrix");
        assertPivots(expectedPivots, actualPivots, label);
        workspaceClear(workspace, label + " supported path");

        double[] solution = null;
        if (rhs != null && expectedResult) {
            double[] expectedRhs = rhs.clone();
            solution = rhs.clone();
            CirSim.lu_solve(expected, n, expectedPivots, expectedRhs);
            CirSim.lu_solve(actual, n, actualPivots, solution);
            for (int i = 0; i < n; i++)
                check(sameBits(expectedRhs[i], solution[i]),
                        label + ": solve raw-bit mismatch at " + i);
        }
        return new Comparison(expectedResult, actual, actualPivots, solution);
    }

    // The unchanged accepted zero-product LU preserves untouched zero signs;
    // the historical dense Crout loop can create -0.0 (pinned by the separate
    // accepted-baseline witness). Nonzero factor bits remain independent here.
    // comparePrepared retains exact full-path factor/pivot/solve bits, including zeros.
    private static void independentOracle(double[][] matrix, double[] rhs,
            Comparison result, String label) {
        int n = matrix.length;
        double[][] oracle = copyRows(matrix);
        int[] oraclePivots = new int[n];
        boolean oracleAccepted = invokeOriginalFactor(oracle, n, oraclePivots);
        check(oracleAccepted == result.accepted,
                label + ": independent dense oracle result differs");
        if (!oracleAccepted) return;
        for (int i = 0; i < n; i++) {
            check(oraclePivots[i] == result.pivots[i],
                    label + ": independent pivot differs at " + i);
            for (int j = 0; j < n; j++)
                check(sameBits(oracle[i][j], result.factors[i][j]) ||
                        (oracle[i][j] == 0.0 && result.factors[i][j] == 0.0),
                        label + ": independent nonzero factor bits differ at [" + i + "][" + j + "]");
        }
        if (rhs != null) {
            double[] oracleRhs = rhs.clone();
            invokeOriginalSolve(oracle, n, oraclePivots, oracleRhs);
            assertVectorNear(result.solution, oracleRhs,
                    label + ": independent dense solve", 1e-12);
        }
    }

    private static void requireNumericalFailureParity(double[][] matrix, int n,
            CirSim.LuFactorizationWorkspace workspace, String label) {
        double[][] expected = copyRows(matrix);
        int[] expectedPivots = pivots(n);
        SolverExecutionBoundary.Outcome expectedOutcome = null;
        try {
            CirSim.lu_factor(expected, n, expectedPivots, workspace);
        } catch (SolverExecutionBoundary.Failure failure) {
            expectedOutcome = failure.outcome;
        }
        check(expectedOutcome == SolverExecutionBoundary.Outcome.NUMERICAL_FAILURE,
                label + ": full LU did not report numerical failure");
        workspaceClear(workspace, label + " full failure cleanup");

        double[][] actual = copyRows(matrix);
        double[][] original = copyRows(matrix);
        Object mapping = new Object();
        Object support = createSupport(actual, original, n, mapping);
        check(support != null && matches(support, actual, original, n, mapping),
                label + ": failure fixture did not receive eligible support");
        int[] actualPivots = pivots(n);
        SolverExecutionBoundary.Outcome actualOutcome = null;
        try {
            invokeOwnedFactor(actual, n, actualPivots, workspace, support, original, mapping);
        } catch (SolverExecutionBoundary.Failure failure) {
            actualOutcome = failure.outcome;
        }
        check(actualOutcome == SolverExecutionBoundary.Outcome.NUMERICAL_FAILURE,
                label + ": supported LU did not preserve numerical failure");
        assertMatrixBits(expected, actual, label + ": partial factor after failure");
        assertPivots(expectedPivots, actualPivots, label + ": failed pivots");
        workspaceClear(workspace, label + " supported failure cleanup");
    }

    private static Object createSupport(double[][] matrix, double[][] original,
            int n, Object mapping) {
        try {
            return supportCreate.invoke(null, matrix, original, Integer.valueOf(n), mapping);
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
            throw new AssertionError("unreachable");
        } catch (Exception failure) {
            throw new AssertionError("could not create LU structural support", failure);
        }
    }

    private static boolean matches(Object support, double[][] matrix,
            double[][] original, int n, Object mapping) {
        if (support == null) return false;
        try {
            return ((Boolean) supportMatches.invoke(support, matrix, original,
                    Integer.valueOf(n), mapping)).booleanValue();
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
            throw new AssertionError("unreachable");
        } catch (Exception failure) {
            throw new AssertionError("could not check LU structural support", failure);
        }
    }

    private static void recordStamp(Object support, int row, int column) {
        try {
            supportRecordStamp.invoke(support, Integer.valueOf(row), Integer.valueOf(column));
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
        } catch (Exception failure) {
            throw new AssertionError("could not record structural stamp", failure);
        }
    }

    private static void invalidate(Object support) {
        try {
            supportInvalidate.invoke(support);
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
        } catch (Exception failure) {
            throw new AssertionError("could not invalidate structural support", failure);
        }
    }

    private static boolean invokeOwnedFactor(double[][] matrix, int n, int[] pivots,
            CirSim.LuFactorizationWorkspace workspace, Object support,
            double[][] original, Object mapping) {
        try {
            return ((Boolean) ownedFactor.invoke(null, matrix, Integer.valueOf(n), pivots,
                    workspace, support, original, mapping)).booleanValue();
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
            throw new AssertionError("unreachable");
        } catch (Exception failure) {
            throw new AssertionError("could not invoke structural LU factor", failure);
        }
    }

    private static boolean invokeOriginalFactor(double[][] matrix, int n, int[] pivots) {
        try {
            return ((Boolean) originalFactor.invoke(null, matrix, Integer.valueOf(n), pivots))
                    .booleanValue();
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
            throw new AssertionError("unreachable");
        } catch (Exception failure) {
            throw new AssertionError("could not invoke independent dense LU oracle", failure);
        }
    }

    private static void invokeOriginalSolve(double[][] matrix, int n, int[] pivots,
            double[] rhs) {
        try {
            originalSolve.invoke(null, matrix, Integer.valueOf(n), pivots, rhs);
        } catch (InvocationTargetException wrapped) {
            throwUnchecked(wrapped.getCause());
        } catch (Exception failure) {
            throw new AssertionError("could not invoke independent dense solve oracle", failure);
        }
    }

    private static void accessible(Method method) {
        method.setAccessible(true);
    }

    private static void rowObjectPermutationParity(double[][] matrix, int n,
            CirSim.LuFactorizationWorkspace workspace) {
        double[][] expected = copyRows(matrix);
        double[][] actual = copyRows(matrix);
        double[][] expectedRowsBefore = expected.clone();
        double[][] actualRowsBefore = actual.clone();
        double[][] original = copyRows(matrix);
        Object mapping = new Object();
        Object support = createSupport(actual, original, n, mapping);
        check(support != null && matches(support, actual, original, n, mapping),
                "row identity fixture did not receive eligible support");
        int[] expectedPivots = pivots(n);
        int[] actualPivots = pivots(n);
        check(CirSim.lu_factor(expected, n, expectedPivots, workspace),
                "row identity full factor was rejected");
        workspaceClear(workspace, "row identity full path");
        check(invokeOwnedFactor(actual, n, actualPivots, workspace,
                support, original, mapping),
                "row identity supported factor was rejected");
        assertMatrixBits(expected, actual, "row identity factor values");
        assertPivots(expectedPivots, actualPivots, "row identity pivots");
        for (int i = 0; i < n; i++) {
            int expectedOrigin = rowOrigin(expected[i], expectedRowsBefore);
            int actualOrigin = rowOrigin(actual[i], actualRowsBefore);
            check(expectedOrigin >= 0 && expectedOrigin == actualOrigin,
                    "row object permutation differs at factor row " + i);
        }
        workspaceClear(workspace, "row identity supported path");
    }

    private static int rowOrigin(double[] row, double[][] originalRows) {
        for (int i = 0; i < originalRows.length; i++)
            if (row == originalRows[i]) return i;
        return -1;
    }

    private static int[] pivots(int n) {
        int[] result = new int[n + 2];
        for (int i = 0; i < result.length; i++) result[i] = PIVOT_TAIL;
        return result;
    }

    private static void assertPivots(int[] expected, int[] actual, String label) {
        check(expected.length == actual.length, label + ": pivot vector length changed");
        for (int i = 0; i < expected.length; i++)
            check(expected[i] == actual[i],
                    label + ": pivot mismatch at " + i + " (expected " +
                    expected[i] + ", got " + actual[i] + ")");
    }

    private static void assertMatrixBits(double[][] expected, double[][] actual,
            String label) {
        check(expected.length == actual.length, label + ": outer matrix length changed");
        for (int i = 0; i < expected.length; i++) {
            check(expected[i].length == actual[i].length,
                    label + ": row length changed at " + i);
            for (int j = 0; j < expected[i].length; j++)
                check(sameBits(expected[i][j], actual[i][j]),
                        label + ": raw-bit mismatch at [" + i + "][" + j + "]");
        }
    }

    private static void assertVector(double[] actual, double[] expected, String label) {
        check(actual != null && actual.length == expected.length,
                label + ": solution length mismatch");
        for (int i = 0; i < expected.length; i++)
            check(sameBits(actual[i], expected[i]),
                    label + ": solution mismatch at " + i);
    }

    private static void assertVectorNear(double[] actual, double[] expected,
            String label, double tolerance) {
        check(actual != null && actual.length == expected.length,
                label + ": solution length mismatch");
        for (int i = 0; i < expected.length; i++)
            check(Math.abs(actual[i] - expected[i]) <= tolerance * (1 + Math.abs(expected[i])),
                    label + ": solution outside tolerance at " + i);
    }

    private static void assertResidual(double[][] matrix, double[] solution,
            double[] rhs, String label, double tolerance) {
        double scale = 1;
        for (int i = 0; i < rhs.length; i++) scale = Math.max(scale, Math.abs(rhs[i]));
        for (int i = 0; i < matrix.length; i++) {
            double value = 0;
            for (int j = 0; j < matrix.length; j++)
                value += matrix[i][j] * solution[j];
            check(Math.abs(value - rhs[i]) <= tolerance * scale,
                    label + ": residual outside tolerance at row " + i);
        }
    }

    private static void restoreMatrix(double[][] matrix, double[][] original) {
        for (int i = 0; i < matrix.length; i++)
            System.arraycopy(original[i], 0, matrix[i], 0, original[i].length);
    }

    private static double[][] copyRows(double[][] matrix) {
        double[][] result = new double[matrix.length][];
        for (int i = 0; i < matrix.length; i++) {
            int previous = -1;
            for (int j = 0; j < i; j++) {
                if (matrix[j] == matrix[i]) {
                    previous = j;
                    break;
                }
            }
            result[i] = previous >= 0 ? result[previous] : matrix[i].clone();
        }
        return result;
    }

    private static boolean sameBits(double left, double right) {
        return Double.doubleToRawLongBits(left) == Double.doubleToRawLongBits(right);
    }

    private static void workspaceClear(CirSim.LuFactorizationWorkspace workspace,
            String point) {
        check(workspace.allCountsZeroForChecks(),
                point + ": workspace retained counters or active size");
        check(workspace.allRowReferencesNullForChecks(),
                point + ": workspace retained row references");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private static void throwUnchecked(Throwable cause) {
        if (cause instanceof RuntimeException) throw (RuntimeException) cause;
        if (cause instanceof Error) throw (Error) cause;
        throw new AssertionError("LU contract method threw checked exception", cause);
    }

    private static final class Comparison {
        final boolean accepted;
        final double[][] factors;
        final int[] pivots;
        final double[] solution;

        Comparison(boolean accepted, double[][] factors, int[] pivots, double[] solution) {
            this.accepted = accepted;
            this.factors = factors;
            this.pivots = pivots;
            this.solution = solution;
        }
    }

    private LuStructuralFactorizationContractTest() { }
}
