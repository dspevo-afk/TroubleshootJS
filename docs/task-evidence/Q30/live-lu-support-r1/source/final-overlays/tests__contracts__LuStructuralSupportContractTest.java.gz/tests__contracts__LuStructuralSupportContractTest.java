package com.lushprojects.circuitjs1.client;

/** Native structural oracle for the bounded live-LU support tracker. */
public final class LuStructuralSupportContractTest {
    private static int assertions;

    public static void main(String[] args) {
        int count = run();
        System.out.println("PASS: LU structural support contracts assertions=" + count);
    }

    static int run() {
        assertions = 0;
        testUnionAgainstNaiveBfs();
        testCreationAndOwnerValidation();
        testBalancedSupportAndDomains();
        testAsymmetricPermutationFixture();
        testCrossGroupResortingAndCleanup();
        return assertions;
    }

    private static void testUnionAgainstNaiveBfs() {
        int n = 6;
        double[][] original = identity(n);
        double[][] matrix = copy(original);
        Object mapping = new Object();
        LuStructuralSupport support = LuStructuralSupport.create(matrix, original, n, mapping);
        check(support != null, "diagonal support owner was rejected");
        boolean[][] edges = new boolean[n * 2][n * 2];
        addOriginalEdges(edges, original, n);
        comparePartition(support, edges, n, "seeded diagonal partition");

        int[][] stamps = {
            { 0, 1 }, { 1, 0 }, { 2, 3 }, { 3, 2 },
            { 4, 5 }, { 5, 4 }, { 1, 2 }, { 4, 0 },
            { 0, 1 } // duplicate mapped coordinate must be amortized
        };
        double[][] beforeStamps = copy(matrix);
        for (int index = 0; index < stamps.length; index++) {
            int row = stamps[index][0];
            int column = stamps[index][1];
            support.recordStamp(row, column);
            addEdge(edges, row, column, n);
            comparePartition(support, edges, n, "mapped stamp " + index);
            check(equalValues(matrix, beforeStamps, n),
                    "recordStamp wrote a matrix value at stamp " + index);
        }
        check(support.hasSingleComponent(),
                "all mapped zero/cancelling coordinates did not merge support monotonically");
        support.recordStamp(-1, 0);
        check(!support.matches(matrix, original, n, mapping),
                "out-of-range stamp did not invalidate its owner");
        check(support.componentLabelForChecks(0) == -1,
                "invalid owner exposed a usable component label");
    }

    private static void testCreationAndOwnerValidation() {
        check(LuStructuralSupport.create(new double[0][0], new double[0][0], 1,
                new Object()) == null, "n below two was accepted");
        check(LuStructuralSupport.create(new double[0][0], new double[0][0], 513,
                new Object()) == null, "n above 512 was accepted");
        check(LuStructuralSupport.create(null, new double[2][2], 2,
                new Object()) == null, "null working matrix was accepted");
        check(LuStructuralSupport.create(new double[2][2], null, 2,
                new Object()) == null, "null original matrix was accepted");
        check(LuStructuralSupport.create(new double[][] { { 1, 0 }, { 0 } },
                new double[][] { { 1, 0 }, { 0, 1 } }, 2,
                new Object()) == null, "short working row was accepted");
        check(LuStructuralSupport.create(new double[][] { { 1, 0 }, { 0, 1 } },
                new double[][] { { 1, 0 }, { 0 } }, 2,
                new Object()) == null, "short original row was accepted");

        for (double bad : new double[] {
                Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY }) {
            double[][] original = { { 1, 0 }, { 0, bad } };
            check(LuStructuralSupport.create(copy(original), original, 2,
                    new Object()) == null, "nonfinite original value was accepted: " + bad);
        }
        double[] aliased = new double[] { 0, 0 };
        double[][] duplicateRows = { aliased, aliased };
        check(LuStructuralSupport.create(duplicateRows,
                new double[][] { { 0, 0 }, { 0, 0 } }, 2,
                new Object()) == null, "duplicate working row identity was accepted");
        double[][] original = identity(2);
        double[][] mismatched = copy(original);
        mismatched[1][1] = 3;
        check(LuStructuralSupport.create(mismatched, original, 2,
                new Object()) == null, "working/original active-value mismatch was accepted");

        // Allocation tails are outside the active prefix and remain permitted.
        double[][] tailedOriginal = new double[3][5];
        tailedOriginal[0][0] = 1;
        tailedOriginal[1][1] = 2;
        tailedOriginal[2][4] = Double.NaN;
        double[][] tailedMatrix = copy(tailedOriginal);
        Object mapping = new Object();
        LuStructuralSupport tailed = LuStructuralSupport.create(tailedMatrix,
                tailedOriginal, 2, mapping);
        check(tailed != null, "valid allocation tails were rejected");
        check(tailed.matches(tailedMatrix, tailedOriginal, 2, mapping),
                "fresh owner did not match its exact array/mapping identities");
        check(!tailed.matches(copy(tailedMatrix), tailedOriginal, 2, mapping),
                "different working-array identity matched");
        check(!tailed.matches(tailedMatrix, copy(tailedOriginal), 2, mapping),
                "different original-array identity matched");
        check(!tailed.matches(tailedMatrix, tailedOriginal, 2, new Object()),
                "different mapping identity matched");
        check(!tailed.matches(tailedMatrix, tailedOriginal, 3, mapping),
                "different dimension matched");
        tailed.invalidate();
        check(!tailed.matches(tailedMatrix, tailedOriginal, 2, mapping),
                "explicit invalidation left the owner usable");
    }

    private static void testBalancedSupportAndDomains() {
        int n = 3;
        double[][] original = identity(n);
        double[][] matrix = copy(original);
        Object mapping = new Object();
        LuStructuralSupport balanced = LuStructuralSupport.create(matrix, original, n, mapping);
        LuStructuralSupport.Domains domains = new LuStructuralSupport.Domains();
        matrix[0][0] = 19.0; // The next factor may contain trial values after setup.
        check(balanced.matches(matrix, original, n, mapping),
                "matching owner rescanned changed working numeric values");
        check(balanced.prepareDomains(domains, matrix, original, n,
                mapping),
                "balanced diagonal components failed to prepare");
        check(!domains.allCountsZeroForChecks() && !domains.allReferencesNullForChecks(),
                "successful diagonal preparation did not retain factor membership");
        check(domains.active, "successful domain preparation did not mark scratch active");
        assertSortedMembership(domains, matrix, n, "diagonal domains");
        domains.clear();
        check(domains.allCountsZeroForChecks() && domains.allReferencesNullForChecks(),
                "clear did not release diagonal domains");

        double[][] unbalancedMatrix = { { 1, 1 }, { 0, 0 } };
        double[][] unbalancedOriginal = copy(unbalancedMatrix);
        Object unbalancedMapping = new Object();
        LuStructuralSupport unbalanced = LuStructuralSupport.create(unbalancedMatrix,
                unbalancedOriginal, 2, unbalancedMapping);
        check(unbalanced != null, "unbalanced support owner was rejected at creation");
        check(!unbalanced.prepareDomains(domains, unbalancedMatrix, unbalancedOriginal,
                2, unbalancedMapping), "unbalanced support unexpectedly prepared domains");
        check(!domains.active && domains.allReferencesNullForChecks() &&
                domains.allCountsZeroForChecks(), "unbalanced preparation left scratch active");

        double[][] singleMatrix = { { 1, 2 }, { 3, 4 } };
        double[][] singleOriginal = copy(singleMatrix);
        Object singleMapping = new Object();
        LuStructuralSupport single = LuStructuralSupport.create(singleMatrix,
                singleOriginal, 2, singleMapping);
        check(single.hasSingleComponent(), "dense support was not recognized as single-component");
        check(!single.prepareDomains(domains, singleMatrix, singleOriginal, 2, singleMapping),
                "single component unexpectedly created pruning domains");
        check(domains.allReferencesNullForChecks() && domains.allCountsZeroForChecks(),
                "single-component rejection retained domain scratch");
    }

    private static void testAsymmetricPermutationFixture() {
        double[][] original = {
            { 0, 1, 1 },
            { 1, 0, 0 },
            { 0, 1, 1 }
        };
        double[][] matrix = copy(original);
        Object mapping = new Object();
        LuStructuralSupport support = LuStructuralSupport.create(matrix, original, 3, mapping);
        LuStructuralSupport.Domains domains = new LuStructuralSupport.Domains();
        check(support.prepareDomains(domains, matrix, original, 3, mapping),
                "asymmetric balanced support did not prepare");
        int groupA = domains.rowGroups[0];
        int groupB = domains.rowGroups[1];
        check(groupA != groupB && domains.rowGroups[2] == groupA,
                "asymmetric row groups differ from manual A,B,A fixture");
        check(domains.columnGroups[0] == groupB && domains.columnGroups[1] == groupA &&
                domains.columnGroups[2] == groupA,
                "asymmetric column groups differ from manual B,A,A fixture");
        int[] manualPivotRows = { 1, 2, 2 };
        for (int k = 0; k < manualPivotRows.length; k++) {
            int group = domains.columnGroups[k];
            check(domains.columns[group][domains.starts[group]] == k,
                    "column cursor did not point to global k before pivot " + k);
            int pivotRow = manualPivotRows[k];
            check(domains.rowGroups[pivotRow] == group,
                    "manual pivot row is outside column support at pivot " + k);
            int priorStart = domains.starts[group];
            swapMatrixRows(matrix, k, pivotRow);
            domains.swap(k, pivotRow);
            check(domains.rowGroups[k] == group,
                    "row group did not follow the manual pivot swap at " + k);
            assertSortedMembership(domains, matrix, 3, "asymmetric pivot " + k);
            domains.finishPivot(k);
            check(domains.active && domains.starts[group] == priorStart + 1,
                    "finishPivot did not advance the active prefix once at " + k);
        }
        domains.clear();
        check(domains.allCountsZeroForChecks() && domains.allReferencesNullForChecks(),
                "asymmetric factor cleanup retained domains");
    }

    private static void testCrossGroupResortingAndCleanup() {
        double[][] original = {
            { 0, 1, 0, 1 },
            { 1, 0, 1, 0 },
            { 0, 1, 0, 1 },
            { 1, 0, 1, 0 }
        };
        double[][] matrix = copy(original);
        Object mapping = new Object();
        LuStructuralSupport support = LuStructuralSupport.create(matrix, original, 4, mapping);
        LuStructuralSupport.Domains domains = new LuStructuralSupport.Domains();
        check(support.prepareDomains(domains, matrix, original, 4, mapping),
                "two interleaved balanced components did not prepare");
        int[] manualPivotRows = { 3, 3, 3, 3 };
        for (int k = 0; k < manualPivotRows.length; k++) {
            int group = domains.columnGroups[k];
            check(domains.columns[group][domains.starts[group]] == k,
                    "column list/cursor lost global order at pivot " + k);
            check(domains.rowGroups[manualPivotRows[k]] == group,
                    "manual cross-group pivot row is outside column component at " + k);
            swapMatrixRows(matrix, k, manualPivotRows[k]);
            domains.swap(k, manualPivotRows[k]);
            check(domains.rowGroups[k] == group,
                    "cross-group pivot did not move target component to k at " + k);
            assertSortedMembership(domains, matrix, 4, "cross-group pivot " + k);
            domains.finishPivot(k);
        }
        check(domains.starts[domains.columnGroups[0]] == 2 &&
                domains.starts[domains.columnGroups[1]] == 2,
                "global finish sequence did not consume each component's two pivots");
        domains.clear();
        check(domains.allReferencesNullForChecks() && domains.allCountsZeroForChecks(),
                "cross-group factor cleanup retained scratch");

        // Prepare again to model the next restored nonlinear factor. Then abort
        // after one consumed row and reject an owner mismatch; prepare must clear
        // every remaining matrix reference before returning false.
        restoreActiveValues(matrix, original, 4);
        check(support.prepareDomains(domains, matrix, original, 4, mapping),
                "reused scratch failed to prepare another factor");
        int firstGroup = domains.columnGroups[0];
        swapMatrixRows(matrix, 0, manualPivotRows[0]);
        domains.swap(0, manualPivotRows[0]);
        domains.finishPivot(0);
        check(!domains.allReferencesNullForChecks(),
                "partial-factor fixture did not retain unconsumed references");
        check(!support.prepareDomains(domains, matrix, original, 4, new Object()),
                "owner mismatch unexpectedly prepared domains");
        check(!domains.active && domains.allCountsZeroForChecks() &&
                domains.allReferencesNullForChecks(),
                "failed reused preparation retained partial factor references");

        restoreActiveValues(matrix, original, 4);
        check(support.prepareDomains(domains, matrix, original, 4, mapping),
                "scratch failed to recover after a failed preparation");
        check(domains.starts[firstGroup] == 0,
                "new factor inherited a previous factor's active-prefix cursor");
        domains.clear();
        check(domains.allCountsZeroForChecks() && domains.allReferencesNullForChecks(),
                "final scratch reuse cleanup failed");
    }

    private static void comparePartition(LuStructuralSupport support,
            boolean[][] edges, int n, String point) {
        int[] expected = naiveComponents(edges);
        int vertices = n * 2;
        for (int first = 0; first < vertices; first++) {
            for (int second = 0; second < vertices; second++) {
                boolean actualSame = support.componentLabelForChecks(first) ==
                        support.componentLabelForChecks(second);
                check(actualSame == (expected[first] == expected[second]),
                        point + ": UF partition differs from BFS at vertices " +
                                first + "," + second);
            }
        }
    }

    private static int[] naiveComponents(boolean[][] edges) {
        int count = edges.length;
        int[] components = new int[count];
        for (int index = 0; index < count; index++) components[index] = -1;
        int[] queue = new int[count];
        int component = 0;
        for (int start = 0; start < count; start++) {
            if (components[start] >= 0) continue;
            int read = 0;
            int write = 0;
            queue[write++] = start;
            components[start] = component;
            while (read < write) {
                int vertex = queue[read++];
                for (int neighbor = 0; neighbor < count; neighbor++) {
                    if (edges[vertex][neighbor] && components[neighbor] < 0) {
                        components[neighbor] = component;
                        queue[write++] = neighbor;
                    }
                }
            }
            component++;
        }
        return components;
    }

    private static void addOriginalEdges(boolean[][] edges, double[][] original, int n) {
        for (int row = 0; row < n; row++)
            for (int column = 0; column < n; column++)
                if (original[row][column] != 0.0) addEdge(edges, row, column, n);
    }

    private static void addEdge(boolean[][] edges, int row, int column, int n) {
        edges[row][n + column] = true;
        edges[n + column][row] = true;
    }

    private static void assertSortedMembership(LuStructuralSupport.Domains domains,
            double[][] matrix, int n, String point) {
        for (int column = 0; column < n; column++) {
            int group = domains.columnGroups[column];
            check(group >= 0 && group < domains.columns.length,
                    point + ": column group missing at " + column);
        }
        for (int group = 0; group < domains.counts.length; group++) {
            int previous = -1;
            for (int slot = domains.starts[group]; slot < domains.counts[group]; slot++) {
                int row = domains.rowIndexes[group][slot];
                check(row > previous, point + ": active row indices are not ascending");
                check(domains.rowReferences[group][slot] == matrix[row],
                        point + ": cached row reference differs from matrix row " + row);
                check(domains.rowSlots[row] == slot && domains.rowGroups[row] == group,
                        point + ": reverse row membership differs at row " + row);
                previous = row;
            }
            previous = -1;
            for (int slot = 0; slot < domains.columnCounts[group]; slot++) {
                int column = domains.columns[group][slot];
                check(column > previous, point + ": column indices are not ascending");
                check(domains.columnGroups[column] == group,
                        point + ": column group differs from its list at " + column);
                previous = column;
            }
        }
    }

    private static double[][] identity(int n) {
        double[][] matrix = new double[n][n];
        for (int i = 0; i < n; i++) matrix[i][i] = i + 1;
        return matrix;
    }

    private static double[][] copy(double[][] source) {
        double[][] result = new double[source.length][];
        for (int row = 0; row < source.length; row++) {
            result[row] = new double[source[row].length];
            System.arraycopy(source[row], 0, result[row], 0, source[row].length);
        }
        return result;
    }

    private static boolean equalValues(double[][] first, double[][] second, int n) {
        for (int row = 0; row < n; row++)
            for (int column = 0; column < n; column++)
                if (first[row][column] != second[row][column]) return false;
        return true;
    }

    private static void swapMatrixRows(double[][] matrix, int first, int second) {
        double[] row = matrix[first];
        matrix[first] = matrix[second];
        matrix[second] = row;
    }

    private static void restoreActiveValues(double[][] matrix, double[][] original, int n) {
        for (int row = 0; row < n; row++)
            System.arraycopy(original[row], 0, matrix[row], 0, n);
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private LuStructuralSupportContractTest() { }
}
