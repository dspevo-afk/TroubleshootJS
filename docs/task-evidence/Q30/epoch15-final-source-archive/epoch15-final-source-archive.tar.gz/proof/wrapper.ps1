$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$workspace = $PSScriptRoot
$repo = '$REPO'
$pointerPath = Join-Path $workspace 'epoch15-task-pointer.json'
$expectedBaseHead = 'd37c3b3b8581abdeaa9b88b7bfb2349cff958d31'
$expectedSourceIdentity = 'a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51'
$expectedArchiveScriptSha256 = 'd14c811e487c0817003d5171fc0c1c53820c5d213e05a9c2c5724fb808b9fb8d'
$archiveScript = Join-Path $repo 'docs/task-evidence/Q30/resume-20261002/archive-q30-sources.ps1'
$pwsh = '$USER_HOME\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'

if (-not (Test-Path -LiteralPath $pointerPath -PathType Leaf)) { throw 'Current epoch15 task pointer is missing' }
$pointer = Get-Content -LiteralPath $pointerPath -Raw | ConvertFrom-Json
if ($pointer.schema -ne 1) { throw 'Current epoch15 task pointer schema changed' }
if ([string]$pointer.baseHead -cne $expectedBaseHead) { throw 'Current epoch15 task pointer baseHead changed' }
if ([string]$pointer.sourceIdentity -cne $expectedSourceIdentity) { throw 'Current epoch15 task pointer sourceIdentity changed' }
if ([int]$pointer.layoutEpoch -ne 15 -or [int]$pointer.frozenRoots -ne 77 -or
    [int]$pointer.frozenServiceSensitivityRoots -ne 21) {
    throw 'Current epoch15 task pointer cohort or layout binding changed'
}

$taskRoot = [IO.Path]::GetFullPath([string]$pointer.taskRoot)
$tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([char[]]@([char]'\', [char]'/')) + [IO.Path]::DirectorySeparatorChar
if (-not $taskRoot.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Pointer taskRoot is outside the OS temporary directory'
}
$taskRootLeaf = [IO.Path]::GetFileName($taskRoot.TrimEnd([char[]]@([char]'\', [char]'/')))
if ($taskRootLeaf -cne 'q30-process-pinned-final-qualification-fcffecff8fa444889bce93725495c628') {
    throw 'Pointer does not identify the expected final qualification task root'
}
if (-not (Test-Path -LiteralPath $taskRoot -PathType Container)) { throw 'Pointer taskRoot is missing' }
if ((Get-Item -LiteralPath $taskRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) {
    throw 'Pointer taskRoot is a reparse point'
}
if (-not (Test-Path -LiteralPath $repo -PathType Container)) { throw 'Repository path is missing' }

$destination = Join-Path $taskRoot 'archive-stage-result.json'
$logPath = Join-Path $taskRoot 'archive-stage.log'
$archiveRoot = Join-Path $taskRoot 'source-attempt-archive-epoch15'
foreach ($path in @($destination, $logPath, $archiveRoot)) {
    if (Test-Path -LiteralPath $path) { throw ('Preserve prior archive evidence: ' + $path) }
}

$owner = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $PID)
if ($null -eq $owner -or [int]$owner.ProcessId -ne $PID -or
    [string]::IsNullOrWhiteSpace([string]$owner.ExecutablePath)) {
    throw 'Could not establish archive-wrapper process identity'
}
$record = [ordered]@{
    schema = 1
    task = 'epoch15-source-archive'
    status = 'RUNNING'
    startedUtc = (Get-Date).ToUniversalTime().ToString('o')
    taskRoot = $taskRoot
    candidate = 'isolated'
    baseHead = [string]$pointer.baseHead
    sourceIdentity = [string]$pointer.sourceIdentity
    owner = [ordered]@{
        pid = $PID
        createdUtc = $owner.CreationDate.ToUniversalTime().ToString('o')
        executable = [string]$owner.ExecutablePath
        commandLine = [string]$owner.CommandLine
    }
    archiveRoot = $archiveRoot
    archiveLog = $logPath
    archiveScript = $archiveScript
    archiveScriptExpectedSha256 = $expectedArchiveScriptSha256
    commandOptions = @('CandidateNames=isolated', 'SkipProfile=true', 'IncludeSourceTrees=false')
    command = @($pwsh, '-NoProfile', '-File', $archiveScript, '-TaskRoot', $taskRoot,
        '-Repo', $repo, '-ArchiveRoot', $archiveRoot, '-CandidateNames', 'isolated', '-SkipProfile')
    acceptanceStatus = 'NOT_ASSESSED'
}
$record | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $destination -Encoding UTF8
$clock = [Diagnostics.Stopwatch]::StartNew()

try {
    $integrationPath = Join-Path $workspace 'integration-pointer.json'
    if (-not (Test-Path -LiteralPath $integrationPath -PathType Leaf)) { throw 'Integration pointer is missing' }
    $integration = Get-Content -LiteralPath $integrationPath -Raw | ConvertFrom-Json
    $integrationHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $integrationPath).Hash.ToLowerInvariant()
    if ($integration.status -ne 'INTEGRATED_PENDING_FRESH_GATES' -or
        [string]$integration.baseHead -cne [string]$pointer.baseHead -or
        [string]$integration.taskRoot -cne $taskRoot -or
        $integrationHash -cne ([string]$pointer.integrationPointerSha256).ToLowerInvariant()) {
        throw 'Integration pointer does not match the final task pointer'
    }
    $changedPaths = @($integration.changes | ForEach-Object { [string]$_.path } | Sort-Object)
    $pointerChangedPaths = @($pointer.changedSourcePaths | ForEach-Object { [string]$_ } | Sort-Object)
    if (@(Compare-Object -ReferenceObject $changedPaths -DifferenceObject $pointerChangedPaths).Count -ne 0) {
        throw 'Pointer changed-source set differs from integrated candidate'
    }
    if ([string]$pointer.previousSourceIdentity -cne [string]$integration.priorSourceIdentity) {
        throw 'Pointer prior source identity differs from integration provenance'
    }

    $snapshotPath = Join-Path $taskRoot 'source-snapshot.json'
    $candidateRoot = Join-Path $taskRoot 'isolated'
    $candidateSnapshotPath = Join-Path $candidateRoot 'source-snapshot.json'
    $receiptPath = Join-Path $candidateRoot 'prepare-receipt.json'
    $appRoot = Join-Path $candidateRoot 'app'
    $planPath = Join-Path $taskRoot 'acceptance-plan.json'
    $bundledPlanPath = Join-Path $repo 'tests/qualification/q30-scale-acceptance/acceptance-plan.json'
    foreach ($path in @($snapshotPath, $candidateSnapshotPath, $receiptPath, $planPath, $bundledPlanPath)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Required archive input is missing: ' + $path) }
    }
    if (-not (Test-Path -LiteralPath $appRoot -PathType Container)) { throw 'Isolated source app is missing' }

    $sourceSnapshot = Get-Content -LiteralPath $snapshotPath -Raw | ConvertFrom-Json
    $candidateSnapshot = Get-Content -LiteralPath $candidateSnapshotPath -Raw | ConvertFrom-Json
    $receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
    $plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
    $bundledPlan = Get-Content -LiteralPath $bundledPlanPath -Raw | ConvertFrom-Json
    if ($sourceSnapshot.status -ne 'PASS' -or $sourceSnapshot.q30NormalPlayerEnabled -ne $false -or
        [int]$sourceSnapshot.layoutAlgorithmVersion -ne 15) {
        throw 'Current source snapshot metadata is not PASS/layout15/disabled'
    }
    foreach ($snapshot in @($sourceSnapshot, $candidateSnapshot)) {
        if ([string]$snapshot.baseHead -cne [string]$pointer.baseHead -or
            [string]$snapshot.sourceIdentity -cne [string]$pointer.sourceIdentity -or
            @($snapshot.files).Count -ne 1354) {
            throw 'Source snapshot differs from the pointer-bound 1,354-input candidate'
        }
    }
    if ($receipt.status -ne 'PREPARED' -or
        [string]$receipt.baseHead -cne [string]$pointer.baseHead -or
        [string]$receipt.sourceIdentity -cne [string]$pointer.sourceIdentity -or
        [int]$receipt.sourceFileCount -ne 1354 -or
        [string]$receipt.sourceSnapshotSha256 -cne
            (Get-FileHash -Algorithm SHA256 -LiteralPath $candidateSnapshotPath).Hash.ToLowerInvariant()) {
        throw 'Isolated preparation receipt does not bind the current source snapshot'
    }
    if (@($pointer.changedPlanFields).Count -ne 1 -or
        [string]$pointer.changedPlanFields[0] -cne 'baseHead' -or
        [string]$receipt.acceptancePlanSha256 -cne [string]$pointer.continuedPlanSha256 -or
        (Get-FileHash -Algorithm SHA256 -LiteralPath $bundledPlanPath).Hash.ToLowerInvariant() -cne
            ([string]$pointer.originalPlanSha256).ToLowerInvariant() -or
        (Get-FileHash -Algorithm SHA256 -LiteralPath $planPath).Hash.ToLowerInvariant() -cne
            ([string]$pointer.continuedPlanSha256).ToLowerInvariant() -or
        [string]$plan.baseHead -cne [string]$pointer.baseHead -or
        @($plan.cases).Count -ne 77 -or @($plan.coldOrder).Count -ne 77 -or
        @($plan.serviceAndSensitivitySeeds).Count -ne 21 -or
        [int]$plan.limits.jobMillis -ne 90000 -or
        [int]$plan.limits.sharedWork -ne 640 -or
        [int]$plan.limits.activeOperationMillis -ne 5000) {
        throw 'Isolated receipt or acceptance plan differs from the frozen epoch15 contract'
    }
    $bundledProjection = [ordered]@{}
    foreach ($property in $bundledPlan.PSObject.Properties) {
        if ($property.Name -cne 'baseHead') { $bundledProjection[$property.Name] = $property.Value }
    }
    $continuedProjection = [ordered]@{}
    foreach ($property in $plan.PSObject.Properties) {
        if ($property.Name -cne 'baseHead') { $continuedProjection[$property.Name] = $property.Value }
    }
    $bundledProjectionJson = ConvertTo-Json -InputObject $bundledProjection -Depth 100 -Compress
    $continuedProjectionJson = ConvertTo-Json -InputObject $continuedProjection -Depth 100 -Compress
    if ($bundledProjectionJson -cne $continuedProjectionJson) {
        throw 'Continued acceptance plan changed fields beyond baseHead'
    }
    $sourceRows = @($sourceSnapshot.files | ForEach-Object {
        '{0}|{1}|{2}' -f ([string]$_.path), ([int64]$_.size), ([string]$_.sha256).ToLowerInvariant()
    } | Sort-Object)
    $candidateRows = @($candidateSnapshot.files | ForEach-Object {
        '{0}|{1}|{2}' -f ([string]$_.path), ([int64]$_.size), ([string]$_.sha256).ToLowerInvariant()
    } | Sort-Object)
    if (@(Compare-Object -ReferenceObject $sourceRows -DifferenceObject $candidateRows).Count -ne 0) {
        throw 'Top-level and isolated source snapshots differ'
    }

    $archiveScriptHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $archiveScript).Hash.ToLowerInvariant()
    if ($archiveScriptHash -cne $expectedArchiveScriptSha256) { throw 'Maintained archive script hash changed' }
    if (-not (Test-Path -LiteralPath $pwsh -PathType Leaf)) { throw 'Pinned PowerShell 7 executable is missing' }
    $record.integrationPointerSha256 = $integrationHash
    $record.sourceSnapshotSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $snapshotPath).Hash.ToLowerInvariant()
    $record.candidateSnapshotSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $candidateSnapshotPath).Hash.ToLowerInvariant()
    $record.prepareReceiptSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $receiptPath).Hash.ToLowerInvariant()
    $record.originalPlanSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $bundledPlanPath).Hash.ToLowerInvariant()
    $record.acceptancePlanSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $planPath).Hash.ToLowerInvariant()
    $record.archiveScriptSha256 = $archiveScriptHash
    $record.pwshExecutable = $pwsh

    $oldGitConfigCount = $env:GIT_CONFIG_COUNT
    $oldGitConfigKey0 = $env:GIT_CONFIG_KEY_0
    $oldGitConfigValue0 = $env:GIT_CONFIG_VALUE_0
    try {
        $env:GIT_CONFIG_COUNT = '1'
        $env:GIT_CONFIG_KEY_0 = 'safe.directory'
        $env:GIT_CONFIG_VALUE_0 = $repo
        $LASTEXITCODE = $null
        & $pwsh -NoProfile -File $archiveScript -TaskRoot $taskRoot -Repo $repo `
            -ArchiveRoot $archiveRoot -CandidateNames @('isolated') -SkipProfile `
            *> $logPath
        $record.exitCode = $LASTEXITCODE
    }
    finally {
        $env:GIT_CONFIG_COUNT = $oldGitConfigCount
        $env:GIT_CONFIG_KEY_0 = $oldGitConfigKey0
        $env:GIT_CONFIG_VALUE_0 = $oldGitConfigValue0
    }
    if ($record.exitCode -ne 0) { throw ('Archive returned ' + $record.exitCode) }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $archiveScript).Hash.ToLowerInvariant() -cne $expectedArchiveScriptSha256) {
        throw 'Maintained archive script changed during the run'
    }
    $logText = Get-Content -LiteralPath $logPath -Raw
    $scratchMatches = [regex]::Matches($logText, '(?m)^ARCHIVE_SCRATCH_RETAINED (q30-source-archive-[0-9a-f]{32})\s*$')
    if ($scratchMatches.Count -ne 1) { throw 'Maintained archive scratch-retention marker is missing or ambiguous' }
    $record.scratchLabel = $scratchMatches[0].Groups[1].Value

    $manifestPath = Join-Path $archiveRoot 'archive-manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'Archive manifest is missing' }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $candidateRows = @($manifest.candidates)
    if ($manifest.archiveRunStatus -ne 'PASS' -or $manifest.status -ne 'SOURCE_ARCHIVE_ONLY' -or
        $manifest.acceptanceStatus -ne 'NOT_ASSESSED' -or $manifest.compactMode -ne $true -or
        [string]$manifest.baseHead -cne [string]$pointer.baseHead -or
        $candidateRows.Count -ne 1 -or $null -ne $manifest.profile) {
        throw 'Archive manifest status, cohort, compact mode, or acceptance boundary differs'
    }
    $candidate = $candidateRows[0]
    if ([string]$candidate.candidate -cne 'isolated' -or
        [string]$candidate.sourceIdentity -cne [string]$pointer.sourceIdentity -or
        [string]$candidate.status -cne 'ARCHIVED_SOURCE_ONLY' -or
        $candidate.archiveValid -ne $true -or [int]$candidate.sourceFileCount -ne 1354 -or
        $candidate.sourceSnapshotReceiptHashMatch -ne $true -or
        [string]$candidate.snapshotMismatchClassification -cne 'EXPECTED_BASELINE_PATCH' -or
        [string]$candidate.baselinePatchVerification -cne 'PASS' -or
        [string]$candidate.sourceDelta.reconstruction -cne 'PASS' -or
        [string]$candidate.sourceDelta.patchRoundTrip -cne 'PASS' -or
        [string]$candidate.overlayDeclaredBytesMatch -cne 'PASS' -or
        [string]$candidate.overlayArchive.extractedBytesMatchSource -cne 'PASS' -or
        [string]$candidate.effectiveSourceArchive.status -cne 'OMITTED_COMPACT') {
        throw 'Isolated candidate archive integrity receipt is incomplete or nonpass'
    }
    if (Test-Path -LiteralPath (Join-Path $archiveRoot 'isolated/source-tree.tar.gz')) {
        throw 'Compact archive unexpectedly contains a source-tree archive'
    }
    $record.archiveManifestSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $manifestPath).Hash.ToLowerInvariant()
    $record.archiveRunStatus = [string]$manifest.archiveRunStatus
    $record.candidateStatus = [string]$candidate.status
    $record.baselinePatchVerification = [string]$candidate.baselinePatchVerification
    $record.sourceDeltaReconstruction = [string]$candidate.sourceDelta.reconstruction
    $record.status = 'PASS'
}
catch {
    $record.status = 'FAIL'
    $record.error = $_.Exception.Message
}
finally {
    $record.finishedUtc = (Get-Date).ToUniversalTime().ToString('o')
    $record.elapsedSeconds = $clock.Elapsed.TotalSeconds
    $record | ConvertTo-Json -Depth 24 | Set-Content -LiteralPath $destination -Encoding UTF8
}

$record | ConvertTo-Json -Depth 24
if ($record.status -ne 'PASS') { exit 1 }
