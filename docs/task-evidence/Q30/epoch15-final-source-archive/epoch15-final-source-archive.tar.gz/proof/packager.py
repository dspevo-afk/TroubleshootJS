"""Preserve and independently audit the final compact source-only archive."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
from datetime import datetime, timezone
import save_process_final_cold_failure as sanitation

REPO=sanitation.REPO
TASK=Path(r'$TASK_ROOT')
WORK=Path(__file__).resolve().parent
SOURCE=TASK/'source-attempt-archive-epoch15'
DEST=REPO/'docs/task-evidence/Q30/epoch15-final-source-archive'
sha=lambda data:hashlib.sha256(data).hexdigest()
private=re.compile(rb'(?i)(?:[A-Z]:[\\/]+Users[\\/]+david|$USER_HOME')
checks=0
expanded=0

def scan(name,data,depth=0):
    global checks,expanded
    assert depth<=4 and len(data)<=64*1024*1024
    expanded+=len(data)
    assert expanded<=128*1024*1024 and not private.search(data),name
    checks+=1
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive:
                path=PurePosixPath(member.name)
                assert not path.is_absolute() and '..' not in path.parts and not member.issym() and not member.islnk()
                assert member.isfile() or member.isdir()
                if member.isfile():
                    assert member.size<=64*1024*1024
                    scan(name+':'+member.name,archive.extractfile(member).read(),depth+1)
    elif name.endswith('.gz'):
        scan(name[:-3],gzip.decompress(data),depth+1)

def main():
    assert not DEST.exists(),'preserve prior evidence'
    stage=json.loads((TASK/'archive-stage-result.json').read_bytes())
    manifest=json.loads((SOURCE/'archive-manifest.json').read_bytes())
    cleanup=json.loads((TASK/'menu-archive-terminal-independent-process-review.json').read_bytes())
    assert stage['status']=='PASS' and stage['exitCode']==0 and stage['sourceIdentity']==sanitation.SOURCE
    assert stage['baseHead']==sanitation.HEAD and stage['acceptanceStatus']=='NOT_ASSESSED'
    assert manifest['archiveRunStatus']=='PASS' and manifest['acceptanceStatus']=='NOT_ASSESSED'
    assert manifest['status']=='SOURCE_ARCHIVE_ONLY' and manifest['compactMode'] is True
    assert len(manifest['candidates'])==1 and manifest['invalidCandidates']==[] and manifest['profile'] is None
    candidate=manifest['candidates'][0]
    assert candidate['sourceIdentity']==sanitation.SOURCE and candidate['sourceFileCount']==1354
    assert candidate['baselinePatchVerification']==candidate['sourceDelta']['reconstruction']==candidate['sourceDelta']['patchRoundTrip']=='PASS'
    assert candidate['overlayDeclaredBytesMatch']==candidate['overlayArchive']['extractedBytesMatchSource']=='PASS'
    assert candidate['snapshotMismatchClassification']=='EXPECTED_BASELINE_PATCH' and candidate['declaredSnapshotMismatchCount']==4
    assert cleanup['status']=='PASS' and cleanup['identitiesChecked']==10 and cleanup['noTerminationPerformed'] is True
    inputs={}
    payloads={}
    for path in sorted(SOURCE.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            rel=path.relative_to(SOURCE).as_posix()
            raw=path.read_bytes();scan(rel,raw)
            inputs[str(path)]=sha(raw);payloads['archive/'+rel]=raw
    assert len(payloads)==9,'unexpected compact archive file inventory'
    for name,path in [('archive-stage-result.json',TASK/'archive-stage-result.json'),
                      ('archive-stage.log',TASK/'archive-stage.log'),
                      ('terminal-process-review.json',TASK/'menu-archive-terminal-independent-process-review.json'),
                      ('wrapper.ps1',WORK/'run_epoch15_archive.ps1'),
                      ('packager.py',Path(__file__))]:
        raw=path.read_bytes();inputs[str(path)]=sha(raw)
        portable=sanitation.scrub_text(sanitation.decode(raw,name),REPO,TASK,WORK).encode('utf-8')
        scan(name,portable);payloads['proof/'+name]=portable
    snapshot=json.loads((TASK/'isolated/source-snapshot.json').read_bytes())
    assert len(snapshot['files'])==1354 and snapshot['sourceIdentity']==sanitation.SOURCE
    for row in snapshot['files']:
        raw=(REPO/row['path']).read_bytes()
        assert len(raw)==row['size'] and sha(raw)==row['sha256'],row['path']
    records=[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(payloads.items())]
    memory=io.BytesIO()
    with tarfile.open(fileobj=memory,mode='w:gz') as archive:
        for name,raw in sorted(payloads.items()):
            info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644
            archive.addfile(info,io.BytesIO(raw))
    archive_raw=memory.getvalue()
    with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as archive:
        actual={m.name:sha(archive.extractfile(m).read()) for m in archive}
        assert actual=={row['path']:row['sha256'] for row in records}
    for path,digest in inputs.items():
        assert sha(Path(path).read_bytes())==digest,path
    receipt={'schema':1,'status':'SOURCE_ARCHIVE_ONLY_PASS','acceptanceStatus':'NOT_ASSESSED',
        'createdUtc':datetime.now(timezone.utc).isoformat(),'baseHead':sanitation.HEAD,'sourceIdentity':sanitation.SOURCE,
        'operationSeconds':stage['elapsedSeconds'],'cleanupElapsedSeconds':'NOT_RECORDED_SEPARATELY',
        'archiveFile':'epoch15-final-source-archive.tar.gz','archiveSha256':sha(archive_raw),'archiveBytes':len(archive_raw),
        'sourceArchiveFiles':9,'packetMembers':len(records),'expandedPrivacyChecks':checks,
        'sourceInputsRechecked':1354,'rawInputHashesRechecked':len(inputs),'portableMemberComparison':'PASS',
        'privacyAudit':'PASS','recordedProcessReview':'PASS','candidateCount':1,'members':records}
    DEST.mkdir(exist_ok=False)
    with (DEST/receipt['archiveFile']).open('xb') as stream:stream.write(archive_raw)
    (DEST/'source-archive-transport.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    (DEST/'README.md').write_text('# Q30 final source archive\n\nFresh maintained compact archive PASS for source '+sanitation.SOURCE+
        '. Source integrity only; acceptance NOT ASSESSED. Q30 remains disabled.\n\n'+
        'One isolated candidate; 1,354 source inputs, baseline restoration, source delta roundtrip and overlay extraction checked. '+
        'Nine archive files plus five sanitized proof files are byte-bound in source-archive-transport.json. '+
        'Operation 77.337 seconds; cleanup elapsed not recorded separately; exact wrapper instance absent. '+
        'Scratch q30-source-archive-217be45978364c74ac25349cf44ba8b7 retained. No profiles, publishing or qualification claim.\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in receipt.items() if k!='members'},indent=2))

if __name__=='__main__':main()
