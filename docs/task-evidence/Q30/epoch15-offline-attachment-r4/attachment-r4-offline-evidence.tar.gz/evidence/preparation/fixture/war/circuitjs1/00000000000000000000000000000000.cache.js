(() => {
  const mode = new URLSearchParams(location.search).get("attachmentCanary");
  if (mode === "attached" || mode === "duplicate" || mode === "iframe") {
    const target = mode === "iframe" ? parent.document : document;
    target.documentElement.setAttribute("data-tsj-attachment-canary", "PASS:" + mode);
    return;
  }
  if (mode === "detached") {
    window.addEventListener("load", () => setTimeout(() => {
      if (document.readyState !== "complete") throw new Error("replacement before parsing completed");
      document.open();
      document.write('<!doctype html><html data-tsj-attachment-canary="PASS:detached"><head><title>same-url replacement</title></head><body>replacement</body></html>');
      document.close();
    }, 0), {once: true});
    return;
  }
  throw new Error("unexpected compiled fixture mode");
})();
