"""Freeze isolated r2 drafts and read-only evidence/runtime inputs; no browser."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import time

HERE = Path(__file__).resolve().parent
REPO = Path(r'${REPO}')
OLD = HERE.parent / 'attachment-offline-resume'
TEMP = Path(tempfile.gettempdir())
SOURCES = ('compiled_attribute_acceptance.py', 'run_attachment_scope_canaries.py', 'offline_attachment_checks.py')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
def main():
    root = Path(tempfile.mkdtemp(prefix='q30-offline-r2-ready-'))
    start = time.monotonic()
    result = {'schema': 1, 'status': 'FAIL', 'scope': 'READ_ONLY_OFFLINE_NO_EDGE_Q30_BUILD',
              'startedUtc': datetime.now(timezone.utc).isoformat()}
    try:
        pins = {name: sha(HERE / name) for name in SOURCES}
        for name in SOURCES:
            ast.parse((HERE / name).read_text(encoding='utf-8'), filename=name)
        snapshot = json.loads((TEMP / 'q30-process-pinned-final-qualification-fcffecff8fa444889bce93725495c628/source-snapshot-maintained.json').read_text(encoding='utf-8-sig'))
        assert snapshot['sourceIdentity'] == 'a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51'
        assert len(snapshot['files']) == 1354
        mismatches = [row['path'] for row in snapshot['files']
                      if (REPO / row['path']).stat().st_size != row['size'] or sha(REPO / row['path']) != row['sha256']]
        assert not mismatches, mismatches
        spec = importlib.util.spec_from_file_location('r2_ready_canary', HERE / SOURCES[1])
        canary = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(canary)
        packet = REPO / 'docs/task-evidence/Q30/epoch15-process-final-compiled31/compiled31-process-final-evidence.tar.gz'
        manifest = packet.parent / 'manifest.json'
        prior = TEMP / 'q30-final-qualification-be815db03e7d4421b061ebc228a984fd/compiled31/result.json'
        historical_final = canary.validate_final_packet(packet, manifest)
        historical_failure = canary.validate_prior_failed_receipts(prior)
        host, host_hash, module, runtime = canary.load_host(HERE / SOURCES[0], pins[SOURCES[0]])
        assert module.async_playwright is not None
        failed_inputs = {
            'oldGuard': (OLD / SOURCES[0], '5ff81d18a7a9beab10ef161166ede4a4cfa58bab1074c4a53a41270486eb4460'),
            'oldCanary': (OLD / SOURCES[1], 'a65458a353cd78db435200e48619016f834ec96c7a9a9f9c0c49840da5ee980f'),
        }
        preserved = {}
        for name, (path, expected) in failed_inputs.items():
            assert sha(path) == expected
            preserved[name] = {'path': str(path), 'sha256': expected}
        failed_raw = TEMP / 'q30-attachment-scope-canary-psbjt3qf/host-output/result.json'
        outer = TEMP / 'q30-attachment-edge-window-dk30axka/launcher-result.json'
        failed = json.loads(failed_raw.read_text())
        outer_receipt = json.loads(outer.read_text())
        assert failed['outcome'] == 'FAIL' and failed['cleanup']['status'] == 'PASS'
        assert outer_receipt['status'] == 'FAIL' and outer_receipt['operation']['exitCode'] == 1
        assert outer_receipt['operation']['cleanup']['cleanupVerified'] is True
        for name, path in [('failedEdgeRaw', failed_raw), ('failedEdgeOuter', outer)]:
            preserved[name] = {'path': str(path), 'sha256': sha(path)}
        assert sha(failed_raw) == sha(OLD / 'edge-window-host-result.json')
        python = Path(r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe')
        argv = [str(python), '-B', '-u', str(HERE / SOURCES[1]), '--host-path', str(host),
                '--expected-host-sha256', host_hash, '--final-packet', str(packet),
                '--final-manifest', str(manifest), '--prior-failed-result', str(prior)]
        runner = REPO / 'docs/task-evidence/Q30/qualification-workflow/serial_runner.py'
        runner_hash = '19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6'
        assert sha(runner) == runner_hash
        plan = {'schema': 1, 'status': 'READY_OFFLINE_ACTUAL_EDGE_NOT_RUN_NEW_PARENT_WINDOW_REQUIRED',
                'windowSeconds': 240, 'jobCount': 1, 'outerTimeoutMs': 120000, 'cleanupBudgetMs': 15000,
                'reserveSeconds': 105, 'cases': list(canary.CASE_NAMES), 'argv': argv,
                'runnerPath': str(runner), 'runnerSha256': runner_hash,
                'launcherPath': str(HERE.parent / 'launch_owned_review_check.py'),
                'launcherSha256': sha(HERE.parent / 'launch_owned_review_check.py'),
                'requiredEnvironment': {'PYTHONPATH': str(TEMP / 'q30-finish-0fa2512465/deps'),
                                        'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONIOENCODING': 'utf-8'},
                'sourcePins': pins, 'frozenSourceIdentity': snapshot['sourceIdentity'],
                'priorFailedInputs': preserved, 'runtime': runtime,
                'expected': 'ATTACHED_PASS_FOUR_SPECIFIC_NEGATIVES_AND_HOST_OUTER_CLEANUP_PASS',
                'qualification': False, 'timingAcceptance': False, 'browserVisibleQa': False,
                'coordinateBeforeRun': True, 'autoRun': False, 'windowGranted': False}
        app, output, fixture_spec = canary.write_fixture(root)
        fixture = json.loads(fixture_spec.read_text())
        assert len(fixture['cases']) == 5 and not output.exists()
        assert all(c['timeoutSeconds'] == 20 for c in fixture['cases'])
        write(root / 'quiet-window-plan.json', plan)
        result.update(status='PASS', sourcePins=pins, sourcesUnchanged=all(sha(HERE / n) == v for n, v in pins.items()),
                      frozenInputsVerified=1354, frozenSourceIdentity=snapshot['sourceIdentity'],
                      runtime=runtime, historicalFinalPacket=historical_final, historicalFailure=historical_failure,
                      preservedFailedEdgeInputs=preserved, plan=str(root / 'quiet-window-plan.json'))
        assert result['sourcesUnchanged']
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    result.update(operationSeconds=time.monotonic() - start, finishedUtc=datetime.now(timezone.utc).isoformat())
    write(root / 'result.json', result)
    write(HERE / 'preparation-pointer.json', {'root': str(root), 'status': result['status']})
    if result['status'] == 'PASS':
        write(HERE / 'quiet-window-plan.json', plan)
    print(json.dumps({'taskRoot': str(root), 'status': result['status'], 'operationSeconds': result['operationSeconds'],
                      'error': result.get('error')}, indent=2))
    return 0 if result['status'] == 'PASS' else 1
if __name__ == '__main__':
    raise SystemExit(main())
