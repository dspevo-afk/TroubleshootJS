"""Bounded real-Edge canaries for compiled-script attachment scope.

This helper runs a tiny local HTML fixture through the selected compiled
attribute host. It proves a valid attachment still passes and that missing or
detached script attachments fail for the intended terminal-scope reason. It
also checks, without rewriting, the retained 31-case compiled receipt set.
All new files stay in one unique OS-temp directory and are retained.

Run with the pinned CPython 3.13 / Playwright 1.63 environment::

    python -B run_attachment_scope_canaries.py --host-path HOST.py \
        --expected-host-sha256 SHA256 --final-packet PACKET.tar.gz \
        --final-manifest MANIFEST.json --prior-failed-result RESULT.json

The host must be the reviewed workspace draft. The final packet and manifest
must be the source-bound compiled31 evidence; the raw prior failure remains a
separate input so it is preserved and reported as a failure.
"""

import argparse
import asyncio
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import sys
import tempfile
import tarfile
import traceback
from pathlib import PurePosixPath
from urllib.parse import urlsplit


EXPECTED_RETAINED_HOST_SHA256 = (
    "ab84751f0ba0ad7c46cc53e34dc2f69a397bd1186f55d266fe4c44e22e6e6456"
)
EXPECTED_RETAINED_RESULT_SHA256 = (
    "6645b63c5214a7e46bb4491702d27e0edf2bbeb94435c7b02e545fdd2427fcd7"
)
EXPECTED_FINAL_PACKET_SHA256 = (
    "aed802688029259b6adf21dbe86dae46deb90409959056fd71b5dabab4a43cfe"
)
EXPECTED_FINAL_SOURCE_IDENTITY = (
    "a43f8165921f08c309636d2bf1a971905fdbc9382885c0708788d79744e1fb51"
)
EXPECTED_FINAL_BASE_HEAD = "d37c3b3b8581abdeaa9b88b7bfb2349cff958d31"
EXPECTED_FINAL_RUNNER_SHA256 = (
    "fb6c78570101c19c8b477da48884ff00d7563eb35c2e5f52033c9be63e74d839"
)
EXPECTED_COMPILED31_SPEC_SHA256 = (
    "898145a040b8920350461961dbad85b94f2d7ef286e95a0ebd347781d291bc97"
)
RETAINED_CASE_COUNT = 31
CASE_NAMES = ("attached-positive", "missing-script-negative", "detached-script-negative",
              "iframe-script-negative", "duplicate-script-negative")
SCRIPT_ID = "00000000000000000000000000000000"
SCRIPT_NAME = SCRIPT_ID + ".cache.js"
STATE_ATTRIBUTE = "data-tsj-attachment-canary"
HOST_TIMEOUT_SECONDS = 20.0


def sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_prior_failed_receipts(result_path):
    result_path = result_path.resolve(strict=True)
    raw_hash = sha256_file(result_path)
    require(raw_hash == EXPECTED_RETAINED_RESULT_SHA256,
            "retained compiled31 result SHA-256 differs from the reviewed receipt")
    result = read_json(result_path)
    require(result.get("caseCount") == RETAINED_CASE_COUNT and
            isinstance(result.get("cases"), list) and
            len(result["cases"]) == RETAINED_CASE_COUNT,
            "retained compiled31 result does not contain exactly 31 cases")
    require(result.get("outcome") == "FAIL_CLEANUP" and
            (result.get("cleanup") or {}).get("status") == "FAIL",
            "retained compiled31 cleanup limitation changed; do not relabel it")
    require(result.get("inputAudit", {}).get("status") == "PASS",
            "retained compiled31 input audit is not PASS")
    require(not result.get("errors"), "retained compiled31 result has host errors")

    before_path = result_path.parent / "runner-before.json"
    after_path = result_path.parent / "runner-after.json"
    before, after = read_json(before_path), read_json(after_path)
    require(before.get("sha256") == EXPECTED_RETAINED_HOST_SHA256 and
            after.get("sha256") == EXPECTED_RETAINED_HOST_SHA256 and
            before == after,
            "retained compiled31 runner identity is not the reviewed unchanged host")
    case_proofs = validate_attachment_rows(result, "retained prior failed compiled31 receipt")

    return {
        "resultSha256": raw_hash,
        "runnerSha256": EXPECTED_RETAINED_HOST_SHA256,
        "caseCount": RETAINED_CASE_COUNT,
        "matchingAttachments": len(case_proofs),
        "overallOutcome": result["outcome"],
        "cleanupStatus": result["cleanup"]["status"],
        "caseProofs": case_proofs,
    }


def validate_attachment_rows(result, label):
    require(result.get("caseCount") == RETAINED_CASE_COUNT and
            isinstance(result.get("cases"), list) and
            len(result["cases"]) == RETAINED_CASE_COUNT,
            label + " does not contain exactly 31 cases")
    indices = []
    proofs = []
    for row in result["cases"]:
        case = row.get("case") or {}
        indices.append(case.get("index"))
        observation = row.get("observation") or {}
        attachment = observation.get("scriptAttachment") or {}
        scope = observation.get("scopeIdentity") or {}
        valid = (
            row.get("outcome") == "PASS" and
            row.get("terminalReached") is True and row.get("stateMatch") is True and
            row.get("timedOut") is False and
            not row.get("observerErrors") and not row.get("attributeReadErrors") and
            observation.get("transport") == "PASSIVE_CDP_DOM" and
            observation.get("compiledScriptsHeld") == 1 and
            observation.get("terminalScopeVerified") is True and
            attachment.get("resourceType") == "script" and
            attachment.get("exactPageUrl") is True and
            type(attachment.get("documentBackend")) is int and
            type(attachment.get("htmlBackend")) is int and
            attachment.get("documentBackend") == scope.get("documentBackendAfter") and
            attachment.get("htmlBackend") == scope.get("htmlBackendAfter") and
            scope.get("pageUrlMatches") is True and scope.get("documentUrlMatches") is True and
            scope.get("stateMatches") is True and scope.get("attributeMatches") is True
        )
        require(valid, label + " has a case without an exact terminal script attachment: " +
                str(case.get("name")))
        proofs.append({"index": case.get("index"), "name": case.get("name"),
                       "outcome": row.get("outcome"), "compiledScriptRequests": 1,
                       "attachmentMatchesTerminalBackends": True})
    require(indices == list(range(1, RETAINED_CASE_COUNT + 1)),
            label + " case order is incomplete or changed")
    return proofs


def validate_final_packet(packet_path, manifest_path):
    packet_path = packet_path.resolve(strict=True)
    manifest_path = manifest_path.resolve(strict=True)
    require(packet_path.is_file() and not packet_path.is_symlink() and
            manifest_path.is_file() and not manifest_path.is_symlink(),
            "final compiled31 packet and manifest must be regular files")
    packet_hash = sha256_file(packet_path)
    require(packet_hash == EXPECTED_FINAL_PACKET_SHA256,
            "final compiled31 packet SHA-256 differs from the reviewed packet")
    manifest = read_json(manifest_path)
    require(manifest.get("archiveName") == packet_path.name and
            manifest.get("archiveSha256") == packet_hash and
            manifest.get("archiveBytes") == packet_path.stat().st_size and
            manifest.get("sourceIdentity") == EXPECTED_FINAL_SOURCE_IDENTITY and
            manifest.get("baseHead") == EXPECTED_FINAL_BASE_HEAD and
            manifest.get("layoutEpoch") == 15 and
            manifest.get("normalPlayerQ30Enabled") is False and
            manifest.get("packetStatus") == "COMPILED31_EVIDENCE_ONLY" and
            manifest.get("overallOutcome") == "PASS" and
            manifest.get("auditStatus") == "PASS" and
            manifest.get("sourceBindingExitCode") == 0 and
            manifest.get("caseCount") == RETAINED_CASE_COUNT and
            manifest.get("caseOutcomes") == {"PASS": RETAINED_CASE_COUNT} and
            manifest.get("cleanupStatus") == "PASS" and
            manifest.get("compiled31RunnerSha256") == EXPECTED_FINAL_RUNNER_SHA256 and
            manifest.get("compiled31SpecSha256") == EXPECTED_COMPILED31_SPEC_SHA256 and
            manifest.get("limits") == {"jobMillis": 90000, "sharedWork": 640,
                                       "activeOperationMillis": 5000},
            "final compiled31 manifest does not match the pinned PASS packet")

    rows = manifest.get("files")
    require(isinstance(rows, list) and len(rows) > 0,
            "final compiled31 manifest has no member inventory")
    by_name = {}
    portable_hashes = {}
    with tarfile.open(packet_path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            require(member.name not in by_name,
                    "final compiled31 packet contains duplicate member names")
            by_name[member.name] = member
        require(len(by_name) == len(rows),
                "final compiled31 packet member count differs from its manifest")
        for row in rows:
            member_name = row.get("member")
            relative = PurePosixPath(member_name) if isinstance(member_name, str) else None
            require(relative is not None and not relative.is_absolute() and
                    ".." not in relative.parts and "\\" not in member_name and
                    member_name and member_name not in portable_hashes,
                    "final compiled31 manifest contains an unsafe or duplicate path")
            archive_name = "evidence/" + member_name
            member = by_name.get(archive_name)
            require(member is not None and member.isfile() and not member.issym() and
                    not member.islnk() and member.size == row.get("portableBytes"),
                    "final compiled31 packet member is missing or has an invalid type/size")
            stream = archive.extractfile(member)
            require(stream is not None, "final compiled31 packet member cannot be read")
            data = stream.read()
            member_hash = sha256_bytes(data)
            require(member_hash == row.get("portableSha256") == row.get("memberSha256"),
                    "final compiled31 packet member hash differs from its manifest")
            portable_hashes[member_name] = member_hash
            if member_name in {
                    "compiled31/result.json", "compiled31/runner-before.json",
                    "compiled31/runner-after.json", "task/compiled31-audit.json",
                    "task/compiled31-stage-result.json", "task/source-input-audit.json",
                    "task/source-snapshot-maintained.json"}:
                portable_hashes[member_name + ":data"] = data

    def member_json(name):
        data = portable_hashes.get(name + ":data")
        require(isinstance(data, bytes), "final packet lacks required receipt " + name)
        return json.loads(data.decode("utf-8-sig"))

    result = member_json("compiled31/result.json")
    runner_before = member_json("compiled31/runner-before.json")
    runner_after = member_json("compiled31/runner-after.json")
    audit = member_json("task/compiled31-audit.json")
    stage = member_json("task/compiled31-stage-result.json")
    input_audit = member_json("task/source-input-audit.json")
    snapshot = member_json("task/source-snapshot-maintained.json")
    require(result.get("outcome") == "PASS" and result.get("errors") == [] and
            result.get("inputAudit", {}).get("status") == "PASS" and
            (result.get("cleanup") or {}).get("status") == "PASS" and
            (result.get("cleanup") or {}).get("serverStopped") is True and
            (result.get("cleanup") or {}).get("ownedSurvivors") == [] and
            runner_before == runner_after and
            runner_before.get("sha256") == EXPECTED_FINAL_RUNNER_SHA256,
            "final compiled31 aggregate/runner/cleanup receipts are not PASS")
    require(audit.get("status") == "PASS" and audit.get("errors") == [] and
            audit.get("specSha256") == EXPECTED_COMPILED31_SPEC_SHA256 and
            (audit.get("summary") or {}).get("expectedCases") == RETAINED_CASE_COUNT and
            (audit.get("summary") or {}).get("observedCases") == RETAINED_CASE_COUNT,
            "final compiled31 strict audit is not PASS for all 31 cases")
    require(stage.get("stage") == "compiled31" and
            stage.get("sourceIdentity") == EXPECTED_FINAL_SOURCE_IDENTITY and
            stage.get("candidateBaseHead") == EXPECTED_FINAL_BASE_HEAD and
            stage.get("head") == EXPECTED_FINAL_BASE_HEAD and
            stage.get("status") == "COMMAND_PASS_PENDING_RECEIPT_REVIEW" and
            stage.get("exitCode") == 0 and stage.get("rawInputsVerified") == 1354 and
            stage.get("consumedInputsUnchanged") is True and
            stage.get("q30NormalPlayerEnabled") is False and
            stage.get("specSha256") == EXPECTED_COMPILED31_SPEC_SHA256 and
            stage.get("runnerSha256") == EXPECTED_FINAL_RUNNER_SHA256 and
            stage.get("hostOutcome") == "PASS" and
            stage.get("shippingBuildStatus") == "PASS" and
            stage.get("shippingBuildCompilationConfirmed") is True and
            stage.get("shippingBuildConsumedInputsVerified") == 1354 and
            stage.get("shippingBuildConsumedSourceIdentity") == EXPECTED_FINAL_SOURCE_IDENTITY,
            "final compiled31 source/build binding does not match the pinned run")
    before_inputs, after_inputs = stage.get("compiledInputsBefore"), stage.get("compiledInputsAfter")
    require(isinstance(before_inputs, list) and before_inputs and before_inputs == after_inputs,
            "final compiled31 before/after GWT input inventories differ or are empty")
    seen_paths = set()
    cache_count = 0
    for item in before_inputs:
        path = item.get("path")
        relative = PurePosixPath(path) if isinstance(path, str) else None
        require(relative is not None and not relative.is_absolute() and ".." not in relative.parts and
                "\\" not in path and path.startswith("war/circuitjs1/") and
                path not in seen_paths and type(item.get("size")) is int and item["size"] > 0 and
                re.fullmatch(r"[0-9a-f]{64}", item.get("sha256", "")) is not None,
                "final compiled31 GWT inventory contains an invalid input identity")
        seen_paths.add(path)
        cache_count += path.lower().endswith(".cache.js")
    require(cache_count == 5,
            "final compiled31 source binding does not list exactly five GWT cache scripts")
    require(input_audit.get("status") == "PASS" and
            input_audit.get("sourceIdentity") == EXPECTED_FINAL_SOURCE_IDENTITY and
            input_audit.get("baseHead") == EXPECTED_FINAL_BASE_HEAD and
            input_audit.get("inputsVerified") == 1354 and
            input_audit.get("q30NormalPlayerEnabled") is False and
            snapshot.get("sourceIdentity") == EXPECTED_FINAL_SOURCE_IDENTITY and
            snapshot.get("baseHead") == EXPECTED_FINAL_BASE_HEAD,
            "final compiled31 source snapshot/audit does not match its source identity")
    case_proofs = validate_attachment_rows(result, "final compiled31 receipt")
    return {
        "packetSha256": packet_hash,
        "manifestSha256": sha256_file(manifest_path),
        "portableResultSha256": portable_hashes["compiled31/result.json"],
        "sourceIdentity": EXPECTED_FINAL_SOURCE_IDENTITY,
        "baseHead": EXPECTED_FINAL_BASE_HEAD,
        "runnerSha256": EXPECTED_FINAL_RUNNER_SHA256,
        "strictAudit": audit["status"],
        "sourceBinding": stage["status"],
        "inputCount": stage["rawInputsVerified"],
        "gwtInventoryCount": len(before_inputs),
        "gwtCacheCount": cache_count,
        "caseCount": len(case_proofs),
        "matchingAttachments": len(case_proofs),
        "cleanupStatus": result["cleanup"]["status"],
        "caseProofs": case_proofs,
    }


def load_host(host_path, expected_sha256):
    host_path = host_path.resolve(strict=True)
    require(host_path.is_file() and not host_path.is_symlink(),
            "host path must be a regular non-symlink file")
    actual = sha256_file(host_path)
    require(re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is not None and
            actual == expected_sha256,
            "selected host SHA-256 does not match the reviewed expected value")
    require(platform.python_implementation() == "CPython" and sys.version_info[:2] == (3, 13),
            "canary requires CPython 3.13")
    playwright_version = importlib.metadata.version("playwright")
    greenlet_version = importlib.metadata.version("greenlet")
    require(playwright_version == "1.63.0", "Playwright must be 1.63.0")
    require(greenlet_version == "3.5.6", "greenlet must be 3.5.6")
    spec = importlib.util.spec_from_file_location("q30_attachment_scope_host", host_path)
    require(spec is not None and spec.loader is not None, "unable to load selected host")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return host_path, actual, module, {
        "pythonImplementation": platform.python_implementation(),
        "pythonVersion": platform.python_version(),
        "playwrightVersion": playwright_version,
        "greenletVersion": greenlet_version,
    }


def exclusive_json(path, value):
    payload = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(payload)


def write_fixture(task_root):
    app = task_root / "fixture"
    src = app / "src"
    war = app / "war"
    module_dir = war / "circuitjs1"
    output = task_root / "host-output"
    spec_path = task_root / "canary-spec.json"
    src.mkdir(parents=True)
    module_dir.mkdir(parents=True)

    html = """<!doctype html>
<html><head><meta charset=\"utf-8\"><title>attachment scope fixture</title>
<script>
(() => {
  const mode = new URLSearchParams(location.search).get("attachmentCanary");
  if (mode === "missing") {
    document.documentElement.setAttribute("%s", "FAIL:missing");
    return;
  }
  if (mode === "iframe") {
    document.write('<iframe src="/frame.html?attachmentCanary=iframe"></iframe>');
    return;
  }
  if (mode !== "attached" && mode !== "detached" && mode !== "duplicate") {
    throw new Error("unexpected fixture mode");
  }
  document.write('<scr' + 'ipt src="/circuitjs1/%s.cache.js?mode=' +
    encodeURIComponent(mode) + '"></scr' + 'ipt>');
  if (mode === "duplicate") {
    document.write('<scr' + 'ipt src="/circuitjs1/%s.cache.js?mode=duplicate&request=2"></scr' + 'ipt>');
  }
})();
</script></head><body>local fixture</body></html>
""" % (STATE_ATTRIBUTE, SCRIPT_ID, SCRIPT_ID)
    js = """(() => {
  const mode = new URLSearchParams(location.search).get("attachmentCanary");
  if (mode === "attached" || mode === "duplicate" || mode === "iframe") {
    const target = mode === "iframe" ? parent.document : document;
    target.documentElement.setAttribute("%s", "PASS:" + mode);
    return;
  }
  if (mode === "detached") {
    window.addEventListener("load", () => setTimeout(() => {
      if (document.readyState !== "complete") throw new Error("replacement before parsing completed");
      document.open();
      document.write('<!doctype html><html %s="PASS:detached"><head><title>same-url replacement</title></head><body>replacement</body></html>');
      document.close();
    }, 0), {once: true});
    return;
  }
  throw new Error("unexpected compiled fixture mode");
})();
""" % (STATE_ATTRIBUTE, STATE_ATTRIBUTE)
    (war / "circuitjs.html").write_text(html, encoding="utf-8", newline="\n")
    (module_dir / SCRIPT_NAME).write_text(js, encoding="utf-8", newline="\n")
    frame = """<!doctype html><html><head><script>
parent.document.documentElement.setAttribute("%s", "PASS:iframe");
document.write('<scr' + 'ipt src="/circuitjs1/%s.cache.js?mode=iframe"></scr' + 'ipt>');
</script></head><body>same-origin child</body></html>
""" % (STATE_ATTRIBUTE, SCRIPT_ID)
    (war / "frame.html").write_text(frame, encoding="utf-8", newline="\n")
    cases = []
    for name, mode, expected in (
            (CASE_NAMES[0], "attached", "PASS:attached"),
            (CASE_NAMES[1], "missing", "FAIL:missing"),
            (CASE_NAMES[2], "detached", "PASS:detached"),
            (CASE_NAMES[3], "iframe", "PASS:iframe"),
            (CASE_NAMES[4], "duplicate", "PASS:duplicate")):
        cases.append({"name": name, "path": "circuitjs.html?attachmentCanary=" + mode,
                      "stateAttribute": STATE_ATTRIBUTE, "expectedState": expected,
                      "timeoutSeconds": HOST_TIMEOUT_SECONDS})
    exclusive_json(spec_path, {"cases": cases})
    return app, output, spec_path


def no_case_errors(row):
    return all(not row.get(key) for key in (
        "pageErrors", "httpErrors", "consoleErrors", "attributeReadErrors",
        "listenerCleanupErrors", "navigationError"))


def terminal_scope_error(row):
    errors = row.get("observerErrors", [])
    return (len(errors) == 1 and
            errors[0].get("phase") == "terminal-document-scope" and
            "compiled-script HTML attachment" in errors[0].get("message", ""))


def expected_aborted_script_errors(row, mode):
    """Retain the controlled route-abort diagnostic; reject unrelated errors."""
    if any(row.get(key) for key in (
            "pageErrors", "httpErrors", "attributeReadErrors", "listenerCleanupErrors", "navigationError")):
        return False
    origin = urlsplit(row.get("url", ""))
    suffix = "?mode=iframe" if mode == "iframe" else "?mode=duplicate&request=2"
    script_url = origin.scheme + "://" + origin.netloc + "/circuitjs1/" + SCRIPT_NAME + suffix
    errors = row.get("consoleErrors") or []
    return len(errors) <= 1 and all(
        error.get("text") in ("Failed to load resource: net::ERR_FAILED",
                              "Failed to load resource: net::ERR_ABORTED") and
        (error.get("location") or {}).get("url") == script_url for error in errors)


def validate_case_files(output, rows):
    for row in rows:
        case = row.get("case") or {}
        path = output / "cases" / ("%03d-%s.json" % (case.get("index"),
            re.sub(r"[^A-Za-z0-9._-]+", "-", case.get("name", "")).strip("-._")[:80] or "case"))
        require(path.is_file() and read_json(path) == row,
                "host per-case receipt is missing or differs from result.json: " +
                str(case.get("name")))


def validate_canary_output(output, host_return_code):
    result_path = output / "result.json"
    require(result_path.is_file(), "selected host did not retain result.json")
    result = read_json(result_path)
    rows = result.get("cases")
    require(isinstance(rows, list) and len(rows) == len(CASE_NAMES),
            "selected host did not complete all five canary cases")
    validate_case_files(output, rows)
    require(result.get("caseCount") == len(CASE_NAMES) and result.get("errors") == [] and
            result.get("outcome") == "FAIL" and host_return_code == 1,
            "host did not fail at the four expected negative cases")
    require((result.get("inputAudit") or {}).get("status") == "PASS",
            "canary fixture or selected host changed during execution")
    cleanup = result.get("cleanup") or {}
    require(cleanup.get("status") == "PASS" and cleanup.get("serverStopped") is True and
            cleanup.get("ownedSurvivors") == [] and cleanup.get("errors") == [],
            "selected host cleanup did not PASS")
    operation_seconds = [row.get("operationSeconds") for row in rows]
    require(all(type(value) in (int, float) and value > 0 for value in operation_seconds) and
            type(cleanup.get("seconds")) in (int, float) and cleanup["seconds"] >= 0,
            "host did not retain distinct per-case operation and cleanup elapsed values")
    edge_rows = ((result.get("identity") or {}).get("edgeProcessesBeforeCases") or [])
    require(any("msedge.exe" in str(row.get("ExecutablePath", "")).lower() and
                type(row.get("pid")) is int and row.get("created") for row in edge_rows),
            "host did not record an owned Edge process identity")
    require([((row.get("case") or {}).get("name")) for row in rows] == list(CASE_NAMES),
            "canary cases ran out of order or names changed")
    require(all(row.get("timedOut") is False and
                (row.get("observation") or {}).get("transport") == "PASSIVE_CDP_DOM"
                for row in rows),
            "canary cases must use the selected passive DOM transport without timeouts")
    require(all(row.get("observedPageUrl") == row.get("url") and
                row.get("observedState") == (row.get("case") or {}).get("expectedState")
                for row in rows),
            "canary receipts must retain the actual exact URL and declared terminal state")

    positive, missing, detached, iframe, duplicate = rows
    po = positive.get("observation") or {}
    pa = po.get("scriptAttachment") or {}
    ps = po.get("scopeIdentity") or {}
    require(positive.get("outcome") == "PASS" and positive.get("terminalReached") is True and
            positive.get("stateMatch") is True and no_case_errors(positive) and
            not positive.get("observerErrors") and po.get("compiledScriptsHeld") == 1 and
            po.get("terminalScopeVerified") is True and
            ps.get("scriptAttachmentMatchesTerminalScope") is True and
            pa.get("resourceType") == "script" and pa.get("exactPageUrl") is True and
            pa.get("mainFrameRequest") is True and
            pa.get("pageUrl") == positive.get("url") and ps.get("frameSnapshotStable") is True and
            isinstance(pa.get("frameId"), str) and bool(pa["frameId"]) and
            isinstance(pa.get("loaderId"), str) and bool(pa["loaderId"]) and
            pa.get("frameId") == ps.get("frameBefore") == ps.get("frameAfter") and
            pa.get("loaderId") == ps.get("loaderBefore") == ps.get("loaderAfter") and
            type(pa.get("generation")) is int and
            type(pa.get("documentBackend")) is int and type(pa.get("htmlBackend")) is int and
            pa.get("generation") == ps.get("generationBefore") == ps.get("generationAfter") and
            pa.get("documentBackend") == ps.get("documentBackendAfter") and
            pa.get("htmlBackend") == ps.get("htmlBackendAfter"),
            "valid attached-script positive case did not pass its full scope")

    mo = missing.get("observation") or {}
    ms = mo.get("scopeIdentity") or {}
    require(missing.get("outcome") == "FAIL" and missing.get("terminalReached") is True and
            missing.get("stateMatch") is False and no_case_errors(missing) and
            terminal_scope_error(missing) and mo.get("compiledScriptsHeld") == 0 and
            mo.get("scriptAttachment") is None and
            mo.get("terminalScopeVerified") is False and
            ms.get("scriptAttachmentMatchesTerminalScope") is False and
            ms.get("pageUrlMatches") is True and ms.get("documentUrlMatches") is True and
            ms.get("stateMatches") is True and ms.get("attributeMatches") is True,
            "missing-script negative did not fail specifically on its absent attachment")

    do = detached.get("observation") or {}
    da = do.get("scriptAttachment") or {}
    ds = do.get("scopeIdentity") or {}
    require(detached.get("outcome") == "FAIL" and detached.get("terminalReached") is True and
            detached.get("stateMatch") is False and no_case_errors(detached) and
            terminal_scope_error(detached) and do.get("compiledScriptsHeld") == 1 and
            do.get("terminalScopeVerified") is False and
            ds.get("scriptAttachmentMatchesTerminalScope") is False and
            da.get("resourceType") == "script" and da.get("exactPageUrl") is True and
            type(da.get("documentBackend")) is int and type(da.get("htmlBackend")) is int and
            type(ds.get("documentBackendAfter")) is int and
            type(ds.get("htmlBackendAfter")) is int and
            (da.get("documentBackend") != ds.get("documentBackendAfter") or
             da.get("htmlBackend") != ds.get("htmlBackendAfter")) and
            ds.get("pageUrlMatches") is True and ds.get("documentUrlMatches") is True and
            ds.get("stateMatches") is True and ds.get("attributeMatches") is True,
            "same-URL detached-script negative did not fail specifically on terminal identity")

    for row, mode, count, message in (
            (iframe, "iframe", 1, "not owned by the main frame"),
            (duplicate, "duplicate", 2, "More than one selected compiled module script request")):
        observation = row.get("observation") or {}
        errors = row.get("observerErrors") or []
        require(row.get("outcome") == "FAIL" and row.get("stateMatch") is False and
                observation.get("compiledScriptsHeld") == count and
                observation.get("terminalScopeVerified") is False and
                len(errors) == 1 and errors[0].get("phase") == "compiled-script-attachment" and
                message in errors[0].get("message", "") and expected_aborted_script_errors(row, mode),
                mode + " request did not fail only for its declared attachment guard")
    require((iframe.get("observation") or {}).get("scriptAttachment") is None,
            "iframe request was recorded as the main document's attachment")

    return {
        "hostReturnCode": host_return_code,
        "hostOutcome": result["outcome"],
        "caseCount": len(CASE_NAMES),
        "caseOperationSeconds": [row.get("operationSeconds") for row in rows],
        "cleanupSeconds": cleanup.get("seconds"),
        "runnerStartedUtc": result.get("startedUtc"),
        "runnerOperationStartedUtc": result.get("operationStartedUtc"),
        "runnerFinishedUtc": result.get("finishedUtc"),
        "positiveAttachedScript": "PASS",
        "missingScriptGuard": "PASS_NEGATIVE_PROOF",
        "sameUrlDetachedScriptGuard": "PASS_NEGATIVE_PROOF",
        "iframeOnlyScriptGuard": "PASS_NEGATIVE_PROOF",
        "duplicateScriptGuard": "PASS_NEGATIVE_PROOF",
        "cleanup": cleanup,
        "edgeIdentityCountBeforeCases": len(edge_rows),
        "inputAudit": result["inputAudit"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true",
                        help="validate retained compiled31 evidence without loading Playwright or launching Edge")
    parser.add_argument("--host-path", type=Path)
    parser.add_argument("--expected-host-sha256")
    parser.add_argument("--final-packet", required=True, type=Path)
    parser.add_argument("--final-manifest", required=True, type=Path)
    parser.add_argument("--prior-failed-result", required=True, type=Path)
    args = parser.parse_args()

    final_packet = validate_final_packet(args.final_packet, args.final_manifest)
    prior_failed = validate_prior_failed_receipts(args.prior_failed_result)
    if args.audit_only:
        print(json.dumps({"outcome": "STATIC_AUDIT_PASS",
                          "finalCompiled31": {k: final_packet[k] for k in (
                              "sourceIdentity", "baseHead", "strictAudit", "sourceBinding",
                              "inputCount", "gwtInventoryCount", "gwtCacheCount",
                              "caseCount", "matchingAttachments", "cleanupStatus")},
                          "priorFailedCompiled31": {k: prior_failed[k] for k in (
                              "runnerSha256", "caseCount", "matchingAttachments",
                              "overallOutcome", "cleanupStatus")}},
                         indent=2, sort_keys=True))
        return 0
    require(args.host_path is not None and args.expected_host_sha256 is not None,
            "real Edge mode requires --host-path and --expected-host-sha256")
    host_path, host_sha, host, runtime = load_host(args.host_path, args.expected_host_sha256.lower())
    final_packet_path = args.final_packet.resolve(strict=True)
    final_manifest_path = args.final_manifest.resolve(strict=True)
    prior_failed_path = args.prior_failed_result.resolve(strict=True)
    host_before = sha256_file(host_path)
    final_packet_before = sha256_file(final_packet_path)
    final_manifest_before = sha256_file(final_manifest_path)
    prior_failed_before = sha256_file(prior_failed_path)
    task_root = Path(tempfile.mkdtemp(prefix="q30-attachment-scope-canary-")).resolve()
    app, output, spec_path = write_fixture(task_root)
    report = {"schema": 1, "outcome": "RUNNING", "runtime": runtime,
              "selectedHostSha256": host_sha, "finalCompiled31": final_packet,
              "priorFailedCompiled31": prior_failed,
              "fixture": {"caseNames": list(CASE_NAMES), "timeoutSecondsPerCase": HOST_TIMEOUT_SECONDS},
              "hostOutputRelative": "host-output"}
    host_return_code = None
    try:
        host_return_code = asyncio.run(host.main(
            [str(host_path), str(app), str(output), str(spec_path)]))
        canary = validate_canary_output(output, host_return_code)
        report.update({"outcome": "PASS", "canary": canary})
    except BaseException as error:
        report.update({"outcome": "FAIL", "errorType": type(error).__name__,
                       "error": str(error), "traceback": traceback.format_exc(),
                       "hostReturnCode": host_return_code})
    finally:
        host_after = sha256_file(host_path)
        final_packet_after = sha256_file(final_packet_path)
        final_manifest_after = sha256_file(final_manifest_path)
        prior_failed_after = sha256_file(prior_failed_path)
        report["inputHashesUnchanged"] = {
            "selectedHost": host_before == host_after == host_sha,
            "finalCompiled31Packet": final_packet_before == final_packet_after == final_packet["packetSha256"],
            "finalCompiled31Manifest": final_manifest_before == final_manifest_after == final_packet["manifestSha256"],
            "priorFailedCompiled31Result": prior_failed_before == prior_failed_after == prior_failed["resultSha256"],
        }
        if not all(report["inputHashesUnchanged"].values()) and report["outcome"] == "PASS":
            report["outcome"] = "FAIL_INPUT_MUTATION"
        report["retainedHostOutput"] = output.exists()
        report_path = task_root / "canary-result.json"
        exclusive_json(report_path, report)
        print("TASK_ROOT=" + str(task_root), flush=True)
        print("HOST_OUTPUT=" + str(output), flush=True)
        print("CANARY_RESULT=" + str(report_path), flush=True)
        print("OUTCOME=" + report["outcome"], flush=True)
    return 0 if report["outcome"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
