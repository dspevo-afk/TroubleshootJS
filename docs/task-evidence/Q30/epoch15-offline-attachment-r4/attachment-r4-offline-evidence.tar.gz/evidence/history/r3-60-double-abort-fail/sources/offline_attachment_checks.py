"""Offline guard/receipt checks. Synthetic CDP and receipts are not Edge proof."""
import argparse
import asyncio
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import time
import types
import unittest


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def receipt(canary):
    rows = []
    for index, name in enumerate(canary.CASE_NAMES, 1):
        attached, missing = index == 1, index == 2
        doc, html = (101, 201) if index != 3 else (102, 202)
        attachment = None if missing or index == 4 else {
            'resourceType': 'script', 'exactPageUrl': True,
            'documentBackend': 101, 'htmlBackend': 201, 'generation': 0, 'mainFrameRequest': True,
        }
        mode = ('attached', 'missing', 'detached', 'iframe', 'duplicate')[index - 1]
        state = ('FAIL:' if missing else 'PASS:') + mode
        url = 'http://127.0.0.1:1/circuitjs.html?attachmentCanary=' + mode
        if attachment is not None:
            attachment.update(frameId='frame-A', loaderId='loader-A', pageUrl=url)
        errors = [] if attached else [{
            'phase': 'terminal-document-scope', 'type': 'ValueError',
            'message': 'Terminal state/report lacks its exact compiled-script HTML attachment',
        }]
        if index > 3:
            errors = [{'phase': 'compiled-script-attachment', 'type': 'ValueError',
                       'message': ('Selected compiled module request is not owned by the main frame'
                                   if index == 4 else 'More than one selected compiled module script request')}]
        rows.append({
            'case': {'index': index, 'name': name, 'expectedState': state},
            'url': url, 'observedPageUrl': url, 'observedState': state,
            'outcome': 'PASS' if attached else 'FAIL',
            'terminalReached': index < 4, 'stateMatch': attached, 'timedOut': False,
            'operationSeconds': 0.1,
            'observerErrors': errors,
            'observation': {
                'transport': 'PASSIVE_CDP_DOM',
                'compiledScriptsHeld': 0 if missing else (2 if index == 5 else 1),
                'scriptAttachment': attachment, 'terminalScopeVerified': attached,
                'scopeIdentity': {
                    'generationBefore': 0, 'generationAfter': 0,
                    'frameBefore': 'frame-A', 'frameAfter': 'frame-A',
                    'loaderBefore': 'loader-A', 'loaderAfter': 'loader-A',
                    'frameSnapshotStable': True,
                    'scriptAttachmentMatchesTerminalScope': attached,
                    'documentBackendAfter': doc, 'htmlBackendAfter': html,
                    'pageUrlMatches': True, 'documentUrlMatches': True,
                    'stateMatches': True, 'attributeMatches': True,
                },
            },
        })
    return {
        'caseCount': len(canary.CASE_NAMES), 'cases': rows, 'errors': [], 'outcome': 'FAIL',
        'inputAudit': {'status': 'PASS'},
        'cleanup': {'status': 'PASS', 'serverStopped': True,
                    'ownedSurvivors': [], 'errors': [], 'seconds': 0.01},
        'identity': {'edgeProcessesBeforeCases': [
            {'ExecutablePath': 'synthetic/msedge.exe', 'pid': 123,
             'created': 'synthetic-only-never-launched'},
        ]},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--canary', type=Path, required=True)
    parser.add_argument('--guard', type=Path, required=True)
    args = parser.parse_args()
    canary, guard = load('offline_canary', args.canary), load('offline_guard', args.guard)
    root = Path(tempfile.mkdtemp(prefix='q30-offline-attachment-checks-'))
    output = root / 'synthetic-host-output'
    (output / 'cases').mkdir(parents=True)
    source_before = {str(path): digest(path) for path in (args.canary, args.guard, Path(__file__))}

    def check(value):
        for row in value['cases']:
            item = row['case']
            path = output / 'cases' / ('%03d-%s.json' % (item['index'], item['name']))
            path.write_text(json.dumps(row), encoding='utf-8')
        (output / 'result.json').write_text(json.dumps(value), encoding='utf-8')
        return canary.validate_canary_output(output, 1)

    class ReceiptChecks(unittest.TestCase):
        def test_valid_detached_document_and_html(self):
            check(receipt(canary))

        def test_valid_detached_html_with_preserved_document(self):
            value = receipt(canary)
            value['cases'][2]['observation']['scopeIdentity']['documentBackendAfter'] = 101
            check(value)

        def test_valid_detached_document_with_preserved_html(self):
            value = receipt(canary)
            value['cases'][2]['observation']['scopeIdentity']['htmlBackendAfter'] = 201
            check(value)

        def reject(self, mutate):
            value = receipt(canary)
            mutate(value)
            with self.assertRaises(ValueError):
                check(value)

        def test_reject_unchanged_detached_identity(self):
            def mutate(value):
                value['cases'][2]['observation']['scopeIdentity'].update(
                    documentBackendAfter=101, htmlBackendAfter=201)
            self.reject(mutate)

        def test_reject_detached_loader_navigation_as_replacement(self):
            self.reject(lambda v: v['cases'][2]['observation']['scopeIdentity'].update(loaderAfter='loader-B'))

        def test_reject_detached_successor_frame_as_replacement(self):
            self.reject(lambda v: v['cases'][2]['observation']['scopeIdentity'].update(frameAfter='frame-B'))

        def test_reject_detached_wrong_attachment_url(self):
            self.reject(lambda v: v['cases'][2]['observation']['scriptAttachment'].update(pageUrl='http://127.0.0.1:1/other'))

        def test_reject_detached_missing_main_frame_provenance(self):
            self.reject(lambda v: v['cases'][2]['observation']['scriptAttachment'].pop('mainFrameRequest'))

        def test_reject_positive_missing_attachment(self):
            self.reject(lambda v: v['cases'][0]['observation'].update(scriptAttachment=None))

        def test_reject_positive_duplicate_script(self):
            self.reject(lambda v: v['cases'][0]['observation'].update(compiledScriptsHeld=2))

        def test_reject_positive_wrong_html(self):
            self.reject(lambda v: v['cases'][0]['observation']['scriptAttachment'].update(htmlBackend=999))

        def test_reject_negative_wrong_url(self):
            self.reject(lambda v: v['cases'][2]['observation']['scopeIdentity'].update(pageUrlMatches=False))

        def test_reject_extra_observer_error(self):
            self.reject(lambda v: v['cases'][1]['observerErrors'].append({'phase': 'other'}))

        def test_reject_negative_timeout(self):
            self.reject(lambda v: v['cases'][1].update(timedOut=True))

        def test_reject_positive_timeout(self):
            self.reject(lambda v: v['cases'][0].update(timedOut=True))

        def test_reject_wrong_transport(self):
            self.reject(lambda v: v['cases'][0]['observation'].update(transport='OTHER'))

        def test_reject_cleanup_failure(self):
            self.reject(lambda v: v['cleanup'].update(status='FAIL'))

        def test_reject_mutated_input_audit(self):
            self.reject(lambda v: v['inputAudit'].update(status='FAIL'))

        def test_reject_non_integer_terminal_backend(self):
            self.reject(lambda v: v['cases'][2]['observation']['scopeIdentity'].update(htmlBackendAfter=True))

        def test_reject_unrecorded_edge_identity(self):
            self.reject(lambda v: v['identity'].update(edgeProcessesBeforeCases=[]))

        def test_reject_wrong_negative_state(self):
            self.reject(lambda v: v['cases'][1].update(observedState='FAIL:unrelated'))

        def test_reject_wrong_actual_url(self):
            self.reject(lambda v: v['cases'][3].update(observedPageUrl='http://127.0.0.1:1/other'))

        def test_accept_recorded_targeted_abort_diagnostic(self):
            value = receipt(canary)
            value['cases'][3]['consoleErrors'] = [{
                'text': 'Failed to load resource: net::ERR_FAILED',
                'location': {'url': 'http://127.0.0.1:1/circuitjs1/' + canary.SCRIPT_NAME + '?mode=iframe'},
            }]
            check(value)

        def test_reject_abort_diagnostic_for_unrelated_resource(self):
            self.reject(lambda v: v['cases'][3].update(consoleErrors=[{
                'text': 'Failed to load resource: net::ERR_FAILED',
                'location': {'url': 'http://127.0.0.1:1/unrelated'},
            }]))

        def test_reject_unrelated_console_error(self):
            self.reject(lambda v: v['cases'][3].update(consoleErrors=[{
                'text': 'unexpected exception',
                'location': {'url': 'http://127.0.0.1:1/circuitjs1/' + canary.SCRIPT_NAME + '?mode=iframe'},
            }]))

    url, state = 'http://127.0.0.1:1/circuitjs.html', 'PASS:synthetic'
    def scope(backends=(101, 201), frame='frame-A', loader='loader-A'):
        return {'pageUrl': url, 'frameId': frame, 'loaderId': loader,
                'documentBackend': backends[0], 'htmlBackend': backends[1]}
    def document(backends=(101, 201)):
        return {'nodeId': 111, 'backendNodeId': backends[0], 'documentURL': url,
                'children': [{'nodeId': 211, 'backendNodeId': backends[1], 'nodeName': 'HTML',
                              'attributes': ['data-tsj-synthetic', state]}]}
    class Session:
        def __init__(self, current=None, after=None, hook=None):
            self.current, self.after = current or scope(), after
            self.hook, self.frame_reads, self.methods = hook, 0, []
        async def send(self, method, payload):
            self.methods.append(method)
            if self.hook:
                self.hook(method)
            if method == 'Page.getFrameTree':
                self.frame_reads += 1
                selected = self.after if self.frame_reads == 2 and self.after else self.current
                return {'frameTree': {'frame': {'id': selected['frameId'],
                        'loaderId': selected['loaderId'], 'url': selected['pageUrl']}}}
            if method == 'DOM.getDocument':
                return {'root': document((self.current['documentBackend'], self.current['htmlBackend']))}
            raise AssertionError(method)
    def observer(current=None):
        errors = []
        value = guard.HtmlAttributeObserver(types.SimpleNamespace(url=url), url,
                      'data-tsj-synthetic', time.monotonic() + 2, errors)
        value.document_id, value.html_id = 11, 21
        value.document_scope = current or scope()
        value.document_backend = value.document_scope['documentBackend']
        value.html_backend = value.document_scope['htmlBackend']
        value.state = state
        return value, errors

    class ScopeChecks(unittest.TestCase):
        def attachment(self, **changes):
            value = {**scope(), 'exactPageUrl': True, 'resourceType': 'script',
                     'generation': 0, 'mainFrameRequest': True}
            value.update(changes)
            return value
        def verify(self, script_count=1, attachment=None, current=None,
                   navigation_epoch=0, dom_epoch=0, after=None, refresh=False):
            value, errors = observer(current)
            value.navigation_epoch, value.version = navigation_epoch, dom_epoch
            value.script_requests, value.script_attachment = script_count, attachment
            refreshed = False
            def hook(method):
                nonlocal refreshed
                if refresh and method == 'DOM.getDocument' and not refreshed:
                    refreshed = True
                    value.document_updated({})
            value.session = Session(value.document_scope, after=after, hook=hook)
            terminal_scope = dict(value.document_scope)
            async def run():
                await value.verify_terminal_scope(terminal_scope, 0, state, 0)
                if value.tasks:
                    await asyncio.gather(*value.tasks)
            asyncio.run(run())
            return value, errors
        def test_accept_exact_attachment_with_refreshed_frontend_ids(self):
            value, errors = self.verify(attachment=self.attachment())
            self.assertTrue(value.terminal_verified)
            self.assertEqual(errors, [])
            self.assertEqual(value.scope_identity['htmlNodeBefore'], 21)
            self.assertEqual(value.scope_identity['htmlNodeAfter'], 211)
        def test_accept_dom_epoch_refresh_of_same_semantic_scope(self):
            value, errors = self.verify(attachment=self.attachment(), dom_epoch=9, refresh=True)
            self.assertTrue(value.terminal_verified)
            self.assertEqual(errors, [])
            self.assertEqual(value.scope_identity['domEpochBefore'], 9)
            self.assertEqual(value.scope_identity['domEpochAfter'], 10)
        def reject(self, **args):
            value, errors = self.verify(**args)
            self.assertFalse(value.terminal_verified)
            self.assertEqual([e['phase'] for e in errors], ['terminal-document-scope'])
        def test_reject_absent_script(self):
            self.reject(script_count=0)
        def test_reject_duplicate_script(self):
            self.reject(script_count=2, attachment=self.attachment())
        def test_reject_html_replacement(self):
            self.reject(attachment=self.attachment(), current=scope((101, 202)))
        def test_reject_document_replacement(self):
            self.reject(attachment=self.attachment(), current=scope((102, 201)))
        def test_reject_both_replaced(self):
            self.reject(attachment=self.attachment(), current=scope((102, 202)))
        def test_reject_same_url_new_loader_reusing_backend_ids(self):
            self.reject(attachment=self.attachment(), current=scope(loader='loader-B'))
        def test_reject_successor_frame_reusing_backend_ids(self):
            self.reject(attachment=self.attachment(), current=scope(frame='frame-B'))
        def test_reject_loader_change_during_terminal_query(self):
            self.reject(attachment=self.attachment(), after=scope(loader='loader-B'))
        def test_reject_frame_change_during_terminal_query(self):
            self.reject(attachment=self.attachment(), after=scope(frame='frame-B'))
        def test_reject_wrong_url_attachment(self):
            self.reject(attachment=self.attachment(exactPageUrl=False))
        def test_reject_wrong_resource_type(self):
            self.reject(attachment=self.attachment(resourceType='document'))
        def test_reject_wrong_frame_provenance(self):
            self.reject(attachment=self.attachment(mainFrameRequest=False))
        def test_reject_missing_frame_provenance(self):
            attachment = self.attachment()
            del attachment['mainFrameRequest']
            self.reject(attachment=attachment)
        def test_reject_old_attachment_navigation_epoch(self):
            self.reject(attachment=self.attachment(generation=-1))
        def test_reject_navigation_epoch_reusing_all_scope_ids(self):
            self.reject(attachment=self.attachment(), navigation_epoch=1)

    class AcquisitionChecks(unittest.TestCase):
        def acquire(self, hook=None, after=None, closed=False):
            value, errors = observer()
            value.document_id = value.html_id = value.state = value.document_scope = None
            value.closed = closed
            value.session = Session(after=after, hook=(lambda method: hook(value, method)) if hook else None)
            asyncio.run(value.acquire_document(0))
            self.assertEqual(errors, [])
            return value
        def test_stable_scope_adopts_frontend_ids_and_signals_ready(self):
            value = self.acquire()
            self.assertTrue(value.html_ready.is_set())
            self.assertEqual(value.document_scope, scope())
            self.assertEqual(value.session.methods, ['Page.getFrameTree', 'DOM.getDocument', 'Page.getFrameTree'])
        def assert_unattached(self, value):
            self.assertIsNone(value.document_scope)
            self.assertIsNone(value.html_id)
            self.assertFalse(value.html_ready.is_set())
        def test_stale_epoch_between_first_frame_and_dom_read_does_not_adopt(self):
            self.assert_unattached(self.acquire(hook=lambda v, m: setattr(v, 'version', 1) if m == 'DOM.getDocument' else None))
        def test_stale_epoch_at_second_frame_read_does_not_adopt(self):
            def hook(value, method):
                if method == 'Page.getFrameTree' and value.session.frame_reads == 1:
                    value.version += 1
            self.assert_unattached(self.acquire(hook=hook))
        def test_loader_change_between_reads_does_not_adopt(self):
            self.assert_unattached(self.acquire(after=scope(loader='loader-B')))
        def test_frame_change_between_reads_does_not_adopt(self):
            self.assert_unattached(self.acquire(after=scope(frame='frame-B')))
        def test_navigation_epoch_change_during_query_does_not_adopt(self):
            self.assert_unattached(self.acquire(hook=lambda v, m: setattr(v, 'navigation_epoch', 1) if m == 'DOM.getDocument' else None))
        def test_closed_observer_does_not_adopt(self):
            self.assert_unattached(self.acquire(closed=True))
        def test_missing_loader_does_not_adopt(self):
            self.assert_unattached(self.acquire(after=scope(loader='')))
        def test_child_frame_navigation_leaves_main_scope_untouched(self):
            value, _ = observer()
            value.frame_navigated({'frame': {'id': 'child', 'parentId': 'frame-A'}})
            self.assertEqual(value.version, 0)
            self.assertEqual(value.navigation_epoch, 0)
            self.assertEqual(value.document_scope, scope())
        def test_main_frame_navigation_cancels_old_acquisition_and_reacquires(self):
            value, errors = observer()
            value.session = Session(scope(loader='loader-B'))
            async def run():
                stale = asyncio.create_task(asyncio.sleep(10))
                value.tasks.add(stale)
                value.frame_navigated({'frame': {'id': 'frame-A', 'loaderId': 'loader-B', 'url': url}})
                await asyncio.gather(*value.tasks, return_exceptions=True)
                self.assertTrue(stale.cancelled())
            asyncio.run(run())
            self.assertEqual(errors, [])
            self.assertEqual(value.navigation_epoch, 1)
            self.assertEqual(value.document_scope, scope(loader='loader-B'))
            self.assertTrue(value.html_ready.is_set())

    class FixtureChecks(unittest.TestCase):
        def test_detached_pass_is_only_written_after_load_and_timer(self):
            fixture = root / 'deferred-fixture'
            fixture.mkdir()
            app, _, _ = canary.write_fixture(fixture)
            initial = (app / 'war/circuitjs.html').read_text()
            script = (app / 'war/circuitjs1' / canary.SCRIPT_NAME).read_text()
            self.assertNotIn('PASS:detached', initial)
            self.assertEqual(script.count('PASS:detached'), 1)
            self.assertLess(script.index('window.addEventListener("load"'), script.index('setTimeout'))
            self.assertLess(script.index('document.readyState !== "complete"'), script.index('document.open()'))
            self.assertIn('}, 0), {once: true});', script)

    class RouteChecks(unittest.TestCase):
        def route(self, frame_kind='main', resource_type='script', count=0):
            frame = object()
            page = types.SimpleNamespace(url='http://127.0.0.1:1/circuitjs.html', main_frame=frame)
            errors = []
            observer = guard.HtmlAttributeObserver(page, page.url, 'data-tsj-synthetic',
                                                  time.monotonic() + 2, errors)
            observer.document_backend, observer.html_backend = 101, 201
            observer.document_scope = scope()
            observer.script_requests = count
            observer.html_ready.set()
            class Request:
                @property
                def frame(self):
                    if frame_kind == 'unavailable':
                        raise RuntimeError('synthetic frame unavailable')
                    return frame if frame_kind == 'main' else object()
            request = Request()
            request.resource_type = resource_type
            class Route:
                continued = aborted = False
                async def continue_(self):
                    self.continued = True
                async def abort(self):
                    self.aborted = True
            route = Route()
            route.request = request
            asyncio.run(observer.hold_compiled_script(route))
            self.assertFalse(observer.route_tasks)
            return observer, route, errors

        def test_main_frame_request_continues(self):
            observer, route, errors = self.route()
            self.assertEqual(errors, [])
            self.assertTrue(route.continued)
            self.assertFalse(route.aborted)
            self.assertIs(observer.script_attachment['mainFrameRequest'], True)

        def reject(self, **args):
            observer, route, errors = self.route(**args)
            self.assertFalse(route.continued)
            self.assertTrue(route.aborted)
            self.assertIsNone(observer.script_attachment)
            self.assertEqual([e['phase'] for e in errors], ['compiled-script-attachment'])

        def test_iframe_request_aborts(self):
            self.reject(frame_kind='iframe')

        def test_unavailable_frame_aborts(self):
            self.reject(frame_kind='unavailable')

        def test_duplicate_script_aborts(self):
            self.reject(count=1)

        def test_wrong_resource_aborts(self):
            self.reject(resource_type='other')

    class WaitingRouteChecks(unittest.TestCase):
        def waiting(self, closing=False):
            value, errors = observer()
            value.page.main_frame = object()
            async def unroute(*args):
                await asyncio.sleep(0)
            value.page.unroute = unroute
            class CloseSession(Session):
                def remove_listener(self, *args):
                    pass
                async def detach(self):
                    pass
            value.session = CloseSession(scope(loader='loader-B'))
            class Route:
                continued = False
                abort_count = 0
                request = types.SimpleNamespace(frame=value.page.main_frame, resource_type='script')
                async def continue_(self):
                    self.continued = True
                async def abort(self):
                    self.abort_count += 1
                    await asyncio.sleep(0)
            route = Route()
            async def run():
                task = asyncio.create_task(value.hold_compiled_script(route))
                # Wait for registration inside the real handler, before readiness.
                while task not in value.route_tasks:
                    await asyncio.sleep(0)
                self.assertFalse(value.html_ready.is_set())
                if closing:
                    await value.close()
                else:
                    value.frame_navigated({'frame': {'id': 'frame-A', 'loaderId': 'loader-B', 'url': url}})
                    await asyncio.gather(*value.tasks)
                await asyncio.gather(task, return_exceptions=True)
                self.assertFalse(value.route_tasks)
            asyncio.run(run())
            return value, route, errors
        def test_held_request_cannot_attach_to_successor_navigation(self):
            value, route, errors = self.waiting()
            self.assertFalse(route.continued)
            self.assertEqual(route.abort_count, 1)
            self.assertIsNone(value.script_attachment)
            self.assertEqual(len(errors), 1)
            self.assertEqual(errors[0]['phase'], 'compiled-script-attachment')
            self.assertIn('crossed a main-frame navigation', errors[0]['message'])
        def test_held_route_close_aborts_once_and_releases_owned_work(self):
            value, route, errors = self.waiting(closing=True)
            self.assertTrue(value.closed)
            self.assertFalse(route.continued)
            self.assertEqual(route.abort_count, 1)
            self.assertIsNone(value.script_attachment)
            self.assertEqual(errors, [])

    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (ReceiptChecks, ScopeChecks, AcquisitionChecks, RouteChecks, WaitingRouteChecks, FixtureChecks)])
    started = time.monotonic()
    with (root / 'unittest.log').open('x', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    operation = time.monotonic() - started
    source_after = {str(path): digest(path) for path in (args.canary, args.guard, Path(__file__))}
    report = {'schema': 1, 'status': 'PASS' if result.wasSuccessful() else 'FAIL',
              'scope': 'OFFLINE_SYNTHETIC_ONLY_NO_EDGE_OR_Q30', 'tests': result.testsRun,
              'failures': [test.id() for test, _ in result.failures],
              'errors': [test.id() for test, _ in result.errors], 'skips': len(result.skipped),
              'operationSeconds': operation, 'sourceBefore': source_before,
              'sourcesUnchanged': source_before == source_after,
              'finishedUtc': datetime.now(timezone.utc).isoformat()}
    if not report['sourcesUnchanged']:
        report['status'] = 'FAIL'
    write(root / 'result.json', report)
    print(json.dumps({'taskRoot': str(root), **report}, indent=2))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
