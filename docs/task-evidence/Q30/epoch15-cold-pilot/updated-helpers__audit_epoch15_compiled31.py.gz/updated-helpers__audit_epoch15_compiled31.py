"""Audit a completed, source-bound Q30 compiled-31 run without launching it."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path, PurePosixPath
import sys


EXPECTED_SPEC_SHA256 = "898145a040b8920350461961dbad85b94f2d7ef286e95a0ebd347781d291bc97"
EXPECTED_SOURCE_IDENTITY = "a3bd150019d00870a08896efd893c99aff120ce11a49f34cca0af07f33d59c31"
EXPECTED_BASE_HEAD = "7bdc23e8170e4a9e737b33daf4bb533f87468b22"
EXPECTED_RUNNER = "tests/browser/compiled_attribute_acceptance.py"
EXPECTED_GWT_CACHE_PERMUTATIONS = 5
EXPECTED_REQUEST_MANIFEST = (
    "tsj-q30-normal-d01-qualification-request@1;family=RB30;profile=MEDIUM"
)
EXPECTED_D01_SEEDS = (
    "10387", "10226", "10014", "0", "1", "15", "14", "8", "10", "12",
    "48", "35", "18", "43", "4", "11", "3", "10000", "10009", "10016",
    "10017",
)
EXPECTED_CASE_NAMES = (
    "alpha-full41",
    "alpha-explicit-negative",
    "a07-real-solver-nonfinite-pivot",
    "a07-explicit-negative",
    "a10-positive",
    "a10-explicit-negative",
    "e02-positive",
    "e02-explicit-negative",
    "e04-sensor-control-quickplay",
    "q30-service-seed13",
) + tuple("d01-descriptive21-seed-" + seed for seed in EXPECTED_D01_SEEDS)
EXPECTED_NEGATIVES = {
    "incompleteSession",
    "foreignHypothesis",
    "failedCleanupRetry",
    "sourceContextChange",
    "mismatchedContext",
}
PHYSICAL_REJECTION_REASON = (
    "Normal medium admission requires a selected P07 two-layer route"
)
PHYSICAL_REJECTION_FLAGS = {
    "status": "FAIL",
    "normalAdmission": False,
    "d01Admission": False,
    "playerPublished": False,
    "cleanupComplete": True,
    "cleanupPending": False,
    "ownerRestored": True,
}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path, label, inputs):
    path = Path(path).expanduser().resolve()
    raw = path.read_bytes()
    inputs[label] = {"path": str(path), "size": len(raw), "sha256": sha256(raw)}
    return json.loads(raw.decode("utf-8-sig")), raw, path


def check(errors, condition, message):
    if not condition:
        errors.append(message)


def same(actual, expected, errors, label):
    same_type = type(actual) is type(expected)
    numeric_pair = (
        type(actual) in (int, float) and not isinstance(actual, bool)
        and type(expected) in (int, float) and not isinstance(expected, bool)
    )
    check(errors, (same_type or numeric_pair) and actual == expected,
          "%s: expected %r, observed %r" % (label, expected, actual))


def is_true(value):
    return value is True


def is_false(value):
    return value is False


def valid_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def canonical_hash(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256(raw)


def check_input_manifest(manifest, errors, label):
    check(errors, isinstance(manifest, dict), label + " is not an object")
    if not isinstance(manifest, dict):
        return
    same(manifest.get("roots"), ["src", "war"], errors, label + ".roots")
    rows = manifest.get("files")
    check(errors, isinstance(rows, list) and bool(rows),
          label + ".files is empty or invalid")
    if not isinstance(rows, list):
        return
    source_rows = []
    web_rows = []
    paths = []
    for index, row in enumerate(rows):
        item_label = "%s.files[%d]" % (label, index)
        check(errors, isinstance(row, dict), item_label + " is not an object")
        if not isinstance(row, dict):
            continue
        path = row.get("path")
        check(errors, isinstance(path, str), item_label + ".path is invalid")
        if isinstance(path, str):
            paths.append(path)
            if path.startswith("src/"):
                source_rows.append(row)
            elif path.startswith("war/"):
                web_rows.append(row)
            else:
                errors.append(item_label + " is outside src/ and war/")
        check(errors, valid_int(row.get("size")) and row.get("size") >= 0,
              item_label + ".size is invalid")
        digest = row.get("sha256")
        check(errors, isinstance(digest, str) and
              re.fullmatch(r"[0-9a-f]{64}", digest) is not None,
              item_label + ".sha256 is invalid")
    same(paths, sorted(paths), errors, label + " path ordering")
    same(len(paths), len(set(paths)), errors, label + " duplicate paths")
    same(manifest.get("fileCount"), len(rows), errors, label + ".fileCount")
    same(manifest.get("sourceFileCount"), len(source_rows), errors,
         label + ".sourceFileCount")
    same(manifest.get("webFileCount"), len(web_rows), errors,
         label + ".webFileCount")
    same(manifest.get("sha256"), canonical_hash(rows), errors,
         label + ".sha256")
    same(manifest.get("sourceSha256"), canonical_hash(source_rows), errors,
         label + ".sourceSha256")
    same(manifest.get("webSha256"), canonical_hash(web_rows), errors,
         label + ".webSha256")


def check_report_cleanup(audit, errors, label, expected_failures=0,
                         expected_disposed=5):
    check(errors, isinstance(audit, dict), label + " cleanupAudit is missing")
    if not isinstance(audit, dict):
        return
    same(audit.get("disposalFailureCount"), expected_failures, errors,
         label + ".disposalFailureCount")
    same(audit.get("disposedHypothesisCount"), expected_disposed, errors,
         label + ".disposedHypothesisCount")
    for field in (
        "lastOwnerGuardPassed",
        "lastBindingsActuallyDisconnected",
        "lastElementsActuallyDeleted",
        "lastGraphDetached",
        "lastCleanupComplete",
    ):
        check(errors, is_true(audit.get(field)), label + "." + field + " is not true")
    for field in (
        "cleanupAttemptCount", "disposedHypothesisCount",
        "disconnectedBindingCount", "disposedElementCount",
        "disposalFailureCount", "lastBindingCount",
        "lastDisconnectedBindingCount", "lastElementCount",
        "lastDeletedElementCount",
    ):
        check(errors, valid_int(audit.get(field)) and audit.get(field) >= 0,
              label + "." + field + " is invalid")
    same(audit.get("lastBindingCount"), audit.get("lastDisconnectedBindingCount"),
         errors, label + " binding cleanup counts")
    same(audit.get("lastElementCount"), audit.get("lastDeletedElementCount"),
         errors, label + " element cleanup counts")


def check_negative_canaries(negatives, seed, errors):
    check(errors, isinstance(negatives, dict), "D01 negatives object is missing")
    if not isinstance(negatives, dict):
        return
    same(set(negatives), EXPECTED_NEGATIVES, errors, "D01 negative canary names")
    for name in EXPECTED_NEGATIVES:
        item = negatives.get(name)
        check(errors, isinstance(item, dict), "negative %s is missing" % name)
        if isinstance(item, dict):
            same(item.get("status"), "PASS", errors, "negative %s status" % name)

    incomplete = negatives.get("incompleteSession")
    if isinstance(incomplete, dict):
        check(errors, is_true(incomplete.get("rejected")),
              "incompleteSession was not rejected")
        check(errors, "incomplete" in str(incomplete.get("rejection", "")).lower(),
              "incompleteSession rejection did not identify incompleteness")
        check(errors, is_false(incomplete.get("receiptIssued")),
              "incompleteSession issued a receipt")
        check(errors, is_true(incomplete.get("exactOwnerRestored")),
              "incompleteSession did not restore its exact owner")

    foreign = negatives.get("foreignHypothesis")
    if isinstance(foreign, dict):
        foreign_seed = foreign.get("foreignSeed")
        check(errors, isinstance(foreign_seed, str) and foreign_seed != seed,
              "foreignHypothesis did not use a different seed")
        check(errors, isinstance(foreign.get("hypothesisKey"), str) and
              bool(foreign.get("hypothesisKey")),
              "foreignHypothesis has no hypothesis key")
        check(errors, is_true(foreign.get("rejected")),
              "foreignHypothesis was not rejected")
        check(errors, isinstance(foreign.get("rejection"), str) and
              bool(foreign.get("rejection")),
              "foreignHypothesis has no rejection reason")
        check(errors, is_true(foreign.get("foreignConstructionDisposed")),
              "foreignHypothesis construction was not disposed")

    retry = negatives.get("failedCleanupRetry")
    if isinstance(retry, dict):
        for field in (
            "injectedFailure",
            "exactOwnerRestored",
            "pendingCleanupBeforeRetry",
            "exactRetryInvoked",
            "retryCompleted",
            "contextRestoredAfterCanaries",
        ):
            check(errors, is_true(retry.get(field)),
                  "failedCleanupRetry.%s is not true" % field)
        for field in ("receiptIssued", "pendingCleanupAfterRetry"):
            check(errors, is_false(retry.get(field)),
                  "failedCleanupRetry.%s is not false" % field)
        check(errors, isinstance(retry.get("failure"), str) and
              bool(retry.get("failure")),
              "failedCleanupRetry has no injected failure description")
        check_report_cleanup(retry.get("cleanupAudit"), errors,
                             "failedCleanupRetry", expected_failures=1,
                             expected_disposed=1)

    changed = negatives.get("sourceContextChange")
    if isinstance(changed, dict):
        same(changed.get("inputId"), "MAIN12", errors,
             "sourceContextChange.inputId")
        for field in (
            "changedContextCaptured",
            "sourceConnectionRestored",
            "restoredContextMatchesWarm",
        ):
            check(errors, is_true(changed.get(field)),
                  "sourceContextChange.%s is not true" % field)

    mismatch = negatives.get("mismatchedContext")
    if isinstance(mismatch, dict):
        for field in (
            "mismatchedRequestCaptured",
            "cacheMissed",
            "receiptRejectedMismatchedContext",
        ):
            check(errors, is_true(mismatch.get(field)),
                  "mismatchedContext.%s is not true" % field)
        check(errors, valid_int(mismatch.get("cacheMissCount")) and
              mismatch.get("cacheMissCount") >= 1,
              "mismatchedContext did not record a cache miss")


def check_positive_d01(report, seed, errors, name):
    label = "D01 %s" % seed
    check(errors, isinstance(report, dict), label + " report is not an object")
    if not isinstance(report, dict):
        return
    same(report.get("schema"), 2, errors, label + ".schema")
    same(report.get("seed"), seed, errors, label + ".seed")
    same(report.get("requestedSeed"), seed, errors, label + ".requestedSeed")
    same(report.get("requestManifest"), EXPECTED_REQUEST_MANIFEST,
         errors, label + ".requestManifest")
    same(report.get("status"), "PASS", errors, label + ".status")
    for field, expected in (
        ("normalAdmission", False),
        ("registered", True),
        ("playerPublished", False),
        ("normalOwner", True),
        ("d01Admission", True),
        ("restored", True),
        ("ownerRestored", True),
        ("cleanupComplete", True),
        ("cleanupPending", False),
        ("coldStageCleanupComplete", True),
    ):
        same(report.get(field), expected, errors, label + "." + field)
    same(report.get("cacheScope"), "verifierOnly", errors,
         label + ".cacheScope")
    same(report.get("cacheEntries"), 1, errors, label + ".cacheEntries")
    same(report.get("hypothesisCount"), 5, errors, label + ".hypothesisCount")
    check(errors, valid_int(report.get("actualSampleCount")) and
          report.get("actualSampleCount") > 0,
          label + ".actualSampleCount is missing or zero")
    check(errors, is_false(report.get("explicitCompletion")),
          label + ".explicitCompletion is not false")
    check(errors, is_true(report.get("contextTrusted")),
          label + ".contextTrusted is not true")

    cold = report.get("cold")
    check(errors, isinstance(cold, dict), label + ".cold object is missing")
    if isinstance(cold, dict):
        same(cold.get("status"), "PASS", errors, label + ".cold.status")
        check(errors, valid_int(cold.get("workUnits")) and cold.get("workUnits") > 0,
              label + ".cold.workUnits is missing or zero")
        check(errors, valid_int(cold.get("activeWorkMillis")) and
              cold.get("activeWorkMillis") >= 0,
              label + ".cold.activeWorkMillis is invalid")
        evidence = cold.get("evidence")
        check(errors, isinstance(evidence, list) and len(evidence) == 5,
              label + ".cold.evidence does not contain five hypotheses")
        check_report_cleanup(cold.get("cleanupAudit"), errors, label + ".cold")

    warm = report.get("warm")
    check(errors, isinstance(warm, dict), label + ".warm object is missing")
    if isinstance(warm, dict):
        same(warm.get("status"), "PASS", errors, label + ".warm.status")
        same(warm.get("cacheScope"), "verifierOnly", errors,
             label + ".warm.cacheScope")
        same(warm.get("cacheHit"), True, errors, label + ".warm.cacheHit")
        for field in (
            "sameTrustedContext",
            "sameProviderProgramPartition",
            "sameImmutableEvidence",
            "receiptBoundToFreshOwner",
            "warmReuseReceipt",
        ):
            check(errors, is_true(warm.get(field)),
                  label + ".warm.%s is not true" % field)
        same(warm.get("hypothesisCount"), 5, errors,
             label + ".warm.hypothesisCount")
        same(warm.get("ownerSeed"), seed, errors, label + ".warm.ownerSeed")
        same(warm.get("elapsedMillis"), 0, errors,
             label + ".warm.elapsedMillis")
        check(errors, valid_int(warm.get("samplePopulationPerHypothesis")) and
              warm.get("samplePopulationPerHypothesis") > 0,
              label + ".warm sample population is missing or zero")

    check_report_cleanup(report.get("cleanupAudit"), errors, label)
    check_negative_canaries(report.get("negatives"), seed, errors)


def check_seed35_rejection(report, oracle, errors):
    label = "D01 seed 35 intentional physical rejection"
    check(errors, isinstance(report, dict), label + " report is not an object")
    if not isinstance(report, dict):
        return
    check(errors, isinstance(oracle, dict),
          label + " oracle is not an object")
    if not isinstance(oracle, dict):
        return
    same(report.get("schema"), 2, errors, label + ".schema")
    same(report.get("seed"), "35", errors, label + ".seed")
    same(report.get("requestedSeed"), "35", errors, label + ".requestedSeed")
    same(report.get("requestManifest"), EXPECTED_REQUEST_MANIFEST,
         errors, label + ".requestManifest")
    same(report.get("status"), "FAIL", errors, label + ".status")
    same(report.get("failurePhase"), "construction", errors,
         label + ".failurePhase")
    same(report.get("failure"), oracle.get("reason"), errors,
         label + ".failure reason")
    required_flags = oracle.get("requiredFlags")
    if isinstance(required_flags, dict):
        for field, expected in required_flags.items():
            same(report.get(field), expected, errors, label + "." + field)
    same(report.get("normalOwner"), False, errors, label + ".normalOwner")
    cold = report.get("cold")
    check(errors, isinstance(cold, dict), label + ".cold object is missing")
    if isinstance(cold, dict):
        same(cold.get("status"), "FAIL", errors, label + ".cold.status")
    warm = report.get("warm")
    check(errors, isinstance(warm, dict), label + ".warm object is missing")
    if isinstance(warm, dict):
        same(warm.get("status"), "NOT_RUN", errors, label + ".warm.status")
        check(errors, warm.get("status") != "PASS",
              label + " unexpectedly recorded a warm pass")


def check_oracle(oracle, errors):
    check(errors, isinstance(oracle, dict),
          "seed-35 physical-rejection oracle is not an object")
    if not isinstance(oracle, dict):
        return
    same(oracle.get("schema"), 1, errors, "seed-35 oracle.schema")
    same(oracle.get("caseName"), "d01-descriptive21-seed-35", errors,
         "seed-35 oracle.caseName")
    same(oracle.get("seed"), "35", errors, "seed-35 oracle.seed")
    same(oracle.get("outcome"), "REJECTED_POLICY", errors,
         "seed-35 oracle.outcome")
    same(oracle.get("isWarmPass"), False, errors,
         "seed-35 oracle.isWarmPass")
    same(oracle.get("reason"), PHYSICAL_REJECTION_REASON, errors,
         "seed-35 oracle.reason")
    same(oracle.get("requiredFailurePhase"), "construction", errors,
         "seed-35 oracle.requiredFailurePhase")
    flags = oracle.get("requiredFlags")
    check(errors, isinstance(flags, dict), "seed-35 oracle.requiredFlags is not an object")
    if isinstance(flags, dict):
        same(set(flags), set(PHYSICAL_REJECTION_FLAGS), errors,
             "seed-35 oracle.requiredFlags keys")
        for field, expected in PHYSICAL_REJECTION_FLAGS.items():
            same(flags.get(field), expected, errors,
                 "seed-35 oracle.requiredFlags." + field)


def read_case_report(run_dir, receipt, errors, files, label):
    relative = receipt.get("reportFile")
    check(errors, isinstance(relative, str) and bool(relative),
          label + " has no reportFile")
    if not isinstance(relative, str) or not relative:
        return None
    normalized = PurePosixPath(relative.replace("\\", "/"))
    check(errors, not normalized.is_absolute() and
          ".." not in normalized.parts and ":" not in relative,
          label + " reportFile escapes the run directory")
    if normalized.is_absolute() or ".." in normalized.parts or ":" in relative:
        return None
    try:
        report_path = run_dir.joinpath(*normalized.parts).resolve()
        report_path.relative_to(run_dir.resolve())
    except (OSError, ValueError):
        errors.append(label + " reportFile resolves outside the run directory")
        return None
    try:
        raw = report_path.read_bytes()
    except OSError as error:
        errors.append(label + " report cannot be read: " + str(error))
        return None
    files[label + " report"] = {
        "path": relative.replace("\\", "/"),
        "size": len(raw),
        "sha256": sha256(raw),
    }
    same(receipt.get("reportSha256"), sha256(raw), errors,
         label + " reportSha256")
    same(receipt.get("reportLength"), len(raw), errors,
         label + " reportLength")
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        errors.append(label + " report JSON is invalid: " + str(error))
        return None


def check_saved_case_receipt(run_dir, index, name, embedded, errors, files):
    slug = re.sub(r"[^A-Za-z0-9_.-]+", "-", name).strip("-._") or "case"
    relative = Path("cases") / ("%03d-%s.json" % (index, slug[:80]))
    path = run_dir / relative
    try:
        path.resolve().relative_to(run_dir.resolve())
        saved, _, _ = read_json(path, "case receipt " + name, files)
    except (OSError, ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
        errors.append("cannot read saved case receipt %s: %s" % (name, error))
        return
    same(saved, embedded, errors, "saved case receipt " + name)


def check_binding(binding, spec_hash, runner_path, manifest_before,
                  manifest_after, errors):
    check(errors, isinstance(binding, dict), "source binding is not an object")
    if not isinstance(binding, dict):
        return {}
    for field, expected in (
        ("schema", 1),
        ("stage", "compiled31"),
        ("sourceIdentity", EXPECTED_SOURCE_IDENTITY),
        ("candidateBaseHead", EXPECTED_BASE_HEAD),
        ("status", "COMMAND_PASS_PENDING_RECEIPT_REVIEW"),
        ("exitCode", 0),
        ("rawInputsVerified", 1354),
        ("consumedInputsUnchanged", True),
        ("q30NormalPlayerEnabled", False),
        ("specSha256", spec_hash),
    ):
        same(binding.get(field), expected, errors, "source binding." + field)

    shipping_app = binding.get("shippingApp")
    check(errors, isinstance(shipping_app, str) and
          bool(shipping_app) and Path(shipping_app).is_absolute(),
          "source binding.shippingApp is not an absolute path")

    before = binding.get("compiledInputsBefore")
    after = binding.get("compiledInputsAfter")
    check(errors, isinstance(before, list) and bool(before),
          "source binding.compiledInputsBefore is empty or invalid")
    check(errors, isinstance(after, list) and bool(after),
          "source binding.compiledInputsAfter is empty or invalid")
    if isinstance(before, list) and isinstance(after, list):
        same(before, after, errors, "source binding compiled input before/after")
        cache_paths = set()
        for index, row in enumerate(before):
            label = "source binding compiledInputsBefore[%d]" % index
            check(errors, isinstance(row, dict), label + " is not an object")
            if not isinstance(row, dict):
                continue
            same(set(row), {"path", "size", "sha256"}, errors,
                 label + " fields")
            path = row.get("path")
            size = row.get("size")
            digest = row.get("sha256")
            check(errors, isinstance(path, str) and
                  path.startswith("war/circuitjs1/"),
                  label + " path is outside war/circuitjs1")
            if isinstance(path, str):
                safe = PurePosixPath(path)
                check(errors, not safe.is_absolute() and
                      "\\" not in path and ".." not in safe.parts and
                      ":" not in path and safe.as_posix() == path,
                      label + " path is not a safe relative path")
                check(errors, path not in cache_paths,
                      label + " duplicates a compiled path")
                cache_paths.add(path)
            check(errors, valid_int(size) and size >= 0,
                  label + " size is invalid")
            check(errors, isinstance(digest, str) and
                  re.fullmatch(r"[0-9a-f]{64}", digest) is not None,
                  label + " sha256 is not lower-case hex")
        check(errors, any(path.lower().endswith(".cache.js")
                          for path in cache_paths),
              "source binding has no compiled .cache.js input")

    try:
        current_runner_sha = sha256(runner_path.read_bytes())
    except OSError as error:
        current_runner_sha = None
        errors.append("cannot hash tracked compiled runner: " + str(error))
    same(binding.get("runnerSha256"), current_runner_sha, errors,
         "source binding.runnerSha256")
    if isinstance(manifest_before, dict):
        same(manifest_before.get("sha256"), current_runner_sha, errors,
             "runner-before.sha256")
    if isinstance(manifest_after, dict):
        same(manifest_after.get("sha256"), current_runner_sha, errors,
             "runner-after.sha256")
    return {
        "sourceIdentity": binding.get("sourceIdentity"),
        "candidateBaseHead": binding.get("candidateBaseHead"),
        "shippingApp": shipping_app,
        "runnerSha256": current_runner_sha,
        "compiledInputCount": len(before) if isinstance(before, list) else 0,
    }


def audit(args):
    record = {
        "schema": 1,
        "audit": "epoch15-compiled31",
        "startedUtc": datetime.now(timezone.utc).isoformat(),
        "status": "RUNNING",
        "inputs": {},
        "cases": [],
        "errors": [],
    }
    errors = record["errors"]
    files = record["inputs"]
    run_dir = Path(args.run_dir).expanduser().resolve()
    repo = Path(args.repo).expanduser().resolve()
    runner_path = repo.joinpath(*PurePosixPath(EXPECTED_RUNNER).parts)
    record["runDirectory"] = str(run_dir)

    try:
        result, _, _ = read_json(run_dir / "result.json", "compiled31 result.json", files)
        spec, spec_raw, _ = read_json(args.spec, "compiled31 spec", files)
        oracle, _, _ = read_json(args.oracle, "seed35 rejection oracle", files)
        binding, _, _ = read_json(args.source_binding, "compiled31 source binding", files)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        errors.append("cannot read required audit input: " + str(error))
        return record

    check(errors, isinstance(result, dict),
          "compiled31 result.json is not an object")
    if not isinstance(result, dict):
        result = {}
    check_oracle(oracle, errors)

    spec_hash = sha256(spec_raw)
    record["specSha256"] = spec_hash
    same(spec_hash, EXPECTED_SPEC_SHA256, errors, "compiled31 spec SHA-256")
    check(errors, isinstance(spec, dict) and set(spec) == {"cases"} and
          isinstance(spec.get("cases"), list),
          "compiled31 spec has the wrong top-level shape")
    spec_cases = spec.get("cases", []) if isinstance(spec, dict) else []
    spec_names = [row.get("name") if isinstance(row, dict) else None
                  for row in spec_cases]
    same(spec_names, list(EXPECTED_CASE_NAMES), errors,
         "compiled31 ordered case names")

    embedded_spec = run_dir / "spec.json"
    try:
        embedded_raw = embedded_spec.read_bytes()
        files["run spec.json"] = {
            "path": str(embedded_spec.resolve()),
            "size": len(embedded_raw),
            "sha256": sha256(embedded_raw),
        }
        same(sha256(embedded_raw), spec_hash, errors,
             "run spec.json SHA-256")
    except OSError as error:
        errors.append("cannot read run spec.json: " + str(error))

    same(result.get("runner"), "compiled_attribute_acceptance.py",
         errors, "compiled31 runner name")
    same(result.get("outcome"), "PASS", errors, "compiled31 overall outcome")
    same(result.get("caseCount"), 31, errors, "compiled31 caseCount")
    check(errors, isinstance(result.get("errors"), list) and
          not result.get("errors"), "compiled31 host errors are present")
    case_rows = result.get("cases")
    check(errors, isinstance(case_rows, list) and len(case_rows) == 31,
          "compiled31 result does not contain exactly 31 case receipts")
    if not isinstance(case_rows, list):
        case_rows = []
    result_names = []
    spec_by_name = {
        row.get("name"): row for row in spec_cases if isinstance(row, dict)
    }

    for index, receipt in enumerate(case_rows):
        label = "case %03d" % (index + 1)
        check(errors, isinstance(receipt, dict), label + " receipt is not an object")
        if not isinstance(receipt, dict):
            continue
        case = receipt.get("case")
        check(errors, isinstance(case, dict), label + " case descriptor is missing")
        if not isinstance(case, dict):
            continue
        name = case.get("name")
        result_names.append(name)
        if isinstance(name, str):
            check_saved_case_receipt(run_dir, index + 1, name, receipt,
                                     errors, files)
        expected_spec = spec_by_name.get(name) if isinstance(name, str) else None
        check(errors, isinstance(expected_spec, dict),
              label + " name is absent from the bound spec")
        if isinstance(expected_spec, dict):
            same(case.get("index"), index + 1, errors, label + ".index")
            for field in (
                "name", "path", "stateAttribute", "expectedState",
                "expectedPrefix", "terminalPrefixes", "timeoutSeconds",
                "reportAttribute",
            ):
                expected_value = expected_spec.get(field)
                if field == "terminalPrefixes" and field not in expected_spec:
                    expected_value = ["PASS", "FAIL"]
                same(case.get(field), expected_value, errors,
                     label + ".case." + field)
        expected_state = (expected_spec.get("expectedState")
                          if isinstance(expected_spec, dict) else None)
        expected_prefix = (expected_spec.get("expectedPrefix")
                           if isinstance(expected_spec, dict) else None)
        expected_failure = str(expected_state or expected_prefix or "").startswith("FAIL")
        same(receipt.get("outcome"), "PASS", errors, label + ".outcome")
        same(receipt.get("terminalReached"), True, errors,
             label + ".terminalReached")
        same(receipt.get("timedOut"), False, errors, label + ".timedOut")
        same(receipt.get("stateMatch"), True, errors, label + ".stateMatch")
        observed = receipt.get("observedState")
        if expected_state is not None:
            same(observed, expected_state, errors, label + ".observedState")
        elif expected_prefix is not None:
            check(errors, isinstance(observed, str) and
                  observed.startswith(expected_prefix),
                  label + ".observedState does not match expectedPrefix")
        same(receipt.get("expectedFailureCanary"), expected_failure, errors,
             label + ".expectedFailureCanary")
        if expected_failure:
            same(receipt.get("expectedFailureStateWasNotAnUnexpectedError"),
                 True, errors, label + ".expectedFailureStateWasNotAnUnexpectedError")
        else:
            same(receipt.get("expectedFailureStateWasNotAnUnexpectedError"),
                 False, errors, label + ".expectedFailureStateWasNotAnUnexpectedError")
        for field in (
            "pageErrors", "httpErrors", "consoleErrors",
            "attributeReadErrors", "listenerCleanupErrors",
        ):
            same(receipt.get(field), [], errors, label + "." + field)
        same(receipt.get("navigationError"), None, errors,
             label + ".navigationError")
        if expected_spec and expected_spec.get("reportAttribute") is not None:
            same(receipt.get("reportObserved"), True, errors,
                 label + ".reportObserved")
            same(receipt.get("reportJsonValid"), True, errors,
                 label + ".reportJsonValid")
            same(receipt.get("reportMatch"), True, errors,
                 label + ".reportMatch")
            same(receipt.get("reportJsonError"), None, errors,
                 label + ".reportJsonError")

        row_audit = {
            "index": index + 1,
            "name": name,
            "outcome": receipt.get("outcome"),
            "observedState": receipt.get("observedState"),
            "semanticStatus": "NOT_APPLICABLE",
        }
        if isinstance(name, str) and name.startswith("d01-descriptive21-seed-"):
            case_error_start = len(errors)
            seed = name.rsplit("-", 1)[-1]
            report = read_case_report(run_dir, receipt, errors, files, name)
            if seed == "35":
                check_seed35_rejection(report, oracle, errors)
            elif seed in EXPECTED_D01_SEEDS:
                check_positive_d01(report, seed, errors, name)
            else:
                errors.append(name + " uses an unrecognized D01 seed")
            row_audit["reportSha256"] = receipt.get("reportSha256")
            row_audit["semanticStatus"] = (
                "PASS" if len(errors) == case_error_start else "FAIL"
            )
        record["cases"].append(row_audit)

    same(result_names, list(EXPECTED_CASE_NAMES), errors,
         "compiled31 result ordered case names")

    identity = result.get("identity")
    check(errors, isinstance(identity, dict), "compiled31 host identity is missing")
    if isinstance(identity, dict):
        runner_identity = identity.get("runner")
        check(errors, isinstance(runner_identity, dict),
              "compiled31 runner process identity is missing")
        if isinstance(runner_identity, dict):
            check(errors, valid_int(runner_identity.get("pid")) and
                  bool(runner_identity.get("created")) and
                  bool(runner_identity.get("executable")),
                  "compiled31 runner process identity is incomplete")
        edge = identity.get("edgeProcessesBeforeCases")
        check(errors, isinstance(edge, list) and bool(edge),
              "compiled31 has no recorded Edge process identity")
        if isinstance(edge, list):
            for index, process in enumerate(edge):
                check(errors, isinstance(process, dict) and
                      valid_int(process.get("pid")) and
                      bool(process.get("created")) and
                      bool(process.get("ExecutablePath")),
                      "compiled31 Edge identity %d is incomplete" % index)
        check(errors, valid_int(identity.get("port")) and
              0 < identity.get("port") < 65536,
              "compiled31 local server port is invalid")
        same(identity.get("baseUrl"),
             "http://127.0.0.1:%s" % identity.get("port"),
             errors, "compiled31 local server baseUrl")
        profile = identity.get("profile")
        check(errors, isinstance(profile, str) and
              _is_under(Path(profile), run_dir),
              "compiled31 browser profile is outside the run directory")

    input_audit = result.get("inputAudit")
    check(errors, isinstance(input_audit, dict),
          "compiled31 inputAudit is missing")
    manifest_before = None
    manifest_after = None
    runner_before = None
    runner_after = None
    for label, filename in (
        ("input manifest before", "input-manifest-before.json"),
        ("input manifest after", "input-manifest-after.json"),
        ("runner before", "runner-before.json"),
        ("runner after", "runner-after.json"),
    ):
        try:
            loaded, _, _ = read_json(run_dir / filename, label, files)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            errors.append("cannot read %s: %s" % (label, error))
            continue
        if filename == "input-manifest-before.json":
            manifest_before = loaded
        elif filename == "input-manifest-after.json":
            manifest_after = loaded
        elif filename == "runner-before.json":
            runner_before = loaded
        else:
            runner_after = loaded

    if isinstance(input_audit, dict):
        same(input_audit.get("status"), "PASS", errors, "inputAudit.status")
        same(input_audit.get("beforeSha256"),
             manifest_before.get("sha256") if isinstance(manifest_before, dict) else None,
             errors, "inputAudit.beforeSha256")
        same(input_audit.get("afterSha256"),
             manifest_after.get("sha256") if isinstance(manifest_after, dict) else None,
             errors, "inputAudit.afterSha256")
        for manifest_field in ("sourceSha256", "webSha256"):
            before_field = manifest_field + "Before"
            after_field = manifest_field + "After"
            expected_before = (manifest_before.get(manifest_field)
                               if isinstance(manifest_before, dict) else None)
            expected_after = (manifest_after.get(manifest_field)
                              if isinstance(manifest_after, dict) else None)
            same(input_audit.get(before_field), expected_before, errors,
                 "inputAudit." + before_field)
            same(input_audit.get(after_field), expected_after, errors,
                 "inputAudit." + after_field)
            same(expected_before, expected_after, errors,
                 "input manifest " + manifest_field + " unchanged")
        same(input_audit.get("fileCountBefore"),
             manifest_before.get("fileCount") if isinstance(manifest_before, dict) else None,
             errors, "inputAudit.fileCountBefore")
        same(input_audit.get("fileCountAfter"),
             manifest_after.get("fileCount") if isinstance(manifest_after, dict) else None,
             errors, "inputAudit.fileCountAfter")
        same(input_audit.get("fileCountBefore"), input_audit.get("fileCountAfter"),
             errors, "inputAudit file count unchanged")
        same(input_audit.get("beforeSha256"), input_audit.get("afterSha256"),
             errors, "inputAudit complete manifest unchanged")
        same(input_audit.get("runnerBeforeSha256"),
             input_audit.get("runnerAfterSha256"), errors,
             "inputAudit runner script unchanged")
        same(input_audit.get("runnerBeforeSha256"),
             runner_before.get("sha256") if isinstance(runner_before, dict) else None,
             errors, "inputAudit.runnerBeforeSha256")
        same(input_audit.get("runnerAfterSha256"),
             runner_after.get("sha256") if isinstance(runner_after, dict) else None,
             errors, "inputAudit.runnerAfterSha256")

    if isinstance(manifest_before, dict) and isinstance(manifest_after, dict):
        check_input_manifest(manifest_before, errors, "input manifest before")
        check_input_manifest(manifest_after, errors, "input manifest after")
        before_files = manifest_before.get("files")
        after_files = manifest_after.get("files")
        check(errors, isinstance(before_files, list) and bool(before_files),
              "input manifest before has no files")
        check(errors, isinstance(after_files, list) and bool(after_files),
              "input manifest after has no files")
        same(before_files, after_files, errors, "input manifest file inventory")
        compiled_manifest_rows = []
        if isinstance(before_files, list):
            compiled_manifest_rows = [
                row for row in before_files
                if isinstance(row, dict)
                and str(row.get("path", "")).startswith("war/circuitjs1/")
            ]
        compiled_manifest_after_rows = []
        if isinstance(after_files, list):
            compiled_manifest_after_rows = [
                row for row in after_files
                if isinstance(row, dict)
                and str(row.get("path", "")).startswith("war/circuitjs1/")
            ]
        cache_rows = [
            row for row in compiled_manifest_rows
            if str(row.get("path", "")).lower().endswith(".cache.js")
        ]
        same(len(cache_rows), EXPECTED_GWT_CACHE_PERMUTATIONS, errors,
             "runner input manifest GWT .cache.js permutation count")
        for index, row in enumerate(cache_rows):
            path = row.get("path", "")
            basename = PurePosixPath(path).name
            check(errors, re.fullmatch(r"[0-9A-Fa-f]{32}\.cache\.js", basename)
                  is not None,
                  "runner input manifest cache permutation %d has an unexpected name" %
                  (index + 1))
        same(compiled_manifest_rows, compiled_manifest_after_rows, errors,
             "runner input manifest full war/circuitjs1 inventory unchanged")
        binding_before = binding.get("compiledInputsBefore", []) \
            if isinstance(binding, dict) else []
        binding_after = binding.get("compiledInputsAfter", []) \
            if isinstance(binding, dict) else []
        if isinstance(binding_before, list):
            binding_by_path = {
                row.get("path"): row for row in binding_before
                if isinstance(row, dict) and isinstance(row.get("path"), str)
            }
            manifest_by_path = {
                row.get("path"): row for row in compiled_manifest_rows
                if isinstance(row, dict) and isinstance(row.get("path"), str)
            }
            same(binding_by_path, manifest_by_path, errors,
                 "source-binding full war/circuitjs1 inventory vs runner input manifest")
            binding_cache_paths = [
                row.get("path") for row in binding_before
                if isinstance(row, dict) and isinstance(row.get("path"), str)
                and row.get("path").lower().endswith(".cache.js")
            ]
            same(len(binding_cache_paths), EXPECTED_GWT_CACHE_PERMUTATIONS, errors,
                 "source-binding GWT .cache.js permutation count")
            same(set(binding_cache_paths),
                 {row.get("path") for row in cache_rows}, errors,
                 "source-binding GWT cache permutations vs runner input manifest")
        if isinstance(binding_after, list):
            binding_after_by_path = {
                row.get("path"): row for row in binding_after
                if isinstance(row, dict) and isinstance(row.get("path"), str)
            }
            manifest_after_by_path = {
                row.get("path"): row for row in compiled_manifest_after_rows
                if isinstance(row, dict) and isinstance(row.get("path"), str)
            }
            same(binding_after_by_path, manifest_after_by_path, errors,
                 "source-binding after full war/circuitjs1 inventory vs runner input manifest")

    try:
        check_binding(binding, spec_hash, runner_path, runner_before,
                      runner_after, errors)
    except (OSError, TypeError, ValueError) as error:
        errors.append("source binding validation failed: " + str(error))

    cleanup = result.get("cleanup")
    check(errors, isinstance(cleanup, dict), "compiled31 cleanup report is missing")
    if isinstance(cleanup, dict):
        same(cleanup.get("status"), "PASS", errors, "cleanup.status")
        same(cleanup.get("serverStopped"), True, errors, "cleanup.serverStopped")
        same(cleanup.get("ownedSurvivors"), [], errors, "cleanup.ownedSurvivors")
        same(cleanup.get("errors"), [], errors, "cleanup.errors")

    record["status"] = "PASS" if not errors else "FAIL"
    record["finishedUtc"] = datetime.now(timezone.utc).isoformat()
    seed35_row = next((row for row in record["cases"]
                       if row.get("name") == "d01-descriptive21-seed-35"), {})
    record["summary"] = {
        "expectedCases": 31,
        "observedCases": len(case_rows),
        "positiveD01Cases": 20,
        "seed35IntentionalRejection": seed35_row.get("semanticStatus", "FAIL"),
        "sourceBinding": {
            "sourceIdentity": binding.get("sourceIdentity")
            if isinstance(binding, dict) else None,
            "candidateBaseHead": binding.get("candidateBaseHead")
            if isinstance(binding, dict) else None,
            "shippingApp": binding.get("shippingApp")
            if isinstance(binding, dict) else None,
            "compiledInputsCount": len(binding.get("compiledInputsBefore", []))
            if isinstance(binding, dict) and
            isinstance(binding.get("compiledInputsBefore"), list) else 0,
        },
    }
    return record


def _is_under(path, root):
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def parse_args(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True,
                        help="completed compiled_attribute_acceptance.py output directory")
    parser.add_argument("--spec", required=True, help="bound 31-case spec JSON")
    parser.add_argument("--oracle", required=True,
                        help="seed-35 typed physical-rejection oracle JSON")
    parser.add_argument("--source-binding", required=True,
                        help="root-produced compiled31-stage-result.json")
    parser.add_argument("--repo", required=True,
                        help="candidate repository used to hash the tracked browser runner")
    parser.add_argument("--output", required=True,
                        help="new audit JSON path; existing files are preserved")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(sys.argv[1:] if argv is None else argv)
    output = Path(args.output).expanduser().resolve()
    if output.exists():
        print("ERROR refusing to overwrite audit evidence: " + str(output),
              file=sys.stderr)
        return 2
    if not output.parent.is_dir():
        print("ERROR audit output parent must already exist: " +
              str(output.parent), file=sys.stderr)
        return 2

    try:
        record = audit(args)
    except Exception as error:
        record = {
            "schema": 1,
            "audit": "epoch15-compiled31",
            "startedUtc": datetime.now(timezone.utc).isoformat(),
            "finishedUtc": datetime.now(timezone.utc).isoformat(),
            "status": "FAIL",
            "inputs": {},
            "cases": [],
            "errors": ["audit failed while retaining evidence: " + repr(error)],
        }
    if record.get("status") == "RUNNING":
        record["status"] = "FAIL"
        record["finishedUtc"] = datetime.now(timezone.utc).isoformat()
        record.setdefault("errors", []).append(
            "audit stopped before all checks completed"
        )
    try:
        with output.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(record, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
    except OSError as error:
        print("ERROR unable to retain audit evidence: " + str(error),
              file=sys.stderr)
        return 2

    print(json.dumps({
        "status": record.get("status"),
        "output": str(output),
        "errorCount": len(record.get("errors", [])),
        "errors": record.get("errors", []),
    }, indent=2))
    return 0 if record.get("status") == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
