"""Bounded real-host process ownership canary for the epoch-15 Q30 gate.

This is a preparation artifact. It has not been run as part of its creation.
It preserves all evidence under a unique TEMP directory and never kills a
process or deletes a browser profile.
"""

import argparse
import asyncio
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import traceback
import uuid
from types import SimpleNamespace
from unittest.mock import patch


EXPECTED_HOST_SHA256 = "fb6c78570101c19c8b477da48884ff00d7563eb35c2e5f52033c9be63e74d839"
EXPECTED_SCALE_HOST_SHA256 = "8da1af0f184cea190f17fb02629e4475013337558e32903e95992552723a4440"
APPROVED_HOST_SHA256S = {EXPECTED_HOST_SHA256, EXPECTED_SCALE_HOST_SHA256}
WORKSPACE = Path(__file__).resolve().parent
DEFAULT_HOST = WORKSPACE / "process-identity-draft" / "compiled_attribute_acceptance.py"
DEFAULT_DEPS = Path(os.environ.get("TEMP", tempfile.gettempdir())) / "q30-finish-0fa2512465" / "deps"
POINTER_NAME = "process-identity-canary-pointer.json"
QUERY_TIMEOUT_SECONDS = 25
WORKER_READY_SECONDS = 60
WORKER_COMMAND_SECONDS = 45
WORKER_EXIT_SECONDS = 20
LAST_OUTPUT_ROOT = None


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    with temporary.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def read_json(path):
    with Path(path).open("r", encoding="utf-8") as stream:
        return json.load(stream)


def load_host(host_path, expected_sha, deps_path):
    actual = sha256(host_path)
    if actual != expected_sha:
        raise RuntimeError("host source SHA-256 mismatch: expected %s, got %s" % (expected_sha, actual))
    if not deps_path.is_dir():
        raise RuntimeError("pinned dependency directory is missing: %s" % deps_path)
    deps = str(deps_path)
    if deps not in sys.path:
        sys.path.insert(0, deps)
    module_name = "q30_compiled_attribute_host_%s" % os.getpid()
    spec = importlib.util.spec_from_file_location(module_name, host_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load the hash-bound host source")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, actual


def identity_key(row):
    return (row["pid"], row["created"], (row["ExecutablePath"] or "").casefold())


def current_process_image():
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    get_current = kernel32.GetCurrentProcess
    get_current.argtypes = []
    get_current.restype = wintypes.HANDLE
    query_image = kernel32.QueryFullProcessImageNameW
    query_image.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    query_image.restype = wintypes.BOOL
    buffer = ctypes.create_unicode_buffer(32768)
    length = wintypes.DWORD(len(buffer))
    if not query_image(get_current(), 0, buffer, ctypes.byref(length)):
        raise ctypes.WinError(ctypes.get_last_error())
    return str(Path(buffer.value).resolve(strict=True))


def same_executable_file(observed, expected):
    try:
        return Path(observed).is_file() and Path(expected).is_file() and Path(observed).samefile(Path(expected))
    except OSError:
        return False


def identity_summary(row):
    return {"pid": row["pid"], "created": row["created"], "executable": row["ExecutablePath"]}


def row_by_pid(rows, pid):
    matches = [row for row in rows if row["pid"] == pid]
    if len(matches) != 1:
        raise RuntimeError("process inventory did not contain exactly one PID %s" % pid)
    return matches[0]


def require_same_identity(rows, expected, label):
    observed = row_by_pid(rows, expected["pid"])
    if identity_key(observed) != (expected["pid"], expected["created"], expected["executable"].casefold()):
        raise RuntimeError("%s identity changed: expected %r, observed %r" % (label, expected, identity_summary(observed)))
    return observed


def edge_identities(rows):
    output = []
    for row in rows:
        if "msedge.exe" in (row.get("ExecutablePath") or "").casefold():
            output.append(identity_summary(row))
    return sorted(output, key=lambda item: item["pid"])


def row_identity_set(rows):
    return {identity_key(row) for row in rows}


def descendant_pid_set(rows, root_pid):
    process_ids = {root_pid}
    while True:
        expanded = set(process_ids)
        for row in rows:
            if row["parent"] in process_ids:
                expanded.add(row["pid"])
        if expanded == process_ids:
            return process_ids - {root_pid}
        process_ids = expanded


def edge_identity_keys(items):
    return {(item["pid"], item["created"], item["executable"].casefold()) for item in items}


def parser_negative_fixtures(host):
    """Exercise the actual parser with mocked subprocess results only."""
    own_pid = os.getpid()
    valid = {"pid": own_pid, "parent": 1,
             "created": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
             "ExecutablePath": str(Path(sys.executable))}
    other = dict(valid, pid=own_pid + 1000000)
    fixtures = [
        ("empty-zero-exit", 0, "", "", "empty inventory"),
        ("empty-list-zero-exit", 0, "[]", "", "invalid inventory"),
        ("malformed-json", 0, "{", "", "JSONDecodeError"),
        ("partial-row", 0, json.dumps({"pid": own_pid, "parent": 1}), "", "malformed or duplicate row"),
        ("missing-own-pid", 0, json.dumps(other), "", "omitted the runner identity"),
        ("duplicate-own-pid", 0, json.dumps([valid, valid]), "", "malformed or duplicate row"),
        ("nonzero-empty-stderr", 1, "", "", "process identity query failed"),
    ]
    evidence = []
    for name, returncode, stdout, stderr, expected in fixtures:
        result = SimpleNamespace(returncode=returncode, stdout=stdout, stderr=stderr)
        try:
            with patch.object(host.subprocess, "run", return_value=result):
                host.process_rows()
        except Exception as error:
            message = "%s: %s" % (type(error).__name__, error)
            passed = expected.casefold() in message.casefold()
            if name == "nonzero-empty-stderr":
                passed = passed and '"stderrLength": 0' in message and '"returnCode": 1' in message
            evidence.append({"name": name, "status": "PASS" if passed else "FAIL",
                             "expectedDiagnostic": expected, "observed": message})
        else:
            evidence.append({"name": name, "status": "FAIL", "expectedDiagnostic": expected,
                             "observed": "parser accepted the synthetic invalid result"})
    return evidence


def save_worker_response(directory, sequence, kind, payload):
    write_json(directory / "response.json", {"sequence": sequence, "kind": kind,
                                              "writtenUtc": utc_now(), "payload": payload})


async def bounded_process_rows(host):
    return await asyncio.wait_for(asyncio.to_thread(host.process_rows), timeout=QUERY_TIMEOUT_SECONDS)


async def worker_main(args):
    worker_dir = Path(args.worker_dir).resolve()
    profile = Path(args.profile).resolve()
    command_path = worker_dir / "command.json"
    response_path = worker_dir / "response.json"
    role = args.worker_role
    host_path = Path(args.host_path).resolve(strict=True)
    deps_path = Path(args.deps).resolve(strict=True)
    record = {"role": role, "status": "RUNNING", "startedUtc": utc_now(),
              "profile": str(profile), "pid": os.getpid(), "pythonVersion": sys.version}
    context = None
    playwright = None
    host = None
    last_sequence = -1
    try:
        if sys.version_info[:2] != (3, 13):
            raise RuntimeError("worker must run CPython 3.13")
        if profile.exists():
            raise RuntimeError("browser profile path already exists; refusing to reuse it")
        host, host_sha = load_host(host_path, args.expected_host_sha256, deps_path)
        if not same_executable_file(current_process_image(), args.python_executable):
            raise RuntimeError("worker interpreter does not resolve to the supervisor's CIM-reported executable")
        version = importlib.metadata.version("playwright")
        if not version.startswith("1.63"):
            raise RuntimeError("expected pinned Playwright 1.63, found %s" % version)
        from playwright.async_api import async_playwright
        playwright = await async_playwright().start()
        context = await asyncio.wait_for(
            playwright.chromium.launch_persistent_context(str(profile), channel="msedge", headless=True),
            timeout=45)
        pages = context.pages
        page = pages[0] if pages else await asyncio.wait_for(context.new_page(), timeout=15)
        rows = await bounded_process_rows(host)
        self_row = row_by_pid(rows, os.getpid())
        owned = host.owned_edge_rows(rows)
        if not owned:
            raise RuntimeError("worker has no Edge descendants in the live process tree")
        record.update({"hostSha256": host_sha, "playwrightVersion": version,
                       "runner": identity_summary(self_row), "initialEdgeProcesses": edge_identities(owned),
                       "edgeCount": len(owned), "initialPageUrl": page.url})
        write_json(worker_dir / "worker-start.json", record)
        save_worker_response(worker_dir, 0, "ready", {"role": role, "runner": record["runner"],
                                                        "edgeProcesses": record["initialEdgeProcesses"],
                                                        "edgeCount": len(owned), "profile": str(profile),
                                                        "playwrightVersion": version})
        while True:
            try:
                command = read_json(command_path)
            except FileNotFoundError:
                await asyncio.sleep(0.05)
                continue
            sequence = command.get("sequence") if isinstance(command, dict) else None
            if type(sequence) is not int or sequence <= last_sequence:
                await asyncio.sleep(0.05)
                continue
            op = command.get("op")
            last_sequence = sequence
            if op == "verify":
                peer = command.get("peer")
                rows = await bounded_process_rows(host)
                self_row = row_by_pid(rows, os.getpid())
                if identity_key(self_row) != (record["runner"]["pid"], record["runner"]["created"],
                                               record["runner"]["executable"].casefold()):
                    raise RuntimeError("worker Python identity changed during ownership check")
                peer_row = require_same_identity(rows, peer["runner"], role + " peer worker")
                own_now = edge_identities(host.owned_edge_rows(rows))
                all_keys = row_identity_set(rows)
                own_keys = edge_identity_keys(own_now)
                peer_edge_keys = edge_identity_keys(peer["edgeProcesses"])
                descendants = descendant_pid_set(rows, os.getpid())
                if not own_now:
                    raise RuntimeError("worker lost all owned Edge descendants during ownership check")
                if not peer_edge_keys or not peer_edge_keys.issubset(all_keys):
                    raise RuntimeError("peer Edge identities are not visible in the shared process inventory")
                if peer_row["pid"] in descendants or any(key[0] in descendants for key in peer_edge_keys):
                    raise RuntimeError("peer worker or Edge process appeared in this worker's descendant tree")
                if peer_edge_keys.intersection(own_keys):
                    raise RuntimeError("owned Edge filter incorrectly included peer browser processes")
                payload = {"role": role, "runner": identity_summary(self_row),
                           "peerRunnerVisible": identity_summary(peer_row),
                           "ownedEdgeProcesses": own_now, "peerEdgeProcessesVisible": peer["edgeProcesses"],
                           "peerWorkerExcludedFromOwnedTree": peer_row["pid"] not in descendants,
                           "peerEdgesExcludedFromOwnedTree": True,
                           "inventoryRowCount": len(rows), "descendantCount": len(descendants)}
                save_worker_response(worker_dir, sequence, "verified", payload)
            elif op == "close":
                if context is not None:
                    await asyncio.wait_for(context.close(), timeout=30)
                    context = None
                if playwright is not None:
                    await asyncio.wait_for(playwright.stop(), timeout=30)
                    playwright = None
                rows = await bounded_process_rows(host)
                self_row = row_by_pid(rows, os.getpid())
                all_keys = row_identity_set(rows)
                initial_edge_keys = edge_identity_keys(record["initialEdgeProcesses"])
                remaining_owned_edges = edge_identities(host.owned_edge_rows(rows))
                if remaining_owned_edges:
                    raise RuntimeError("browser close left Edge descendants in the owned process tree: %r" %
                                       remaining_owned_edges)
                if initial_edge_keys.intersection(all_keys):
                    raise RuntimeError("closed browser still has one or more original Edge identities")
                peer = command.get("peer")
                peer_payload = None
                if peer is not None:
                    peer_row = require_same_identity(rows, peer["runner"], role + " peer worker after close")
                    peer_keys = edge_identity_keys(peer["edgeProcesses"])
                    if not peer_keys.issubset(all_keys):
                        raise RuntimeError("unrelated peer Edge tree did not remain alive after close")
                    peer_payload = {"runner": identity_summary(peer_row),
                                    "edgeProcessesStillVisible": peer["edgeProcesses"]}
                payload = {"role": role, "runner": identity_summary(self_row),
                           "originalEdgeProcessesAbsent": True,
                           "peerStillAlive": peer_payload, "inventoryRowCount": len(rows)}
                record["closedUtc"] = utc_now()
                record["closeReceipt"] = payload
                write_json(worker_dir / "worker-closed.json", record)
                save_worker_response(worker_dir, sequence, "closed", payload)
            elif op == "exit":
                record.update({"status": "PASS", "finishedUtc": utc_now()})
                write_json(worker_dir / "worker-exit.json", record)
                save_worker_response(worker_dir, sequence, "exited", {"role": role, "runner": record["runner"]})
                return 0
            else:
                raise RuntimeError("unknown worker command: %r" % op)
    except BaseException as error:
        record.update({"status": "FAIL", "finishedUtc": utc_now(),
                       "error": {"type": type(error).__name__, "message": str(error),
                                 "traceback": traceback.format_exc()}})
        try:
            write_json(worker_dir / "worker-error.json", record)
            save_worker_response(worker_dir, max(last_sequence + 1, 0), "error", record["error"])
        except Exception:
            pass
        return 1
    finally:
        cleanup_errors = []
        if context is not None:
            try:
                await asyncio.wait_for(context.close(), timeout=30)
            except Exception as error:
                cleanup_errors.append("context.close: %s: %s" % (type(error).__name__, error))
        if playwright is not None:
            try:
                await asyncio.wait_for(playwright.stop(), timeout=30)
            except Exception as error:
                cleanup_errors.append("playwright.stop: %s: %s" % (type(error).__name__, error))
        if cleanup_errors:
            record.setdefault("cleanupErrors", []).extend(cleanup_errors)
            record["status"] = "FAIL"
            try:
                write_json(worker_dir / "worker-finally-cleanup.json", record)
            except Exception:
                pass


class Worker:
    def __init__(self, role, process, directory, profile, runner, edge_processes):
        self.role = role
        self.process = process
        self.directory = directory
        self.profile = profile
        self.runner = runner
        self.edge_processes = edge_processes
        self.sequence = 0
        self.pending = False
        self.pending_kind = None
        self.closed = False
        self.exited = False
        self.stdout = b""
        self.stderr = b""

    def peer_document(self):
        return {"runner": self.runner, "edgeProcesses": self.edge_processes}


async def wait_for_response(worker, sequence, expected_kind, timeout):
    deadline = time.monotonic() + timeout
    path = worker.directory / "response.json"
    while time.monotonic() < deadline:
        if path.exists():
            try:
                response = read_json(path)
            except (OSError, json.JSONDecodeError):
                response = None
            if response and response.get("sequence") == sequence:
                worker.pending = False
                if response.get("kind") == "error":
                    raise RuntimeError("%s worker failed: %s" % (worker.role, response.get("payload")))
                if response.get("kind") != expected_kind:
                    raise RuntimeError("%s worker returned %r, expected %r" %
                                       (worker.role, response.get("kind"), expected_kind))
                return response["payload"]
        if worker.process.returncode is not None:
            raise RuntimeError("%s worker exited early with rc=%s" % (worker.role, worker.process.returncode))
        await asyncio.sleep(0.05)
    raise TimeoutError("%s worker did not return %s within %.1fs" % (worker.role, expected_kind, timeout))


async def command_worker(worker, operation, expected_kind, payload=None, timeout=WORKER_COMMAND_SECONDS):
    worker.sequence += 1
    seq = worker.sequence
    command = {"sequence": seq, "op": operation, "issuedUtc": utc_now()}
    if payload:
        command.update(payload)
    write_json(worker.directory / "command.json", command)
    worker.pending = True
    worker.pending_kind = expected_kind
    response = await wait_for_response(worker, seq, expected_kind, timeout)
    worker.pending_kind = None
    if operation == "close":
        worker.closed = True
    if operation == "exit":
        worker.exited = True
    return response


async def read_child_output(worker, timeout=3):
    if worker.process.returncode is None:
        try:
            await asyncio.wait_for(worker.process.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            return False
    try:
        stdout, stderr = await asyncio.wait_for(worker.process.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        return False
    worker.stdout, worker.stderr = stdout, stderr
    (worker.directory / "worker-stdout.bin").write_bytes(stdout)
    (worker.directory / "worker-stderr.bin").write_bytes(stderr)
    if (worker.directory / "worker-finally-cleanup.json").exists():
        raise RuntimeError("%s worker reported a cleanup failure in its final receipt" % worker.role)
    if (worker.directory / "worker-error.json").exists():
        raise RuntimeError("%s worker preserved an error receipt" % worker.role)
    if worker.process.returncode != 0:
        raise RuntimeError("%s worker exit code %s; stderr bytes=%d" %
                           (worker.role, worker.process.returncode, len(stderr)))
    return True


async def spawn_worker(args, root, host, role, workers):
    worker_dir = root / "workers" / role
    worker_dir.mkdir(parents=True, exist_ok=False)
    profile = root / "profiles" / role
    if profile.exists():
        raise RuntimeError("profile path already exists: %s" % profile)
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(args.deps) + (os.pathsep + existing_pythonpath if existing_pythonpath else "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    command = [args.actual_python_executable, "-B", str(Path(__file__).resolve()), "--worker-role", role,
               "--worker-dir", str(worker_dir), "--profile", str(profile),
               "--host-path", str(args.host_path), "--deps", str(args.deps),
               "--expected-host-sha256", args.expected_host_sha256,
               "--python-executable", args.actual_python_executable]
    started = time.monotonic()
    process = await asyncio.create_subprocess_exec(*command, env=env,
                                                   stdout=asyncio.subprocess.PIPE,
                                                   stderr=asyncio.subprocess.PIPE,
                                                   cwd=str(WORKSPACE))
    worker = Worker(role, process, worker_dir, profile,
                    {"pid": process.pid, "created": "PENDING", "executable": str(sys.executable)}, [])
    workers.append(worker)
    rows = await bounded_process_rows(host)
    own = row_by_pid(rows, process.pid)
    worker.runner = identity_summary(own)
    if not own["ExecutablePath"] or not same_executable_file(own["ExecutablePath"], args.actual_python_executable):
        raise RuntimeError("spawned worker PID is not the expected CPython executable")
    response = await wait_for_response(worker, 0, "ready", WORKER_READY_SECONDS)
    ready_runner = response.get("runner")
    if (response.get("role") != role or not isinstance(ready_runner, dict)
            or ready_runner.get("pid") != worker.runner["pid"]
            or ready_runner.get("created") != worker.runner["created"]
            or not same_executable_file(ready_runner.get("executable") or "", args.actual_python_executable)):
        raise RuntimeError("worker ready identity does not match its live parent observation")
    if response.get("playwrightVersion", "").split(".")[:2] != ["1", "63"]:
        raise RuntimeError("worker did not report pinned Playwright 1.63")
    edges = response.get("edgeProcesses")
    if not isinstance(edges, list) or not edges:
        raise RuntimeError("worker ready receipt did not contain Edge identities")
    worker.edge_processes = edges
    worker.pending_kind = None
    worker.readySeconds = time.monotonic() - started
    return worker


async def parent_process_rows(host):
    return await bounded_process_rows(host)


def assert_edge_set_present(rows, edges, label):
    actual = row_identity_set(rows)
    expected = edge_identity_keys(edges)
    if not expected or not expected.issubset(actual):
        raise RuntimeError("%s Edge process identities are missing from the system inventory" % label)


def assert_edge_set_absent(rows, edges, label):
    actual = row_identity_set(rows)
    expected = edge_identity_keys(edges)
    survivors = expected.intersection(actual)
    if survivors:
        raise RuntimeError("%s still has captured Edge process identities: %r" % (label, sorted(survivors)))


async def close_worker_safely(worker, peer=None, errors=None):
    errors = errors if errors is not None else []
    if worker.exited or worker.process.returncode is not None:
        return
    try:
        if worker.pending:
            await wait_for_response(worker, worker.sequence, worker.pending_kind or "verified", 30)
            worker.pending = False
            worker.pending_kind = None
        if not worker.closed:
            payload = {"peer": peer.peer_document()} if peer and not peer.exited else {}
            await command_worker(worker, "close", "closed", payload, timeout=45)
        await command_worker(worker, "exit", "exited", timeout=20)
        if not await read_child_output(worker, timeout=5):
            errors.append("%s process did not exit after graceful close" % worker.role)
    except Exception as error:
        errors.append("%s graceful cleanup: %s: %s" % (worker.role, type(error).__name__, error))


async def run_live_canary(args, root, host, record):
    workers = []
    try:
        target = await spawn_worker(args, root, host, "target", workers)
        record["targetReady"] = {"runner": target.runner, "edgeProcesses": target.edge_processes,
                                  "readySeconds": target.readySeconds}
        write_json(root / "result.json", record)
        peer = await spawn_worker(args, root, host, "unrelated", workers)
        record["unrelatedReady"] = {"runner": peer.runner, "edgeProcesses": peer.edge_processes,
                                     "readySeconds": peer.readySeconds}
        write_json(root / "result.json", record)

        # Both workers independently query the real full system inventory and
        # apply the selected host's actual descendant filter.
        target_check = await command_worker(target, "verify", "verified", {"peer": peer.peer_document()})
        peer_check = await command_worker(peer, "verify", "verified", {"peer": target.peer_document()})
        record["mutualOwnership"] = {"target": target_check, "unrelated": peer_check}
        rows = await parent_process_rows(host)
        require_same_identity(rows, target.runner, "target worker before close")
        require_same_identity(rows, peer.runner, "unrelated worker before close")
        assert_edge_set_present(rows, target.edge_processes, "target")
        assert_edge_set_present(rows, peer.edge_processes, "unrelated")
        write_json(root / "result.json", record)

        target_close = await command_worker(target, "close", "closed",
                                            {"peer": peer.peer_document()}, timeout=45)
        record["targetClose"] = target_close
        rows_after_target_close = await parent_process_rows(host)
        require_same_identity(rows_after_target_close, target.runner, "target worker after browser close")
        require_same_identity(rows_after_target_close, peer.runner, "unrelated worker after target close")
        assert_edge_set_absent(rows_after_target_close, target.edge_processes, "closed target")
        assert_edge_set_present(rows_after_target_close, peer.edge_processes, "unrelated after target close")
        record["targetEdgeProcessesAbsentWhilePeerRemains"] = True

        await command_worker(target, "exit", "exited", timeout=WORKER_EXIT_SECONDS)
        if not await read_child_output(target, timeout=WORKER_EXIT_SECONDS):
            raise TimeoutError("target Python worker did not exit after its graceful close")
        rows_after_target_exit = await parent_process_rows(host)
        if any(identity_key(row) == (target.runner["pid"], target.runner["created"],
                                    target.runner["executable"].casefold()) for row in rows_after_target_exit):
            raise RuntimeError("target Python worker remained after its explicit exit")
        require_same_identity(rows_after_target_exit, peer.runner, "unrelated worker after target exit")
        assert_edge_set_present(rows_after_target_exit, peer.edge_processes, "unrelated after target exit")
        record["targetWorkerGonePeerStillAlive"] = True

        peer_close = await command_worker(peer, "close", "closed", timeout=45)
        record["unrelatedClose"] = peer_close
        rows_after_peer_close = await parent_process_rows(host)
        require_same_identity(rows_after_peer_close, peer.runner, "unrelated worker after browser close")
        assert_edge_set_absent(rows_after_peer_close, peer.edge_processes, "closed unrelated worker")
        await command_worker(peer, "exit", "exited", timeout=WORKER_EXIT_SECONDS)
        if not await read_child_output(peer, timeout=WORKER_EXIT_SECONDS):
            raise TimeoutError("unrelated Python worker did not exit after its graceful close")

        final_rows = await parent_process_rows(host)
        for label, worker in (("target", target), ("unrelated", peer)):
            key = (worker.runner["pid"], worker.runner["created"], worker.runner["executable"].casefold())
            if key in row_identity_set(final_rows):
                raise RuntimeError("%s Python worker identity remains after exit" % label)
            assert_edge_set_absent(final_rows, worker.edge_processes, label)
        record["finalProcessInventory"] = {"rowCount": len(final_rows),
                                           "targetWorkerAbsent": True,
                                           "unrelatedWorkerAbsent": True,
                                           "targetEdgeProcessesAbsent": True,
                                           "unrelatedEdgeProcessesAbsent": True}
        return {"status": "PASS", "workers": workers}
    except BaseException:
        cleanup_errors = []
        for index, worker in enumerate(workers):
            peer = next((other for other in workers if other is not worker and not other.exited
                         and other.process.returncode is None), None)
            await close_worker_safely(worker, peer=peer, errors=cleanup_errors)
        record["gracefulFailureCleanupErrors"] = cleanup_errors
        record["workerTerminalStates"] = [
            {"role": worker.role, "returnCode": worker.process.returncode,
             "closed": worker.closed, "exited": worker.exited,
             "pid": worker.runner["pid"], "profile": str(worker.profile)} for worker in workers]
        raise


async def main_async(args):
    global LAST_OUTPUT_ROOT
    if args.worker_role:
        return await worker_main(args)

    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("canary must run with CPython 3.13")
    args.host_path = args.host_path.resolve(strict=True)
    args.deps = args.deps.resolve(strict=True)
    if not args.host_path.is_file():
        raise RuntimeError("host source is missing")
    if not args.deps.is_dir():
        raise RuntimeError("pinned dependency directory is missing")
    if args.expected_host_sha256 not in APPROVED_HOST_SHA256S:
        raise RuntimeError("requested host SHA does not match either approved selected host")
    temp_root = Path(os.environ.get("TEMP", tempfile.gettempdir())).resolve()
    output_root = args.output_root
    if output_root is None:
        output_root = temp_root / ("q30-process-identity-canary-" + uuid.uuid4().hex)
    output_root = output_root.resolve(strict=False)
    if output_root.parent != temp_root or output_root.exists():
        raise RuntimeError("output root must be a new direct child of TEMP")
    LAST_OUTPUT_ROOT = output_root
    pointer_path = args.pointer_path.resolve(strict=False)
    if pointer_path.exists():
        raise RuntimeError("process-identity pointer already exists; refusing to overwrite it")

    output_root.mkdir(parents=False, exist_ok=False)
    (output_root / "workers").mkdir()
    (output_root / "profiles").mkdir()
    helper_source = Path(__file__).resolve(strict=True)
    helper_sha = sha256(helper_source)
    host_sha = sha256(args.host_path)
    if host_sha != args.expected_host_sha256:
        raise RuntimeError("host source SHA changed before canary setup")
    helper_copy = output_root / "canary-source.py"
    host_copy = output_root / "draft-host-source.py"
    shutil.copyfile(helper_source, helper_copy)
    shutil.copyfile(args.host_path, host_copy)
    if sha256(helper_copy) != helper_sha or sha256(host_copy) != host_sha:
        raise RuntimeError("evidence source copy hash mismatch")

    record = {"schemaVersion": 1, "status": "RUNNING", "startedUtc": utc_now(),
              "root": str(output_root), "hostSha256": host_sha, "helperSha256": helper_sha,
              "pythonVersion": sys.version, "playwrightVersion": None,
              "dependencyLabel": "caller-supplied pinned CPython 3.13 Playwright 1.63 directory",
              "outputPolicy": "preserve all files; no process kill or profile deletion",
              "parserNegativeFixtures": [], "phases": []}
    result_path = output_root / "result.json"
    write_json(result_path, record)
    operation_start = time.monotonic()
    try:
        host, observed_host_sha = load_host(args.host_path, args.expected_host_sha256, args.deps)
        if observed_host_sha != host_sha:
            raise RuntimeError("loaded host identity changed")
        version = importlib.metadata.version("playwright")
        if not version.startswith("1.63"):
            raise RuntimeError("expected Playwright 1.63, found %s" % version)
        from playwright.async_api import async_playwright  # noqa: F401
        record["playwrightVersion"] = version
        phase_start = time.monotonic()
        record["parserNegativeFixtures"] = parser_negative_fixtures(host)
        write_json(result_path, record)
        if any(row["status"] != "PASS" for row in record["parserNegativeFixtures"]):
            raise RuntimeError("one or more process parser negative fixtures failed")
        record["phases"].append({"name": "parser-negative-fixtures", "status": "PASS",
                                 "seconds": time.monotonic() - phase_start})
        write_json(result_path, record)

        phase_start = time.monotonic()
        rows, self_identity = await current_identity_async(host)
        args.actual_python_executable = self_identity["executable"]
        if not same_executable_file(args.actual_python_executable, current_process_image()):
            raise RuntimeError("CIM and Windows process-image identities differ")
        record["supervisorIdentity"] = self_identity
        record["supervisorInitialInventoryRows"] = len(rows)
        record["phases"].append({"name": "selected-process-query", "status": "PASS",
                                 "seconds": time.monotonic() - phase_start})
        write_json(result_path, record)

        live = await run_live_canary(args, output_root, host, record)
        if live["status"] != "PASS":
            raise RuntimeError("live process ownership canary did not pass")
        record["phases"].append({"name": "two-worker-live-ownership-and-cleanup", "status": "PASS"})
        record["status"] = "PASS"
        record["finishedUtc"] = utc_now()
        record["operationSeconds"] = time.monotonic() - operation_start
        write_json(result_path, record)
        pointer = {"root": str(output_root)}
        with pointer_path.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(pointer, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        record["pointerPath"] = str(pointer_path)
        write_json(result_path, record)
        return 0
    except BaseException as error:
        record.update({"status": "FAIL", "finishedUtc": utc_now(),
                       "operationSeconds": time.monotonic() - operation_start,
                       "error": {"type": type(error).__name__, "message": str(error),
                                 "traceback": traceback.format_exc()}})
        write_json(result_path, record)
        return 1


async def current_identity_async(host):
    rows = await bounded_process_rows(host)
    own = row_by_pid(rows, os.getpid())
    if not own["ExecutablePath"]:
        raise RuntimeError("supervisor process has no executable identity")
    return rows, identity_summary(own)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host-path", type=Path, default=DEFAULT_HOST)
    parser.add_argument("--deps", type=Path, default=DEFAULT_DEPS)
    parser.add_argument("--expected-host-sha256", "--host-sha256", dest="expected_host_sha256",
                        default=EXPECTED_HOST_SHA256)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--pointer-path", type=Path, default=WORKSPACE / POINTER_NAME)
    parser.add_argument("--worker-role", choices=("target", "unrelated"))
    parser.add_argument("--worker-dir")
    parser.add_argument("--profile")
    parser.add_argument("--python-executable")
    return parser.parse_args(argv)


def entrypoint():
    args = parse_args()
    try:
        code = asyncio.run(main_async(args))
        if not args.worker_role:
            result_root = args.output_root or LAST_OUTPUT_ROOT
            result_path = (result_root / "result.json") if result_root else None
            if result_path and result_path.exists():
                result = read_json(result_path)
                print(json.dumps({"status": result.get("status"), "root": result.get("root"),
                                  "hostSha256": result.get("hostSha256"),
                                  "pointerPath": result.get("pointerPath")}, separators=(",", ":")), flush=True)
            else:
                print(json.dumps({"status": "PASS" if code == 0 else "FAIL", "exitCode": code}), flush=True)
        return code
    except BaseException as error:
        print(json.dumps({"status": "FAIL", "errorType": type(error).__name__,
                          "error": str(error), "traceback": traceback.format_exc()}, separators=(",", ":")), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(entrypoint())
