"""Real selected-host canaries; deliberate negatives must retain fatal signals."""
import asyncio
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time
import uuid
from playwright.async_api import async_playwright
workspace = Path(__file__).resolve().parent
source = workspace / 'process-identity-draft/compiled_attribute_acceptance.py'
root = Path(os.environ['TEMP']) / ('q30-selected-transport-' + uuid.uuid4().hex)
root.mkdir()
app = root / 'app'
(app / 'src').mkdir(parents=True)
(app / 'war').mkdir()
(app / 'src/transport-fixture.txt').write_text('Transport-only HTML fixtures, no electrical model.\n', encoding='utf-8')
replacement = '<html data-tsj-transport="PASS:replacement" data-tsj-transport-report=\'{"fixture":"replacement"}\'><body>Replacement</body></html>'
stale_document = '<html data-tsj-transport="PASS:stale-document" data-tsj-transport-report=\'{"fixture":"stale-document"}\'><body>Successor</body></html>'
html = '''<!doctype html><html><head><script>
const mode=new URL(location.href).searchParams.get('mode');
function emit(state, report=true) {
 if(report)document.documentElement.setAttribute('data-tsj-transport-report',JSON.stringify({fixture:mode}));
 document.documentElement.setAttribute('data-tsj-transport',state);
}
if(mode==='slow')setTimeout(()=>{const start=performance.now();while(performance.now()-start<12000){}emit('PASS:slow');},500);
else if(mode==='script-startup'||mode==='script-slow')document.write('<script src="circuitjs1/00000000000000000000000000000000.cache.js?mode='+mode+'"></'+'script>');
else if(mode==='script-duplicate')document.write('<script src="circuitjs1/00000000000000000000000000000000.cache.js?mode='+mode+'&n=1"></'+'script><script src="circuitjs1/00000000000000000000000000000000.cache.js?mode='+mode+'&n=2"></'+'script>');
else if(mode==='negative')emit('FAIL:negative');
else if(mode==='no-terminal')setTimeout(()=>{document.body.setAttribute('data-tsj-transport','PASS:wrong-node');},50);
else if(mode==='wrong-target')setTimeout(()=>{document.body.setAttribute('data-tsj-transport','PASS:wrong-node');setTimeout(()=>emit('PASS:wrong-target'),300);},50);
else if(mode==='replacement')setTimeout(()=>{document.open();document.write(REPLACEMENT);document.close();},500);
else if(mode==='immediate')emit('PASS:immediate');
else if(mode==='malformed'){document.documentElement.setAttribute('data-tsj-transport-report','{invalid');emit('PASS:malformed',false);}
else if(mode==='missing-report')emit('PASS:missing-report',false);
else if(mode==='page-error'){setTimeout(()=>{throw new Error('transport-pageerror-marker');},0);setTimeout(()=>emit('PASS:page-error'),100);}
else if(mode==='console-error'){console.error('transport-console-marker');emit('PASS:console-error');}
else if(mode==='http-error'){fetch('/transport-missing-file').then(()=>emit('PASS:http-error'));}
else if(mode==='missing-html')setTimeout(()=>{emit('PASS:missing-html');document.documentElement.remove();},300);
else if(mode==='stale-state'||mode==='stale-document'||mode==='stale-same-url')emit('PASS:'+mode);
</script></head><body>Selected transport fixture</body></html>'''.replace('REPLACEMENT',json.dumps(replacement)).replace('STALE_DOCUMENT',json.dumps(stale_document))
(app / 'war/circuitjs.html').write_text(html, encoding='utf-8')
(app / 'war/circuitjs1').mkdir()
(app / 'war/circuitjs1/00000000000000000000000000000000.cache.js').write_text(
    "const cacheMode=new URL(location.href).searchParams.get('mode');if(cacheMode==='script-slow'){const start=performance.now();while(performance.now()-start<12000){}}document.documentElement.setAttribute('data-tsj-transport-report',JSON.stringify({fixture:cacheMode}));document.documentElement.setAttribute('data-tsj-transport','PASS:'+cacheMode);",encoding='utf-8')
module_spec = importlib.util.spec_from_file_location('selected_host', source)
host = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(host)
names = ['script-startup','script-slow','script-duplicate','slow','negative','no-terminal','wrong-target','replacement','immediate','malformed','missing-report','page-error','console-error','http-error','missing-html','stale-state','stale-document','stale-same-url']
cases = []
for name in names:
    cases.append({'name':name,'path':'circuitjs.html?mode='+name,'stateAttribute':'data-tsj-transport',
                  'timeoutSeconds':3 if name=='no-terminal' else 30,
                  'expectedState':('FAIL:' if name=='negative' else 'PASS:')+name,
                  **({} if name=='no-terminal' else {'reportAttribute':'data-tsj-transport-report'})})
spec_path = root / 'spec.json'
spec_path.write_text(json.dumps({'cases':cases},indent=2)+'\n',encoding='utf-8')
record = {'status':'RUNNING','startedUtc':datetime.now(timezone.utc).isoformat(),'root':str(root),
          'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'identity':next(row for row in host.process_rows() if row['pid']==os.getpid())}
def save(): (root / 'canary-result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()

async def closed_page_canary():
    profile = root / 'closed-page-profile'
    context = None
    playwright = None
    owned = []
    detail = {'status':'RUNNING','profile':str(profile)}
    try:
        playwright = await async_playwright().start()
        context = await playwright.chromium.launch_persistent_context(str(profile),channel='msedge',headless=True)
        owned = host.owned_edge_rows(host.process_rows())
        assert owned
        detail['owned']=owned
        (root/'closed-page-identity.json').write_text(json.dumps(detail,indent=2)+'\n',encoding='utf-8')
        page = context.pages[0] if context.pages else await context.new_page()
        await page.close()
        case = host.normalise_case({'name':'closed-page','path':'circuitjs.html','stateAttribute':'data-tsj-transport',
                                    'expectedState':'PASS:closed-page','timeoutSeconds':3},1)
        output = root/'closed-page'
        output.mkdir()
        receipt = await host.run_case(page,'http://127.0.0.1:1',case,output)
        detail['receipt']=receipt
        assert receipt['outcome']=='FAIL' and receipt['observerErrors'], receipt
        assert any(row['phase']=='DOM.start' for row in receipt['observerErrors'])
        detail['status']='PASS_NEGATIVE_PROOF'
    except Exception as error:
        detail['status']='FAIL'; detail['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        cleanup_start=time.monotonic()
        errors=[]
        if context is not None:
            try:
                owned=list({(row['pid'],row['created']):row for row in owned+host.owned_edge_rows(host.process_rows())}.values())
                await asyncio.wait_for(context.close(),timeout=30)
            except Exception as error: errors.append(str(error))
        if playwright is not None:
            try: await asyncio.wait_for(playwright.stop(),timeout=30)
            except Exception as error: errors.append(str(error))
        saved={(row['pid'],row['created']) for row in owned}
        survivors=[row for row in host.process_rows() if (row['pid'],row['created']) in saved]
        detail['cleanup']={'status':'PASS' if not errors and not survivors else 'FAIL',
                           'seconds':time.monotonic()-cleanup_start,'ownedSurvivors':survivors,'errors':errors}
        if detail['cleanup']['status']!='PASS':detail['status']='FAIL'
        (root/'closed-page-result.json').write_text(json.dumps(detail,indent=2)+'\n',encoding='utf-8')
    return detail

async def main():
    started=time.monotonic()
    try:
        # Test-only orchestration mutates actual fixture DOM through real CDP
        # after both reads; the production observer itself never injects code.
        original_scope=host.HtmlAttributeObserver.verify_terminal_scope
        async def mutate_at_scope_boundary(observer,*arguments):
            expression=None
            if observer.url.endswith('mode=stale-state'):
                expression="document.documentElement.setAttribute('data-tsj-transport','FAIL:changed-after-terminal')"
            elif observer.url.endswith('mode=stale-document'):
                expression='document.open();document.write('+json.dumps(stale_document)+");document.close();history.replaceState({},'',location.href+'&successor=1')"
            elif observer.url.endswith('mode=stale-same-url'):
                successor=stale_document.replace('stale-document','stale-same-url')
                expression='document.open();document.write('+json.dumps(successor)+');document.close()'
            if expression:
                response=await asyncio.wait_for(observer.session.send('Runtime.evaluate',{'expression':expression}),timeout=10)
                assert 'exceptionDetails' not in response,response
            await original_scope(observer,*arguments)
        host.HtmlAttributeObserver.verify_terminal_scope=mutate_at_scope_boundary
        try:
            code=await host.main(['compiled_attribute_acceptance.py',str(app),str(root/'host'),str(spec_path)])
        finally:
            host.HtmlAttributeObserver.verify_terminal_scope=original_scope
        result=json.loads((root/'host/result.json').read_text(encoding='utf-8'))
        assert code==1 and result['outcome']=='FAIL' and not result['errors']
        assert result['inputAudit']['status']=='PASS' and result['cleanup']['status']=='PASS'
        receipts={row['case']['name']:row for row in result['cases']}
        assert len(receipts)==18
        for name in ['script-startup','script-slow','slow','negative','wrong-target','replacement','immediate']:
            row=receipts[name]
            assert row['outcome']=='PASS', row
            assert not any(row[key] for key in ['pageErrors','httpErrors','consoleErrors','attributeReadErrors','observerErrors','listenerCleanupErrors'])
            assert row['observation']['terminalScopeVerified'] is True
            report=json.loads((root/'host'/row['reportFile']).read_text(encoding='utf-8'))
            assert report=={'fixture':name}, (name,report)
        assert receipts['slow']['operationSeconds']>12
        assert receipts['script-slow']['operationSeconds']>12
        for name in ['script-startup','script-slow']:
            observation=receipts[name]['observation']
            assert observation['compiledScriptsHeld']==1 and observation['scriptAttachment']['exactPageUrl'] is True
            assert observation['scriptAttachment']['resourceType']=='script'
            assert observation['scriptAttachment']['htmlBackend'] is not None
        assert receipts['negative']['expectedFailureCanary']
        assert receipts['wrong-target']['observedState']=='PASS:wrong-target'
        assert receipts['no-terminal']['outcome']=='TIMEOUT' and receipts['no-terminal']['timedOut']
        assert receipts['malformed']['outcome']=='FAIL' and receipts['malformed']['reportJsonValid'] is False
        assert receipts['missing-report']['outcome']=='FAIL' and not receipts['missing-report']['reportObserved']
        for name,key,marker in [('page-error','pageErrors','transport-pageerror-marker'),('console-error','consoleErrors','transport-console-marker'),('http-error','httpErrors','404')]:
            row=receipts[name]
            assert row['outcome']=='FAIL' and marker in json.dumps(row[key]), row
        assert receipts['missing-html']['outcome']=='FAIL' and any(row['type']=='TimeoutError' for row in receipts['missing-html']['attributeReadErrors'])
        assert receipts['script-duplicate']['outcome']=='FAIL' and receipts['script-duplicate']['observation']['compiledScriptsHeld']==2
        assert any(item['phase']=='compiled-script-attachment' for item in receipts['script-duplicate']['observerErrors'])
        for name in ['stale-state','stale-document','stale-same-url']:
            row=receipts[name]
            assert row['outcome']=='FAIL' and any(item['phase']=='terminal-document-scope' for item in row['observerErrors']),row
        same_scope=receipts['stale-same-url']['observation']['scopeIdentity']
        assert same_scope['pageUrlMatches'] and same_scope['documentUrlMatches']
        assert same_scope['htmlBackendBefore'] != same_scope['htmlBackendAfter']
        closed=await closed_page_canary()
        assert closed['status']=='PASS_NEGATIVE_PROOF',closed
        # Detach an actual CDP session unexpectedly; no fake receiver is used.
        loss_spec=root/'loss-spec.json'
        loss_spec.write_text(json.dumps({'cases':[{'name':'observer-loss','path':'circuitjs.html?mode=immediate',
            'stateAttribute':'data-tsj-transport','expectedState':'PASS:immediate','timeoutSeconds':3}]}),encoding='utf-8')
        original_start=host.HtmlAttributeObserver.start
        async def detach_after_start(observer):
            await original_start(observer)
            await observer.session.detach()
        host.HtmlAttributeObserver.start=detach_after_start
        try:
            loss_code=await host.main(['host',str(app),str(root/'loss-host'),str(loss_spec)])
        finally:
            host.HtmlAttributeObserver.start=original_start
        loss=json.loads((root/'loss-host/result.json').read_text(encoding='utf-8'))
        assert loss_code==1 and loss['outcome']=='FAIL' and loss['cleanup']['status']=='PASS',loss
        assert len(loss['cases'])==1 and any(row['phase']=='DOM.session-close' for row in loss['cases'][0]['observerErrors']),loss
        # Cancel the real host while its no-terminal page is being observed.
        cancel_spec=root/'cancel-spec.json'
        cancel_spec.write_text(json.dumps({'cases':[{'name':'cancel','path':'circuitjs.html?mode=no-terminal',
            'stateAttribute':'data-tsj-transport','expectedState':'PASS:cancel','timeoutSeconds':30}]}),encoding='utf-8')
        task=asyncio.create_task(host.main(['host',str(app),str(root/'cancel-host'),str(cancel_spec)]))
        ready_deadline=time.monotonic()+15
        while not (root/'cancel-host/identity.json').is_file() and not task.done() and time.monotonic()<ready_deadline:
            await asyncio.sleep(.05)
        assert (root/'cancel-host/identity.json').is_file() and not task.done(), 'Cancellation host was not live'
        await asyncio.sleep(.4)
        cancelled_at=time.monotonic()
        task.cancel()
        cancel_code=await asyncio.wait_for(asyncio.shield(task),timeout=45)
        cancel=json.loads((root/'cancel-host/result.json').read_text(encoding='utf-8'))
        assert cancel_code==1 and cancel['outcome']=='FAIL' and cancel['cleanup']['status']=='PASS',cancel
        assert any('CancelledError' in row['traceback'] for row in cancel['errors']),cancel
        record['cancelTerminalSeconds']=time.monotonic()-cancelled_at
        assert hashlib.sha256(source.read_bytes()).hexdigest()==record['sourceSha256']
        record.update({'status':'PASS','cases':18,'positiveAndExpectedTerminalCases':7,'fatalNegativeCases':11,
                       'closedPageObserverFailure':'PASS_NEGATIVE_PROOF','hostCleanup':result['cleanup'],
                       'closedPageCleanup':closed['cleanup'],'hostInputAudit':result['inputAudit'],
                       'sessionLossNegative':'PASS','sessionLossCleanup':loss['cleanup'],
                       'cancellationNegative':'PASS','cancellationCleanup':cancel['cleanup']})
    except Exception as error:
        record.update({'status':'FAIL','error':{'type':type(error).__name__,'message':str(error)}})
    record['finishedUtc']=datetime.now(timezone.utc).isoformat()
    record['operationSeconds']=time.monotonic()-started
    save();print(json.dumps(record),flush=True)
    return 0 if record['status']=='PASS' else 1
raise SystemExit(asyncio.run(main()))
