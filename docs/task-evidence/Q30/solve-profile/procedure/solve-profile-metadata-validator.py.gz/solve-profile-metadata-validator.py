"""Strict validation for the new sampled LU-solve profile fields only.

The caller composes this with the existing repetition/preflight validator.
"""
from copy import deepcopy
import math
import re


LU_SOLVE_SCOPE = (
    "actual lu_solve for sampled successful factors at work-scope starts or a "
    "matching adjacent same-generation/revision/analysis comparison; excludes "
    "initial RHS census and triangular census")
TRIANGULAR_STRUCTURE_DEFINITION = (
    "one read-only census after each sampled successful lu_solve; strict lower/upper "
    "triangles exclude diagonal; value == 0 counts both signed zeros")
EXPECTED_SOLVE_CLOCK = "performance.now"


class SolveMetadataValidationError(AssertionError):
    """A solve-profile field or identity does not meet its frozen contract."""


def _need(condition, message):
    if not condition:
        raise SolveMetadataValidationError(message)


def _integer(value, label, minimum=0):
    # json.loads produces ints for integer tokens, but GWT may serialize a
    # JSONNumber with a decimal point. Accept only finite whole numbers; bool
    # must be rejected explicitly because it subclasses int in Python.
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise SolveMetadataValidationError(label + " must be an integer")
    if isinstance(value, float) and (not math.isfinite(value) or not value.is_integer()):
        raise SolveMetadataValidationError(label + " must be a finite whole number")
    result = int(value)
    _need(result >= minimum, label + " is below its minimum")
    return result


def _finite_nonnegative(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise SolveMetadataValidationError(label + " must be a finite number")
    try:
        result = float(value)
    except (OverflowError, ValueError):
        raise SolveMetadataValidationError(label + " must be a finite number")
    _need(math.isfinite(result), label + " must be finite")
    _need(result >= 0.0, label + " must be nonnegative")
    return result


def _ratio_counts(zero_count, nonzero_count, entry_count, label):
    _need(zero_count + nonzero_count == entry_count,
          label + " zero/nonzero counts do not sum to entries")
    if entry_count == 0:
        _need(zero_count == 0 and nonzero_count == 0,
              label + " has counts without triangular entries")
        return None, None
    zero_ratio = zero_count / float(entry_count)
    nonzero_ratio = nonzero_count / float(entry_count)
    _need(math.isfinite(zero_ratio) and math.isfinite(nonzero_ratio) and
          0.0 <= zero_ratio <= 1.0 and 0.0 <= nonzero_ratio <= 1.0,
          label + " density ratios are outside [0,1]")
    _need(math.isclose(zero_ratio + nonzero_ratio, 1.0,
                       rel_tol=0.0, abs_tol=1e-12),
          label + " zero/nonzero density ratios do not sum to one")
    return zero_ratio, nonzero_ratio


def validate_solve_metadata(profile, phase, report):
    """Validate only new lu_solve timing/RHS/triangle fields and sampler ties.

    The existing preflight validator remains responsible for full sampler
    positions, matrix-pair equality, and legacy profile fields. This function
    uses their aggregate counters only to prove that each solve sample came
    from a start or an identity-valid adjacent compare.
    """
    _need(isinstance(phase, str) and phase in ("cold", "warm"),
          "phase must be cold or warm")
    _need(isinstance(profile, dict), phase + " solve profile must be an object")
    _need(profile.get("phase") == phase, phase + " solve profile phase mismatch")
    _need(profile.get("luSolveTimingScope") == LU_SOLVE_SCOPE,
          phase + " lu_solve timing scope changed")
    _need(profile.get("triangularStructureDefinition") == TRIANGULAR_STRUCTURE_DEFINITION,
          phase + " triangular structure definition changed")

    # Existing sampler counters: comparisons are eligible only when their
    # adjacent sample still has the same size/generation/revision/analysis epoch.
    starts = _integer(profile.get("sampledStarts"), phase + " sampledStarts", 1)
    compare_attempts = _integer(profile.get("compareAttempts"),
                                phase + " compareAttempts")
    completed_pairs = _integer(profile.get("completedPairs"),
                               phase + " completedPairs")
    sampled_matrix_inputs = _integer(profile.get("sampledMatrixInputs"),
                                     phase + " sampledMatrixInputs", 1)
    _need(completed_pairs <= compare_attempts <= starts,
          phase + " eligible solve comparisons exceed sampler attempts/starts")
    # The solve metadata contains no per-size split for rejected comparisons,
    # so a qualification sample must have every attempted compare eligible.
    _need(completed_pairs == compare_attempts,
          phase + " has an ineligible adjacent compare without a timed solve")
    _need(sampled_matrix_inputs == starts + compare_attempts,
          phase + " sampled matrix inputs do not equal starts plus compare attempts")
    solve_samples = starts + completed_pairs
    _need(solve_samples <= _integer(profile.get("factorCalls"),
                                    phase + " factorCalls", 1),
          phase + " solve samples exceed counted factor calls")

    raw_groups = profile.get("sampledSizeGroups")
    _need(isinstance(raw_groups, dict) and raw_groups,
          phase + " sampled size groups are missing")
    size_groups = {}
    for raw_size, raw_count in raw_groups.items():
        _need(isinstance(raw_size, str) and
              re.fullmatch(r"[1-9][0-9]*", raw_size) is not None,
              phase + " has a noncanonical sampled matrix size")
        size = int(raw_size)
        _need(size not in size_groups, phase + " has duplicate normalized matrix sizes")
        size_groups[size] = _integer(raw_count,
                                     phase + " sampled size-group count", 1)
    _need(sum(size_groups.values()) == sampled_matrix_inputs == solve_samples,
          phase + " sampled sizes do not bound the eligible solve samples")

    timing_attempts = _integer(profile.get("luSolveTimingAttempts"),
                               phase + " luSolveTimingAttempts", 1)
    timing_completions = _integer(profile.get("luSolveTimingCompletions"),
                                  phase + " luSolveTimingCompletions")
    timing_samples = _integer(profile.get("luSolveTimingSamples"),
                              phase + " luSolveTimingSamples")
    timing_errors = _integer(profile.get("luSolveTimingErrors"),
                             phase + " luSolveTimingErrors")
    native_unavailable = _integer(profile.get("luSolveNativeClockUnavailable"),
                                  phase + " luSolveNativeClockUnavailable")
    successes = _integer(profile.get("luSolveSuccesses"),
                         phase + " luSolveSuccesses")
    failures = _integer(profile.get("luSolveFailures"),
                        phase + " luSolveFailures")
    triangular_samples = _integer(profile.get("triangularStructureSamples"),
                                  phase + " triangularStructureSamples")
    _need(timing_attempts == solve_samples,
          phase + " solve timing attempts differ from starts plus eligible compares")
    _need(timing_completions == timing_attempts and timing_samples == timing_attempts and
          timing_errors == 0,
          phase + " solve timing attempts/completions/samples/errors do not balance")
    _need(successes == timing_attempts and failures == 0 and
          successes + failures == timing_attempts,
          phase + " solve return/failure counters do not show all sampled solves returned")
    _need(triangular_samples == successes,
          phase + " triangular census count differs from successful solves")
    _need(native_unavailable == 0 and profile.get("luSolveClock") == EXPECTED_SOLVE_CLOCK,
          phase + " solve timing did not use the browser performance.now clock")

    rhs_samples = _integer(profile.get("luSolveInitialRhsSamples"),
                           phase + " luSolveInitialRhsSamples")
    rhs_finite = _integer(profile.get("luSolveInitialRhsFiniteValues"),
                          phase + " luSolveInitialRhsFiniteValues")
    rhs_nonfinite = _integer(profile.get("luSolveInitialRhsNonfiniteValues"),
                             phase + " luSolveInitialRhsNonfiniteValues")
    expected_rhs_entries = sum(size * count for size, count in size_groups.items())
    _need(rhs_samples == timing_attempts,
          phase + " initial RHS sample count differs from profiled solve count")
    _need(rhs_finite + rhs_nonfinite == expected_rhs_entries,
          phase + " initial RHS value counts differ from sampled matrix dimensions")
    _need(rhs_nonfinite == 0 and rhs_finite == expected_rhs_entries,
          phase + " sampled solve RHS contains nonfinite entries")

    lower_entries = _integer(profile.get("strictLowerEntries"),
                              phase + " strictLowerEntries")
    lower_zeros = _integer(profile.get("strictLowerExactZeros"),
                           phase + " strictLowerExactZeros")
    lower_nonzeros = _integer(profile.get("strictLowerNonzeros"),
                              phase + " strictLowerNonzeros")
    upper_entries = _integer(profile.get("strictUpperEntries"),
                              phase + " strictUpperEntries")
    upper_zeros = _integer(profile.get("strictUpperExactZeros"),
                           phase + " strictUpperExactZeros")
    upper_nonzeros = _integer(profile.get("strictUpperNonzeros"),
                              phase + " strictUpperNonzeros")
    expected_triangle_entries = sum(count * size * (size - 1) // 2
                                    for size, count in size_groups.items())
    _need(lower_entries == expected_triangle_entries and
          upper_entries == expected_triangle_entries,
          phase + " strict triangle entry totals differ from sampled matrix sizes")
    lower_zero_ratio, lower_nonzero_ratio = _ratio_counts(
        lower_zeros, lower_nonzeros, lower_entries, phase + " strict lower")
    upper_zero_ratio, upper_nonzero_ratio = _ratio_counts(
        upper_zeros, upper_nonzeros, upper_entries, phase + " strict upper")

    solve_millis = _finite_nonnegative(profile.get("luSolveMillis"),
                                       phase + " luSolveMillis")
    _need(isinstance(report, dict), phase + " coordinator report must be an object")
    phase_report = report.get(phase)
    _need(isinstance(phase_report, dict), phase + " coordinator phase report is missing")
    phase_millis = _finite_nonnegative(phase_report.get("elapsedMs"),
                                       phase + " elapsedMs")
    deadline = _integer(report.get("measurementMaxJobMillis"),
                        "measurementMaxJobMillis", 1)
    _need(solve_millis <= phase_millis and solve_millis <= deadline,
          phase + " luSolveMillis exceeds phase elapsed time or measurement deadline")

    return {
        "phase": phase,
        "solveSamples": solve_samples,
        "luSolveMillis": solve_millis,
        "phaseElapsedMs": phase_millis,
        "timingClock": EXPECTED_SOLVE_CLOCK,
        "initialRhsSamples": rhs_samples,
        "initialRhsValues": expected_rhs_entries,
        "initialRhsFiniteValues": rhs_finite,
        "initialRhsNonfiniteValues": rhs_nonfinite,
        "triangularStructureSamples": triangular_samples,
        "strictLower": {
            "entries": lower_entries,
            "exactZeros": lower_zeros,
            "nonzeros": lower_nonzeros,
            "zeroRatio": lower_zero_ratio,
            "nonzeroRatio": lower_nonzero_ratio,
        },
        "strictUpper": {
            "entries": upper_entries,
            "exactZeros": upper_zeros,
            "nonzeros": upper_nonzeros,
            "zeroRatio": upper_zero_ratio,
            "nonzeroRatio": upper_nonzero_ratio,
        },
    }


def negative_canaries(profile, phase, report):
    """Return corruption cases that must be rejected by solve metadata checks."""
    validate_solve_metadata(profile, phase, report)
    cases = []

    def rejects(name, mutate):
        changed = deepcopy(profile)
        mutate(changed)
        try:
            validate_solve_metadata(changed, phase, report)
        except (SolveMetadataValidationError, AssertionError, KeyError, TypeError,
                ValueError, OverflowError) as error:
            cases.append({"case": name, "status": "REJECTED_AS_EXPECTED",
                          "reason": str(error)})
        else:
            raise AssertionError("solve metadata corruption was accepted: " + name)

    def bump(field, amount=1):
        def mutation(value):
            value[field] = value[field] + amount
        return mutation

    rejects("boolean is not an integer counter",
            lambda p: p.__setitem__("luSolveTimingAttempts", True))
    rejects("solve attempt sample bound", bump("luSolveTimingAttempts"))
    rejects("solve timing completion balance", bump("luSolveTimingCompletions"))
    rejects("solve outcome counters", bump("luSolveFailures"))
    rejects("native clock availability", bump("luSolveNativeClockUnavailable"))
    rejects("initial RHS solve sample count", bump("luSolveInitialRhsSamples"))

    def nonfinite_rhs(p):
        p["luSolveInitialRhsFiniteValues"] -= 1
        p["luSolveInitialRhsNonfiniteValues"] += 1
    rejects("nonfinite initial RHS values", nonfinite_rhs)
    rejects("solve timer finite", lambda p: p.__setitem__("luSolveMillis", float("nan")))
    phase_millis = _finite_nonnegative(report[phase]["elapsedMs"], phase + " elapsedMs")
    rejects("solve timer phase bound",
            lambda p: p.__setitem__("luSolveMillis", phase_millis + 1.0))
    rejects("solve timing scope identity",
            lambda p: p.__setitem__("luSolveTimingScope", "generic solve time"))
    rejects("solve clock identity",
            lambda p: p.__setitem__("luSolveClock", "Date.now"))
    rejects("triangular census/sample bound", lambda p: p.__setitem__(
        "triangularStructureSamples", p["triangularStructureSamples"] - 1))
    rejects("strict lower zero/nonzero identity", bump("strictLowerExactZeros"))
    rejects("strict upper size identity", bump("strictUpperEntries"))
    return cases