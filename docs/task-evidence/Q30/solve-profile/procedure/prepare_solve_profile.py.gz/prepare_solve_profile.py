from pathlib import Path
import hashlib,json,subprocess,uuid
s=Path(__file__).resolve().parent
root=Path('[REDACTED_USER_PATH]
draft=s/'solve-profile-draft'
old=s/'current-preflight-profile-b934bc7c77344c31b9d6a81b6e0fbcfe'
pointer=s/'solve-profile-source-path.txt'
assert not pointer.exists()
def sha(raw):return hashlib.sha256(raw).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='57929125daf6322006fe7da871b2edc7cca9590d'
cir='src/com/lushprojects/circuitjs1/client/CirSim.java'
coordinator='src/com/lushprojects/circuitjs1/client/Q30CoordinatorQualificationVerifier.java'
driver='scripts/verify-current-contracts.ps1'
solve='tests/contracts/Q30LuSolveProfileContractTest.java'
repeat='tests/contracts/Q30LuRepetitionProfileContractTest.java'
raw=(draft/'candidate'/cir).read_bytes()
assert sha(raw)=='24a60c727806d7ed9a577effd558f68fabf52f2b39a2897d0f80bd0b672f0bd1'
assert sha((draft/'baseline'/cir).read_bytes())=='15a576e8a254def5e1a90dcd860992ec36cacb9d1c1dbfd61026e52988cf340d'
assert sha((draft/'candidate'/solve).read_bytes())=='57dced0549bbe7f90cd5fc60b52f378e32e3a8be9fdca2de691e5d4c4b482b99'
assert sha((old/coordinator).read_bytes())=='b378808e40c9173e337fea996c74375c361c251f1c9032d90504b777f0f147d8'
assert sha((old/repeat).read_bytes())=='3bf162017b8967304e87a07928c3fdd5d7966dd3a7945e988560a9ed4b9d5e3c'
paths=[p for p in subprocess.check_output(['git','ls-files','-z','--','src','scripts','tests','war','.settings','.classpath','.project'],cwd=root).decode().split('\0') if p]
paths+=['src/com/lushprojects/circuitjs1/client/Q30NormalAcceptanceVerifier.java']
paths+=sorted(p.relative_to(root).as_posix() for p in (root/'.tools/gwt-2.7.0').glob('*.jar'))
assert len(paths)==len(set(paths))==1339
assert not any('__pycache__' in p or p.startswith('war/circuitjs1/') for p in paths)
prior=s/Path((s/'owned-zero-row-r2-source-pair-path.txt').read_text())
records=json.loads((prior/'source-audit.json').read_bytes())['armInputs']['candidate']
for r in records:
 raw=(root/r['path']).read_bytes()
 assert sha(raw)==r['sha256'] and len(raw)==r['bytes'],r['path']
target=s/('solve-profile-'+uuid.uuid4().hex);target.mkdir()
for name in paths:
 src=root/name;assert src.is_file() and not src.is_symlink()
 dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
assert len([p for p in (target/'war').rglob('*') if p.is_file()])==29
text=(draft/'candidate'/cir).read_text(encoding='utf-8')
before='''                    for (j = 0; j != n; j++)
                        if (row[j] != 0) row_all_zeros = false;'''
after='''                    for (j = 0; j != n; j++) {
                        if (row[j] != 0) {
                            row_all_zeros = false;
                            break;
                        }
                    }'''
assert text.count(before)==1
text=text.replace(before,after)
(target/cir).write_text(text,encoding='utf-8',newline='\n')
(target/coordinator).write_bytes((old/coordinator).read_bytes())
(target/repeat).write_bytes((old/repeat).read_bytes())
test=(draft/'candidate'/solve).read_text(encoding='utf-8')
assert test.count('System.out.println("Q30 LU solve profile contracts assertions=')==1
assert test.count('double[] rhs = { 22.0, 10.0, 12.5, 8.0 };')==1
test=test.replace('System.out.println("Q30 LU solve profile contracts assertions=','System.out.println("PASS: Q30 LU solve profile contracts assertions=')
test=test.replace('double[] rhs = { 22.0, 10.0, 12.5, 8.0 };','double[] rhs = { 22.0, 10.0, 23.0, 8.0 };')
(target/solve).write_text(test,encoding='utf-8',newline='\n')
raw=(target/driver).read_bytes();anchor=b"        @{ Name = 'Q30OwnedLuZeroRowContractTest'; Marker = 'Q30 owned LU zero-row contracts ' },"
assert raw.count(anchor)==1
nl=b'\r\n' if b'\r\n' in raw else b'\n'
extra=[b"        @{ Name = 'Q30LuRepetitionProfileContractTest'; Marker = 'Q30 LU repetition profile contracts ' },",b"        @{ Name = 'Q30LuSolveProfileContractTest'; Marker = 'Q30 LU solve profile contracts ' },"]
(target/driver).write_bytes(raw.replace(anchor,nl.join([anchor]+extra)))
allpaths=sorted(paths+[repeat,solve]);assert len(allpaths)==1341
inputs=[{'path':p,'sha256':sha((target/p).read_bytes()),'bytes':(target/p).stat().st_size} for p in allpaths]
audit={'status':'SOURCE_ONLY_FIXTURE_PREPARED_NOT_VALIDATED','head':head,'scope':'private measurement only; accepted zero-row path plus unchanged existing private repetition sampler and new sampled solve timing/density; no sampler integrated into root','rootInputs':records,'inputs':inputs,'generatedWarCopied':False,'workerCirSimSha256':'24a60c727806d7ed9a577effd558f68fabf52f2b39a2897d0f80bd0b672f0bd1','rootRepairsBeforeFirstGate':['Rebase accepted private zero-row early exit.','Add maintained PASS: output marker to new test.','Correct explicit fixture RHS third entry from 12.5 to 23: L*U*[1,2,3,4] = [22,10,23,8]. No assertion removed.'],'changedPaths':[cir,coordinator,driver,repeat,solve]}
(target/'source-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
pointer.write_text(str(target),encoding='utf-8')
print(json.dumps({'fixture':str(target),'inputs':len(inputs),'sourceAuditSha256':sha((target/'source-audit.json').read_bytes()),'changedFiles':[r for r in inputs if r['path'] in audit['changedPaths']]}))
