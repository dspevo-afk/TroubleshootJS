# Independent review: solve-profile pair validator

## Result

The composed validator is fail-closed for the new solve-profile fields and preserves the existing preflight/report checks. I found no invalid source or run binding in the recorded PASS report. The off arm precedes the profile arm in the frozen plan and host sequence receipt; the summary lists profile then off only to simplify comparison.

The recorded validation summary is PASS for seed 10014 and explicitly disclaims production acceptance and speed claims. Both host rows have PASS outcomes, no timeout, cleanup PASS, and matching before/after source, web, runner, and input-manifest hashes. Both exact reports pass the same strict current-plan-4 reader with 43 corruption canaries each. Profile parity removes exactly cold/warm luRepetitionProfile objects and the same explicitly listed timing paths from each arm; the remaining reports compare equal. The combined validator records 79 expected metadata rejections: 51 from the preserved preflight checks and 28 from the new solve checks.

The solve-metadata module checks sampled starts/eligible comparisons against timing attempts, balanced timing outcomes, browser clock identity, RHS sample dimensions/finiteness, triangle sizes and zero/nonzero sums, and solve time bounds. It validates cold and warm profile metadata and runs negative mutations. The legacy helper hash and preflight checker are pinned and reused. The off arm is required to omit the profile object.

## Evidence binding and scope note

The root validator pins the new measurement-plan hash and exact seed/labels/order, runner source, solve-metadata module, profile candidate source hashes, legacy helper/canary receipts, host sequence receipt, and focused-gate receipt. It rehashes every one of the 1,341 source-audit inputs before accepting the candidate. The source-audit file remains the intentionally historical preparation receipt; the separate solve-profile-r1-gates.json has status FOCUSED_GATES_PASS_NOT_ACCEPTANCE, pins source-audit SHA-256 9186034B2CFE23A3C77F6E2C0D31C466BBC6EE798FEADC1FA9542397381D680C, and records four zero-exit focused gate steps. The source-audit status should remain unchanged. This supersedes my prior note suggesting that file itself be refreshed.

One small plan-guard difference is worth making explicit: the old validator required “40-package” in plan scope and a “no population speed estimate” limit. The new plan has no package-count field and the new guard checks seed plus “Do not infer population timing.” The actual paired reports do contain the exact same request with packages=40, are bound to the same frozen source/build inputs, and pass the strict reader, so I found no evidence that this run used a different scope. If 40 packages remains a hard predeclared scope, add an explicit package-count assertion to the plan/validator; otherwise the current run evidence is still correctly attributable but that constraint is less visible in the plan guard.

The run remains one-seed instrumentation evidence only. Its profile/off timing differences do not isolate disabled-guard cost, establish population performance, or qualify normal acceptance. I did not rerun validation, native tests, browser, or builds.

## Reviewed hashes

| Artifact | SHA-256 |
| --- | --- |
| Prior current-preflight pair validator | 6ABCF80D263E0411D15BF2425AA7EC1B352A09937B43B54C39E6FB85157050D1 |
| Root solve-profile pair validator | DFCDF80D9246FC87D49E5C6FBE8C05B2A6E1E7B86F39212AE47F1F37635B1DB3 |
| Composed solve-metadata validator | 58A0C3003C7279F61D100D87CF853EA453D4A04261C76431A15AB5215D20E337 |
| Frozen plan | 63311E723E7D9A66EDD4D71A09098CC809932287E5CE5D2B96FA7F3FD82D90E0 |
| Validation summary | FCFADE445F286E0E63627C4EBF2A69B0E338B3A205810A2B8E30690081B10BD1 |
| Focused-gate receipt | 0E7F65A6F09108772E4FE985B7CC9E4987F9B8E6A5E6357B3A7698826E933AB6 |
| Earlier solve-profile-independent-review.md | 02150376232A496BFADB54DFF22957F945ADA3E62212C469D1DF5C4C09A0723B |
