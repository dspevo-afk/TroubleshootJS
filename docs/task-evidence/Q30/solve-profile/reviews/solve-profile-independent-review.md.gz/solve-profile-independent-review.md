# Independent review: sampled LU solve profile

## Finding

No remaining production correctness blocker found by source review. The frozen draft had two test blockers, both fixed in the prepared root fixture:

- The maintained native marker lacked the required PASS: prefix.
- The explicit 4x4 LU fixture used RHS entry 12.5, but its expected solution [1,2,3,4] requires L*U*x = [22,10,23,8]. Final RHS is [22,10,23,8].

The final fixture additionally rebases the accepted private zero-row early exit. Comparing the final fixture to the draft shows only that six-line loop change in CirSim; the test diff contains only the marker and RHS fixes. No assertions were removed. The early exit stops scanning a row after a nonzero is found, preserving the all-zero result while avoiding unnecessary reads.

## Source review

The selected solve calls the existing lu_solve once through lu_solveProfiled. That wrapper counts the initial RHS before timing, brackets only the actual solver call, balances timing and success/failure counters with nested finally blocks, and runs the triangle census only after lu_solve returns. The existing lu_solve reads the factor matrix and mutates only RHS; the census therefore measures the same LU factors. Strict-triangle counts exclude diagonals and count both signed zeros as exact zero. The corrected fixture’s expected lower/upper entry totals are consistent with its matrix.

Sampling is gated at the call site. The ordinary profile-null or inactive-scope branch uses the existing unprofiled factor overload and direct lu_solve call, with no new scans or clock reads. A sampled start is eligible only after successful factorization; an adjacent comparison is eligible only when compareNext confirms size, generation, revision, and analysis epoch. A mismatched comparison still follows the existing factor-profile path, but sampleOwnerMatches remains false and the solve wrapper is not selected. Thus the code adds a local null check/dispatch branch to each solve, but no new per-solve loop or timing call on the unselected path.

The instrumentation does not change LU arithmetic, solver settling, convergence tests, finite checks, proof work, or electrical state. The only other production delta is the accepted early-exit rebase. Profile data is emitted only through the private Q30 repetition-profile request and work scope; no player UI path was added.

## Test coverage and evidence limits

Final native canaries cover the exact solution and triangle counts, nonfinite initial RHS classification, native clock-unavailable reporting, solve-return versus throw counters, balanced timing completion, and no structural census after a throwing solve. The comparison test proves matching identity and rejects a generation mismatch. It does not separately exercise size, revision, or analysis-epoch mismatch; the implementation checks all four. This is a small nonblocking canary gap, not a source defect.

Root reports the focused gates now PASS: native7 with 24 solve-profile assertions, GWT five-permutation build, compiled A07, disabled normal policy, and three strict negative canaries. I did not run any gate. The prepared fixture’s source-audit.json still says SOURCE_ONLY_FIXTURE_PREPARED_NOT_VALIDATED, so refresh that status or preserve a separate post-gate receipt before using the audit file as final validation evidence. No solve-profile timing rows were available in this review; no performance attribution or acceptance claim follows.

## Exact hash scope

| Artifact | SHA-256 |
| --- | --- |
| Draft baseline CirSim.java | 15A576E8A254DEF5E1A90DCD860992EC36CACB9D1C1DBFD61026E52988CF340D |
| Frozen draft CirSim.java | 24A60C727806D7ED9A577EFFD558F68FABF52F2B39A2897D0F80BD0B672F0BD1 |
| Frozen draft solve-profile test | 57DCED0549BBE7F90CD5FC60B52F378E32E3A8BE9FDCA2DE691E5D4C4B482B99 |
| Prepared root fixture CirSim.java | 60371360961ABF8645C388B06D8F3741D311D4B0A3D045B6CC1BA2E123B887FC |
| Prepared root fixture solve-profile test | 60F9C427182976778D11B4877B813B2FCC2AE0AED21206F369E5CBB8A8D5EADB |
| Prepared root fixture source-audit.json | 9186034B2CFE23A3C77F6E2C0D31C466BBC6EE798FEADC1FA9542397381D680C |

Reviewed production lines: final CirSim.java 3411-3457 (sampling and dispatch), 8175-8188 (pair identity), 8310-8370 and 8646-8661 (counters and wrapper), and 8558-8564 (accepted zero-row early exit). Reviewed test lines: 16 and 36 (repaired marker/RHS), 73-86 (comparison canary).
