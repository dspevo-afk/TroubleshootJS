package com.lushprojects.circuitjs1.client;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Native canaries for sampled solve timing and one-pass triangular census. */
public final class Q30LuSolveProfileContractTest {
    private static final String PROFILE_CLASS =
        "com.lushprojects.circuitjs1.client.CirSim$LuRepetitionProfile";
    private static int assertions;

    public static void main(String[] args) throws Exception {
        int count = run();
        System.out.println("PASS: Q30 LU solve profile contracts assertions=" + count);
    }

    public static int run() throws Exception {
        assertions = 0;
        verifySuccessfulSolveAndExactTriangleCounts();
        verifyComparisonIdentityGate();
        verifyNonfiniteInitialRhsIsCounted();
        verifyTimingCompletesWhenSolveThrows();
        return assertions;
    }

    private static void verifySuccessfulSolveAndExactTriangleCounts() throws Exception {
        Object profile = newProfile();
        double[][] factors = {
            { 2.0, 0.0, -0.0, 5.0 },
            { 0.0, 3.0, 0.0, 1.0 },
            { 0.5, -0.0, 4.0, 0.0 },
            { 0.0, 0.0, 0.0, 2.0 }
        };
        double[] rhs = { 22.0, 10.0, 23.0, 8.0 };
        int[] pivots = { 0, 1, 2, 3 };
        invokeProfiledSolve(factors, 4, pivots, rhs, profile);

        double[] expected = { 1.0, 2.0, 3.0, 4.0 };
        for (int i = 0; i < expected.length; i++)
            require(rhs[i] == expected[i], "profiled solve changed result at index " + i);

        require(intValue(profile, "luSolveTimingAttempts") == 1 &&
                intValue(profile, "luSolveTimingCompletions") == 1,
                "successful solve timing was not balanced");
        require(intValue(profile, "luSolveInitialRhsSamples") == 1 &&
                longValue(profile, "luSolveInitialRhsFiniteValues") == 4 &&
                longValue(profile, "luSolveInitialRhsNonfiniteValues") == 0,
                "successful solve initial RHS census was incorrect");
        require(intValue(profile, "luSolveSuccesses") == 1 &&
                intValue(profile, "luSolveFailures") == 0,
                "successful solve outcome counters were incorrect");
        require(intValue(profile, "luSolveNativeClockUnavailable") == 1,
                "native timing unavailability was not counted separately");
        require(intValue(profile, "luSolveTimingSamples") == 0 &&
                intValue(profile, "luSolveTimingErrors") == 0,
                "native clock absence was misreported as a timing sample/error");
        require(invokeClock(profile).equals("unavailable-native"),
                "native solve clock identity was incorrect");
        require(intValue(profile, "triangularStructureSamples") == 1,
                "successful solve did not record exactly one triangular census");
        require(longValue(profile, "strictLowerEntries") == 6 &&
                longValue(profile, "strictLowerExactZeros") == 5 &&
                longValue(profile, "strictLowerNonzeros") == 1,
                "strict-lower exact-zero census was incorrect");
        require(longValue(profile, "strictUpperEntries") == 6 &&
                longValue(profile, "strictUpperExactZeros") == 4 &&
                longValue(profile, "strictUpperNonzeros") == 2,
                "strict-upper exact-zero census was incorrect");
    }

    private static void verifyComparisonIdentityGate() throws Exception {
        Object profile = newProfile();
        Class<?> profileType = profile.getClass();
        Method capture = profileType.getDeclaredMethod("captureStart",
                double[][].class, Integer.TYPE, Long.TYPE, Long.TYPE);
        capture.setAccessible(true);
        double[][] matrix = { { 1.0 } };
        capture.invoke(profile, matrix, Integer.valueOf(1), Long.valueOf(7), Long.valueOf(4));
        require(invokeCompare(profile, matrix, 1, 7, 4),
                "matching same-generation/revision pair was not eligible for sampled solve timing");

        capture.invoke(profile, matrix, Integer.valueOf(1), Long.valueOf(7), Long.valueOf(4));
        require(!invokeCompare(profile, matrix, 1, 8, 4),
                "mismatched generation was eligible for sampled solve timing");
    }

    private static boolean invokeCompare(Object profile, double[][] matrix, int n,
            long generation, long revision) throws Exception {
        Method compare = profile.getClass().getDeclaredMethod("compareNext",
                double[][].class, Integer.TYPE, Long.TYPE, Long.TYPE);
        compare.setAccessible(true);
        return ((Boolean) compare.invoke(profile, matrix, Integer.valueOf(n),
                Long.valueOf(generation), Long.valueOf(revision))).booleanValue();
    }

    private static void verifyNonfiniteInitialRhsIsCounted() throws Exception {
        Object profile = newProfile();
        double[] rhs = { Double.NaN, 1.0 };
        invokeProfiledSolve(new double[][] { { 1.0, 0.0 }, { 0.0, 1.0 } }, 2,
                new int[] { 0, 1 }, rhs, profile);
        require(intValue(profile, "luSolveInitialRhsSamples") == 1 &&
                longValue(profile, "luSolveInitialRhsFiniteValues") == 1 &&
                longValue(profile, "luSolveInitialRhsNonfiniteValues") == 1,
                "initial NaN RHS entry was not reported separately");
        require(Double.isNaN(rhs[0]) && intValue(profile, "luSolveSuccesses") == 1 &&
                intValue(profile, "luSolveFailures") == 0,
                "profile wrapper changed nonfinite RHS solve propagation");
    }

    private static void verifyTimingCompletesWhenSolveThrows() throws Exception {
        Object profile = newProfile();
        boolean failed = false;
        try {
            invokeProfiledSolve(new double[][] { { 1.0, 0.0 }, {} }, 2,
                    new int[] { 0, 1 }, new double[] { 0.0, 1.0 }, profile);
        } catch (ArrayIndexOutOfBoundsException expected) {
            failed = true;
        }
        require(failed, "malformed matrix did not exercise the throwing solve path");
        require(intValue(profile, "luSolveTimingAttempts") == 1 &&
                intValue(profile, "luSolveTimingCompletions") == 1,
                "throwing solve left timing starts/completions unbalanced");
        require(intValue(profile, "luSolveNativeClockUnavailable") == 1,
                "throwing native solve did not record clock unavailability");
        require(intValue(profile, "luSolveTimingSamples") == 0 &&
                intValue(profile, "luSolveTimingErrors") == 0,
                "throwing native solve misreported unavailable timing");
        require(intValue(profile, "luSolveInitialRhsSamples") == 1 &&
                longValue(profile, "luSolveInitialRhsFiniteValues") == 2 &&
                longValue(profile, "luSolveInitialRhsNonfiniteValues") == 0,
                "throwing solve did not census the initial RHS before timing");
        require(intValue(profile, "luSolveSuccesses") == 0 &&
                intValue(profile, "luSolveFailures") == 1,
                "throwing solve outcome was not distinguished from timing failure");
        require(intValue(profile, "triangularStructureSamples") == 0,
                "failed solve incorrectly recorded a successful-factor census");
    }

    private static Object newProfile() throws Exception {
        Class<?> type = Class.forName(PROFILE_CLASS);
        Constructor<?> constructor = type.getDeclaredConstructor(String.class);
        constructor.setAccessible(true);
        Object profile = constructor.newInstance("solve-contract");
        Method setScope = type.getDeclaredMethod("setWorkScope", Boolean.TYPE);
        setScope.setAccessible(true);
        setScope.invoke(profile, Boolean.TRUE);
        return profile;
    }

    private static void invokeProfiledSolve(double[][] matrix, int n, int[] pivots,
            double[] rhs, Object profile) throws Exception {
        Class<?> profileType = Class.forName(PROFILE_CLASS);
        Method solve = CirSim.class.getDeclaredMethod("lu_solveProfiled",
                double[][].class, Integer.TYPE, int[].class, double[].class, profileType);
        solve.setAccessible(true);
        try {
            solve.invoke(null, matrix, Integer.valueOf(n), pivots, rhs, profile);
        } catch (InvocationTargetException wrapped) {
            Throwable cause = wrapped.getCause();
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            if (cause instanceof Error) throw (Error) cause;
            throw wrapped;
        }
    }

    private static String invokeClock(Object profile) throws Exception {
        Method method = profile.getClass().getDeclaredMethod("luSolveClock");
        method.setAccessible(true);
        return (String) method.invoke(profile);
    }

    private static int intValue(Object profile, String fieldName) throws Exception {
        Field field = profile.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getInt(profile);
    }

    private static long longValue(Object profile, String fieldName) throws Exception {
        Field field = profile.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getLong(profile);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private Q30LuSolveProfileContractTest() { }
}