$ErrorActionPreference = 'Stop'
$taskRoot = '<task-temp>'
$repo = '<repo>'
$destination = Join-Path $taskRoot 'archive-stage-result.json'
$archiveRoot = Join-Path $taskRoot 'source-attempt-archive-epoch15'
if ((Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath $archiveRoot)) { throw 'Preserve prior archive evidence' }
$owner = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $PID)
$record = [ordered]@{status='RUNNING'; startedUtc=(Get-Date).ToUniversalTime().ToString('o'); owner=[ordered]@{pid=$PID; createdUtc=$owner.CreationDate.ToUniversalTime().ToString('o'); executable=$owner.ExecutablePath; commandLine=$owner.CommandLine}; archiveRoot=$archiveRoot}
$record | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $destination -Encoding UTF8
$clock = [Diagnostics.Stopwatch]::StartNew()
try {
    $env:GIT_CONFIG_COUNT = '1'
    $env:GIT_CONFIG_KEY_0 = 'safe.directory'
    $env:GIT_CONFIG_VALUE_0 = $repo
    & '%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe' -NoProfile -File (Join-Path $repo 'docs/task-evidence/Q30/resume-20261002/archive-q30-sources.ps1') -TaskRoot $taskRoot -Repo $repo -ArchiveRoot $archiveRoot -CandidateNames isolated -SkipProfile *> (Join-Path $taskRoot 'archive-stage.log')
    $record.exitCode = $LASTEXITCODE
    if ($LASTEXITCODE -ne 0) { throw ('Archive returned ' + $LASTEXITCODE) }
    $manifest = Get-Content -LiteralPath (Join-Path $archiveRoot 'archive-manifest.json') -Raw | ConvertFrom-Json
    if ($manifest.archiveRunStatus -ne 'PASS') { throw 'Archive manifest not PASS' }
    $record.status = 'PASS'
} catch { $record.status='FAIL'; $record.error=$_.Exception.Message }
finally {
    $record.finishedUtc = (Get-Date).ToUniversalTime().ToString('o')
    $record.elapsedSeconds = $clock.Elapsed.TotalSeconds
    $record | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $destination -Encoding UTF8
}
$record | ConvertTo-Json -Depth 12
if ($record.status -ne 'PASS') { exit 1 }
