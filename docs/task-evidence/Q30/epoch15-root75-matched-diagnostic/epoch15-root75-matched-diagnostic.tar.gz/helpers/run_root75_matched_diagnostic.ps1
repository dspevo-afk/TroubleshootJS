$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$q30Python='$USER_HOME\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$q30Helper=Join-Path $PSScriptRoot 'run_root75_matched_diagnostic.py'
$q30Task=Join-Path ([IO.Path]::GetTempPath()) ('q30-root75-matched-'+[Guid]::NewGuid().ToString('N'))
if(Test-Path -LiteralPath $q30Task){throw 'Unique diagnostic task root already exists'}
New-Item -ItemType Directory -Path $q30Task | Out-Null
$q30Pointer=Join-Path $PSScriptRoot 'root75-matched-pointer.json'
if(Test-Path -LiteralPath $q30Pointer){throw 'Preserve earlier diagnostic pointer'}
$q30Self=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID) -ErrorAction Stop
if($null -eq $q30Self -or [string]::IsNullOrWhiteSpace($q30Self.ExecutablePath)){throw 'Wrapper ownership missing'}
$q30Record=[ordered]@{schema=1;status='RUNNING';diagnosticOnly=$true;qualification=$false;taskRoot=$q30Task;helperSha256=(Get-FileHash -LiteralPath $q30Helper -Algorithm SHA256).Hash.ToLowerInvariant();startedUtc=[DateTime]::UtcNow.ToString('o');wrapper=@{pid=$PID;createdUtc=$q30Self.CreationDate.ToUniversalTime().ToString('o');executable=$q30Self.ExecutablePath;commandLine=$q30Self.CommandLine}}
$q30Record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $q30Pointer -Encoding UTF8
$q30Stdout=Join-Path $q30Task 'controller.stdout.log'
$q30Stderr=Join-Path $q30Task 'controller.stderr.log'
$q30Clock=[Diagnostics.Stopwatch]::StartNew()
try{
    $q30Process=Start-Process -FilePath $q30Python -ArgumentList @('-B','-u',$q30Helper,'--task-root',$q30Task) -WindowStyle Hidden -RedirectStandardOutput $q30Stdout -RedirectStandardError $q30Stderr -PassThru
    $q30Record.controllerPid=$q30Process.Id
    $q30Controller=Get-CimInstance Win32_Process -Filter ('ProcessId='+$q30Process.Id) -ErrorAction Stop
    if($null -eq $q30Controller -or $q30Controller.ExecutablePath -ne $q30Python){throw 'Actual diagnostic controller ownership not observable'}
    $q30Record.controller=@{pid=$q30Controller.ProcessId;createdUtc=$q30Controller.CreationDate.ToUniversalTime().ToString('o');executable=$q30Controller.ExecutablePath;commandLine=$q30Controller.CommandLine}
    $q30Record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $q30Pointer -Encoding UTF8
    while(-not $q30Process.HasExited){
        $q30Process.WaitForExit(40000)
        $q30Progress=Join-Path $q30Task 'root75-matched-diagnostic\run.json'
        if(Test-Path -LiteralPath $q30Progress){
            $q30Run=Get-Content -LiteralPath $q30Progress -Raw | ConvertFrom-Json
            Write-Output ('Root75 diagnostic '+$q30Run.status+' cases='+@($q30Run.cases).Count+' elapsed='+[Math]::Round($q30Clock.Elapsed.TotalSeconds,1)+'s')
        }
    }
    $q30Process.WaitForExit()
    $q30Record.exitCode=$q30Process.ExitCode
    $q30Run=Get-Content -LiteralPath (Join-Path $q30Task 'root75-matched-diagnostic\run.json') -Raw | ConvertFrom-Json
    $q30Record.diagnosticStatus=$q30Run.status
    $q30Record.caseCount=$q30Run.caseCount
    $q30Record.sourceBindingUnchangedBeforeAfter=$q30Run.sourceBindingUnchangedBeforeAfter
    $q30Record.status=$(if($q30Record.exitCode -eq 0 -and $q30Run.status -eq 'DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION' -and $q30Run.caseCount -eq 4 -and $q30Run.sourceBindingUnchangedBeforeAfter){'DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION'}else{'FAIL'})
}catch{
    $q30Record.status='FAIL';$q30Record.error=$_.Exception.Message
}finally{
    $q30Record.finishedUtc=[DateTime]::UtcNow.ToString('o');$q30Record.operationSeconds=$q30Clock.Elapsed.TotalSeconds
    $q30Record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $q30Pointer -Encoding UTF8
}
$q30Record | ConvertTo-Json -Depth 8
if($q30Record.status -ne 'DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION'){exit 1}
