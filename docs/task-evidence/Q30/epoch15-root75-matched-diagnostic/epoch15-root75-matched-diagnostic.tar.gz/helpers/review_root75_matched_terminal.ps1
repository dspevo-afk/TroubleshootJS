$ErrorActionPreference='Stop'
$q30PointerPath=Join-Path $PSScriptRoot 'root75-matched-pointer.json'
$q30Pointer=Get-Content -LiteralPath $q30PointerPath -Raw | ConvertFrom-Json
$q30Root=Join-Path $q30Pointer.taskRoot 'root75-matched-diagnostic'
$q30Destination=Join-Path $q30Root 'terminal-independent-process-review.json'
if(Test-Path -LiteralPath $q30Destination){throw 'Preserve prior review'}
if($q30Pointer.exitCode -ne 0 -or $q30Pointer.status -ne 'DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION'){throw 'Diagnostic not terminal'}
$q30Run=Get-Content -LiteralPath (Join-Path $q30Root 'run.json') -Raw | ConvertFrom-Json
if($q30Run.caseCount -ne 4 -or -not $q30Run.sourceBindingUnchangedBeforeAfter){throw 'Diagnostic incomplete/input mutation'}
$q30Ids=@()
foreach($q30Key in @('wrapper','controller')){
    $q30Owner=$q30Pointer.$q30Key
    $q30Ids+=@{pid=$q30Owner.pid;created=$q30Owner.createdUtc;executable=$q30Owner.executable;kind=$q30Key}
}
foreach($q30Case in $q30Run.cases){
    $q30Slug=('{0:D2}-{1}-seed75' -f [int]$q30Case.index,[string]$q30Case.variant)
    $q30Host=Get-Content -LiteralPath (Join-Path $q30Root ($q30Slug+'\host\result.json')) -Raw | ConvertFrom-Json
    if($q30Host.cleanup.status -ne 'PASS' -or -not $q30Host.cleanup.serverStopped -or @($q30Host.cleanup.errors).Count -ne 0 -or @($q30Host.cleanup.ownedSurvivors).Count -ne 0){throw 'Host cleanup nonpass'}
    $q30Ids+=@{pid=$q30Host.identity.runner.pid;created=$q30Host.identity.runner.created;executable=$q30Host.identity.runner.executable;kind=$q30Slug+'-host'}
    foreach($q30Edge in $q30Host.identity.edgeProcessesBeforeCases){
        $q30Ids+=@{pid=$q30Edge.pid;created=$q30Edge.created;executable=$q30Edge.ExecutablePath;kind=$q30Slug+'-initial-edge'}
    }
}
$q30Processes=@(Get-CimInstance Win32_Process -ErrorAction Stop)
if($q30Processes.Count -eq 0){throw 'Empty process inventory'}
$q30Rows=@()
foreach($q30Id in $q30Ids){
    if([int]$q30Id.pid -le 0 -or [string]::IsNullOrWhiteSpace([string]$q30Id.created) -or [string]::IsNullOrWhiteSpace([string]$q30Id.executable)){throw 'Incomplete owned identity'}
    $q30Matches=@($q30Processes | Where-Object {$_.ProcessId -eq $q30Id.pid})
    if($q30Matches.Count -gt 1){throw 'Duplicate process inventory PID'}
    $q30Same=$q30Matches.Count -eq 1 -and $q30Matches[0].CreationDate.ToUniversalTime() -eq ([DateTimeOffset]::Parse([string]$q30Id.created)).UtcDateTime -and $q30Matches[0].ExecutablePath -eq $q30Id.executable
    $q30Rows+=@{kind=$q30Id.kind;pid=$q30Id.pid;createdUtc=$q30Id.created;recordedInstanceGone=(-not $q30Same);pidCurrentlyPresent=($q30Matches.Count -eq 1)}
}
$q30Live=@($q30Rows | Where-Object {-not $_.recordedInstanceGone})
@{schema=1;status=$(if($q30Live.Count -eq 0){'PASS'}else{'FAIL'});observedUtc=[DateTime]::UtcNow.ToString('o');diagnosticOnly=$true;qualification=$false;scope='Exact recorded wrapper/controller/four hosts/initial Edge instances; driver instances not separately sampled';identitiesChecked=$q30Rows.Count;rows=$q30Rows;noTerminationPerformed=$true;cleanupElapsedSeconds='NOT_RECORDED_SEPARATELY'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $q30Destination -Encoding UTF8
Write-Output ('Root75 diagnostic identities='+$q30Rows.Count+' live='+$q30Live.Count)
if($q30Live.Count -ne 0){exit 1}
