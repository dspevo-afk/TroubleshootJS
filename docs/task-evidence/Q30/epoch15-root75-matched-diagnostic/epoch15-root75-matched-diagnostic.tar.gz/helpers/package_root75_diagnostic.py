"""Preserve four matched observations with every original reader nonpass retained."""
import io
import json
from pathlib import Path
import tarfile
import save_process_final_cold_failure as lib

WORK=Path(__file__).resolve().parent
DEST=lib.REPO/'docs/task-evidence/Q30/epoch15-root75-matched-diagnostic'

def main():
    assert not DEST.exists(),'preserve prior diagnostic packet'
    ledger=lib.Ledger()
    pointer,raw=lib.doc(ledger,WORK/'root75-matched-pointer.json',WORK,'diagnostic pointer')
    task=Path(pointer['taskRoot']);root=task/'root75-matched-diagnostic'
    run,_=lib.doc(ledger,root/'run.json',root,'diagnostic run')
    review,_=lib.doc(ledger,root/'terminal-independent-process-review.json',root,'terminal process review')
    assert pointer['exitCode']==0 and pointer['status']==run['status']=='DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION'
    assert run['qualification'] is False and run['diagnosticOnly'] is True and run['caseCount']==4
    assert run['sourceBindingUnchangedBeforeAfter'] is True
    assert run['caseOrder']==['current','old','old','current']
    assert run['limits']==lib.LIMITS and review['status']=='PASS' and review['identitiesChecked']==34
    assert review['noTerminationPerformed'] is True and all(x['recordedInstanceGone'] for x in review['rows'])
    before,_=lib.doc(ledger,root/'hashes-before.json',root,'before hashes')
    after,_=lib.doc(ledger,root/'hashes-after.json',root,'after hashes')
    assert after.pop('unchanged') is True and after==before
    assert len(before['currentRepository1354'])==1354
    for rel,row in before['currentRepository1354'].items():
        ledger.hash_source(lib.REPO/rel,lib.REPO,row['size'],row['sha256'])
    packet=lib.Packet(ledger,lib.REPO,task,WORK)
    for name in ('run.json','hashes-before.json','hashes-after.json','terminal-independent-process-review.json'):
        packet.add(name,root/name,root,'json')
    for name in ('host-runtime.stdout.bin','host-runtime.stderr.bin'):
        packet.add(name,root/name,root,'text')
    for name in ('controller.stdout.log','controller.stderr.log'):
        packet.add(name,task/name,task,'text')
    for name in ('root75-matched-pointer.json','run_root75_matched_diagnostic.py',
                 'run_root75_matched_diagnostic.ps1','review_root75_matched_terminal.ps1','package_root75_diagnostic.py'):
        packet.add('helpers/'+name,WORK/name,WORK,'json' if name.endswith('.json') else 'text')
    metrics=[]
    expected_pin_errors=['host runner hash/count differs from frozen plan',
                         'host runner after hash/count differs from frozen plan']
    for case in run['cases']:
        slug='%02d-%s-seed75'%(case['index'],case['variant']);base=root/slug
        assert case['actualHostPass'] is True and case['actualCleanupPass'] is True
        assert case['status']=='APP_PASS_DIAGNOSTIC' and case['reader']['appStatus']=='APP_PASS'
        assert case['app']['generationElapsedMs']<=90000 and case['app']['workUnits']==483
        if case['variant']=='old':
            assert case['reader']['hostStatus']=='HOST_FAIL' and case['reader']['hostErrors']==expected_pin_errors
            assert case['originalPlanHostPinMismatchOnly'] is True
        else:
            assert case['reader']['hostStatus']=='HOST_PASS' and case['reader']['hostErrors']==[]
        for name in ('case-progress.json','case-result.json','case-spec.json','host.stdout.bin',
                     'reader.stdout.bin','reader.stderr.bin'):
            packet.add(slug+'/'+name,base/name,root,'json' if name.endswith('.json') else 'text')
        for name in ('identity.json','input-manifest-before.json','input-manifest-after.json',
                     'owned-processes-before.json','owned-processes-before-close.json','progress.json',
                     'result.json','run-start.json','runner-after.json','runner-before.json','spec.json',
                     'cases/001-cold-75.json','cases/001-cold-75.report.json','cases/001-cold-75.state.txt'):
            packet.add(slug+'/host/'+name,base/'host'/name,root,'json' if name.endswith('.json') else 'text')
        metrics.append({'variant':case['variant'],'elapsedMs':case['app']['generationElapsedMs'],
                        'workUnits':483,'stages':case['app']['stages'],'actualHostPass':True,
                        'cleanupSeconds':case['cleanup']['seconds'],'strictReaderHostStatus':case['reader']['hostStatus']})
    manifest={'schema':1,'status':'DIAGNOSTIC_COMPLETE_NOT_QUALIFICATION','q30Acceptance':'NOT_ESTABLISHED',
        'qualification':False,'normalPlayerQ30Enabled':False,'sourceIdentity':lib.SOURCE,'baseHead':lib.HEAD,
        'commonHostSha256':run['commonHostSha256'],'limits':lib.LIMITS,'hostCaseLimitSeconds':150,
        'operationSeconds':pointer['operationSeconds'],'cleanupSecondsByCase':[x['cleanupSeconds'] for x in metrics],
        'independentRecordedInstancesGone':34,'noTerminationPerformed':True,'systemCpuSampling':'NOT_SAMPLED',
        'observations':metrics,'retainedQualificationFailure':{'rootSeed':'75','elapsedMs':90221,'status':'TIMEOUT'},
        'oldStrictReaderHostFailures':'Original old plans reject the common current host pin; exactly two errors retained per old case. Actual host/input/cleanup receipts pass; this allowance applies only to this diagnostic.',
        'conclusion':'No consistent current-build slowdown appears in these four samples; the full-run timeout cause remains unknown. No cohort rerun or acceptance inferred.',
        'priorPackagingAttempt':{'status':'FAIL','exitCode':1,'operation':'parse helper before any evidence read/write',
            'reason':'SyntaxError at multiline README expression','resolution':'parenthesize expression; diagnostic gate not rerun'},
        'payloads':[{'path':name,**{k:v for k,v in value.items() if k!='data'}} for name,value in sorted(packet.items.items())]}
    readme=('# Q30 root75 matched diagnostic\n\nCURRENT / OLD / OLD / CURRENT completed in 74.517 / 74.591 / 73.614 / 73.452 seconds, each483 work units. '+
        'Common current host, physical CPython3.13, original90s/640/5s limits and150-second host cases. Four actual hosts and cleanup pass; 34 recorded process instances absent. '+
        'The two old strict readers retain HOST_FAIL because their original plans pin the older host bytes. This diagnostic exception does not apply to qualification.\n\n'+
        'Source/app/overlay/allfive compiled-cache hashes unchanged before/after. Operation318.675 seconds; per-case cleanup recorded separately. CPU was not sampled. '+
        'No consistent current-build slowdown appears in these four observations; root cause remains unknown. The original cold77 TIMEOUT90.221s and45 NOT_RUN roots remain unresolved. Q30 stays disabled.\n')
    archive,contents=lib.build_archive(packet.items,manifest,readme)
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as check:
        assert {m.name:check.extractfile(m).read() for m in check}==contents
    ledger.recheck()
    DEST.mkdir(exist_ok=False)
    (DEST/'epoch15-root75-matched-diagnostic.tar.gz').write_bytes(archive)
    (DEST/'README.md').write_text(readme,encoding='utf-8')
    result={'schema':1,'status':'PACKAGED_DIAGNOSTIC_ONLY','archiveSha256':lib.sha(archive),
            'memberCount':len(contents),'sourceInputsRechecked':1354,'operationSeconds':pointer['operationSeconds'],
            'q30Acceptance':'NOT_ESTABLISHED','oldStrictReaderHostFailuresRetained':2}
    (DEST/'packet-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
