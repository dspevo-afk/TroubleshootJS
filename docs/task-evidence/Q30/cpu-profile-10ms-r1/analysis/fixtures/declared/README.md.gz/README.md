# CPU profile analysis fixtures

These data-only fixtures cover two attribution boundaries that must remain
independent of a browser run:

* A V8 profile sample points to the directly sampled top-of-stack node even
  when that aggregate call-tree node has children. The children remain
  aggregate context.
* A raw or unmapped function name cannot establish a routing, map, typed-heap,
  or publisher owner bucket. A unique validated source row is required. When a
  validated row contains both a specific map or typed-heap term and a broad
  routing term, the specific map bucket wins.

The fixture interpretation follows the Chrome DevTools Protocol Profiler
definition of ProfileNode children and Profile.samples:

https://raw.githubusercontent.com/ChromeDevTools/devtools-protocol/master/pdl/js_protocol.pdl

The fixtures are not a host proof and are not a substitute for the real A07
transport canaries or the maintained strict A07 report reader.
