# Q30 10 ms CPU-profile independent interpretation

## Scope and evidence

This is a read-only interpretation of the completed `cpu-10ms-r1-02-profile-10014`
diagnostic for the private Q30 baseline, seed `10014` (board seed `3`).  No host,
browser, build, or native test was launched for this note.  The case and input
audit are `PASS`; the full/source/web input aggregates are respectively
`53f869e8164f6b8edc3b75ba1e6a299a984de5c88829b60b04a9ca59e76787a9`,
`cb257f2158d02ece1fb0a3f7ac7386ec9a14e43100be1ad337d2e344aae0828e`, and
`e7377863185fc8208cb356474b39d14c9a82a35f5470bd7824d68113e1c03961` before and
after the case.

The archived raw V8 profile is 902,402 bytes with SHA-256
`829e1a8ef12c856761d83a3bbf404f867e98d8b555bb223aaed752e12d1aa142`.  The
sanitized profile hash is
`b2620e8275bd6a618373e3e1a31741536a306e17dcc2fb7641d8616e9c3bd54d`; the
canonical ScriptParsed-event hash is
`09967e3e0b499a8d616418b927bb7c184b6b7d20f41ef8a19ad81c02c450fce2`.
Script id `26` has an exact decoded cache payload match.  The decoded payload
SHA-256 is
`b10cd75edabbfd0954b3e96eecad14c15c56285454b5725db13318eb630daa5c`, the
cache artifact SHA-256 is
`09383cea503a4dd4219ae3877fee674ef455c58f47316da02547fe9734268bab`, and the
validated symbol-map artifact SHA-256 is
`99a7c9a7e85070aee5dabe44a4621ea489f40c5e259a861d8e8397fdb2e58018`.
The map contains one known exact `CirSim.lu_factor` row.  These hashes bind the
profile samples to the archived source payload and symbol map; they do not make
the sampled time a wall-time measurement.

## Profile result

The profile interval is 101,619,144 microseconds (101.619144 s), with 10,488
paired samples and paired delta sum 101,618,936 microseconds (101.618936 s).
The host requested a 10,000-microsecond interval, but the recorded deltas are
dynamic: min 5 us, p50 10,250 us, p95 10,589 us by linear interpolation (the
nearest observed delta at that percentile is 10,590 us), p99 10,734 us, max
14,948 us, mean 9,689.067 us.  Therefore the sample sum below is the actual paired
`timeDeltas` sum, not `sample_count * 10 ms`.

`Profile.samples[i]` identifies the directly sampled top-of-stack profile node
for sample `i`.  A sampled node is retained as direct sampled work even when
its aggregate call-tree node has `children`; those children are separate
aggregate context.  The archived attribution reports 10,019 mapped direct
samples, 424 unproven/unmapped samples, and zero non-leaf-context samples.

The independent method totals below aggregate duplicate profile-tree groups
that resolve to the same exact source method and sum their paired sample
deltas.  They are direct CPU-profile sample deltas, with no conversion to
elapsed application time.

| Direct mapped source method | Samples | Paired delta |
| --- | ---: | ---: |
| `CirSim::lu_factorAfterInputScan` (`CirSim.java:8075`) | 2,624 | 26.939751 s |
| `CirSim::$runCircuitOwned` (`CirSim.java:3283`) | 1,227 | 11.446438 s |
| `CirSim::lu_solve` (`CirSim.java:8171`) | 748 | 7.673846 s |
| `com.google.gwt.lang.Cast::canCast` (`Cast.java:40`) | 434 | 4.452377 s |
| `CircuitNode::$applyVoltage` (`CircuitNode.java:45`) | 315 | 3.225596 s |
| `CirSim::$stampMatrix` (`CirSim.java:3188`) | 204 | 2.041678 s |
| `CirSim::$calcWireCurrents` (`CirSim.java:3524`) | 192 | 1.973853 s |
| `CirSim::requireFiniteStamp` (`CirSim.java:3211`) | 192 | 1.963913 s |
| `CircuitElm::setNodeVoltage` (`CircuitElm.java:212`) | 143 | 1.460389 s |
| `PcbNetRouter$Router::$canTraverse` (`PcbNetRouter.java:574`) | about 140 | about 1.447 s |

The LU-named methods and factorization workspace total 3,491 samples and
35.828852 s (about 35.3% of paired CPU sample deltas).  A broader solver set
(`CirSim` plus `CircuitSolverExecutor`) totals 5,821 samples and 58.373747 s
(about 57.4%); it includes the LU subtotal, so those figures must not be added.

For comparison with the P07 areas, independently grouped mapped methods in the
broad routing/geometry classes (`PcbLayerRoutingPrototype`, `PcbNetRouter`,
spatial/coordinate/physical helpers) total 903 samples and 8.158938 s.  The
predeclared attribution routing/geometry/ancestry bucket is slightly broader:
962 samples and 8.513558 s.  The map/index/typed-heap bucket is 317 samples and
2.874846 s; its largest direct methods are GWT `TreeMap` and internal hash-map
helpers (`inOrderAdd`, iterator/entry lookup, and chain helpers).  That bucket
does not prove a particular typed-heap mechanism.  The publisher/admission
bucket has only 5 samples and 22,419 us (0.022419 s), so it is not a leading
direct sampled contributor.

### Context for the two runtime helpers

`Cast::canCast` is 434 direct samples and 4.452377 s.  Its nearest proven
mapped parent is `Cast::dynamicCast` for 397 samples/4.071749 s,
`Cast::instanceOf` for 35 samples/0.360022 s, and `Array::setCheck` for 2
samples/0.020606 s.  Walking farther up the raw parent tree, while keeping the
`Cast` helper's direct self weight unchanged, partitions that same 4.452377 s
into the most visible caller contexts as follows:

| Nearest mapped caller after Cast helper | Direct canCast samples | Inherited direct self delta |
| --- | ---: | ---: |
| `CirSim::$calcWireCurrents` | 91 | 0.935212 s |
| `TreeMap$EntryIterator::$next` | 59 | 0.607787 s |
| `AbstractMap$2$1::$next` | 57 | 0.589815 s |
| `CirSim::$getCircuitNode` | 47 | 0.483520 s |
| `Comparators$1::compare` | 35 | 0.353051 s |
| `Integer::$equals` | 25 | 0.257889 s |
| `PcbLayerRoutingPrototype$Search::$viaFits` | 21 | 0.217701 s |
| `CirSim::$calcWireInfo` | 18 | 0.183774 s |

The rows above are disjoint context assignments for the `canCast` samples, but
each is inherited context, not additional self time.  Across the full ancestry,
116 of those samples/1.197602 s also carry the overlapping
`AbstractCollection::toArray -> ArrayList::$addAll -> Vector::Vector` path.
No directly sampled `canCast` path reached a uniquely proven
`LuFactorizationWorkspace.lowerRows` or `lu_factor*` frame.  The `lowerRows`
field's short symbol is reused in the map, so an ambiguous `d` frame is not
treated as proof.  This run therefore points more strongly to collection,
iteration, and routing contexts than to a lower-row store check, while the
profile alone cannot establish why a cast is requested.

`Array::nativeArraySplice` is 96 direct samples and 0.976841 s.  Its nearest
proven mapped parent is `ArrayList::$insertAt` for 94 samples/0.956434 s and
`System::arraycopy` for 2 samples/0.020407 s.  The `ArrayList::$insertAt`
weight is itself under `ArrayList::$addAll -> Vector::Vector` for all 94
samples; 72 samples/0.740060 s also carry the routing
`Search::viaFits`/`Search::pathViaFits` ancestry, and 10 samples/0.104147 s
carry a `PcbPlacementPlanner` ancestor.  These ancestry weights overlap by
design with the 0.976841 s direct splice total and are not additive.  They
identify the observed call contexts while preserving `nativeArraySplice` as
the only self-time claim.

The Q30 report's independent application timers give cold/warm routing of
23,006/22,484 ms, proof of 71,135/0 ms, and PUBLISH of 68/64 ms.  The CPU
publisher sample total and those PUBLISH wall timers measure different things;
the profile does not establish that publisher CPU caused the full PUBLISH
timer.

The matched sequence also completed two unprofiled controls at the same seed,
with full input/report parity and clean PASS outcomes.  Their cold elapsed
times were 97,811 ms and 97,699 ms, versus 100,493 ms for the profiled run:
the observed profiled-run slowdown is therefore 2,682--2,794 ms.  This is an
observed run difference; exact causal profiler overhead is not isolated from
run order and other execution variation.  The control result binding is
`aa2f94e7198582b8e1412adc6853dbc6519c994c325e618aa3a1bddc4259299d`.

## Boundary and limits

The stop target and observed state were `RUNNING:warm`.  The recorded real stop
dispatch followed the observed-state read by 22.5 us; `Profiler.stop` round trip
was 0.2730073 s.  The profile is explicitly allowed to include warm work until
stop acknowledgement.  Comparing the recorded profile end and host dispatch
clocks gives an approximately 198 ms captured stop/ack tail estimate, not an
attribution of 198 ms of application work.  Navigation and the warm-boundary
tail remain in the captured interval.

This remains one completed CPU-profile attribution run.  The 10 ms setting has
dynamic interval sampling, and the controls show an observed 2.682--2.794 s
cold-run difference without isolating exact profiler overhead.  No wall-time,
allocation, heap-retention, causality, or optimization claim follows from these
samples.  The attribution's capped method listing and
bucket classification are useful for ranking only; the selected method totals
were recomputed from the raw profile and exact validated map.  The results also
do not separate solver work from its callers' inclusive context beyond the
direct sampled frame represented by each sample.

## One next measured step

The two controls are complete, so no control is pending.  As an optional next
CPU measurement for ranking confidence, after the separate publication/refresh
investigation run one matched ON repeat at the same seed, navigation, and
warm-boundary protocol, retaining the raw profile, exact cache/symbol-map
provenance, input aggregates, and Q30 timing report.  Compare LU,
routing/geometry, map/index, and publisher sample-delta totals with the
unprofiled controls and compare the report's cold/warm timers.  Treat it as a
repeatability observation rather than a new acceptance gate or a proof of
isolated diagnostic overhead.
