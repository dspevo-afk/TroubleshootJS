from pathlib import Path
import hashlib,json,statistics
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
sequence=json.loads((s/'cpu-10ms-r1-sequence-result.json').read_bytes())
assert sequence['status']=='FOCUSED_CPU_PROFILE_BOTH_CONTROL_COMPARISONS_PASS_PENDING_INTERPRETATION'
assert len(sequence['rows'])==3 and len(sequence['pairs'])==2 and sequence['notRun']==[]
for row in sequence['rows']:
    assert row['cold']['totalWork']==490 and row['cold']['hypothesisWork']==390
    assert row['cleanup']['status']=='PASS' and row['cleanup']['ownedSurvivors']==[]
cp=s/'cpu-10ms-r1-02-profile-10014/cpu-profile'
raw=json.loads((cp/'raw-v8-cpu-profile.json').read_bytes())
attribution=json.loads((cp/'attribution.json').read_bytes())
values=sorted(raw['timeDeltas']);assert len(values)==len(raw['samples'])==10488 and min(values)>=0
assert sum(values)==attribution['pairedSampledMicroseconds']==101618936
note=s/'scratch/cpu-10ms-r1-independent-interpretation.md'
assert sha(note.read_bytes())=='6289bf6f52c66b0ba2efd0a7ad59c60f9a30d8a194cf5dd827e06a7a81df8e96'
control=[sequence['rows'][i]['cold']['elapsedMs'] for i in [0,2]]
profile=sequence['rows'][1]['cold']['elapsedMs']
out=s/'cpu-10ms-r1-root-decision.json';assert not out.exists()
result={'status':'PASS_COARSE_PRIVATE_CPU_RANKING_ONLY','Q30':'BLOCKED_NOT_ACCEPTED',
 'sequenceSha256':sha((s/'cpu-10ms-r1-sequence-result.json').read_bytes()),
 'independentInterpretationSha256':sha(note.read_bytes()),
 'controlColdMs':control,'profileColdMs':profile,'profileMinusControlMs':[profile-x for x in control],
 'withinControlRangeMs':max(control)-min(control),'allRowsExceed90000':all(x>90000 for x in control+[profile]),
 'sampleDeltaMicroseconds':{'count':len(values),'sum':sum(values),'min':values[0],'p50':statistics.median(values),
   'p95NearestObservedIndexFloor':values[int(.95*len(values))],'max':values[-1],
   'negative':sum(v<0 for v in values),'zero':values.count(0),'below1000':sum(v<1000 for v in values)},
 'mapping':{k:attribution[k] for k in ['mappedGwtSampleCount','ambiguousSampleCount','unprovenOrUnmappedSampleCount','aggregateChildrenContextSampleCount','attributionQuality']},
 'interpretation':'One profile with navigation and observed warm-boundary tail. Paired sample deltas are CPU attribution, not additive application wall stages. Observed slowdown exceeds control spread; exact causal overhead and population performance not established.',
 'decision':'Retain source-mapped CPU ranking. Continue existing private publication/refresh operation probe; consider bounded one-site LU finite-check dispatch trial only after exact compiled guard inspection and focused gates. No generic publication batching or new matrix indexing trial justified.',
 'unchanged':'Same exact source/build/application query in CPU OFF/ON/OFF. Strict original reports, full non-timing parity, private cold cache isolation and owned cleanup pass.'}
out.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'status':result['status'],'sha256':sha(out.read_bytes()),'deltas':result['profileMinusControlMs']}))
