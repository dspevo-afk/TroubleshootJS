from pathlib import Path
import ast,hashlib,json
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
d=s/'cpu-profile-10ms-r1-draft'
manifest=json.loads((d/'manifest.json').read_bytes())
for key in ['driver','validator','readme']:
    e=manifest[key];raw=(d/e['path']).read_bytes()
    assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
for e in manifest['analysisFixtures']:
    raw=(d/e['path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
assert manifest['driver']['sha256']=='1197d7f81653361a91f30ae561fc3e928f96446b6d658c6625e317bb3573c43b'
assert manifest['validator']['sha256']=='e388f9f93982a3f6c3e2b9abfe2ecd6fce59870ac35cdee6afd39bf15f81b4c0'
assert sha((s/'cpu-profile-10ms-lifecycle-review-r2.md').read_bytes())=='d106344aa40d4e94b8f98b16d874e9f6f537424b4541968b56cc63df298abbc2'
assert json.loads((s/'cpu-10ms-analysis-fixtures-root-result.json').read_bytes())['status']=='PASS_OFFLINE_ANALYSIS_ONLY'
assert json.loads((s/'cpu-profile-10ms-r1-fixture-preflight.json').read_bytes())['status']=='PASS_UNCHANGED_SOURCE_AND_RUNTIME_ONLY'
paths=['cpu-profile-10ms-r1-draft/cpu_profile_10ms.py','cpu-profile-10ms-r1-draft/validate_cpu_profile_10ms.py',
       'cpu-profile-10ms-r1-draft/manifest.json','cpu-profile-10ms-r1-draft/README.md',
       'cpu-profile-10ms-lifecycle-review-r2.md','cpu-10ms-analysis-fixtures-root-result.json',
       'cpu-profile-10ms-r1-fixture-preflight.json','cpu-profile-10ms-r1-measurement-plan.json',
       'run_cpu_10ms_host_canaries_root.py','run_cpu_10ms_timing.py','read_a07.ps1']
for name in paths:
    if name.endswith('.py'):ast.parse((s/name).read_bytes().decode('utf-8-sig'))
record={'status':'ROOT_REVIEWED_READY_FOR_REAL_HOST_CANARIES',
        'files':[{'path':f,'sha256':sha((s/f).read_bytes())} for f in paths],
        'review':'Root reviewed sample attribution and metadata reader; independent R2 reviewed only repaired lifecycle defects. Three independent offline analysis fixtures PASS. Root corrected canonical request string type using actual prior report; original reader retained. No application changes.',
        'limits':'Real host canaries NOT RUN yet. Inherited launch-failure-before-process-identity window remains a disclosed host limit; no unsafe cleanup fallback. CPU profile quality and fresh Q30 comparisons pending.'}
out=s/'cpu-10ms-reviewed-host-binding.json';assert not out.exists()
out.write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'status':record['status'],'bindingSha256':sha(out.read_bytes())}))
