from pathlib import Path
import ast,hashlib,json
s=Path(__file__).resolve().parent
repo=Path('<REPO_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
canary=json.loads((s/'cpu-10ms-reviewed-host-binding.json').read_bytes())
for e in canary['files']:assert sha((s/e['path']).read_bytes())==e['sha256'],e['path']
gate=json.loads((s/'cpu-10ms-r1-host-canaries.json').read_bytes())
assert gate['status']=='REAL_HOST_CANARIES_PASS_NOT_Q30_MEASUREMENT' and len(gate['rows'])==3
assert all(r['status']=='PASS' and r['exitCode']==r['readerExitCode']==0 for r in gate['rows'])
paths=[e['path'] for e in canary['files']]+['cpu-10ms-reviewed-host-binding.json','cpu-10ms-r1-host-canaries.json','validate_current_q30_timing_pair.py']
refs={'tests/browser/compiled_attribute_acceptance.py':'1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4',
      'docs/task-evidence/Q30/scale-plan-4/check_coordinator.py':'247ded434bcdbdba6f78e7edf8f9c8b3671aaf8465bfabb29c875d5b2512bddb',
      'docs/task-evidence/Q30/scale-plan-4/check_d01.py':'f58847541571cdf829835d05c200bac6ea0079dab065d90ebdf7f44914241929'}
for f,h in refs.items():assert sha((repo/f).read_bytes())==h,f
assert sha((s/'validate_current_q30_timing_pair.py').read_bytes())=='67430d7c56d872d115a7c38732bf60101cff52e8bf40f7af075213debc8e7e3b'
driver=s/'run_cpu_10ms_sequence_root.py';ast.parse(driver.read_bytes().decode())
out=s/'cpu-10ms-execution-binding.json';assert not out.exists()
record={'status':'FROZEN_READY_FOR_FOCUSED_CPU_MEASUREMENT','driverSha256':sha(driver.read_bytes()),
        'files':[{'path':f,'sha256':sha((s/f).read_bytes())} for f in paths],
        'repoFiles':[{'path':f,'sha256':h} for f,h in refs.items()],
        'preconditions':'Source review, independent lifecycle rereview, three offline attribution fixtures, real A07 positive/start-negative/active-stop-negative, strict A07 and reader negatives, source/runtime input audit all PASS. No overlapping expensive process.',
        'limits':'Configured10000-us sampling; actual sample intervals must be reported, not assumed constant. Fresh comparison and CPU mapping outcome are pending; Q30 remains BLOCKED.'}
out.write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'status':record['status'],'bindingSha256':sha(out.read_bytes()),'driverSha256':record['driverSha256']}))
