from pathlib import Path
import ast, hashlib, json

s = Path(__file__).resolve().parent
old = s / 'run_timing.py'
raw = old.read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(raw) == 'a7ef67c63397a28c1781b40746507fc0fa129f030742b8c6201350f099a9765f'
text = raw.decode('utf-8')
text = text.replace("query='&tsjQ30KernelProfile=true' if profile else ''", "query=''  # External CDP sampling changes no application query.\nhost=scratch/'cpu-profile-10ms-r1-draft/cpu_profile_10ms.py' if profile else repo/'tests/browser/compiled_attribute_acceptance.py'\nhost_flags=['--require-warm-boundary'] if profile else []")
before = "[sys.executable,'-B',str(repo/'tests/browser/compiled_attribute_acceptance.py'),str(root),str(out),str(spec)]"
after = "[sys.executable,'-B',str(host),str(root),str(out),str(spec)]+host_flags"
assert text.count(before) == 1
text = text.replace(before, after).replace('\r\n', '\n')
ast.parse(text)
out = s / 'run_cpu_10ms_timing.py'
assert not out.exists()
out.write_bytes(text.encode('utf-8'))
receipt = {'status': 'SOURCE_ONLY_ADAPTER_READY_PENDING_DRIVER_REVIEW', 'baseSha256': sha(raw),
           'adapterSha256': sha(out.read_bytes()),
           'changes': ['No application profile query', 'External CPU host only for profile arm',
                       'Require host-observed warm boundary in profile arm', 'Normalize source line endings only'],
           'notRun': 'No build, host, browser, measurement or application check run by this preparation.'}
(s / 'cpu-10ms-timing-adapter-preparation.json').write_bytes((json.dumps(receipt, indent=2)+'\n').encode('utf-8'))
print(json.dumps(receipt))
