"""Host-driven acceptance checks for compiled developer attributes.

Each case navigates Edge to a relative ``circuitjs.html`` URL and reads
attributes from ``html`` until a declared terminal state appears.  The runner
does not inject JavaScript or call application controllers.  Its output is
retained for audit and replay; this script never removes it.

Usage::

    python tests/browser/compiled_attribute_acceptance.py REPO OUTPUT SPEC_JSON

The output directory must be a new directory below the OS temporary directory.
The spec is an object containing ``cases``.  Each case contains ``name``,
``path``, ``stateAttribute``, ``timeoutSeconds``, and exactly one of
``expectedState`` or ``expectedPrefix``.  ``terminalPrefixes`` defaults to
``["PASS", "FAIL"]`` and ``reportAttribute`` is optional.
"""

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import urlsplit

import csv
import gzip
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone


try:
    from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
    from playwright.sync_api import sync_playwright
except ImportError:  # Validation still works on a host without Playwright.
    PlaywrightTimeoutError = TimeoutError
    sync_playwright = None


SCRIPT_SCHEMA = 1
DEFAULT_TERMINAL_PREFIXES = ["PASS", "FAIL"]
POLL_SECONDS = 0.2
MAX_ATTRIBUTE_TIMEOUT_MS = 10000
# Outer capture allowance for an aggregate compiled census. Application jobs
# retain their own independent deadlines, unit counts and per-unit guards.
MAX_TIMEOUT_SECONDS = 900.0
ATTRIBUTE_RE = re.compile(r"^data-tsj-[A-Za-z0-9][A-Za-z0-9-]*$")
CASE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")
INPUT_ROOTS = ("src", "war")
CHUNK_SIZE = 1024 * 1024
CPU_PROFILE_SAMPLING_INTERVAL_US = 1000
CPU_PROFILE_CACHE_RE = re.compile(r"/([0-9A-Fa-f]{32})\.cache\.js$")
CPU_PROFILE_ALLOWED_PATHS = ("/circuitjs.html", "/circuitjs1/", "/tsj-", "/font/")
GWT_SYMBOL_FIELDS = ("jsName", "jsniIdent", "className", "memberName",
                     "sourceUri", "sourceLine", "fragmentNumber")


class QuietHandler(SimpleHTTPRequestHandler):
    """Serve the compiled web root without polluting the acceptance log."""

    def log_message(self, *args):
        pass

    def _serve_optional_favicon(self):
        # The browser may request the optional site icon even though this
        # compiled fixture intentionally has no favicon file.  Keep that
        # normal host request out of the app's HTTP error budget; every other
        # missing or failed resource still follows SimpleHTTPRequestHandler
        # and remains a strict acceptance error.
        if self.path != "/favicon.ico":
            return False
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()
        return True

    def do_GET(self):
        if not self._serve_optional_favicon():
            super().do_GET()

    def do_HEAD(self):
        if not self._serve_optional_favicon():
            super().do_HEAD()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def is_within(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def require_string(value, label):
    if not isinstance(value, str) or not value:
        raise ValueError(label + " must be a non-empty string")
    if "\r" in value or "\n" in value or any(ord(char) < 32 for char in value):
        raise ValueError(label + " contains a control character")
    return value


def validate_attribute(value, label):
    value = require_string(value, label)
    if not ATTRIBUTE_RE.fullmatch(value):
        raise ValueError(label + " must be a data-tsj-* attribute")
    return value


def validate_prefix(value, label):
    value = require_string(value, label)
    if len(value) > 256:
        raise ValueError(label + " is too long")
    return value


def validate_case_path(value):
    value = require_string(value, "case.path")
    if "\\" in value or value.startswith("/") or value.startswith("//"):
        raise ValueError("case.path must be a relative URL")
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc or parsed.path != "circuitjs.html":
        raise ValueError("case.path must name circuitjs.html with an optional query")
    if parsed.fragment:
        raise ValueError("case.path must not contain a fragment")
    return value


def validate_timeout(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(label + " must be a number")
    value = float(value)
    if not math.isfinite(value) or value <= 0 or value > MAX_TIMEOUT_SECONDS:
        raise ValueError(label + " must be greater than 0 and no more than 900 seconds")
    return value


def normalise_case(case, index):
    if not isinstance(case, dict):
        raise ValueError("cases[%d] must be an object" % index)
    allowed = {"name", "path", "stateAttribute", "expectedState", "expectedPrefix",
               "terminalPrefixes", "timeoutSeconds", "reportAttribute"}
    unknown = sorted(set(case) - allowed)
    if unknown:
        raise ValueError("cases[%d] has unsupported fields: %s" %
                         (index, ", ".join(unknown)))
    name = require_string(case.get("name"), "cases[%d].name" % index)
    path = validate_case_path(case.get("path"))
    state_attribute = validate_attribute(case.get("stateAttribute"),
                                         "cases[%d].stateAttribute" % index)
    has_expected_state = "expectedState" in case
    has_expected_prefix = "expectedPrefix" in case
    if has_expected_state == has_expected_prefix:
        raise ValueError("cases[%d] must contain exactly one expectedState or expectedPrefix" % index)
    expected_state = (require_string(case["expectedState"],
                                     "cases[%d].expectedState" % index)
                      if has_expected_state else None)
    expected_prefix = (validate_prefix(case["expectedPrefix"],
                                       "cases[%d].expectedPrefix" % index)
                       if has_expected_prefix else None)

    terminal_prefixes = case.get("terminalPrefixes", DEFAULT_TERMINAL_PREFIXES)
    if not isinstance(terminal_prefixes, list) or not terminal_prefixes:
        raise ValueError("cases[%d].terminalPrefixes must be a non-empty array" % index)
    terminal_prefixes = [validate_prefix(prefix,
                                          "cases[%d].terminalPrefixes" % index)
                         for prefix in terminal_prefixes]
    report_attribute = case.get("reportAttribute")
    if report_attribute is not None:
        report_attribute = validate_attribute(report_attribute,
                                              "cases[%d].reportAttribute" % index)
    timeout_seconds = validate_timeout(case.get("timeoutSeconds"),
                                       "cases[%d].timeoutSeconds" % index)
    slug = CASE_NAME_RE.sub("-", name).strip("-._") or "case"
    return {
        "index": index,
        "name": name,
        "path": path,
        "stateAttribute": state_attribute,
        "expectedState": expected_state,
        "expectedPrefix": expected_prefix,
        "terminalPrefixes": terminal_prefixes,
        "reportAttribute": report_attribute,
        "timeoutSeconds": timeout_seconds,
        "slug": "%03d-%s" % (index, slug[:80]),
    }


def load_spec(spec_path):
    raw = spec_path.read_bytes()
    try:
        spec = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("spec JSON is invalid: " + str(error))
    if not isinstance(spec, dict) or set(spec) != {"cases"}:
        raise ValueError("spec JSON must contain only a cases array")
    cases = spec["cases"]
    if not isinstance(cases, list) or not cases:
        raise ValueError("spec.cases must be a non-empty array")
    return spec, raw, [normalise_case(case, index + 1)
                       for index, case in enumerate(cases)]


def input_files(repo):
    """Yield every regular file in the fixed source and compiled web roots."""
    seen = set()
    for root_name in INPUT_ROOTS:
        root = repo / root_name
        if root.is_symlink() or not root.is_dir():
            raise ValueError("input root is missing or a symlink: " + root_name)
        for directory, directory_names, file_names in os.walk(root, followlinks=False):
            directory_path = Path(directory)
            kept_directories = []
            for directory_name in directory_names:
                child = directory_path / directory_name
                if child.is_symlink():
                    raise ValueError("input tree contains a symlink: " +
                                     str(child.relative_to(repo)))
                kept_directories.append(directory_name)
            directory_names[:] = kept_directories
            for file_name in file_names:
                child = directory_path / file_name
                if child.is_symlink():
                    raise ValueError("input tree contains a symlink: " +
                                     str(child.relative_to(repo)))
                resolved = child.resolve()
                if not is_within(resolved, repo):
                    raise ValueError("input tree escapes the repository: " +
                                     str(child.relative_to(repo)))
                relative = resolved.relative_to(repo).as_posix()
                if relative not in seen:
                    seen.add(relative)
                    yield relative, resolved


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            block = stream.read(CHUNK_SIZE)
            if not block:
                return digest.hexdigest()
            digest.update(block)


def capture_input_manifest(repo):
    files = []
    for relative, path in sorted(input_files(repo), key=lambda item: item[0]):
        files.append({"path": relative, "size": path.stat().st_size,
                      "sha256": sha256_file(path)})
    canonical = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8")
    source_files = [row for row in files if row["path"].startswith("src/")]
    web_files = [row for row in files if row["path"].startswith("war/")]
    def aggregate(rows):
        value = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(value).hexdigest()
    return {
        "schema": 1,
        "capturedUtc": utc_now(),
        "roots": list(INPUT_ROOTS),
        "files": files,
        "fileCount": len(files),
        "sourceFileCount": len(source_files),
        "webFileCount": len(web_files),
        "sha256": hashlib.sha256(canonical).hexdigest(),
        "sourceSha256": aggregate(source_files),
        "webSha256": aggregate(web_files),
    }


def capture_script_identity(repo):
    script = Path(__file__).resolve()
    path = script.relative_to(repo).as_posix() if is_within(script, repo) else script.name
    return {"path": path, "size": script.stat().st_size,
            "sha256": sha256_file(script)}


def process_rows():
    query = ("Get-CimInstance Win32_Process | Select-Object "
             "@{n='pid';e={$_.ProcessId}},@{n='parent';e={$_.ParentProcessId}},"
             "@{n='created';e={$_.CreationDate.ToUniversalTime().ToString('o')}},"
             "ExecutablePath | ConvertTo-Json -Compress")
    result = subprocess.run(["powershell.exe", "-NoProfile", "-Command", query],
                            capture_output=True, text=True, timeout=20)
    if result.returncode:
        raise RuntimeError("process identity query failed: " + result.stderr.strip())
    if not result.stdout.strip():
        return []
    rows = json.loads(result.stdout)
    return [rows] if isinstance(rows, dict) else rows


def owned_edge_rows(rows):
    process_ids = {os.getpid()}
    while True:
        expanded = set(process_ids)
        for row in rows:
            try:
                if int(row.get("parent")) in process_ids:
                    expanded.add(int(row.get("pid")))
            except (TypeError, ValueError):
                continue
        if expanded == process_ids:
            break
        process_ids = expanded
    return [row for row in rows
            if int(row.get("pid", -1)) in process_ids and
            "msedge.exe" in (row.get("ExecutablePath") or "").lower()]


def save_json(output, name, value):
    path = output / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def save_raw(output, name, value):
    path = output / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value.encode("utf-8"))
    return path




def _cpu_cache_name(path):
    match = CPU_PROFILE_CACHE_RE.search(path or "")
    return match.group(1).upper() if match else None


def _safe_cpu_profile_path(raw_url):
    """Return only an allowlisted local app path; accept sanitized paths on replay."""
    parsed = urlsplit(raw_url or "")
    path = parsed.path
    local_http = (parsed.scheme in ("http", "https") and
                  parsed.hostname in ("127.0.0.1", "localhost"))
    already_sanitized = not parsed.scheme and not parsed.netloc
    if ((local_http or already_sanitized) and
            path.startswith(CPU_PROFILE_ALLOWED_PATHS)):
        return path
    return ""


def _walk_debugger_stack(stack):
    while isinstance(stack, dict):
        for frame in stack.get("callFrames", []):
            if isinstance(frame, dict):
                yield frame
        parent = stack.get("parent")
        if not isinstance(parent, dict):
            break
        stack = parent


def _read_gwt_download_payload(repo, strong_name):
    """Decode GWT's JSON-string array wrapper without executing its contents."""
    bundle_path = repo / "war/circuitjs1" / (strong_name + ".cache.js")
    bundle_bytes = bundle_path.read_bytes()
    bundle_text = bundle_bytes.decode("utf-8-sig")
    prefix = "circuitjs1.onScriptDownloaded("
    if not bundle_text.startswith(prefix):
        raise ValueError("cache bundle does not start with the expected GWT wrapper")
    position = len(prefix)
    while position < len(bundle_text) and bundle_text[position].isspace():
        position += 1
    if position >= len(bundle_text) or bundle_text[position] != "[":
        raise ValueError("GWT wrapper payload is not a JSON array")
    fragments, end = json.JSONDecoder().raw_decode(bundle_text, position)
    if not isinstance(fragments, list) or not fragments or not all(
            isinstance(fragment, str) for fragment in fragments):
        raise ValueError("GWT wrapper array must contain non-empty string fragments")
    if bundle_text[end:].strip() != ");":
        raise ValueError("GWT wrapper has an unexpected suffix")
    payload_text = "".join(fragments)
    payload_bytes = payload_text.encode("utf-8")
    embedded_names = re.findall(
        r"\$strongName\s*=\s*['\"]([0-9A-Fa-f]{32})['\"]", payload_text)
    if embedded_names != [strong_name]:
        raise ValueError("decoded GWT payload strong name does not match its cache filename")
    return {
        "strongName": strong_name,
        "cacheFileSha256": hashlib.sha256(bundle_bytes).hexdigest(),
        "cacheFileBytes": len(bundle_bytes),
        "payloadSha256": hashlib.sha256(payload_bytes).hexdigest(),
        "payloadUtf8Bytes": len(payload_bytes),
        "fragmentCount": len(fragments),
        "embeddedStrongNameCount": len(embedded_names),
        "wrapperValidated": True,
    }, bundle_bytes, payload_bytes


def capture_profile_script_provenance(repo, profile, cdp_session, script_events):
    """Link sampled scriptIds only to exact GWT URLs or their decoded payload bytes."""
    nodes_by_id = {node.get("id"): node for node in profile.get("nodes", [])}
    sampled_script_ids = set()
    for node_id in profile.get("samples", []):
        node = nodes_by_id.get(node_id)
        frame = node.get("callFrame", {}) if node else {}
        script_id = str(frame.get("scriptId", ""))
        if script_id not in ("", "0") and not _cpu_cache_name(
                _safe_cpu_profile_path(frame.get("url", ""))):
            sampled_script_ids.add(script_id)

    strong_names = set()
    for node in profile.get("nodes", []):
        path = _safe_cpu_profile_path(node.get("callFrame", {}).get("url", ""))
        strong = _cpu_cache_name(path)
        if strong:
            strong_names.add(strong)
    for event in script_events.values():
        strong = _cpu_cache_name(_safe_cpu_profile_path(event.get("url", "")))
        if strong:
            strong_names.add(strong)

    bundles = {}
    bundle_evidence = []
    for strong in sorted(strong_names):
        try:
            metadata, file_bytes, payload_bytes = _read_gwt_download_payload(repo, strong)
            bundles[strong] = (file_bytes, payload_bytes)
            bundle_evidence.append(metadata)
        except BaseException as error:
            bundle_evidence.append({
                "strongName": strong,
                "wrapperValidated": False,
                "error": type(error).__name__ + ": " + str(error),
            })

    script_map = {}
    evidence_rows = []
    for script_id in sorted(sampled_script_ids):
        event = script_events.get(script_id, {})
        event_url = _safe_cpu_profile_path(event.get("url", ""))
        linked_names = set()
        event_url_name = _cpu_cache_name(event_url)
        if event_url_name:
            linked_names.add(event_url_name)
        stack_paths = []
        for stack_frame in _walk_debugger_stack(event.get("stackTrace")):
            path = _safe_cpu_profile_path(stack_frame.get("url", ""))
            if path:
                stack_paths.append(path)

        source_text = None
        source_error = None
        try:
            response = cdp_session.send("Debugger.getScriptSource", {
                "scriptId": script_id})
            value = response.get("scriptSource") if isinstance(response, dict) else None
            if isinstance(value, str):
                source_text = value
            else:
                source_error = "Debugger.getScriptSource returned no source text"
        except BaseException as error:
            source_error = type(error).__name__ + ": " + str(error)

        source_sha256 = None
        source_bytes = None
        payload_matches = []
        if source_text is not None:
            source_bytes_value = source_text.encode("utf-8")
            source_sha256 = hashlib.sha256(source_bytes_value).hexdigest()
            source_bytes = len(source_bytes_value)
            for strong, (file_bytes, payload_bytes) in sorted(bundles.items()):
                match_kind = None
                if source_bytes_value == file_bytes:
                    match_kind = "exact-cache-file-bytes"
                elif source_bytes_value == payload_bytes:
                    match_kind = "exact-decoded-payload-bytes"
                elif source_bytes >= 256 and source_bytes_value in payload_bytes:
                    match_kind = "exact-decoded-payload-substring-256plus"
                if match_kind:
                    payload_matches.append({
                        "strongName": strong,
                        "match": match_kind,
                        "scriptSourceSha256": source_sha256,
                    })
                    linked_names.add(strong)

        unique_names = sorted(linked_names)
        linked_strong = unique_names[0] if len(unique_names) == 1 else None
        if linked_strong:
            script_map[script_id] = linked_strong
        evidence_rows.append({
            "scriptId": script_id,
            "debuggerScriptParsedObserved": bool(event),
            "scriptParsedUrl": event_url,
            "scriptParsedHash": event.get("hash") if isinstance(event.get("hash"), str) else None,
            "scriptParsedStackPaths": sorted(set(stack_paths)),
            "scriptSourceSha256": source_sha256,
            "scriptSourceUtf8Bytes": source_bytes,
            "scriptSourceError": source_error,
            "decodedPayloadMatches": payload_matches,
            "linkedStrongNames": unique_names,
            "linkedStrongName": linked_strong,
            "linkBasis": (
                "exact-scriptParsed-cache-url" if event_url_name and linked_strong else
                "exact-script-source-vs-decoded-payload" if len(payload_matches) == 1 and linked_strong else
                "conflicting-exact-links" if len(unique_names) > 1 else "unlinked"),
        })
    return script_map, evidence_rows, bundle_evidence


def save_cpu_profile_artifacts(repo, output, case, profile, capture,
                               script_id_to_strong_name=None):
    """Keep a sanitized V8 profile and source-proven GWT symbol attribution."""
    script_id_to_strong_name = script_id_to_strong_name or {}
    profile_dir = output / "cpu-profile"
    profile_dir.mkdir(parents=True, exist_ok=True)
    sanitized = profile
    strong_names = set()
    wanted_names = {}

    for node in sanitized.get("nodes", []):
        frame = node.get("callFrame", {})
        path = _safe_cpu_profile_path(frame.get("url", ""))
        frame["url"] = path
        strong = _cpu_cache_name(path)
        if strong:
            strong_names.add(strong)

    # Keep profile function names available to build the symbol lookup table,
    # but do not attribute an empty-URL frame by name alone. Its scriptId must
    # first be linked to a loaded bundle by exact Debugger/source evidence.
    strong_names.update(script_id_to_strong_name.values())
    for node in sanitized.get("nodes", []):
        frame = node.get("callFrame", {})
        name = frame.get("functionName", "")
        script_id = str(frame.get("scriptId", ""))
        if not name:
            continue
        direct = _cpu_cache_name(frame.get("url", ""))
        targets = ([direct] if direct else sorted(strong_names))
        for strong in targets:
            wanted_names.setdefault(strong, set()).add(name)

    profile_bytes = json.dumps(sanitized, ensure_ascii=False,
                               separators=(",", ":")).encode("utf-8")
    profile_path = profile_dir / "v8-cpu-profile.json"
    profile_path.write_bytes(profile_bytes)

    symbol_tables = {}
    symbol_artifacts = []
    symbol_root = profile_dir / "symbolMaps"
    symbol_root.mkdir(parents=True, exist_ok=True)
    for strong in sorted(strong_names):
        symbol_path = (repo / "war/WEB-INF/deploy/circuitjs1/symbolMaps" /
                       (strong + ".symbolMap"))
        if not symbol_path.is_file():
            symbol_artifacts.append({
                "strongName": strong, "status": "MISSING",
                "repoPath": symbol_path.relative_to(repo).as_posix()})
            continue
        symbol_bytes = symbol_path.read_bytes()
        symbol_sha = hashlib.sha256(symbol_bytes).hexdigest()
        archived = symbol_root / (strong + ".symbolMap.gz")
        archived.write_bytes(gzip.compress(symbol_bytes, mtime=0))
        wanted = wanted_names.get(strong, set())
        table = {}
        known_lu_factor_rows = []
        with symbol_path.open("r", encoding="utf-8", newline="") as stream:
            # GWT's CSV field names are themselves a comment. Filtering comments
            # and using DictReader's default would consume the first data row as
            # its header and silently lose all symbol attribution.
            records = csv.DictReader(
                (line for line in stream if not line.startswith("#")),
                fieldnames=GWT_SYMBOL_FIELDS)
            for row in records:
                if (row.get("className") ==
                        "com.lushprojects.circuitjs1.client.CirSim" and
                        row.get("memberName") == "lu_factor"):
                    known_lu_factor_rows.append(row)
                js_name = row.get("jsName", "")
                if js_name in wanted:
                    table.setdefault(js_name, []).append({
                        "jsName": js_name,
                        "jsniIdent": row.get("jsniIdent", ""),
                        "className": row.get("className", ""),
                        "memberName": row.get("memberName", ""),
                        "sourceUri": row.get("sourceUri", ""),
                        "sourceLine": row.get("sourceLine", ""),
                        "fragmentNumber": row.get("fragmentNumber", ""),
                    })
        map_valid = len(known_lu_factor_rows) == 1
        symbol_tables[strong] = table
        symbol_artifacts.append({
            "strongName": strong,
            "status": "PASS" if map_valid else "INVALID",
            "knownCirSimLuFactorRows": len(known_lu_factor_rows),
            "knownCirSimLuFactorJsName": (
                known_lu_factor_rows[0].get("jsName") if map_valid else None),
            "repoPath": symbol_path.relative_to(repo).as_posix(),
            "sha256": symbol_sha,
            "compressedArtifact": archived.relative_to(output).as_posix(),
            "compressedBytes": archived.stat().st_size,
            "mappedProfileFunctionCount": sum(1 for rows in table.values() if len(rows) == 1),
            "ambiguousSymbolCount": sum(1 for rows in table.values() if len(rows) > 1),
            "profileFunctionCount": len(wanted),
        })

    nodes_by_id = {node.get("id"): node for node in sanitized.get("nodes", [])}
    samples = sanitized.get("samples", [])
    deltas = sanitized.get("timeDeltas", [])
    sample_groups = {}
    gwt_sample_count = 0
    mapped_gwt_sample_count = 0
    pair_count = min(len(samples), len(deltas))
    for index in range(pair_count):
        node = nodes_by_id.get(samples[index])
        frame = node.get("callFrame", {}) if node else {}
        function_name = frame.get("functionName", "")
        direct_strong = _cpu_cache_name(frame.get("url", ""))
        script_id = str(frame.get("scriptId", ""))
        proven_strong = (direct_strong or
                         script_id_to_strong_name.get(script_id))
        if direct_strong:
            strong = direct_strong
            mapping_basis = "profile-url"
        elif proven_strong:
            strong = proven_strong
            mapping_basis = "exact-debugger-source-proven-scriptId"
        else:
            strong = None
            mapping_basis = None
        mappings = (symbol_tables.get(strong, {}).get(function_name, [])
                    if strong and function_name else [])
        mapping = mappings[0] if len(mappings) == 1 else None
        if mapping is not None:
            mapped_gwt_sample_count += 1
        if mapping:
            label = mapping["className"] + "::" + mapping["memberName"]
            source_uri = mapping["sourceUri"]
            source_line = mapping["sourceLine"]
        else:
            label = function_name or "<anonymous-or-unmapped>"
            source_uri = ""
            source_line = ""
        key = (strong or "", label, source_uri, source_line, function_name,
               mapping_basis or "unmapped")
        group = sample_groups.get(key)
        if group is None:
            group = {
                "strongName": strong,
                "functionName": function_name,
                "label": label,
                "sourceUri": source_uri,
                "sourceLine": source_line,
                "mapped": mapping is not None,
                "mappingBasis": mapping_basis,
                "sampleCount": 0,
                "sampledMicroseconds": 0,
            }
            sample_groups[key] = group
        group["sampleCount"] += 1
        delta = deltas[index]
        if isinstance(delta, (int, float)) and delta >= 0:
            group["sampledMicroseconds"] += delta

    mapped_groups = [row for row in sample_groups.values() if row["mapped"]]
    unmapped_groups = [row for row in sample_groups.values() if not row["mapped"]]
    sort_groups = lambda rows: sorted(
        rows, key=lambda row: (-row["sampledMicroseconds"], row["label"]))
    summary = {
        "schema": 1,
        "caseName": case["name"],
        "samplingIntervalMicroseconds": CPU_PROFILE_SAMPLING_INTERVAL_US,
        "profileStartTimeMicroseconds": sanitized.get("startTime"),
        "profileEndTimeMicroseconds": sanitized.get("endTime"),
        "profileRangeMicroseconds": (
            sanitized.get("endTime", 0) - sanitized.get("startTime", 0)
            if isinstance(sanitized.get("endTime"), (int, float)) and
               isinstance(sanitized.get("startTime"), (int, float)) else None),
        "profileFile": profile_path.relative_to(output).as_posix(),
        "profileSha256": hashlib.sha256(profile_bytes).hexdigest(),
        "profileNodeCount": len(sanitized.get("nodes", [])),
        "sampleCount": len(samples),
        "timeDeltaCount": len(deltas),
        "pairedSampleCount": pair_count,
        "sampleArraysAligned": len(samples) == len(deltas),
        "gwtBundleCount": len(strong_names),
        "gwtBundleStrongNames": sorted(strong_names),
        "mappedGwtSampleCount": mapped_gwt_sample_count,
        "provenScriptIdCount": len(script_id_to_strong_name),
        "scriptIdStrongNames": dict(sorted(script_id_to_strong_name.items())),
        "allGwtSymbolMapsValidated": bool(strong_names) and all(
            row.get("status") == "PASS" for row in symbol_artifacts),
        "frameAttributionRule": (
            "A sampled frame is attributed only from its own hashed cache URL or "
            "from an exact scriptId link established by Debugger.scriptParsed cache "
            "URL or script-source bytes matching the decoded GWT payload. Function-"
            "name matches and eval-stack ancestry do not establish source identity."),
        "scriptProvenance": capture.get("scriptProvenance", {}),
        "pairedSampledMicroseconds": sum(
            delta for delta in deltas[:pair_count]
            if isinstance(delta, (int, float)) and delta >= 0),
        "symbolMaps": symbol_artifacts,
        "captureBoundary": {
            key: capture.get(key) for key in (
                "scope", "startIncludesNavigation", "stopReason", "stopTargetState",
                "stopObservedState", "stopObservedUtc", "stopObservedHostMonotonicSeconds",
                "transitionDetectionWindowSeconds", "stateReadRoundTripSeconds",
                "pollIntervalSeconds", "profileMayIncludeWarmWorkUntilStopAck",
                "warmBoundaryObserved", "requireWarmBoundary",
                "stopRoundTripSeconds")
        },
        "topMappedMethods": sort_groups(mapped_groups)[:200],
        "topUnmappedFrames": sort_groups(unmapped_groups)[:100],
        "interpretationLimit": (
            "V8 sampled CPU time for this page target only. Do not extrapolate "
            "samples into solver wall time or treat this diagnostic run as a "
            "deadline result. Sampling overhead is unmeasured."),
    }
    save_json(output, "cpu-profile/attribution.json", summary)
    return summary


def expected_matches(case, state):
    if state is None:
        return False
    if case["expectedState"] is not None:
        return state == case["expectedState"]
    return state.startswith(case["expectedPrefix"])


def case_slug(case):
    return "cases/" + case["slug"]


def run_case(page, base_url, case, output, cpu_profile_session=None, cpu_profile_repo=None,
             cpu_profile_stop_state="RUNNING:warm", cpu_profile_negative_canary=False,
             cpu_profile_require_warm_boundary=False, cpu_profile_script_events=None):
    started = time.monotonic()
    started_utc = utc_now()
    deadline = started + case["timeoutSeconds"]
    page_errors = []
    http_errors = []
    console_errors = []
    read_errors = []
    listener_cleanup_errors = []
    navigation_error = None
    last_observed_state = None
    terminal_reached = False
    timed_out = False
    cpu_profile_capture = {"status": "NOT_REQUESTED"}
    cpu_profiler_enabled = False
    cpu_profile_started = False
    last_cold_state_observation = None

    def on_page_error(error):
        page_errors.append(str(error))

    def on_response(response):
        try:
            if response.status >= 400:
                http_errors.append({"url": response.url,
                                    "status": response.status,
                                    "statusText": response.status_text})
        except BaseException as error:
            http_errors.append({"error": str(error)})

    def on_console(message):
        try:
            if message.type == "error":
                location = message.location if isinstance(message.location, dict) else None
                console_errors.append({"type": message.type, "text": message.text,
                                       "location": location})
        except BaseException as error:
            console_errors.append({"error": str(error)})

    page.on("pageerror", on_page_error)
    page.on("response", on_response)
    page.on("console", on_console)
    url = base_url + "/" + case["path"]

    def read_attribute(attribute):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            read_errors.append({"attribute": attribute, "type": "DeadlineExpired",
                                "message": "case deadline elapsed"})
            return None
        try:
            return page.locator("html").get_attribute(
                attribute, timeout=max(1, min(MAX_ATTRIBUTE_TIMEOUT_MS,
                                             int(remaining * 1000))))
        except BaseException as error:
            read_errors.append({"attribute": attribute, "type": type(error).__name__,
                                "message": str(error)})
            return None

    def stop_cpu_profile(stop_reason, observed_state=None, observed_monotonic=None):
        nonlocal cpu_profiler_enabled, cpu_profile_started
        if not cpu_profile_started:
            return
        stop_started = time.monotonic()
        cpu_profile_capture["stopReason"] = stop_reason
        cpu_profile_capture["stopObservedState"] = observed_state
        cpu_profile_capture["stopObservedUtc"] = utc_now()
        cpu_profile_capture["warmBoundaryObserved"] = (
            stop_reason == "target-state-observed" and
            observed_state == cpu_profile_stop_state)
        if observed_monotonic is not None:
            cpu_profile_capture["stopObservedHostMonotonicSeconds"] = observed_monotonic
            cpu_profile_capture["stopDispatchDelaySeconds"] = max(
                0.0, stop_started - observed_monotonic)
        cpu_profile_started = False
        try:
            stopped = cpu_profile_session.send("Profiler.stop")
            cpu_profile_capture["stopRoundTripSeconds"] = time.monotonic() - stop_started
            profile = stopped.get("profile") if isinstance(stopped, dict) else None
            if not isinstance(profile, dict):
                raise RuntimeError("Profiler.stop returned no CPU profile")
            (script_id_to_strong_name, script_provenance,
             loaded_bundle_evidence) = capture_profile_script_provenance(
                cpu_profile_repo, profile, cpu_profile_session,
                cpu_profile_script_events or {})
            script_provenance_record = {
                "sampledScripts": script_provenance,
                "loadedBundles": loaded_bundle_evidence,
            }
            cpu_profile_capture["scriptProvenance"] = script_provenance_record
            save_json(output, "cpu-profile/script-provenance.json",
                      script_provenance_record)
            summary = save_cpu_profile_artifacts(
                cpu_profile_repo, output, case, profile, cpu_profile_capture,
                script_id_to_strong_name)
            quality_failures = []
            if not summary["sampleArraysAligned"]:
                quality_failures.append("sample and time-delta arrays are misaligned")
            if summary["pairedSampleCount"] <= 0:
                quality_failures.append("profile has no aligned samples")
            if (summary["gwtBundleCount"] > 0 and
                    not summary["allGwtSymbolMapsValidated"]):
                quality_failures.append("one or more loaded GWT symbol maps failed CirSim.lu_factor validation")
            if (summary["gwtBundleCount"] > 0 and
                    summary["mappedGwtSampleCount"] <= 0):
                quality_failures.append("loaded GWT code had no sample with exact script provenance and a unique symbol-map row")
            if (cpu_profile_require_warm_boundary and
                    not cpu_profile_capture.get("warmBoundaryObserved")):
                quality_failures.append("required RUNNING:warm boundary was not observed")
            cpu_profile_capture.update({
                "status": "CAPTURED",
                "qualityFailures": quality_failures,
                "artifacts": {
                    "profile": summary["profileFile"],
                    "attribution": "cpu-profile/attribution.json",
                    "symbolMaps": summary["symbolMaps"],
                },
            })
        except BaseException as error:
            cpu_profile_capture.update({
                "status": "STOP_OR_EXPORT_FAILED",
                "stopRoundTripSeconds": time.monotonic() - stop_started,
                "error": {"type": type(error).__name__, "message": str(error)},
            })
        finally:
            if cpu_profiler_enabled:
                try:
                    cpu_profile_session.send("Profiler.disable")
                except BaseException as error:
                    cpu_profile_capture["disableError"] = str(error)
                cpu_profiler_enabled = False
        if cpu_profile_capture.get("status") == "CAPTURED":
            profile_failed = bool(cpu_profile_capture.get("qualityFailures") or
                                  cpu_profile_capture.get("disableError"))
            cpu_profile_capture["status"] = "FAIL_PROFILE" if profile_failed else "PASS"

    try:
        if cpu_profile_session is not None:
            cpu_profile_capture = {
                "status": "STARTING",
                "samplingIntervalMicroseconds": CPU_PROFILE_SAMPLING_INTERVAL_US,
                "scope": "starts before navigation; target-state stop is host-observed and may include a short warm-boundary tail",
                "startIncludesNavigation": True,
                "stopTargetState": cpu_profile_stop_state,
                "requireWarmBoundary": cpu_profile_require_warm_boundary,
            }
            try:
                cpu_profile_session.send("Profiler.enable")
                cpu_profiler_enabled = True
                cpu_profile_session.send("Profiler.setSamplingInterval", {
                    "interval": CPU_PROFILE_SAMPLING_INTERVAL_US})
                cpu_profile_capture["startRequestedUtc"] = utc_now()
                cpu_profile_started_at = time.monotonic()
                if cpu_profile_negative_canary:
                    cpu_profile_session.send("Profiler.__codexUnsupportedCanary")
                else:
                    cpu_profile_session.send("Profiler.start")
                cpu_profile_started = True
                cpu_profile_capture["startRoundTripSeconds"] = (
                    time.monotonic() - cpu_profile_started_at)
                cpu_profile_capture["status"] = "RECORDING"
                if cpu_profile_negative_canary:
                    raise RuntimeError(
                        "Unsupported profiler method unexpectedly succeeded")
            except BaseException as error:
                cpu_profile_capture["status"] = "START_FAILED"
                cpu_profile_capture["error"] = {
                    "type": type(error).__name__, "message": str(error)}
                if cpu_profiler_enabled:
                    try:
                        cpu_profile_session.send("Profiler.disable")
                    except BaseException as disable_error:
                        cpu_profile_capture["disableError"] = str(disable_error)
                    cpu_profiler_enabled = False
                save_json(output, "cpu-profile/start-failure.json",
                          cpu_profile_capture)
                raise RuntimeError("V8 CPU profile failed to start: " + str(error))

        try:
            response = page.goto(url, wait_until="domcontentloaded",
                                 timeout=max(1, int(case["timeoutSeconds"] * 1000)))
            if response is not None and response.status >= 400 and not any(
                    row.get("url") == response.url and row.get("status") == response.status
                    for row in http_errors):
                http_errors.append({"url": response.url, "status": response.status,
                                    "statusText": response.status_text})
        except PlaywrightTimeoutError as error:
            navigation_error = {"type": type(error).__name__, "message": str(error)}
            timed_out = True
        except BaseException as error:
            navigation_error = {"type": type(error).__name__, "message": str(error)}

        if navigation_error is None:
            while time.monotonic() < deadline:
                state_read_started_at = time.monotonic()
                state = read_attribute(case["stateAttribute"])
                state_observed_at = time.monotonic()
                if state is not None:
                    last_observed_state = state
                    if state == "RUNNING:cold":
                        last_cold_state_observation = {
                            "utc": utc_now(), "monotonic": state_observed_at}
                    if cpu_profile_started and state == cpu_profile_stop_state:
                        cpu_profile_capture.update({
                            "stopTargetState": cpu_profile_stop_state,
                            "stopObservedState": state,
                            "stateReadRoundTripSeconds": (
                                state_observed_at - state_read_started_at),
                            "pollIntervalSeconds": POLL_SECONDS,
                            "profileMayIncludeWarmWorkUntilStopAck": True,
                            "lastColdStateObservedUtc": (
                                last_cold_state_observation["utc"]
                                if last_cold_state_observation else None),
                            "transitionDetectionWindowSeconds": (
                                state_observed_at - last_cold_state_observation["monotonic"]
                                if last_cold_state_observation else None),
                        })
                        stop_cpu_profile("target-state-observed", state,
                                         state_observed_at)
                    if any(state.startswith(prefix) for prefix in case["terminalPrefixes"]):
                        terminal_reached = True
                        break
                time.sleep(min(POLL_SECONDS, max(0, deadline - time.monotonic())))
            if not terminal_reached:
                timed_out = True
        else:
            # Preserve the last state available after a navigation error without
            # attempting application-side recovery.
            state = read_attribute(case["stateAttribute"])
            if state is not None:
                last_observed_state = state
    finally:
        if cpu_profile_started:
            stop_cpu_profile("case-exit-before-target-state",
                             last_observed_state, time.monotonic())
        # The event lists are owned by this case.  Detach handlers before the
        # receipt is returned so later navigations cannot mutate old results.
        for event, handler in (("pageerror", on_page_error),
                               ("response", on_response),
                               ("console", on_console)):
            try:
                page.remove_listener(event, handler)
            except BaseException as error:
                listener_cleanup_errors.append({"event": event,
                                                "type": type(error).__name__,
                                                "message": str(error)})

    report = None
    report_file = None
    report_json_valid = None
    report_json_error = None
    if case["reportAttribute"] is not None:
        report = read_attribute(case["reportAttribute"])
        if report is not None:
            report_file = save_raw(output, case_slug(case) + ".report.json", report)
            try:
                json.loads(report)
                report_json_valid = True
            except (TypeError, ValueError) as error:
                report_json_valid = False
                report_json_error = str(error)
    if last_observed_state is not None:
        save_raw(output, case_slug(case) + ".state.txt", last_observed_state)

    state_match = terminal_reached and expected_matches(case, last_observed_state)
    report_match = (case["reportAttribute"] is None or
                    (report is not None and report_json_valid is True))
    browser_error = bool(page_errors or http_errors or console_errors or
                         listener_cleanup_errors)
    expected_failure_canary = (case["expectedState"] or case["expectedPrefix"]).startswith("FAIL")
    if timed_out:
        outcome = "TIMEOUT"
    elif navigation_error is not None:
        outcome = "FAIL"
    elif state_match and report_match and not browser_error:
        outcome = "PASS"
    else:
        outcome = "FAIL"
    application_outcome = outcome
    cpu_profile_outcome = ("NOT_REQUESTED" if cpu_profile_session is None else
                           ("PASS" if cpu_profile_capture.get("status") == "PASS"
                            else "FAIL"))
    if cpu_profile_session is not None and cpu_profile_outcome == "FAIL" and outcome == "PASS":
        outcome = "FAIL_PROFILE"
    finished = time.monotonic()
    receipt = {
        "schema": SCRIPT_SCHEMA,
        "case": {key: case[key] for key in (
            "index", "name", "path", "stateAttribute", "expectedState",
            "expectedPrefix", "terminalPrefixes", "timeoutSeconds", "reportAttribute")},
        "url": url,
        "startedUtc": started_utc,
        "finishedUtc": utc_now(),
        "operationSeconds": finished - started,
        "outcome": outcome,
        "applicationOutcome": application_outcome,
        "cpuProfileOutcome": cpu_profile_outcome,
        "terminalReached": terminal_reached,
        "stateMatch": state_match,
        "observedState": last_observed_state,
        "lastObservedState": last_observed_state,
        "timedOut": timed_out,
        "expectedFailureCanary": expected_failure_canary,
        "expectedFailureStateWasNotAnUnexpectedError": expected_failure_canary and state_match,
        "reportObserved": report is not None,
        "reportJsonValid": report_json_valid,
        "reportJsonError": report_json_error,
        "reportMatch": report_match,
        "reportLength": len(report) if report is not None else 0,
        "reportSha256": hashlib.sha256(report.encode("utf-8")).hexdigest()
        if report is not None else None,
        "reportFile": str(report_file.relative_to(output)).replace("\\", "/")
        if report_file is not None else None,
        "pageErrors": page_errors,
        "httpErrors": http_errors,
        "consoleErrors": console_errors,
        "attributeReadErrors": read_errors,
        "listenerCleanupErrors": listener_cleanup_errors,
        "navigationError": navigation_error,
        "cpuProfile": cpu_profile_capture,
    }
    save_json(output, case_slug(case) + ".json", receipt)
    return receipt


def validate_output(output, repo):
    if not output.is_absolute():
        raise ValueError("output directory must be an absolute path")
    output = output.resolve()
    temporary = Path(tempfile.gettempdir()).resolve()
    if not is_within(output, temporary):
        raise ValueError("output directory must be below the OS temporary directory")
    if is_within(output, repo):
        raise ValueError("output directory must be outside the repository")
    if output.exists():
        raise ValueError("output directory must not already exist")
    if not output.parent.is_dir():
        raise ValueError("output directory parent must already exist")
    return output


def save_error(result, phase, error):
    result["errors"].append({"phase": phase, "message": str(error),
                             "traceback": traceback.format_exc()})


def main(argv):
    flags = argv[4:]
    supported_flags = {"--profiler-negative-canary", "--require-warm-boundary"}
    if (len(argv) < 4 or len(argv) > 6 or len(flags) != len(set(flags)) or
            not set(flags).issubset(supported_flags)):
        print("usage: cpu_profile_candidate.py REPO OUTPUT SPEC_JSON "
              "[--profiler-negative-canary] [--require-warm-boundary]",
              file=sys.stderr)
        return 2
    negative_canary = "--profiler-negative-canary" in flags
    require_warm_boundary = "--require-warm-boundary" in flags
    if negative_canary and require_warm_boundary:
        print("ERROR negative canary cannot require an app boundary", file=sys.stderr)
        return 2
    try:
        repo = Path(argv[1]).expanduser().resolve()
        output = validate_output(Path(argv[2]).expanduser(), repo)
        spec_path = Path(argv[3]).expanduser().resolve()
        if not repo.is_dir() or not (repo / "war" / "circuitjs.html").is_file():
            raise ValueError("repository war/circuitjs.html is missing")
        if not spec_path.is_file():
            raise ValueError("spec JSON path is not a file")
        spec, raw_spec, cases = load_spec(spec_path)
        if len(cases) != 1:
            raise ValueError("CPU profile candidate requires exactly one case")
    except (OSError, ValueError) as error:
        print("ERROR", str(error), file=sys.stderr)
        return 2

    try:
        output.mkdir()
    except OSError as error:
        print("ERROR unable to create unique output directory: " + str(error), file=sys.stderr)
        return 2
    (output / "spec.json").write_bytes(raw_spec)
    result = {"schema": SCRIPT_SCHEMA, "runner": "cpu_profile_candidate.py",
              "repository": str(repo), "startedUtc": utc_now(), "outcome": "NOT_RUN",
              "cases": [], "caseCount": len(cases), "errors": []}
    save_json(output, "run-start.json", result)

    server = None
    server_thread = None
    playwright = None
    context = None
    cdp_session = None
    debugger_enabled = False
    debugger_script_events = {}
    owned = []
    input_before = None
    runner_before = None
    base_url = None
    profile = output / "profile"

    try:
        input_before = capture_input_manifest(repo)
        runner_before = capture_script_identity(repo)
        save_json(output, "input-manifest-before.json", input_before)
        save_json(output, "runner-before.json", runner_before)
        result["inputAudit"] = {"status": "BEFORE_CAPTURED",
                                 "beforeSha256": input_before["sha256"],
                                 "sourceSha256": input_before["sourceSha256"],
                                 "webSha256": input_before["webSha256"],
                                 "fileCount": input_before["fileCount"]}

        server = ThreadingHTTPServer(("127.0.0.1", 0),
                                     partial(QuietHandler, directory=str(repo / "war")))
        server_thread = Thread(target=server.serve_forever, daemon=True,
                               name="compiled-attribute-http")
        server_thread.start()
        base_url = "http://127.0.0.1:%d" % server.server_port

        if sync_playwright is None:
            raise RuntimeError("Playwright is not installed on this host")
        playwright = sync_playwright().start()
        context = playwright.chromium.launch_persistent_context(
            str(profile), channel="msedge", headless=True,
            viewport={"width": 1440, "height": 1000},
            args=["--disable-background-timer-throttling",
                  "--disable-renderer-backgrounding"])
        rows = process_rows()
        owned = owned_edge_rows(rows)
        owner = next((row for row in rows if int(row.get("pid", -1)) == os.getpid()), None)
        if owner is None:
            raise RuntimeError("runner process identity was not returned")
        identity = {
            "schema": SCRIPT_SCHEMA,
            "runner": {"pid": owner.get("pid"), "created": owner.get("created"),
                        "executable": owner.get("ExecutablePath")},
            "edgeProcessesBeforeCases": owned,
            "profile": str(profile),
            "port": server.server_port,
            "baseUrl": base_url,
        }
        save_json(output, "identity.json", identity)
        save_json(output, "owned-processes-before.json", owned)
        if not owned:
            raise RuntimeError("no Edge descendant was observed before browser gates")
        page = context.pages[0] if context.pages else context.new_page()
        cdp_session = context.new_cdp_session(page)
        def on_script_parsed(event):
            if isinstance(event, dict) and event.get("scriptId") is not None:
                debugger_script_events[str(event["scriptId"])] = event
        cdp_session.on("Debugger.scriptParsed", on_script_parsed)
        cdp_session.send("Debugger.enable")
        debugger_enabled = True
        result["cpuProfileConfig"] = {
            "samplingIntervalMicroseconds": CPU_PROFILE_SAMPLING_INTERVAL_US,
            "caseCount": 1,
            "scope": "page target only; CPU sampling and passive Debugger source-provenance capture are diagnostic and may perturb timing",
            "stopTargetState": "RUNNING:warm",
            "requireWarmBoundary": require_warm_boundary,
            "negativeCanary": negative_canary,
        }
        result["identity"] = identity
        result["operationStartedUtc"] = utc_now()
        for case in cases:
            receipt = run_case(page, base_url, case, output,
                               cpu_profile_session=cdp_session,
                               cpu_profile_repo=repo,
                               cpu_profile_negative_canary=negative_canary,
                               cpu_profile_require_warm_boundary=require_warm_boundary,
                               cpu_profile_script_events=debugger_script_events)
            result["cases"].append(receipt)
            save_json(output, "progress.json", result)
            print(receipt["outcome"], case["name"],
                  round(receipt["operationSeconds"], 3), flush=True)
        result["outcome"] = ("PASS" if all(row["outcome"] == "PASS"
                                           for row in result["cases"])
                              else "FAIL")
    except BaseException as error:
        result["outcome"] = "FAIL"
        save_error(result, "operation", error)
        print(traceback.format_exc(), file=sys.stderr, flush=True)
    finally:
        audit_started = time.monotonic()
        try:
            input_after = capture_input_manifest(repo)
            runner_after = capture_script_identity(repo)
            save_json(output, "input-manifest-after.json", input_after)
            save_json(output, "runner-after.json", runner_after)
            unchanged = (input_before is not None and
                         input_before["sha256"] == input_after["sha256"] and
                         runner_before is not None and
                         runner_before["sha256"] == runner_after["sha256"])
            result["inputAudit"] = {
                "status": "PASS" if unchanged else "FAIL",
                "beforeSha256": input_before["sha256"] if input_before else None,
                "afterSha256": input_after["sha256"],
                "sourceSha256Before": input_before["sourceSha256"] if input_before else None,
                "sourceSha256After": input_after["sourceSha256"],
                "webSha256Before": input_before["webSha256"] if input_before else None,
                "webSha256After": input_after["webSha256"],
                "runnerBeforeSha256": runner_before["sha256"] if runner_before else None,
                "runnerAfterSha256": runner_after["sha256"],
                "fileCountBefore": input_before["fileCount"] if input_before else None,
                "fileCountAfter": input_after["fileCount"],
                "seconds": time.monotonic() - audit_started,
            }
            if not unchanged and result["outcome"] == "PASS":
                result["outcome"] = "FAIL_INPUT_MUTATION"
        except BaseException as error:
            result["inputAudit"] = {"status": "FAIL",
                                     "seconds": time.monotonic() - audit_started}
            save_error(result, "input-after", error)
            if result["outcome"] == "PASS":
                result["outcome"] = "FAIL_INPUT_AUDIT"

        cleanup_started = time.monotonic()
        cleanup_errors = []
        try:
            if cdp_session is not None:
                if debugger_enabled:
                    try:
                        cdp_session.send("Debugger.disable")
                    except BaseException as error:
                        cleanup_errors.append({"phase": "debugger-disable",
                                               "message": str(error)})
                try:
                    cdp_session.detach()
                except BaseException as error:
                    cleanup_errors.append({"phase": "cdp-detach", "message": str(error)})
            if context is not None:
                try:
                    rows = process_rows()
                    owned = list({(row.get("pid"), row.get("created")): row
                                  for row in owned + owned_edge_rows(rows)}.values())
                    save_json(output, "owned-processes-before-close.json", owned)
                except BaseException as error:
                    cleanup_errors.append({"phase": "process-snapshot", "message": str(error)})
                try:
                    context.close()
                except BaseException as error:
                    cleanup_errors.append({"phase": "context-close", "message": str(error)})
            if playwright is not None:
                try:
                    playwright.stop()
                except BaseException as error:
                    cleanup_errors.append({"phase": "playwright-stop", "message": str(error)})
        finally:
            if server is not None:
                try:
                    server.shutdown()
                    server.server_close()
                except BaseException as error:
                    cleanup_errors.append({"phase": "server-shutdown", "message": str(error)})
            if server_thread is not None:
                server_thread.join(timeout=5)

        survivors = []
        saved_ids = {(row.get("pid"), row.get("created")) for row in owned}
        for _ in range(20):
            try:
                survivors = [row for row in process_rows()
                             if (row.get("pid"), row.get("created")) in saved_ids]
            except BaseException as error:
                cleanup_errors.append({"phase": "survivor-query", "message": str(error)})
                survivors = [{"error": str(error)}]
            if not survivors:
                break
            time.sleep(0.25)
        server_stopped = server_thread is None or not server_thread.is_alive()
        cleanup_ok = not cleanup_errors and not survivors and server_stopped
        result["cleanup"] = {
            "status": "PASS" if cleanup_ok else "FAIL",
            "seconds": time.monotonic() - cleanup_started,
            "serverStopped": server_stopped,
            "ownedSurvivors": survivors,
            "errors": cleanup_errors,
        }
        if not cleanup_ok:
            result["outcome"] = "FAIL_CLEANUP"
        result["finishedUtc"] = utc_now()
        save_json(output, "result.json", result)
        print("FINISHED", result["outcome"], "cases", len(result["cases"]), flush=True)

    return 0 if result["outcome"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
