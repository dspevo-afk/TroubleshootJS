from pathlib import Path
import hashlib, importlib.util, json, sys, time

sys.dont_write_bytecode = True
s = Path(__file__).resolve().parent
repo = Path('<REPO_ROOT>')
audit_path = s / 'scratch/pivot-lower-fusion-r2-preparation/source-audit.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
audit_raw = audit_path.read_bytes()
assert sha(audit_raw) == '0d27e176dc46afb4db91316570f4674e52b51ce2b462c64f6b6a37b98cbec197'
audit = json.loads(audit_raw)
root = Path(audit['candidateSource'])
entries = audit['armInputs']['candidate']
assert len(entries) == 1340
began = time.monotonic()
for entry in entries:
    raw = (root / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], entry['path']
host_path = repo / 'tests/browser/compiled_attribute_acceptance.py'
assert sha(host_path.read_bytes()) == '1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4'
spec = importlib.util.spec_from_file_location('cpu_preflight_host', host_path)
host = importlib.util.module_from_spec(spec)
spec.loader.exec_module(host)
runtime = host.capture_input_manifest(root)
expected = {'sha256': '53f869e8164f6b8edc3b75ba1e6a299a984de5c88829b60b04a9ca59e76787a9',
            'sourceSha256': 'cb257f2158d02ece1fb0a3f7ac7386ec9a14e43100be1ad337d2e344aae0828e',
            'webSha256': 'e7377863185fc8208cb356474b39d14c9a82a35f5470bd7824d68113e1c03961',
            'fileCount': 1525, 'sourceFileCount': 1133, 'webFileCount': 392}
assert all(runtime[k] == v for k, v in expected.items())
out = s / 'cpu-profile-10ms-r1-fixture-preflight.json'
assert not out.exists()
result = {'status': 'PASS_UNCHANGED_SOURCE_AND_RUNTIME_ONLY',
          'sourceInputs': len(entries), 'sourceAuditSha256': sha(audit_raw),
          'runtime': expected, 'auditSeconds': time.monotonic() - began,
          'reuse': 'The same complete accepted-fusion R2 private fixture passed native6, actual JDK8/GWT5, compiled A07 and disabled-normal gates. This audit verifies unchanged consumed inputs; it is not another execution of those gates.',
          'pending': 'Real selected CPU-host transport canaries, driver review, fresh measurements and full strict comparisons remain required. No Q30 normal acceptance.'}
out.write_bytes((json.dumps(result, indent=2)+'\n').encode('utf-8'))
print(json.dumps(result))
