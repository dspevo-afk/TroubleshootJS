# CPU profiler lifecycle recheck — frozen R1 driver

**PASS: all five prior blockers are resolved in the exact frozen driver reviewed.**

Driver: cpu-profile-10ms-r1-draft/cpu_profile_10ms.py  
SHA-256: 1197d7f81653361a91f30ae561fc3e928f96446b6d658c6625e317bb3573c43b

- Both start and active-stop canaries now require the unsupported method name and a method-not-found/unknown-command marker in the error text (helper at lines 85–91; call sites 1051–1061 and 1186–1204). The start canary then requires a successful Profiler.disable response object (1205–1219); the stop canary is followed by a real Profiler.stop that must return a profile object (1065–1080).
- The start-canary path explicitly disables Profiler and records its acknowledgment before raising the expected-canary marker (1205–1244).
- Case verdicts again include read_errors in browser_error (1348–1349).
- The parser rejects requesting start and active-stop canaries in one invocation (1522–1529).
- stopDispatchDelaySeconds is now measured from the observed warm state to a timestamp immediately before the real Profiler.stop send; the negative canary has a separate duration and helper-entry delay (1040–1077).

The canary error classifier is a method-specific error-string check rather than a structured CDP error-code check; the expected method text and protocol rejection marker must both be present, and each canary path requires a subsequent successful protocol response. This resolves the previously identified false-positive cases within the reviewed transport API.

This was a read-only source check of the five listed blockers only. The driver was not executed; no browser, build, or gate was run.
