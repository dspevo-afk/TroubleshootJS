from pathlib import Path
import ast,hashlib,json
s=Path(__file__).resolve().parent
d=s/'cpu-profile-10ms-r1-draft'
sha=lambda b:hashlib.sha256(b).hexdigest()
reader=d/'validate_cpu_profile_10ms.py'
raw=reader.read_bytes()
assert sha(raw)=='ac3cd6e4006eaaf47a0df881b51c2d93e72ca1c473749aeac6f82ef09d3840f8'
archive=s/'cpu-profile-10ms-review-r1'
for name in ['validate_cpu_profile_10ms.py','README.md','manifest.json']:
    dest=archive/(name+'.before-request-type-fix')
    assert not dest.exists();dest.write_bytes((d/name).read_bytes())
old=b'isinstance(report.get("request"), dict)'
new=b'isinstance(report.get("request"), str) and bool(report["request"])'
assert raw.count(old)==1
raw=raw.replace(old,new)
ast.parse(raw.decode())
reader.write_bytes(raw)
readme=d/'README.md'
raw=readme.read_bytes()
assert raw.count(b'coordinator report request object')==1
readme.write_bytes(raw.replace(b'coordinator report request object',b'coordinator report canonical request string'))
manifest=json.loads((d/'manifest.json').read_bytes())
for key,name in [('validator','validate_cpu_profile_10ms.py'),('readme','README.md')]:
    raw=(d/name).read_bytes();manifest[key]['bytes']=len(raw);manifest[key]['sha256']=sha(raw)
manifest['rootReaderRepair']={'reason':'Actual Q30 report.request is a nonempty canonical string, not a JSON object. Verified existing raw report and production publisher before any CPU host run.',
 'priorValidatorSha256':'ac3cd6e4006eaaf47a0df881b51c2d93e72ca1c473749aeac6f82ef09d3840f8',
 'unchanged':'CPU host driver, sample mapping, limits, application data and original strict readers.'}
(d/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps({'status':'SOURCE_ONLY_READER_TYPE_REPAIRED','driverSha256':manifest['driver']['sha256'],'validator':manifest['validator'],'readme':manifest['readme']}))
