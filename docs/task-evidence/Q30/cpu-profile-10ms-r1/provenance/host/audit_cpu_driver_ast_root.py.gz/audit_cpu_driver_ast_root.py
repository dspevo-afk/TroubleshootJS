from pathlib import Path
import ast, hashlib, json
s = Path(__file__).resolve().parent
repo = Path('<REPO_ROOT>')
target = s/'cpu-profile-10ms-r1-draft/cpu_profile_10ms.py'
def functions(path):
    raw=path.read_bytes()
    tree=ast.parse(raw.decode('utf-8-sig'))
    return raw, {n.name: (ast.dump(n, include_attributes=False), n.lineno, n.end_lineno) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
raw, current=functions(target)
out={'driverSha256':hashlib.sha256(raw).hexdigest(),'comparisons':{}}
for name,path in [('maintained',repo/'tests/browser/compiled_attribute_acceptance.py'),('old1ms',s/'cpu_profile_root.py')]:
    parent,base=functions(path)
    out['comparisons'][name]={'baseSha256':hashlib.sha256(parent).hexdigest(),
      'unchanged':[n for n,v in current.items() if n in base and v[0]==base[n][0]],
      'changed':[{ 'name':n,'start':v[1],'end':v[2]} for n,v in current.items() if n in base and v[0]!=base[n][0]],
      'added':[{ 'name':n,'start':v[1],'end':v[2]} for n,v in current.items() if n not in base],
      'removed':[n for n in base if n not in current]}
print(json.dumps(out,indent=2))
