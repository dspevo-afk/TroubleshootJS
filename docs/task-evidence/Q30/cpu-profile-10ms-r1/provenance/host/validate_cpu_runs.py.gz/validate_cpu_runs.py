from pathlib import Path
import json,subprocess,sys
s=Path(r'<TASK_TEMP>');r=Path(r'<REPO_ROOT>')
reports=[]
for label in ['cpu-q30-B7','cpu-followup-B7']:
 p=s/label;d=json.loads((p/'result.json').read_text());report=json.loads(next((p/'cases').glob('*.report.json')).read_text());m=json.loads((p/'input-manifest-before.json').read_text())
 assert d['outcome']=='PASS' and d['cleanup']['status']=='PASS' and not d['cleanup']['ownedSurvivors']
 assert d['inputAudit']['status']=='PASS'
 wrapper={'rows':[{'seed':'7','previewSourceDigest':m['sourceSha256'],'previewWebDigest':m['webSha256'],'report':report}]}
 w=p/'strict-wrapper.json';w.write_text(json.dumps(wrapper),encoding='utf-8')
 cmd=[sys.executable,'-B',str(r/'docs/task-evidence/Q30/normal-admission/check_coordinator.py'),str(w),'--seeds','7']
 if not reports:cmd+=['--self-test']
 result=subprocess.run(cmd,capture_output=True,text=True)
 (s/(label+'-reader.txt')).write_text(result.stdout+result.stderr,encoding='utf-8')
 assert result.returncode==0,result.stdout+result.stderr
 reports.append(report)
a,b=reports
assert a['request']==b['request']
for phase in ['cold','warm']:
 ao=a[phase]['owner'];bo=b[phase]['owner']
 assert set(ao)==set(bo)
 for key in ao:
  if key!='diagnosticProof':assert ao[key]==bo[key],(phase,key)
 ap=ao['diagnosticProof'];bp=bo['diagnosticProof'];assert set(ap)==set(bp)
 for key in ap:
  if key!='elapsedMillis':assert ap[key]==bp[key],(phase,key)
 for key in ['totalWork','hypothesisWork']:assert a[phase][key]==b[phase][key]
result={'status':'PASS','strictReaders':2,'negativeCanaries':37,'exactRequest':True,'completeOwnerPhysicalAndProofParityExcludingTiming':True,'coldProfileMs':a['cold']['elapsedMs'],'coldControlMs':b['cold']['elapsedMs'],'differenceMs':a['cold']['elapsedMs']-b['cold']['elapsedMs'],'limit':'Sampling/debugger overhead and host variation are not isolated by one pair; profile is ranking evidence only.'}
(s/'cpu-proof-parity.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))

