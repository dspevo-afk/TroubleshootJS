from pathlib import Path
import copy,csv,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
s=Path(__file__).resolve().parent
d=s/'cpu-profile-10ms-r1-draft'
raw=(d/'cpu_profile_10ms.py').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)=='1197d7f81653361a91f30ae561fc3e928f96446b6d658c6625e317bb3573c43b'
spec=importlib.util.spec_from_file_location('cpu_analysis_fixture_driver',d/'cpu_profile_10ms.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fixture_raw=(d/'analysis-fixtures/profile-analysis-fixtures.json').read_bytes()
fixtures=json.loads(fixture_raw)['cases']
root=s/'cpu-10ms-analysis-fixtures-root'
assert not root.exists()
repo=root/'synthetic-input'
strong='A'*32
cache=repo/'war/circuitjs1'/f'{strong}.cache.js'
cache.parent.mkdir(parents=True)
cache.write_bytes(('circuitjs1.onScriptDownloaded('+json.dumps(['var $strongName="'+strong+'";'])+');').encode())
symbol=repo/'war/WEB-INF/deploy/circuitjs1/symbolMaps'/f'{strong}.symbolMap'
symbol.parent.mkdir(parents=True)
with symbol.open('w',encoding='utf-8',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=module.GWT_SYMBOL_FIELDS)
    writer.writerow({'jsName':'knownLuOracle','className':'com.lushprojects.circuitjs1.client.CirSim','memberName':'lu_factor'})
    for fixture in fixtures:
        for name,rows in fixture['symbolMappings'].items():
            for row in rows:writer.writerow({'jsName':name,**row})
results=[]
for fixture in fixtures:
    profile=copy.deepcopy(fixture['profile'])
    mapping,evidence,bundles,cache_payloads=module.capture_profile_script_provenance(repo,profile,None,{})
    out=root/fixture['name'];out.mkdir()
    module.archive_cache_payloads(out,cache_payloads,bundles)
    capture={'scriptProvenance':{'sampledScripts':evidence,'loadedBundles':bundles}}
    result=module.save_cpu_profile_artifacts(repo,out,{'name':fixture['name']},profile,capture,mapping)
    rows=result['topMappedMethods']+result['topUnmappedFrames']
    assert len(rows)==1
    row=rows[0]
    for key,value in fixture['expected'].items():
        if key=='note':continue
        actual=result[key] if key=='mappedLeafSampleCount' else row[key]
        assert actual==value,(fixture['name'],key,actual,value)
    assert sum(b['sampleCount'] for b in result['bucketTotals'].values())==1
    results.append({'name':fixture['name'],'status':'PASS','observed':row})
receipt={'status':'PASS_OFFLINE_ANALYSIS_ONLY','driverSha256':sha(raw),'fixtureSha256':sha(fixture_raw),
         'cases':results,'limits':'Synthetic analysis oracle only; no browser, real CDP canary, application build, electrical proof or Q30 measurement.'}
(s/'cpu-10ms-analysis-fixtures-root-result.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({'status':receipt['status'],'cases':[r['name'] for r in results]}))
