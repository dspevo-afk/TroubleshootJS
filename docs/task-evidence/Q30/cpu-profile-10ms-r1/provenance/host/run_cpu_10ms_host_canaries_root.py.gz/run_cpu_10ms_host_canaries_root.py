from pathlib import Path
import hashlib,json,subprocess,sys,time
s=Path(__file__).resolve().parent
repo=Path('<REPO_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
bindingraw=(s/'cpu-10ms-reviewed-host-binding.json').read_bytes()
binding=json.loads(bindingraw)
assert binding['status']=='ROOT_REVIEWED_READY_FOR_REAL_HOST_CANARIES'
for e in binding['files']:
    assert sha((s/e['path']).read_bytes())==e['sha256'],e['path']
draft=s/'cpu-profile-10ms-r1-draft'
driver=draft/'cpu_profile_10ms.py'
reader=draft/'validate_cpu_profile_10ms.py'
source=s/'scratch/pivot-lower-fusion-r2-preparation/candidate'
base=json.loads((s/'root-routing-integrated-canaries-spec.json').read_bytes())
a07=next(c for c in base['cases'] if c['expectedState']=='PASS:a07')
rows=[('cpu-10ms-r1-positive-a07',[],[],'PASS'),
      ('cpu-10ms-r1-start-negative-a07',['--profiler-negative-canary'],['--expect-start-canary'],'PASS_CANARY'),
      ('cpu-10ms-r1-stop-negative-a07',['--profiler-stop-negative-canary'],['--expect-stop-canary'],'PASS_CANARY')]
receiptpath=s/'cpu-10ms-r1-host-canaries.json'
assert not receiptpath.exists()
receipt={'status':'RUNNING','bindingSha256':sha(bindingraw),'rows':[],'notRun':[r[0] for r in rows]}
def save():receiptpath.write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
save()
try:
    for label,flags,readerflags,outcome in rows:
        for e in binding['files']:
            assert sha((s/e['path']).read_bytes())==e['sha256'],e['path']
        out=s/label;spec=s/(label+'-spec.json');log=s/(label+'.log')
        assert not out.exists() and not spec.exists() and not log.exists()
        spec.write_bytes((json.dumps({'cases':[{**a07,'name':label}]},indent=2)+'\n').encode())
        args=[sys.executable,'-B',str(driver),str(source),str(out),str(spec)]+flags
        print('START '+label,flush=True)
        began=time.monotonic()
        with log.open('w',encoding='utf-8') as stream:
            result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
        row={'label':label,'command':args,'exitCode':result.returncode,'hostSeconds':time.monotonic()-began}
        receipt['rows'].append(row);receipt['notRun'].remove(label);save()
        assert result.returncode==0,log.read_text()[-2200:]
        host=json.loads((out/'result.json').read_bytes())
        assert host['outcome']==outcome and host['inputAudit']['status']=='PASS'
        assert host['inputAudit']['beforeSha256']==host['inputAudit']['afterSha256']=='53f869e8164f6b8edc3b75ba1e6a299a984de5c88829b60b04a9ca59e76787a9'
        cleanup=host['cleanup']
        assert cleanup['status']=='PASS' and cleanup['serverStopped'] and not cleanup['errors'] and not cleanup['ownedSurvivors']
        row['cleanupSeconds']=cleanup['seconds']
        check=subprocess.run([sys.executable,'-B',str(reader),str(out),
                              '--expected-source-sha256','cb257f2158d02ece1fb0a3f7ac7386ec9a14e43100be1ad337d2e344aae0828e',
                              '--expected-web-sha256','e7377863185fc8208cb356474b39d14c9a82a35f5470bd7824d68113e1c03961']+readerflags,
                             capture_output=True,text=True)
        (s/(label+'-reader.log')).write_bytes((check.stdout+check.stderr).encode())
        row['readerExitCode']=check.returncode;save()
        assert check.returncode==0,check.stdout+check.stderr
        if host['cases']:
            assert len(host['cases'])==1
            case=host['cases'][0]
            assert case['observedState']=='PASS:a07'
            raw=(out/case['reportFile']).read_bytes()
            assert sha(raw)==case['reportSha256']
            strict=subprocess.run(['pwsh','-NoProfile','-File',str(s/'read_a07.ps1'),'-Repo',str(repo),'-Report',str(out/case['reportFile'])],capture_output=True,text=True)
            (s/(label+'-a07-strict.log')).write_bytes((strict.stdout+strict.stderr).encode())
            row['a07StrictExitCode']=strict.returncode;row['reportSha256']=sha(raw);save()
            assert strict.returncode==0,strict.stdout+strict.stderr
        row['status']='PASS';save()
        print(json.dumps(row),flush=True)
    receipt['status']='REAL_HOST_CANARIES_PASS_NOT_Q30_MEASUREMENT';save()
except BaseException as error:
    receipt['status']='STOPPED_FAILURE';receipt['failure']=str(error);save();raise
