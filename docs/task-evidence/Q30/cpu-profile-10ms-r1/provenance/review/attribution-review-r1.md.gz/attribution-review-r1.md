# Root review of the initial 10-ms CPU analysis draft

Snapshot: `cpu-profile-10ms-review-r1/cpu_profile_10ms.py`, SHA-256
`d95cbda4b834c0113b462bd4ff87728fcb66f3c16b5b9cb3e064f4f7c0145698`.
Source-only review; no browser, transport canary or Q30 measurement has run.

The sampled-node interpretation needs repair before execution. A directly
sampled call-tree node is the executing top frame for that sample even when
that aggregate node has children from other samples. Requiring the node's
`children` list to be empty discards valid self samples and biases ranking.
The primary [CDP protocol definition](https://raw.githubusercontent.com/ChromeDevTools/devtools-protocol/master/pdl/js_protocol.pdl)
defines sample ids as top nodes and separately defines children and hit counts.
Ancestry totals, if calculated separately, must remain separate from self samples.

Owner buckets also need to reject unproven mappings before matching textual
owner names. The draft can place an unmapped raw name into a source-owner bucket.
Native GC/idle/program frames may remain separately identified. The broad
routing-name match precedes heap/map matching, hiding typed-heap methods owned
by the router; exact method rankings must remain available and bucket priority
must be explicit. Requested independent tiny fixtures cover a sampled node with
children and a misleading unmapped owner-like function name.

The initial reader additionally assumes every case has a Q30 request object,
which does not describe the planned A07 host canary. It needs declared case
dispatch, full status/error/cleanup checks and archived profile/symbol-map hash
verification. Existing strict A07 and Q30 report readers remain independent
requirements. A parallel review covers host lifecycle/canary paths.

The author was given these findings before any host run. The snapshot is
retained; this review is not a PASS for a later repaired source.
