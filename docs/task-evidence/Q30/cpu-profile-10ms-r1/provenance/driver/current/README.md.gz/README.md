# 10 ms CDP CPU-profile diagnostic draft

Status: source-only draft, pending root review and real transport canaries.
This directory is an isolated task-temporary deliverable. It does not change
the repository and does not claim a Q30 timing or qualification result.

The driver is cpu_profile_10ms.py. The frozen repaired source is 88,438 bytes
at SHA-256
1197d7f81653361a91f30ae561fc3e928f96446b6d658c6625e317bb3573c43b
after the mapping and lifecycle review repairs described below. The driver
supports the old positional form and explicit flags:

    python cpu_profile_10ms.py REPO OUTPUT SPEC_JSON [flags]
    python cpu_profile_10ms.py --repo REPO --output OUTPUT --case q30 --seed 10014 --board-seed 3

The output directory must be a new directory below the operating-system
temporary directory and outside the repository. The driver accepts generic
case, repository, output, seed, source identity, pair identity, and
measurement-plan arguments. It does not contain a known-answer Q30 branch.

## Boundaries and identities

The intended base is the compiled candidate fixture
scratch/pivot-lower-fusion-r2-preparation/candidate from the
q30-multirail-qualification/TroubleshootJS checkout at
4b658dcc6f2710718400c5e4f642777cde640e8e. The accepted LU revision is
ffe9132. The source-audit input map for the earlier 1,340-input candidate is
0d27e176dc46afb4db91316570f4674e52b51ce2b462c64f6b6a37b98cbec197.

The fresh runtime identity that the root adapter must bind before a run is:

* full input manifest, 1,525 inputs:
  53f869e8164f6b8edc3b75ba1e6a299a984de5c88829b60b04a9ca59e76787a9
* source aggregate:
  cb257f2158d02ece1fb0a3f7ac7386ec9a14e43100be1ad337d2e344aae0828e
* web aggregate:
  e7377863185fc8208cb356474b39d14c9a82a35f5470bd7824d68113e1c03961

The maintained OFF reference remains
tests/browser/compiled_attribute_acceptance.py, 30,624 bytes,
SHA-256 1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4.
The standalone prior CPU reference is cpu_profile_root.py, 60,815 bytes,
SHA-256 b1586acaf9c76a0b29712b53b70bbb3cb086d0ff14056162d368018eede11fb6.
The earlier 1 ms profile showed about 13 seconds of overhead, so this 10 ms
diagnostic does not assume that sampling is free.

Root's predeclared measurement plan is
cpu-profile-10ms-r1-measurement-plan.json with OFF, ON, and OFF seed 10014
arms. The positional adapter is run_cpu_10ms_timing.py and uses
require-warm-boundary for the ON diagnostic. Root owns the timing run and the
strict timing-pair reader.

## Capture protocol

For an ON case, the host creates one owned Edge process tree and one page CDP
session. It enables Debugger and Profiler, sets the sampling interval to
10,000 microseconds, and starts Profiler before navigation. Debugger.scriptParsed
events are retained for passive source provenance. The driver polls the declared
state attribute at 200 ms and stops at the host-observed RUNNING:warm boundary.
The stop state, poll interval, transition window, state-read round trip,
dispatch delay, real Profiler.stop dispatch timestamp, and stop round trip are
recorded separately. The profile can include a short tail through the stop
acknowledgment.

After every start, navigation, report, stop, export, or attribution failure,
the driver attempts the required cleanup. It issues Profiler.disable when
Profiler remains enabled, disables Debugger, detaches CDP, closes the owned
context, stops the owned server, snapshots owned processes, and reports
survivors. It never uses a kill-all operation. Cleanup errors, survivors,
server liveness, input mutations, and attribute-read errors fail closed.

The OFF arm is the unchanged maintained host path. The driver is intended for
the ON diagnostic and A07 transport canaries; it is not a replacement for the
maintained OFF acceptance host.

## Canary requirements

Root must run the real A07 positive transport canary before the Q30 sequence.
The canary must use the real selected host implementation; a mocked CDP object
cannot prove the host path. A07 may have zero uniquely mapped CPU samples. In
that case the protocol and application can still pass while attribution remains
NOT_PROVEN.

The start negative canary sends
Profiler.__codexUnsupportedCanary after Profiler.enable and interval setup,
before navigation. It records PASS_CANARY only when the error contains the
exact method name and a method-not-found transport rejection, then receives an
explicit successful Profiler.disable acknowledgment. It never navigates.

The active-stop negative canary starts a real profile, sends
Profiler.__codexUnsupportedStopCanary while recording, requires its exact
method-not-found transport rejection, then sends the real Profiler.stop. The
real stop dispatch timestamp is recorded immediately before that send, and
the stop/export path still runs. An accepted unsupported method or an
unexpected transport error is retained as a failure. Start and active-stop
negative canaries must be separate invocations; combined flags are rejected.

The validator distinguishes expected canary errors from host failures and
requires cleanup.errors to be empty. A reader mutation or cleanup-error
fixture can exercise fail-closed handling, but it is not real host-injection
proof.

## Source attribution

The raw V8 profile is archived at
cpu-profile/raw-v8-cpu-profile.json with its exact byte hash. The sanitized
profile is archived at cpu-profile/v8-cpu-profile.json and its exact hash is
recorded in attribution.json. ScriptParsed events are canonicalized with a
hash. For each observed cache bundle, the driver archives both the original
cache bytes and decoded payload bytes under cpu-profile/cacheBundles and
records both hashes. Validated symbol maps are archived as deterministic gzip
files under cpu-profile/symbolMaps; their decompressed byte hashes are
recorded.

CPU samples are attributed only when samples[i] resolves to a directly
sampled top-of-stack node, the cache URL or exact Debugger scriptId evidence
identifies one loaded bundle, the cache wrapper and symbol map are validated,
and the symbol-map function row is unique. Profile-node children are aggregate
call-tree context; they do not erase self time. The analysis fixture cites the
Chrome DevTools Protocol source:

https://raw.githubusercontent.com/ChromeDevTools/devtools-protocol/master/pdl/js_protocol.pdl

Raw, ambiguous, unproven, and missing mappings remain visible. Only the
special V8 garbage-collector, idle, and program frames may enter their
reserved buckets without a source mapping. Other unmapped owner-like names
remain unmapped. Among proven mappings, map/index/typed-heap terms are checked
before broad routing/geometry terms, so a typed-heap member on a routing class
does not get silently ranked as geometry. The routing, map/index/typed-heap,
publisher, garbage-collector, idle, program, ambiguous, unmapped,
non-leaf-context, and other-mapped buckets are exploratory rankings only.

The report keeps CPU sampled microseconds separate from host and application
wall timers. It does not claim allocation volume, retained heap, scheduler
wait, solver wall-time contribution, deadline causality, or ownership from a
function name alone. AttributionQuality is PROVEN only when at least one
uniquely mapped directly sampled row exists; otherwise it is NOT_PROVEN.

## Validation and strict readers

validate_cpu_profile_10ms.py reads one completed output without launching a
browser. It verifies:

* full, source, and web input identity before and after the run;
* the requested 10,000 microsecond interval and aligned raw arrays;
* raw and sanitized profile byte hashes and counts;
* decoded cache and symbol-map archived payload hashes;
* canonical ScriptParsed event hashes;
* PASS profile status, empty quality-failure and host-error arrays;
* application state/report parity and exact raw report bytes;
* cleanup status, empty cleanup errors, no owned survivors, and stopped server;
* expected start or active-stop canary receipts when requested.

For Q30, the validator requires the coordinator report canonical request string and root
must use the existing strict full timing-pair reader. For A07, the validator
checks transport and artifact metadata and names the maintained strict reader
separately: scripts/verify-a03-browser.ps1 -SelectedGate A07. A metadata
reader alone does not certify the A07 report.

The data-only analysis fixtures are in analysis-fixtures. They cover a sampled
node with aggregate children, an unmapped function with misleading owner
words, and a proven typed-heap mapping whose specific bucket must precede
broad routing. They are not browser or host evidence.

## Current limits

No browser, real transport canary, build, test, stage, commit, or push was run
for this source-only draft. Root must run the A07 positive and negative real
transport canaries first, then the planned OFF/ON/OFF Q30 sequence, and inspect
the strict raw-report and timing-pair evidence. The draft does not change Java,
GWT, application instrumentation, qualification state, or the maintained OFF
host.
