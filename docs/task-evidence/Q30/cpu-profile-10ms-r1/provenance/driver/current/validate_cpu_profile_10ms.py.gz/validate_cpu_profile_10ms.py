#!/usr/bin/env python3
"""Validate one completed cpu_profile_10ms.py receipt without launching anything.

The reader checks evidence integrity and lifecycle boundaries only. It does not
prove that CDP was a real browser transport unless a real canary receipt is
present; mocked CDP objects are explicitly reported as insufficient evidence.
It never rewrites the raw report or profile.
"""

import argparse
import gzip
import hashlib
import json
import re
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlsplit


class ValidationError(Exception):
    pass


def need(condition, message):
    if not condition:
        raise ValidationError(message)


def load_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValidationError("{}: {}".format(path, error))


def sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def read_bytes(path, description):
    try:
        return path.read_bytes()
    except (OSError, UnicodeError) as error:
        raise ValidationError("{}: {}".format(description, error))


def require_sha256(value, description):
    need(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value),
         description + " is not a lowercase SHA-256")


def safe_child(root, relative):
    need(isinstance(relative, str) and relative, "missing relative artifact path")
    path = (root / relative.replace("/", "\\")).resolve()
    root = root.resolve()
    need(path != root and root in path.parents,
         "artifact path escapes the run output: " + relative)
    return path


def validate_report(run_root, case):
    report_file = case.get("reportFile")
    report_path = safe_child(run_root, report_file)
    raw = report_path.read_bytes()
    digest = sha256_bytes(raw)
    need(case.get("reportSha256") == digest,
         "standalone report digest differs from case receipt")
    text = raw.decode("utf-8")
    need(case.get("reportLength") == len(text),
         "standalone report length differs from case receipt")
    report = json.loads(text)
    need(case.get("reportJsonValid") is True and
         case.get("reportMatch") is True and
         isinstance(report, dict),
         "report was not accepted as the raw JSON receipt")
    embedded = case.get("report")
    if isinstance(embedded, str):
        need(embedded.encode("utf-8") == raw,
             "embedded report string differs from standalone report bytes")
    return report, raw


def validate_input_audit(run_root, result, expected_source, expected_web):
    need(result.get("inputAudit", {}).get("status") == "PASS",
         "input audit did not pass")
    audit = result["inputAudit"]
    need(audit.get("beforeSha256") == audit.get("afterSha256"),
         "full input manifest changed")
    need(audit.get("sourceSha256Before") == audit.get("sourceSha256After"),
         "source input aggregate changed")
    need(audit.get("webSha256Before") == audit.get("webSha256After"),
         "web input aggregate changed")
    if expected_source is not None:
        need(audit.get("sourceSha256Before") == expected_source,
             "source aggregate differs from requested identity")
    if expected_web is not None:
        need(audit.get("webSha256Before") == expected_web,
             "web aggregate differs from requested identity")


def validate_profile(run_root, case, require_attribution):
    profile_capture = case.get("cpuProfile", {})
    need(profile_capture.get("status") == "PASS",
         "CPU profile capture did not finish PASS")
    need(profile_capture.get("qualityFailures") == [],
         "CPU profile quality failures are present")
    need(not profile_capture.get("error") and
         not profile_capture.get("disableError"),
         "CPU profile contains a stop, export, or disable error")
    need(profile_capture.get("samplingIntervalMicroseconds") == 10000,
         "profile interval is not 10,000 microseconds")
    raw_profile_path = safe_child(run_root, profile_capture.get("rawProfileFile"))
    raw_profile_bytes = read_bytes(raw_profile_path, "raw CPU profile")
    need(profile_capture.get("rawProfileSha256") == sha256_bytes(raw_profile_bytes),
         "raw CDP profile digest differs from capture receipt")
    need(profile_capture.get("rawProfileBytes") == len(raw_profile_bytes),
         "raw CDP profile byte count differs from capture receipt")
    raw_profile = json.loads(raw_profile_bytes.decode("utf-8"))
    samples = raw_profile.get("samples", [])
    deltas = raw_profile.get("timeDeltas", [])
    need(isinstance(raw_profile.get("nodes"), list) and
         isinstance(samples, list) and isinstance(deltas, list),
         "raw profile sample arrays are missing")
    artifacts = profile_capture.get("artifacts", {})
    attribution_path = safe_child(run_root, artifacts.get("attribution"))
    attribution = load_json(attribution_path)
    need(attribution.get("samplingIntervalMicroseconds") == 10000,
         "attribution interval is not 10,000 microseconds")
    need(attribution.get("sampleArraysAligned") is True and
         attribution.get("pairedSampleCount") == min(len(samples), len(deltas)),
         "attribution arrays are not aligned with raw profile")
    need(attribution.get("wallTimerSeparation"),
         "CPU/wall timer separation metadata is missing")
    need(attribution.get("attributionQuality") in ("PROVEN", "NOT_PROVEN"),
         "attribution quality status is missing")
    need(profile_capture.get("attributionQuality") ==
         attribution.get("attributionQuality"),
         "capture and attribution quality statuses differ")
    sanitized_path = safe_child(run_root, artifacts.get("profile"))
    sanitized_bytes = read_bytes(sanitized_path, "sanitized CPU profile")
    sanitized = json.loads(sanitized_bytes.decode("utf-8"))
    need(isinstance(sanitized.get("nodes"), list) and
         isinstance(sanitized.get("samples"), list) and
         isinstance(sanitized.get("timeDeltas"), list),
         "sanitized profile arrays are missing")
    require_sha256(attribution.get("profileSha256"),
                   "sanitized CPU profile hash")
    need(attribution.get("profileFile") == artifacts.get("profile") and
         attribution.get("profileSha256") == sha256_bytes(sanitized_bytes),
         "sanitized CPU profile bytes differ from attribution metadata")
    need(attribution.get("profileNodeCount") == len(sanitized.get("nodes", [])) and
         attribution.get("sampleCount") == len(sanitized.get("samples", [])) and
         attribution.get("sampleCount") == len(samples) and
         attribution.get("timeDeltaCount") == len(deltas),
         "sanitized CPU profile counts differ from attribution metadata")
    if require_attribution:
        need(attribution.get("attributionQuality") == "PROVEN" and
             attribution.get("mappedLeafSampleCount", 0) > 0,
             "requested source attribution was not proven")
    provenance = load_json(safe_child(
        run_root, profile_capture["artifacts"]["profile"].replace(
            "v8-cpu-profile.json", "script-provenance.json")))
    bundles = provenance.get("loadedBundles", [])
    for bundle in bundles:
        need(bundle.get("wrapperValidated") is True,
             "loaded cache bundle wrapper was not validated")
        require_sha256(bundle.get("cacheFileSha256"),
                       "cache file hash for " + str(bundle.get("strongName")))
        require_sha256(bundle.get("payloadSha256"),
                       "decoded cache payload hash for " + str(bundle.get("strongName")))
        cache_path = safe_child(run_root, bundle.get("cacheArtifact"))
        payload_path = safe_child(run_root, bundle.get("decodedPayloadArtifact"))
        cache_bytes = read_bytes(cache_path, "archived cache bundle")
        payload_bytes = read_bytes(payload_path, "archived decoded cache payload")
        need(sha256_bytes(cache_bytes) == bundle.get("cacheFileSha256") and
             sha256_bytes(cache_bytes) == bundle.get("archivedCacheFileSha256") and
             len(cache_bytes) == bundle.get("cacheFileBytes") ==
             bundle.get("archivedCacheFileBytes"),
             "archived cache bundle bytes differ from provenance")
        need(sha256_bytes(payload_bytes) == bundle.get("payloadSha256") and
             sha256_bytes(payload_bytes) == bundle.get("archivedPayloadSha256") and
             len(payload_bytes) == bundle.get("payloadUtf8Bytes") ==
             bundle.get("archivedPayloadUtf8Bytes"),
             "archived decoded cache payload bytes differ from provenance")
    for symbol_map in attribution.get("symbolMaps", []):
        need(symbol_map.get("status") == "PASS",
             "symbol-map validation failed for " + str(symbol_map.get("strongName")))
        require_sha256(symbol_map.get("sha256"),
                       "symbol-map byte hash for " + str(symbol_map.get("strongName")))
        compressed_path = safe_child(run_root, symbol_map.get("compressedArtifact"))
        compressed_bytes = read_bytes(compressed_path, "archived symbol map")
        need(len(compressed_bytes) == symbol_map.get("compressedBytes"),
             "archived symbol-map byte count differs from provenance")
        try:
            symbol_bytes = gzip.decompress(compressed_bytes)
        except (OSError, EOFError) as error:
            raise ValidationError("archived symbol map is not valid gzip: {}".format(error))
        need(sha256_bytes(symbol_bytes) == symbol_map.get("sha256"),
             "archived symbol-map payload differs from provenance")
    parsed_path = safe_child(run_root, profile_capture.get("scriptParsedEventsFile"))
    parsed = load_json(parsed_path)
    encoded = json.dumps(
        {key: parsed[key] for key in ("schema", "eventCount", "events")},
        ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    need(parsed.get("sha256") == sha256_bytes(encoded),
         "scriptParsed event digest differs from capture receipt")
    need(profile_capture.get("scriptParsedEventsSha256") == parsed.get("sha256"),
         "scriptParsed event digest differs from case capture")
    need(parsed.get("eventCount") == len(parsed.get("events", [])),
         "scriptParsed event count is inconsistent")
    return attribution


def validate_case_host_errors(case):
    for field in ("pageErrors", "httpErrors", "consoleErrors",
                  "attributeReadErrors", "listenerCleanupErrors"):
        need(isinstance(case.get(field), list) and not case[field],
             "case host error array is non-empty: " + field)
    need(case.get("navigationError") is None,
         "case navigation failed")


def validate_case(run_root, result, require_attribution, expect_stop_canary):
    need(len(result.get("cases", [])) == 1,
         "ordinary profile validation requires exactly one case")
    case = result["cases"][0]
    need(case.get("outcome") == "PASS" and
         case.get("applicationOutcome") == "PASS" and
         case.get("cpuProfileOutcome") == "PASS" and
         case.get("stateMatch") is True and
         case.get("reportMatch") is True and
         case.get("reportObserved") is True and
         case.get("reportJsonValid") is True and
         case.get("reportJsonError") is None,
         "application case did not pass its declared state/report checks")
    validate_case_host_errors(case)
    report, _ = validate_report(run_root, case)
    declared_case = case.get("case", {})
    state_attribute = declared_case.get("stateAttribute")
    if state_attribute == "data-tsj-q30-coordinator-state":
        need(isinstance(report.get("request"), str) and bool(report["request"]),
             "raw Q30 coordinator report request is missing")
        strict_reader = "q30 coordinator report reader"
    elif state_attribute == "data-tsj-verification":
        need(isinstance(report, dict) and report,
             "raw A07 verification report is missing or not an object")
        # The maintained A07 contract reader remains the authoritative strict
        # report check; this helper only verifies transport/artifact metadata.
        strict_reader = "scripts/verify-a03-browser.ps1 -SelectedGate A07"
    else:
        raise ValidationError("unsupported declared case state attribute: " +
                              str(state_attribute))
    profile_capture = case.get("cpuProfile", {})
    need(profile_capture.get("status") == "PASS" and
         profile_capture.get("qualityFailures") == [],
         "case CPU profile status or quality failures are invalid")
    attribution = validate_profile(run_root, case, require_attribution)
    if expect_stop_canary:
        stop = profile_capture.get("stopNegativeCanary")
        need(isinstance(stop, dict) and
             stop.get("status") == "PASS_EXPECTED_TRANSPORT_ERROR",
             "active stop canary did not fail at transport as expected")
    return {
        "caseName": declared_case.get("name"),
        "stateAttribute": state_attribute,
        "strictReader": strict_reader,
        "reportSha256": case.get("reportSha256"),
        "profileSha256": attribution.get("profileSha256"),
        "attributionQuality": attribution.get("attributionQuality"),
        "mappedLeafSampleCount": attribution.get("mappedLeafSampleCount"),
    }


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("--expected-source-sha256")
    parser.add_argument("--expected-web-sha256")
    parser.add_argument("--require-attribution", action="store_true")
    parser.add_argument("--expect-start-canary", action="store_true")
    parser.add_argument("--expect-stop-canary", action="store_true")
    args = parser.parse_args(argv[1:])
    run_root = args.run.expanduser().resolve()
    try:
        result = load_json(run_root / "result.json")
        validate_input_audit(run_root, result, args.expected_source_sha256,
                             args.expected_web_sha256)
        need(result.get("cleanup", {}).get("status") == "PASS",
             "cleanup status is not PASS")
        need(not result["cleanup"].get("ownedSurvivors"),
             "owned browser survivors remain")
        need(result["cleanup"].get("serverStopped") is True,
             "owned HTTP server did not stop")
        need(result["cleanup"].get("errors") == [],
             "cleanup errors were recorded")
        if args.expect_start_canary:
            need(result.get("outcome") == "PASS_CANARY" and
                 result.get("canary", {}).get("kind") ==
                 "unsupported-profiler-start-transport",
                 "expected start canary was not recorded as PASS_CANARY")
            need(not result.get("cases"),
                 "start canary unexpectedly navigated an application case")
            need(isinstance(result.get("errors"), list) and result["errors"] and
                 all(row.get("expected") is True for row in result["errors"]),
                 "start canary did not preserve only its expected transport error")
            start_capture = load_json(safe_child(
                run_root, "cpu-profile/start-failure.json"))
            need(start_capture.get("status") == "CANARY_PASS" and
                 start_capture.get("negativeCanary", {}).get("status") ==
                 "PASS_EXPECTED_TRANSPORT_ERROR",
                 "start canary capture is incomplete")
            receipt = {"canary": result["canary"], "case": None}
        else:
            expected_outcome = "PASS_CANARY" if args.expect_stop_canary else "PASS"
            need(result.get("outcome") == expected_outcome,
                 "overall outcome does not match the requested canary mode")
            need(isinstance(result.get("errors"), list) and not result["errors"],
                 "ordinary or stop-canary run recorded host errors")
            if args.expect_stop_canary:
                need(result.get("canary", {}).get("kind") ==
                     "active-profile-stop-transport",
                     "active stop canary marker is missing")
            receipt = {"case": validate_case(run_root, result,
                                               args.require_attribution,
                                               args.expect_stop_canary)}
            if args.expect_stop_canary:
                receipt["stopCanary"] = result["cases"][0]["cpuProfile"].get(
                    "stopNegativeCanary")
        receipt.update({
            "status": "PASS",
            "cleanup": "PASS",
            "inputAudit": "PASS",
            "realHostTransportProof": (
                "CANARY_RECEIPT_REQUIRED"
                if not (args.expect_start_canary or args.expect_stop_canary)
                else "REAL_CANARY_REQUIRED"),
        })
        print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
        return 0
    except (OSError, UnicodeError, ValidationError, KeyError, TypeError,
            ValueError) as error:
        print("FAIL " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))

