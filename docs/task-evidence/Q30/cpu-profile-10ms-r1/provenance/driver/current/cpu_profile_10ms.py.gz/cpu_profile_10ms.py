"""Host-driven 10 ms CDP CPU-profile diagnostic for compiled Q30/A07 cases.

Each case navigates Edge to a relative ``circuitjs.html`` URL and reads
attributes from ``html`` until a declared terminal state appears.  The runner
does not inject JavaScript or call application controllers.  Its output is
retained for audit and replay; this script never removes it.

The legacy positional form remains available::

    python cpu_profile_10ms.py REPO OUTPUT SPEC_JSON [flags]

For a generic generated case, pass ``--repo``, ``--output``, ``--case`` and
the relevant seed explicitly.  ``--canary negative`` deliberately sends an
unsupported Profiler method and is PASS only when the expected transport
failure and full cleanup are both observed.  The output directory must be a
new directory below the OS temporary directory.  This runner never changes
application state or adds Java instrumentation; CDP sampling and passive
Debugger source capture are external diagnostics and can perturb timing.
"""

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import urlsplit

import argparse
import csv
import gzip
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone


try:
    from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
    from playwright.sync_api import sync_playwright
except ImportError:  # Validation still works on a host without Playwright.
    PlaywrightTimeoutError = TimeoutError
    sync_playwright = None


SCRIPT_SCHEMA = 1
DEFAULT_TERMINAL_PREFIXES = ["PASS", "FAIL"]
POLL_SECONDS = 0.2
MAX_ATTRIBUTE_TIMEOUT_MS = 10000
# Outer capture allowance for an aggregate compiled census. Application jobs
# retain their own independent deadlines, unit counts and per-unit guards.
MAX_TIMEOUT_SECONDS = 900.0
ATTRIBUTE_RE = re.compile(r"^data-tsj-[A-Za-z0-9][A-Za-z0-9-]*$")
CASE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")
INPUT_ROOTS = ("src", "war")
CHUNK_SIZE = 1024 * 1024
CPU_PROFILE_SAMPLING_INTERVAL_US = 10000
CPU_PROFILE_CACHE_RE = re.compile(r"/([0-9A-Fa-f]{32})\.cache\.js$")
CPU_PROFILE_ALLOWED_PATHS = ("/circuitjs.html", "/circuitjs1/", "/tsj-", "/font/")
GWT_SYMBOL_FIELDS = ("jsName", "jsniIdent", "className", "memberName",
                     "sourceUri", "sourceLine", "fragmentNumber")
CPU_PROFILE_BUCKETS = (
    "routing-geometry-ancestry",
    "map-index-typed-heap",
    "publisher",
    "garbage-collector",
    "idle",
    "program",
    "ambiguous",
    "unmapped",
    "non-leaf-context",
    "other-mapped",
)


class ExpectedProfilerStartCanary(Exception):
    """Expected unsupported-CDP-method failure used by the transport canary."""


def is_expected_unsupported_method_error(error, method):
    """Require a method-specific CDP method-not-found transport rejection."""
    text = str(error or "").casefold()
    method_text = str(method).casefold()
    return (method_text in text and any(marker in text for marker in (
        "method not found", "wasn't found", "was not found", "not found",
        "unknown command", "unsupported command")))


class QuietHandler(SimpleHTTPRequestHandler):
    """Serve the compiled web root without polluting the acceptance log."""

    def log_message(self, *args):
        pass

    def _serve_optional_favicon(self):
        # The browser may request the optional site icon even though this
        # compiled fixture intentionally has no favicon file.  Keep that
        # normal host request out of the app's HTTP error budget; every other
        # missing or failed resource still follows SimpleHTTPRequestHandler
        # and remains a strict acceptance error.
        if self.path != "/favicon.ico":
            return False
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()
        return True

    def do_GET(self):
        if not self._serve_optional_favicon():
            super().do_GET()

    def do_HEAD(self):
        if not self._serve_optional_favicon():
            super().do_HEAD()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def is_within(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def require_string(value, label):
    if not isinstance(value, str) or not value:
        raise ValueError(label + " must be a non-empty string")
    if "\r" in value or "\n" in value or any(ord(char) < 32 for char in value):
        raise ValueError(label + " contains a control character")
    return value


def validate_attribute(value, label):
    value = require_string(value, label)
    if not ATTRIBUTE_RE.fullmatch(value):
        raise ValueError(label + " must be a data-tsj-* attribute")
    return value


def validate_prefix(value, label):
    value = require_string(value, label)
    if len(value) > 256:
        raise ValueError(label + " is too long")
    return value


def validate_case_path(value):
    value = require_string(value, "case.path")
    if "\\" in value or value.startswith("/") or value.startswith("//"):
        raise ValueError("case.path must be a relative URL")
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc or parsed.path != "circuitjs.html":
        raise ValueError("case.path must name circuitjs.html with an optional query")
    if parsed.fragment:
        raise ValueError("case.path must not contain a fragment")
    return value


def validate_timeout(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(label + " must be a number")
    value = float(value)
    if not math.isfinite(value) or value <= 0 or value > MAX_TIMEOUT_SECONDS:
        raise ValueError(label + " must be greater than 0 and no more than 900 seconds")
    return value


def normalise_case(case, index):
    if not isinstance(case, dict):
        raise ValueError("cases[%d] must be an object" % index)
    allowed = {"name", "path", "stateAttribute", "expectedState", "expectedPrefix",
               "terminalPrefixes", "timeoutSeconds", "reportAttribute"}
    unknown = sorted(set(case) - allowed)
    if unknown:
        raise ValueError("cases[%d] has unsupported fields: %s" %
                         (index, ", ".join(unknown)))
    name = require_string(case.get("name"), "cases[%d].name" % index)
    path = validate_case_path(case.get("path"))
    state_attribute = validate_attribute(case.get("stateAttribute"),
                                         "cases[%d].stateAttribute" % index)
    has_expected_state = "expectedState" in case
    has_expected_prefix = "expectedPrefix" in case
    if has_expected_state == has_expected_prefix:
        raise ValueError("cases[%d] must contain exactly one expectedState or expectedPrefix" % index)
    expected_state = (require_string(case["expectedState"],
                                     "cases[%d].expectedState" % index)
                      if has_expected_state else None)
    expected_prefix = (validate_prefix(case["expectedPrefix"],
                                       "cases[%d].expectedPrefix" % index)
                       if has_expected_prefix else None)

    terminal_prefixes = case.get("terminalPrefixes", DEFAULT_TERMINAL_PREFIXES)
    if not isinstance(terminal_prefixes, list) or not terminal_prefixes:
        raise ValueError("cases[%d].terminalPrefixes must be a non-empty array" % index)
    terminal_prefixes = [validate_prefix(prefix,
                                          "cases[%d].terminalPrefixes" % index)
                         for prefix in terminal_prefixes]
    report_attribute = case.get("reportAttribute")
    if report_attribute is not None:
        report_attribute = validate_attribute(report_attribute,
                                              "cases[%d].reportAttribute" % index)
    timeout_seconds = validate_timeout(case.get("timeoutSeconds"),
                                       "cases[%d].timeoutSeconds" % index)
    slug = CASE_NAME_RE.sub("-", name).strip("-._") or "case"
    return {
        "index": index,
        "name": name,
        "path": path,
        "stateAttribute": state_attribute,
        "expectedState": expected_state,
        "expectedPrefix": expected_prefix,
        "terminalPrefixes": terminal_prefixes,
        "reportAttribute": report_attribute,
        "timeoutSeconds": timeout_seconds,
        "slug": "%03d-%s" % (index, slug[:80]),
    }


def load_spec(spec_path):
    raw = spec_path.read_bytes()
    try:
        spec = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("spec JSON is invalid: " + str(error))
    if not isinstance(spec, dict) or set(spec) != {"cases"}:
        raise ValueError("spec JSON must contain only a cases array")
    cases = spec["cases"]
    if not isinstance(cases, list) or not cases:
        raise ValueError("spec.cases must be a non-empty array")
    return spec, raw, [normalise_case(case, index + 1)
                       for index, case in enumerate(cases)]


def input_files(repo):
    """Yield every regular file in the fixed source and compiled web roots."""
    seen = set()
    for root_name in INPUT_ROOTS:
        root = repo / root_name
        if root.is_symlink() or not root.is_dir():
            raise ValueError("input root is missing or a symlink: " + root_name)
        for directory, directory_names, file_names in os.walk(root, followlinks=False):
            directory_path = Path(directory)
            kept_directories = []
            for directory_name in directory_names:
                child = directory_path / directory_name
                if child.is_symlink():
                    raise ValueError("input tree contains a symlink: " +
                                     str(child.relative_to(repo)))
                kept_directories.append(directory_name)
            directory_names[:] = kept_directories
            for file_name in file_names:
                child = directory_path / file_name
                if child.is_symlink():
                    raise ValueError("input tree contains a symlink: " +
                                     str(child.relative_to(repo)))
                resolved = child.resolve()
                if not is_within(resolved, repo):
                    raise ValueError("input tree escapes the repository: " +
                                     str(child.relative_to(repo)))
                relative = resolved.relative_to(repo).as_posix()
                if relative not in seen:
                    seen.add(relative)
                    yield relative, resolved


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            block = stream.read(CHUNK_SIZE)
            if not block:
                return digest.hexdigest()
            digest.update(block)


def capture_input_manifest(repo):
    files = []
    for relative, path in sorted(input_files(repo), key=lambda item: item[0]):
        files.append({"path": relative, "size": path.stat().st_size,
                      "sha256": sha256_file(path)})
    canonical = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8")
    source_files = [row for row in files if row["path"].startswith("src/")]
    web_files = [row for row in files if row["path"].startswith("war/")]
    def aggregate(rows):
        value = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(value).hexdigest()
    return {
        "schema": 1,
        "capturedUtc": utc_now(),
        "roots": list(INPUT_ROOTS),
        "files": files,
        "fileCount": len(files),
        "sourceFileCount": len(source_files),
        "webFileCount": len(web_files),
        "sha256": hashlib.sha256(canonical).hexdigest(),
        "sourceSha256": aggregate(source_files),
        "webSha256": aggregate(web_files),
    }


def capture_script_identity(repo):
    script = Path(__file__).resolve()
    path = script.relative_to(repo).as_posix() if is_within(script, repo) else script.name
    return {"path": path, "size": script.stat().st_size,
            "sha256": sha256_file(script)}


def process_rows():
    query = ("Get-CimInstance Win32_Process | Select-Object "
             "@{n='pid';e={$_.ProcessId}},@{n='parent';e={$_.ParentProcessId}},"
             "@{n='created';e={$_.CreationDate.ToUniversalTime().ToString('o')}},"
             "ExecutablePath | ConvertTo-Json -Compress")
    result = subprocess.run(["powershell.exe", "-NoProfile", "-Command", query],
                            capture_output=True, text=True, timeout=20)
    if result.returncode:
        raise RuntimeError("process identity query failed: " + result.stderr.strip())
    if not result.stdout.strip():
        return []
    rows = json.loads(result.stdout)
    return [rows] if isinstance(rows, dict) else rows


def owned_edge_rows(rows):
    process_ids = {os.getpid()}
    while True:
        expanded = set(process_ids)
        for row in rows:
            try:
                if int(row.get("parent")) in process_ids:
                    expanded.add(int(row.get("pid")))
            except (TypeError, ValueError):
                continue
        if expanded == process_ids:
            break
        process_ids = expanded
    return [row for row in rows
            if int(row.get("pid", -1)) in process_ids and
            "msedge.exe" in (row.get("ExecutablePath") or "").lower()]


def save_json(output, name, value):
    path = output / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def save_raw(output, name, value):
    path = output / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value.encode("utf-8"))
    return path




def _cpu_cache_name(path):
    match = CPU_PROFILE_CACHE_RE.search(path or "")
    return match.group(1).upper() if match else None


def _safe_cpu_profile_path(raw_url):
    """Return only an allowlisted local app path; accept sanitized paths on replay."""
    parsed = urlsplit(raw_url or "")
    path = parsed.path
    local_http = (parsed.scheme in ("http", "https") and
                  parsed.hostname in ("127.0.0.1", "localhost"))
    already_sanitized = not parsed.scheme and not parsed.netloc
    if ((local_http or already_sanitized) and
            path.startswith(CPU_PROFILE_ALLOWED_PATHS)):
        return path
    return ""


def _walk_debugger_stack(stack):
    while isinstance(stack, dict):
        for frame in stack.get("callFrames", []):
            if isinstance(frame, dict):
                yield frame
        parent = stack.get("parent")
        if not isinstance(parent, dict):
            break
        stack = parent


def _sanitize_debugger_stack(stack):
    """Retain scriptParsed stack identity without leaking host paths."""
    if not isinstance(stack, dict):
        return None
    frames = []
    for frame in stack.get("callFrames", []):
        if not isinstance(frame, dict):
            continue
        frames.append({
            "functionName": frame.get("functionName", ""),
            "scriptId": str(frame.get("scriptId", "")),
            "url": _safe_cpu_profile_path(frame.get("url", "")),
            "lineNumber": frame.get("lineNumber"),
            "columnNumber": frame.get("columnNumber"),
        })
    parent = _sanitize_debugger_stack(stack.get("parent"))
    value = {"callFrames": frames}
    if parent is not None:
        value["parent"] = parent
    return value


def _sanitize_script_parsed_event(event):
    """Save the debugger event fields needed to audit script identity."""
    if not isinstance(event, dict):
        return {}
    value = {
        "scriptId": str(event.get("scriptId", "")),
        "url": _safe_cpu_profile_path(event.get("url", "")),
        "hash": event.get("hash") if isinstance(event.get("hash"), str) else None,
        "isLiveEdit": event.get("isLiveEdit"),
        "sourceMapURL": _safe_cpu_profile_path(event.get("sourceMapURL", "")),
        "hasSourceURL": event.get("hasSourceURL"),
        "isModule": event.get("isModule"),
        "length": event.get("length"),
    }
    stack = _sanitize_debugger_stack(event.get("stackTrace"))
    if stack is not None:
        value["stackTrace"] = stack
    return value


def _script_parsed_record(script_events):
    rows = [_sanitize_script_parsed_event(event)
            for _, event in sorted(script_events.items(), key=lambda item: str(item[0]))]
    rows = [row for row in rows if row.get("scriptId")]
    record = {"schema": 1, "eventCount": len(rows), "events": rows}
    encoded = json.dumps(record, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
    record["sha256"] = hashlib.sha256(encoded).hexdigest()
    return record


def _classify_cpu_bucket(function_name, mapping=None, disposition=None):
    """Classify samples for ranking only; this is not a causality claim."""
    function = str(function_name or "").strip().casefold()
    if function in {"(garbage collector)", "garbage collector", "gc"}:
        return "garbage-collector"
    if function in {"(idle)", "idle"}:
        return "idle"
    if function in {"(program)", "program"}:
        return "program"
    if disposition == "ambiguous":
        return "ambiguous"
    if disposition == "non-leaf-context":
        return "non-leaf-context"
    # Owner buckets are meaningful only after exact, unique source mapping. A
    # generated or unmapped function name can contain an owner-like word by
    # coincidence, so keep it in the explicit unmapped bucket.
    if disposition != "mapped-leaf" or mapping is None:
        return "unmapped"
    text = " ".join(str(value or "") for value in (
        function_name,
        mapping.get("className"),
        mapping.get("memberName"),
        mapping.get("sourceUri"),
    )).casefold()
    # Check specific map/index/typed-heap ownership before broad routing
    # geometry terms. For example, PcbLayerRoutingPrototype.typedHeapLookup
    # must remain a map/index/typed-heap row.
    if any(token in text for token in (
            "typedheap", "typed heap", "heap", "map", "index", "lookup",
            "symbol", "cache", "hash")):
        return "map-index-typed-heap"
    if any(token in text for token in (
            "publish", "publisher", "publication", "admission", "candidate")):
        return "publisher"
    if any(token in text for token in (
            "routing", "router", "route", "geometry", "ancestr", "layout",
            "copper", "physical", "footprint", "pcbnet", "pcb layer")):
        return "routing-geometry-ancestry"
    return "other-mapped"


def _read_gwt_download_payload(repo, strong_name):
    """Decode GWT's JSON-string array wrapper without executing its contents."""
    bundle_path = repo / "war/circuitjs1" / (strong_name + ".cache.js")
    bundle_bytes = bundle_path.read_bytes()
    bundle_text = bundle_bytes.decode("utf-8-sig")
    prefix = "circuitjs1.onScriptDownloaded("
    if not bundle_text.startswith(prefix):
        raise ValueError("cache bundle does not start with the expected GWT wrapper")
    position = len(prefix)
    while position < len(bundle_text) and bundle_text[position].isspace():
        position += 1
    if position >= len(bundle_text) or bundle_text[position] != "[":
        raise ValueError("GWT wrapper payload is not a JSON array")
    fragments, end = json.JSONDecoder().raw_decode(bundle_text, position)
    if not isinstance(fragments, list) or not fragments or not all(
            isinstance(fragment, str) for fragment in fragments):
        raise ValueError("GWT wrapper array must contain non-empty string fragments")
    if bundle_text[end:].strip() != ");":
        raise ValueError("GWT wrapper has an unexpected suffix")
    payload_text = "".join(fragments)
    payload_bytes = payload_text.encode("utf-8")
    embedded_names = re.findall(
        r"\$strongName\s*=\s*['\"]([0-9A-Fa-f]{32})['\"]", payload_text)
    if embedded_names != [strong_name]:
        raise ValueError("decoded GWT payload strong name does not match its cache filename")
    return {
        "strongName": strong_name,
        "cacheFileSha256": hashlib.sha256(bundle_bytes).hexdigest(),
        "cacheFileBytes": len(bundle_bytes),
        "payloadSha256": hashlib.sha256(payload_bytes).hexdigest(),
        "payloadUtf8Bytes": len(payload_bytes),
        "fragmentCount": len(fragments),
        "embeddedStrongNameCount": len(embedded_names),
        "wrapperValidated": True,
    }, bundle_bytes, payload_bytes


def capture_profile_script_provenance(repo, profile, cdp_session, script_events):
    """Link sampled scriptIds only to exact GWT URLs or their decoded payload bytes."""
    nodes_by_id = {node.get("id"): node for node in profile.get("nodes", [])}
    sampled_script_ids = set()
    for node_id in profile.get("samples", []):
        node = nodes_by_id.get(node_id)
        frame = node.get("callFrame", {}) if node else {}
        script_id = str(frame.get("scriptId", ""))
        if script_id not in ("", "0") and not _cpu_cache_name(
                _safe_cpu_profile_path(frame.get("url", ""))):
            sampled_script_ids.add(script_id)

    strong_names = set()
    for node in profile.get("nodes", []):
        path = _safe_cpu_profile_path(node.get("callFrame", {}).get("url", ""))
        strong = _cpu_cache_name(path)
        if strong:
            strong_names.add(strong)
    for event in script_events.values():
        strong = _cpu_cache_name(_safe_cpu_profile_path(event.get("url", "")))
        if strong:
            strong_names.add(strong)

    bundles = {}
    bundle_evidence = []
    for strong in sorted(strong_names):
        try:
            metadata, file_bytes, payload_bytes = _read_gwt_download_payload(repo, strong)
            bundles[strong] = (file_bytes, payload_bytes)
            bundle_evidence.append(metadata)
        except BaseException as error:
            bundle_evidence.append({
                "strongName": strong,
                "wrapperValidated": False,
                "error": type(error).__name__ + ": " + str(error),
            })

    script_map = {}
    evidence_rows = []
    for script_id in sorted(sampled_script_ids):
        event = script_events.get(script_id, {})
        event_url = _safe_cpu_profile_path(event.get("url", ""))
        linked_names = set()
        event_url_name = _cpu_cache_name(event_url)
        if event_url_name:
            linked_names.add(event_url_name)
        stack_paths = []
        for stack_frame in _walk_debugger_stack(event.get("stackTrace")):
            path = _safe_cpu_profile_path(stack_frame.get("url", ""))
            if path:
                stack_paths.append(path)

        source_text = None
        source_error = None
        try:
            response = cdp_session.send("Debugger.getScriptSource", {
                "scriptId": script_id})
            value = response.get("scriptSource") if isinstance(response, dict) else None
            if isinstance(value, str):
                source_text = value
            else:
                source_error = "Debugger.getScriptSource returned no source text"
        except BaseException as error:
            source_error = type(error).__name__ + ": " + str(error)

        source_sha256 = None
        source_bytes = None
        payload_matches = []
        if source_text is not None:
            source_bytes_value = source_text.encode("utf-8")
            source_sha256 = hashlib.sha256(source_bytes_value).hexdigest()
            source_bytes = len(source_bytes_value)
            for strong, (file_bytes, payload_bytes) in sorted(bundles.items()):
                match_kind = None
                if source_bytes_value == file_bytes:
                    match_kind = "exact-cache-file-bytes"
                elif source_bytes_value == payload_bytes:
                    match_kind = "exact-decoded-payload-bytes"
                elif source_bytes >= 256 and source_bytes_value in payload_bytes:
                    match_kind = "exact-decoded-payload-substring-256plus"
                if match_kind:
                    payload_matches.append({
                        "strongName": strong,
                        "match": match_kind,
                        "scriptSourceSha256": source_sha256,
                    })
                    linked_names.add(strong)

        unique_names = sorted(linked_names)
        linked_strong = unique_names[0] if len(unique_names) == 1 else None
        if linked_strong:
            script_map[script_id] = linked_strong
        evidence_rows.append({
            "scriptId": script_id,
            "debuggerScriptParsedObserved": bool(event),
            "scriptParsedUrl": event_url,
            "scriptParsedHash": event.get("hash") if isinstance(event.get("hash"), str) else None,
            "scriptParsedStackPaths": sorted(set(stack_paths)),
            "scriptSourceSha256": source_sha256,
            "scriptSourceUtf8Bytes": source_bytes,
            "scriptSourceError": source_error,
            "decodedPayloadMatches": payload_matches,
            "linkedStrongNames": unique_names,
            "linkedStrongName": linked_strong,
            "linkBasis": (
                "exact-scriptParsed-cache-url" if event_url_name and linked_strong else
                "exact-script-source-vs-decoded-payload" if len(payload_matches) == 1 and linked_strong else
                "conflicting-exact-links" if len(unique_names) > 1 else "unlinked"),
        })
    return script_map, evidence_rows, bundle_evidence, bundles


def archive_cache_payloads(output, bundles, bundle_evidence):
    """Archive exact cache and decoded payload bytes used for provenance."""
    root = output / "cpu-profile/cacheBundles"
    root.mkdir(parents=True, exist_ok=True)
    by_name = {row.get("strongName"): row for row in bundle_evidence
               if isinstance(row, dict)}
    for strong_name, (cache_bytes, payload_bytes) in sorted(bundles.items()):
        cache_path = root / (strong_name + ".cache.js")
        payload_path = root / (strong_name + ".decoded.js")
        cache_path.write_bytes(cache_bytes)
        payload_path.write_bytes(payload_bytes)
        row = by_name.get(strong_name)
        if row is not None:
            row.update({
                "cacheArtifact": cache_path.relative_to(output).as_posix(),
                "decodedPayloadArtifact": payload_path.relative_to(output).as_posix(),
                "archivedCacheFileSha256": hashlib.sha256(cache_bytes).hexdigest(),
                "archivedPayloadSha256": hashlib.sha256(payload_bytes).hexdigest(),
                "archivedCacheFileBytes": len(cache_bytes),
                "archivedPayloadUtf8Bytes": len(payload_bytes),
            })


def save_cpu_profile_artifacts(repo, output, case, profile, capture,
                               script_id_to_strong_name=None):
    """Keep a sanitized V8 profile and source-proven GWT symbol attribution."""
    script_id_to_strong_name = script_id_to_strong_name or {}
    profile_dir = output / "cpu-profile"
    profile_dir.mkdir(parents=True, exist_ok=True)
    sanitized = profile
    strong_names = set()
    wanted_names = {}
    provenance = capture.get("scriptProvenance", {})
    loaded_bundles = provenance.get("loadedBundles", [])
    payload_validated_names = {
        row.get("strongName") for row in loaded_bundles
        if isinstance(row, dict) and row.get("wrapperValidated") is True and
        isinstance(row.get("payloadSha256"), str)
    }

    for node in sanitized.get("nodes", []):
        frame = node.get("callFrame", {})
        path = _safe_cpu_profile_path(frame.get("url", ""))
        frame["url"] = path
        strong = _cpu_cache_name(path)
        if strong:
            strong_names.add(strong)

    # Keep profile function names available to build the symbol lookup table,
    # but do not attribute an empty-URL frame by name alone. Its scriptId must
    # first be linked to a loaded bundle by exact Debugger/source evidence.
    strong_names.update(script_id_to_strong_name.values())
    for node in sanitized.get("nodes", []):
        frame = node.get("callFrame", {})
        name = frame.get("functionName", "")
        script_id = str(frame.get("scriptId", ""))
        if not name:
            continue
        direct = _cpu_cache_name(frame.get("url", ""))
        targets = ([direct] if direct else sorted(strong_names))
        for strong in targets:
            wanted_names.setdefault(strong, set()).add(name)

    profile_bytes = json.dumps(sanitized, ensure_ascii=False,
                               separators=(",", ":")).encode("utf-8")
    profile_path = profile_dir / "v8-cpu-profile.json"
    profile_path.write_bytes(profile_bytes)

    symbol_tables = {}
    symbol_artifacts = []
    symbol_root = profile_dir / "symbolMaps"
    symbol_root.mkdir(parents=True, exist_ok=True)
    for strong in sorted(strong_names):
        symbol_path = (repo / "war/WEB-INF/deploy/circuitjs1/symbolMaps" /
                       (strong + ".symbolMap"))
        if not symbol_path.is_file():
            symbol_artifacts.append({
                "strongName": strong, "status": "MISSING",
                "repoPath": symbol_path.relative_to(repo).as_posix()})
            continue
        symbol_bytes = symbol_path.read_bytes()
        symbol_sha = hashlib.sha256(symbol_bytes).hexdigest()
        archived = symbol_root / (strong + ".symbolMap.gz")
        archived.write_bytes(gzip.compress(symbol_bytes, mtime=0))
        wanted = wanted_names.get(strong, set())
        table = {}
        known_lu_factor_rows = []
        with symbol_path.open("r", encoding="utf-8", newline="") as stream:
            # GWT's CSV field names are themselves a comment. Filtering comments
            # and using DictReader's default would consume the first data row as
            # its header and silently lose all symbol attribution.
            records = csv.DictReader(
                (line for line in stream if not line.startswith("#")),
                fieldnames=GWT_SYMBOL_FIELDS)
            for row in records:
                if (row.get("className") ==
                        "com.lushprojects.circuitjs1.client.CirSim" and
                        row.get("memberName") == "lu_factor"):
                    known_lu_factor_rows.append(row)
                js_name = row.get("jsName", "")
                if js_name in wanted:
                    table.setdefault(js_name, []).append({
                        "jsName": js_name,
                        "jsniIdent": row.get("jsniIdent", ""),
                        "className": row.get("className", ""),
                        "memberName": row.get("memberName", ""),
                        "sourceUri": row.get("sourceUri", ""),
                        "sourceLine": row.get("sourceLine", ""),
                        "fragmentNumber": row.get("fragmentNumber", ""),
                    })
        map_valid = len(known_lu_factor_rows) == 1
        symbol_tables[strong] = table
        symbol_artifacts.append({
            "strongName": strong,
            "status": "PASS" if map_valid else "INVALID",
            "knownCirSimLuFactorRows": len(known_lu_factor_rows),
            "knownCirSimLuFactorJsName": (
                known_lu_factor_rows[0].get("jsName") if map_valid else None),
            "repoPath": symbol_path.relative_to(repo).as_posix(),
            "sha256": symbol_sha,
            "compressedArtifact": archived.relative_to(output).as_posix(),
            "compressedBytes": archived.stat().st_size,
            "mappedProfileFunctionCount": sum(1 for rows in table.values() if len(rows) == 1),
            "ambiguousSymbolCount": sum(1 for rows in table.values() if len(rows) > 1),
            "profileFunctionCount": len(wanted),
        })

    symbol_map_valid_names = {
        row.get("strongName") for row in symbol_artifacts
        if row.get("status") == "PASS"
    }

    nodes_by_id = {node.get("id"): node for node in sanitized.get("nodes", [])}
    samples = sanitized.get("samples", [])
    deltas = sanitized.get("timeDeltas", [])
    sample_groups = {}
    gwt_sample_count = 0
    mapped_gwt_sample_count = 0
    ambiguous_sample_count = 0
    aggregate_children_sample_count = 0
    unproven_sample_count = 0
    bucket_totals = {bucket: {"sampleCount": 0, "sampledMicroseconds": 0}
                     for bucket in CPU_PROFILE_BUCKETS}
    pair_count = min(len(samples), len(deltas))
    for index in range(pair_count):
        node = nodes_by_id.get(samples[index])
        frame = node.get("callFrame", {}) if node else {}
        function_name = frame.get("functionName", "")
        # Profile.samples identifies the sampled top-of-stack node. The
        # aggregate call-tree children are independent context and do not mean
        # that this directly sampled frame contributed no self time.
        sampled_frame_is_self = node is not None
        aggregate_node_has_children = bool(node and node.get("children"))
        if aggregate_node_has_children:
            aggregate_children_sample_count += 1
        direct_strong = _cpu_cache_name(frame.get("url", ""))
        script_id = str(frame.get("scriptId", ""))
        script_strong = script_id_to_strong_name.get(script_id)
        if direct_strong and direct_strong in payload_validated_names:
            strong = direct_strong
            mapping_basis = "profile-url"
        elif (script_strong and script_strong in payload_validated_names):
            strong = script_strong
            mapping_basis = "exact-debugger-source-proven-scriptId"
        else:
            strong = None
            mapping_basis = None
        mappings = (symbol_tables.get(strong, {}).get(function_name, [])
                    if strong and function_name else [])
        if len(mappings) > 1:
            mapping_disposition = "ambiguous"
            ambiguous_sample_count += 1
        elif (len(mappings) == 1 and strong in symbol_map_valid_names and
              sampled_frame_is_self):
            mapping_disposition = "mapped-leaf"
        elif strong and strong not in payload_validated_names:
            mapping_disposition = "unproven-cache-payload"
            unproven_sample_count += 1
        else:
            mapping_disposition = "unmapped"
            unproven_sample_count += 1
        mapping = (mappings[0] if mapping_disposition == "mapped-leaf" else None)
        if mapping is not None:
            mapped_gwt_sample_count += 1
        if mapping:
            label = mapping["className"] + "::" + mapping["memberName"]
            source_uri = mapping["sourceUri"]
            source_line = mapping["sourceLine"]
        else:
            label = function_name or "<anonymous-or-unmapped>"
            source_uri = ""
            source_line = ""
        bucket = _classify_cpu_bucket(function_name, mapping, mapping_disposition)
        delta = deltas[index]
        sampled_microseconds = (delta if isinstance(delta, (int, float)) and
                                delta >= 0 else 0)
        bucket_totals[bucket]["sampleCount"] += 1
        bucket_totals[bucket]["sampledMicroseconds"] += sampled_microseconds
        key = (strong or "", label, source_uri, source_line, function_name,
               mapping_basis or "unmapped", mapping_disposition, bucket,
               sampled_frame_is_self, aggregate_node_has_children)
        group = sample_groups.get(key)
        if group is None:
            group = {
                "strongName": strong,
                "functionName": function_name,
                "label": label,
                "sourceUri": source_uri,
                "sourceLine": source_line,
                "mapped": mapping is not None,
                "mappingBasis": mapping_basis,
                "mappingDisposition": mapping_disposition,
                # Keep the legacy leaf field as a compatibility alias for the
                # directly sampled self frame. It is not derived from children.
                "leaf": sampled_frame_is_self,
                "sampledFrameIsSelf": sampled_frame_is_self,
                "aggregateNodeHasChildren": aggregate_node_has_children,
                "bucket": bucket,
                "sampleCount": 0,
                "sampledMicroseconds": 0,
            }
            sample_groups[key] = group
        group["sampleCount"] += 1
        if isinstance(delta, (int, float)) and delta >= 0:
            group["sampledMicroseconds"] += delta

    mapped_groups = [row for row in sample_groups.values() if row["mapped"]]
    unmapped_groups = [row for row in sample_groups.values() if not row["mapped"]]
    sort_groups = lambda rows: sorted(
        rows, key=lambda row: (-row["sampledMicroseconds"], row["label"]))
    summary = {
        "schema": 1,
        "caseName": case["name"],
        "samplingIntervalMicroseconds": CPU_PROFILE_SAMPLING_INTERVAL_US,
        "profileStartTimeMicroseconds": sanitized.get("startTime"),
        "profileEndTimeMicroseconds": sanitized.get("endTime"),
        "profileRangeMicroseconds": (
            sanitized.get("endTime", 0) - sanitized.get("startTime", 0)
            if isinstance(sanitized.get("endTime"), (int, float)) and
               isinstance(sanitized.get("startTime"), (int, float)) else None),
        "profileFile": profile_path.relative_to(output).as_posix(),
        "profileSha256": hashlib.sha256(profile_bytes).hexdigest(),
        "profileNodeCount": len(sanitized.get("nodes", [])),
        "sampleCount": len(samples),
        "timeDeltaCount": len(deltas),
        "pairedSampleCount": pair_count,
        "sampleArraysAligned": len(samples) == len(deltas),
        "gwtBundleCount": len(strong_names),
        "gwtBundleStrongNames": sorted(strong_names),
        "payloadValidatedBundleCount": len(payload_validated_names),
        "payloadValidatedBundleStrongNames": sorted(payload_validated_names),
        "mappedGwtSampleCount": mapped_gwt_sample_count,
        "mappedLeafSampleCount": mapped_gwt_sample_count,
        "ambiguousSampleCount": ambiguous_sample_count,
        "nonLeafContextSampleCount": 0,
        "aggregateChildrenContextSampleCount": aggregate_children_sample_count,
        "unprovenOrUnmappedSampleCount": unproven_sample_count,
        "attributionQuality": (
            "PROVEN" if mapped_gwt_sample_count > 0 else "NOT_PROVEN"),
        "bucketTotals": bucket_totals,
        "provenScriptIdCount": len(script_id_to_strong_name),
        "scriptIdStrongNames": dict(sorted(script_id_to_strong_name.items())),
        "allGwtSymbolMapsValidated": bool(strong_names) and all(
            row.get("status") == "PASS" for row in symbol_artifacts),
        "frameAttributionRule": (
            "A sample is attributed only when samples[i] resolves to a directly "
            "sampled top-of-stack frame, its aggregate children are retained as "
            "context rather than used as a self-time test, its "
            "hashed cache URL or exact scriptId link identifies one loaded bundle, "
            "the decoded cache payload wrapper and symbol map are validated, and "
            "the symbol-map function row is unique. Function-name matches, "
            "aggregate-tree children, non-leaf ancestry, and eval-stack ancestry "
            "do not establish source identity."),
        "scriptProvenance": capture.get("scriptProvenance", {}),
        "pairedSampledMicroseconds": sum(
            delta for delta in deltas[:pair_count]
            if isinstance(delta, (int, float)) and delta >= 0),
        "symbolMaps": symbol_artifacts,
        "captureBoundary": {
            key: capture.get(key) for key in (
                "scope", "startIncludesNavigation", "stopReason", "stopTargetState",
                "stopObservedState", "stopObservedUtc", "stopObservedHostMonotonicSeconds",
                "transitionDetectionWindowSeconds", "stateReadRoundTripSeconds",
                "pollIntervalSeconds", "profileMayIncludeWarmWorkUntilStopAck",
                "warmBoundaryObserved", "requireWarmBoundary",
                "stopHelperDispatchDelaySeconds", "stopDispatchDelaySeconds",
                "realStopDispatchUtc", "realStopDispatchHostMonotonicSeconds",
                "stopRoundTripSeconds")
        },
        "topMappedMethods": sort_groups(mapped_groups)[:200],
        "topUnmappedFrames": sort_groups(unmapped_groups)[:100],
        "bucketDefinitions": {
            "routing-geometry-ancestry": "Uniquely validated mapped sampled rows whose class/member/source names contain routing, geometry, ancestry, layout, copper, physical or PCB terms.",
            "map-index-typed-heap": "Uniquely validated mapped sampled rows whose names contain map, index, lookup, symbol, cache, hash, heap or typed-heap terms; this bucket is checked before broad routing terms.",
            "publisher": "Uniquely validated mapped sampled rows whose names contain publish, admission, publication or candidate terms.",
            "garbage-collector": "V8 browser garbage-collector frame names.",
            "idle": "V8 browser idle frame names.",
            "program": "V8 browser program frame names.",
            "ambiguous": "Frames with more than one symbol-map row; never attributed to a source owner.",
            "unmapped": "Frames without a unique validated source mapping.",
            "non-leaf-context": "Reserved for separately walked ancestry context; aggregate children are never treated as a non-leaf sampled frame.",
            "other-mapped": "Unique validated mapped directly sampled rows outside the named exploratory buckets.",
        },
        "wallTimerSeparation": (
            "CPU sample deltas are retained separately from host/application wall "
            "timers. They cannot establish deadline contribution, scheduler wait, "
            "allocation volume, retained heap, or causality."),
        "interpretationLimit": (
            "V8 sampled CPU time for this page target only. Do not extrapolate "
            "samples into solver wall time or treat this diagnostic run as a "
            "deadline result. Sampling overhead is unmeasured."),
    }
    save_json(output, "cpu-profile/attribution.json", summary)
    return summary


def expected_matches(case, state):
    if state is None:
        return False
    if case["expectedState"] is not None:
        return state == case["expectedState"]
    return state.startswith(case["expectedPrefix"])


def case_slug(case):
    return "cases/" + case["slug"]


def run_case(page, base_url, case, output, cpu_profile_session=None, cpu_profile_repo=None,
             cpu_profile_stop_state="RUNNING:warm", cpu_profile_negative_canary=False,
             cpu_profile_stop_negative_canary=False,
             cpu_profile_require_warm_boundary=False, cpu_profile_script_events=None):
    started = time.monotonic()
    started_utc = utc_now()
    deadline = started + case["timeoutSeconds"]
    page_errors = []
    http_errors = []
    console_errors = []
    read_errors = []
    listener_cleanup_errors = []
    navigation_error = None
    last_observed_state = None
    terminal_reached = False
    timed_out = False
    cpu_profile_capture = {"status": "NOT_REQUESTED"}
    cpu_profiler_enabled = False
    cpu_profile_started = False
    last_cold_state_observation = None

    def on_page_error(error):
        page_errors.append(str(error))

    def on_response(response):
        try:
            if response.status >= 400:
                http_errors.append({"url": response.url,
                                    "status": response.status,
                                    "statusText": response.status_text})
        except BaseException as error:
            http_errors.append({"error": str(error)})

    def on_console(message):
        try:
            if message.type == "error":
                location = message.location if isinstance(message.location, dict) else None
                console_errors.append({"type": message.type, "text": message.text,
                                       "location": location})
        except BaseException as error:
            console_errors.append({"error": str(error)})

    page.on("pageerror", on_page_error)
    page.on("response", on_response)
    page.on("console", on_console)
    url = base_url + "/" + case["path"]

    def read_attribute(attribute):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            read_errors.append({"attribute": attribute, "type": "DeadlineExpired",
                                "message": "case deadline elapsed"})
            return None
        try:
            return page.locator("html").get_attribute(
                attribute, timeout=max(1, min(MAX_ATTRIBUTE_TIMEOUT_MS,
                                             int(remaining * 1000))))
        except BaseException as error:
            read_errors.append({"attribute": attribute, "type": type(error).__name__,
                                "message": str(error)})
            return None

    def stop_cpu_profile(stop_reason, observed_state=None, observed_monotonic=None):
        nonlocal cpu_profiler_enabled, cpu_profile_started
        if not cpu_profile_started:
            return
        stop_started = time.monotonic()
        cpu_profile_capture["stopReason"] = stop_reason
        cpu_profile_capture["stopObservedState"] = observed_state
        cpu_profile_capture["stopObservedUtc"] = utc_now()
        cpu_profile_capture["warmBoundaryObserved"] = (
            stop_reason == "target-state-observed" and
            observed_state == cpu_profile_stop_state)
        if observed_monotonic is not None:
            cpu_profile_capture["stopObservedHostMonotonicSeconds"] = observed_monotonic
            cpu_profile_capture["stopHelperDispatchDelaySeconds"] = max(
                0.0, stop_started - observed_monotonic)
        if cpu_profile_stop_negative_canary:
            canary_started = time.monotonic()
            canary = {
                "requested": True,
                "method": "Profiler.__codexUnsupportedStopCanary",
                "status": "NOT_RUN",
            }
            try:
                cpu_profile_session.send("Profiler.__codexUnsupportedStopCanary")
                canary["status"] = "FAIL_UNSUPPORTED_METHOD_ACCEPTED"
            except BaseException as error:
                canary["error"] = {"type": type(error).__name__,
                                    "message": str(error)}
                canary["status"] = (
                    "PASS_EXPECTED_TRANSPORT_ERROR"
                    if is_expected_unsupported_method_error(
                        error, "Profiler.__codexUnsupportedStopCanary")
                    else "FAIL_UNEXPECTED_TRANSPORT_ERROR")
            canary["roundTripSeconds"] = time.monotonic() - canary_started
            cpu_profile_capture["stopNegativeCanary"] = canary
        cpu_profile_started = False
        try:
            # This timestamp is deliberately adjacent to the real stop send so
            # the reported stop tail includes any negative-canary dispatch.
            real_stop_dispatch_started = time.monotonic()
            cpu_profile_capture["realStopDispatchUtc"] = utc_now()
            cpu_profile_capture["realStopDispatchHostMonotonicSeconds"] = (
                real_stop_dispatch_started)
            if observed_monotonic is not None:
                cpu_profile_capture["stopDispatchDelaySeconds"] = max(
                    0.0, real_stop_dispatch_started - observed_monotonic)
            stopped = cpu_profile_session.send("Profiler.stop")
            cpu_profile_capture["stopRoundTripSeconds"] = (
                time.monotonic() - real_stop_dispatch_started)
            profile = stopped.get("profile") if isinstance(stopped, dict) else None
            if not isinstance(profile, dict):
                raise RuntimeError("Profiler.stop returned no CPU profile")
            raw_profile_bytes = json.dumps(
                profile, ensure_ascii=False, separators=(",", ":"),
                allow_nan=False).encode("utf-8")
            raw_profile_path = output / "cpu-profile/raw-v8-cpu-profile.json"
            raw_profile_path.parent.mkdir(parents=True, exist_ok=True)
            raw_profile_path.write_bytes(raw_profile_bytes)
            cpu_profile_capture.update({
                "rawProfileFile": "cpu-profile/raw-v8-cpu-profile.json",
                "rawProfileSha256": hashlib.sha256(raw_profile_bytes).hexdigest(),
                "rawProfileBytes": len(raw_profile_bytes),
            })
            (script_id_to_strong_name, script_provenance,
             loaded_bundle_evidence, cache_bundles) = capture_profile_script_provenance(
                cpu_profile_repo, profile, cpu_profile_session,
                cpu_profile_script_events or {})
            archive_cache_payloads(output, cache_bundles, loaded_bundle_evidence)
            script_provenance_record = {
                "sampledScripts": script_provenance,
                "loadedBundles": loaded_bundle_evidence,
            }
            cpu_profile_capture["scriptProvenance"] = script_provenance_record
            script_parsed_record = _script_parsed_record(
                cpu_profile_script_events or {})
            save_json(output, "cpu-profile/script-parsed-events.json",
                      script_parsed_record)
            cpu_profile_capture.update({
                "scriptParsedEventCount": script_parsed_record["eventCount"],
                "scriptParsedEventsFile": "cpu-profile/script-parsed-events.json",
                "scriptParsedEventsSha256": script_parsed_record["sha256"],
            })
            save_json(output, "cpu-profile/script-provenance.json",
                      script_provenance_record)
            summary = save_cpu_profile_artifacts(
                cpu_profile_repo, output, case, profile, cpu_profile_capture,
                script_id_to_strong_name)
            quality_failures = []
            if not summary["sampleArraysAligned"]:
                quality_failures.append("sample and time-delta arrays are misaligned")
            if summary["pairedSampleCount"] <= 0:
                quality_failures.append("profile has no aligned samples")
            if (summary["gwtBundleCount"] > 0 and
                    not summary["allGwtSymbolMapsValidated"]):
                quality_failures.append("one or more loaded GWT symbol maps failed CirSim.lu_factor validation")
            if (cpu_profile_require_warm_boundary and
                    not cpu_profile_capture.get("warmBoundaryObserved")):
                quality_failures.append("required RUNNING:warm boundary was not observed")
            cpu_profile_capture.update({
                "status": "CAPTURED",
                "qualityFailures": quality_failures,
                "attributionQuality": summary["attributionQuality"],
                "artifacts": {
                    "profile": summary["profileFile"],
                    "attribution": "cpu-profile/attribution.json",
                    "symbolMaps": summary["symbolMaps"],
                },
            })
            stop_canary = cpu_profile_capture.get("stopNegativeCanary")
            if (isinstance(stop_canary, dict) and
                    stop_canary.get("status") != "PASS_EXPECTED_TRANSPORT_ERROR"):
                cpu_profile_capture["qualityFailures"].append(
                    "active-profile stop transport canary did not fail as expected")
        except BaseException as error:
            cpu_profile_capture.update({
                "status": "STOP_OR_EXPORT_FAILED",
                "stopRoundTripSeconds": time.monotonic() - stop_started,
                "error": {"type": type(error).__name__, "message": str(error)},
            })
        finally:
            if cpu_profiler_enabled:
                try:
                    cpu_profile_session.send("Profiler.disable")
                except BaseException as error:
                    cpu_profile_capture["disableError"] = str(error)
                cpu_profiler_enabled = False
        if cpu_profile_capture.get("status") == "CAPTURED":
            profile_failed = bool(cpu_profile_capture.get("qualityFailures") or
                                  cpu_profile_capture.get("disableError"))
            cpu_profile_capture["status"] = "FAIL_PROFILE" if profile_failed else "PASS"
        if cpu_profile_capture.get("status") == "STOP_OR_EXPORT_FAILED":
            raise RuntimeError(
                "V8 CPU profile stop/export failed: " +
                str(cpu_profile_capture.get("error")))
        if cpu_profile_capture.get("disableError"):
            raise RuntimeError(
                "V8 CPU profiler disable failed: " +
                str(cpu_profile_capture["disableError"]))

    try:
        if cpu_profile_session is not None:
            cpu_profile_capture = {
                "status": "STARTING",
                "samplingIntervalMicroseconds": CPU_PROFILE_SAMPLING_INTERVAL_US,
                "scope": "starts before navigation; target-state stop is host-observed and may include a short warm-boundary tail",
                "startIncludesNavigation": True,
                "stopTargetState": cpu_profile_stop_state,
                "requireWarmBoundary": cpu_profile_require_warm_boundary,
            }
            try:
                cpu_profile_session.send("Profiler.enable")
                cpu_profiler_enabled = True
                cpu_profile_session.send("Profiler.setSamplingInterval", {
                    "interval": CPU_PROFILE_SAMPLING_INTERVAL_US})
                cpu_profile_capture["startRequestedUtc"] = utc_now()
                cpu_profile_started_at = time.monotonic()
                if cpu_profile_negative_canary:
                    try:
                        cpu_profile_session.send("Profiler.__codexUnsupportedCanary")
                    except BaseException as error:
                        expected_error = is_expected_unsupported_method_error(
                            error, "Profiler.__codexUnsupportedCanary")
                        cpu_profile_capture["negativeCanary"] = {
                            "requested": True,
                            "method": "Profiler.__codexUnsupportedCanary",
                            "status": ("PASS_EXPECTED_TRANSPORT_ERROR"
                                       if expected_error else
                                       "FAIL_UNEXPECTED_TRANSPORT_ERROR"),
                            "error": {"type": type(error).__name__,
                                      "message": str(error)},
                        }
                        if not expected_error:
                            raise RuntimeError(
                                "unsupported profiler canary did not receive the "
                                "expected method-not-found transport error: " +
                                str(error))
                        try:
                            disable_ack = cpu_profile_session.send("Profiler.disable")
                            if not isinstance(disable_ack, dict):
                                raise RuntimeError(
                                    "Profiler.disable returned no protocol acknowledgment")
                        except BaseException as disable_error:
                            cpu_profile_capture["disableError"] = {
                                "type": type(disable_error).__name__,
                                "message": str(disable_error),
                            }
                            raise RuntimeError(
                                "Profiler.disable failed after start canary: " +
                                str(disable_error))
                        cpu_profiler_enabled = False
                        cpu_profile_capture["disableAcknowledged"] = True
                        cpu_profile_capture["startRoundTripSeconds"] = (
                            time.monotonic() - cpu_profile_started_at)
                        cpu_profile_capture["status"] = "CANARY_PASS"
                        raise ExpectedProfilerStartCanary(str(error))
                    cpu_profile_capture["negativeCanary"] = {
                        "requested": True,
                        "method": "Profiler.__codexUnsupportedCanary",
                        "status": "FAIL_UNSUPPORTED_METHOD_ACCEPTED",
                    }
                    raise RuntimeError(
                        "Unsupported profiler method unexpectedly succeeded")
                else:
                    cpu_profile_session.send("Profiler.start")
                cpu_profile_started = True
                cpu_profile_capture["startRoundTripSeconds"] = (
                    time.monotonic() - cpu_profile_started_at)
                cpu_profile_capture["status"] = "RECORDING"
                if cpu_profile_negative_canary:
                    raise RuntimeError(
                        "Unsupported profiler method unexpectedly succeeded")
            except ExpectedProfilerStartCanary:
                cpu_profile_started = False
                save_json(output, "cpu-profile/start-failure.json",
                          cpu_profile_capture)
                raise
            except BaseException as error:
                cpu_profile_capture["status"] = "START_FAILED"
                cpu_profile_capture["error"] = {
                    "type": type(error).__name__, "message": str(error)}
                if cpu_profiler_enabled:
                    try:
                        cpu_profile_session.send("Profiler.disable")
                    except BaseException as disable_error:
                        cpu_profile_capture["disableError"] = str(disable_error)
                    cpu_profiler_enabled = False
                save_json(output, "cpu-profile/start-failure.json",
                          cpu_profile_capture)
                raise RuntimeError("V8 CPU profile failed to start: " + str(error))

        try:
            response = page.goto(url, wait_until="domcontentloaded",
                                 timeout=max(1, int(case["timeoutSeconds"] * 1000)))
            if response is not None and response.status >= 400 and not any(
                    row.get("url") == response.url and row.get("status") == response.status
                    for row in http_errors):
                http_errors.append({"url": response.url, "status": response.status,
                                    "statusText": response.status_text})
        except PlaywrightTimeoutError as error:
            navigation_error = {"type": type(error).__name__, "message": str(error)}
            timed_out = True
        except BaseException as error:
            navigation_error = {"type": type(error).__name__, "message": str(error)}

        if navigation_error is None:
            while time.monotonic() < deadline:
                state_read_started_at = time.monotonic()
                state = read_attribute(case["stateAttribute"])
                state_observed_at = time.monotonic()
                if state is not None:
                    last_observed_state = state
                    if state == "RUNNING:cold":
                        last_cold_state_observation = {
                            "utc": utc_now(), "monotonic": state_observed_at}
                    if cpu_profile_started and state == cpu_profile_stop_state:
                        cpu_profile_capture.update({
                            "stopTargetState": cpu_profile_stop_state,
                            "stopObservedState": state,
                            "stateReadRoundTripSeconds": (
                                state_observed_at - state_read_started_at),
                            "pollIntervalSeconds": POLL_SECONDS,
                            "profileMayIncludeWarmWorkUntilStopAck": True,
                            "lastColdStateObservedUtc": (
                                last_cold_state_observation["utc"]
                                if last_cold_state_observation else None),
                            "transitionDetectionWindowSeconds": (
                                state_observed_at - last_cold_state_observation["monotonic"]
                                if last_cold_state_observation else None),
                        })
                        stop_cpu_profile("target-state-observed", state,
                                         state_observed_at)
                    if any(state.startswith(prefix) for prefix in case["terminalPrefixes"]):
                        terminal_reached = True
                        break
                time.sleep(min(POLL_SECONDS, max(0, deadline - time.monotonic())))
            if not terminal_reached:
                timed_out = True
        else:
            # Preserve the last state available after a navigation error without
            # attempting application-side recovery.
            state = read_attribute(case["stateAttribute"])
            if state is not None:
                last_observed_state = state
    finally:
        if cpu_profile_started:
            stop_cpu_profile("case-exit-before-target-state",
                             last_observed_state, time.monotonic())
        # The event lists are owned by this case.  Detach handlers before the
        # receipt is returned so later navigations cannot mutate old results.
        for event, handler in (("pageerror", on_page_error),
                               ("response", on_response),
                               ("console", on_console)):
            try:
                page.remove_listener(event, handler)
            except BaseException as error:
                listener_cleanup_errors.append({"event": event,
                                                "type": type(error).__name__,
                                                "message": str(error)})

    report = None
    report_file = None
    report_json_valid = None
    report_json_error = None
    if case["reportAttribute"] is not None:
        report = read_attribute(case["reportAttribute"])
        if report is not None:
            report_file = save_raw(output, case_slug(case) + ".report.json", report)
            try:
                json.loads(report)
                report_json_valid = True
            except (TypeError, ValueError) as error:
                report_json_valid = False
                report_json_error = str(error)
    if last_observed_state is not None:
        save_raw(output, case_slug(case) + ".state.txt", last_observed_state)

    state_match = terminal_reached and expected_matches(case, last_observed_state)
    report_match = (case["reportAttribute"] is None or
                    (report is not None and report_json_valid is True))
    browser_error = bool(page_errors or http_errors or console_errors or
                         read_errors or listener_cleanup_errors)
    expected_failure_canary = (case["expectedState"] or case["expectedPrefix"]).startswith("FAIL")
    if timed_out:
        outcome = "TIMEOUT"
    elif navigation_error is not None:
        outcome = "FAIL"
    elif state_match and report_match and not browser_error:
        outcome = "PASS"
    else:
        outcome = "FAIL"
    application_outcome = outcome
    cpu_profile_outcome = ("NOT_REQUESTED" if cpu_profile_session is None else
                           ("PASS" if cpu_profile_capture.get("status") == "PASS"
                            else "FAIL"))
    if cpu_profile_session is not None and cpu_profile_outcome == "FAIL" and outcome == "PASS":
        outcome = "FAIL_PROFILE"
    finished = time.monotonic()
    receipt = {
        "schema": SCRIPT_SCHEMA,
        "case": {key: case[key] for key in (
            "index", "name", "path", "stateAttribute", "expectedState",
            "expectedPrefix", "terminalPrefixes", "timeoutSeconds", "reportAttribute")},
        "url": url,
        "startedUtc": started_utc,
        "finishedUtc": utc_now(),
        "operationSeconds": finished - started,
        "outcome": outcome,
        "applicationOutcome": application_outcome,
        "cpuProfileOutcome": cpu_profile_outcome,
        "terminalReached": terminal_reached,
        "stateMatch": state_match,
        "observedState": last_observed_state,
        "lastObservedState": last_observed_state,
        "timedOut": timed_out,
        "expectedFailureCanary": expected_failure_canary,
        "expectedFailureStateWasNotAnUnexpectedError": expected_failure_canary and state_match,
        "reportObserved": report is not None,
        "reportJsonValid": report_json_valid,
        "reportJsonError": report_json_error,
        "reportMatch": report_match,
        "reportLength": len(report) if report is not None else 0,
        "reportSha256": hashlib.sha256(report.encode("utf-8")).hexdigest()
        if report is not None else None,
        "reportFile": str(report_file.relative_to(output)).replace("\\", "/")
        if report_file is not None else None,
        "pageErrors": page_errors,
        "httpErrors": http_errors,
        "consoleErrors": console_errors,
        "attributeReadErrors": read_errors,
        "listenerCleanupErrors": listener_cleanup_errors,
        "navigationError": navigation_error,
        "cpuProfile": cpu_profile_capture,
    }
    save_json(output, case_slug(case) + ".json", receipt)
    return receipt


def validate_output(output, repo):
    if not output.is_absolute():
        raise ValueError("output directory must be an absolute path")
    output = output.resolve()
    temporary = Path(tempfile.gettempdir()).resolve()
    if not is_within(output, temporary):
        raise ValueError("output directory must be below the OS temporary directory")
    if is_within(output, repo):
        raise ValueError("output directory must be outside the repository")
    if output.exists():
        raise ValueError("output directory must not already exist")
    if not output.parent.is_dir():
        raise ValueError("output directory parent must already exist")
    return output


def save_error(result, phase, error):
    result["errors"].append({"phase": phase, "message": str(error),
                             "traceback": traceback.format_exc()})


def _canonical_seed(value, label):
    if not isinstance(value, str) or not re.fullmatch(r"-?(0|[1-9][0-9]*)", value):
        raise ValueError(label + " must be a canonical signed-long decimal string")
    parsed = int(value)
    if parsed < -(2 ** 63) or parsed >= 2 ** 63:
        raise ValueError(label + " is outside the signed-long range")
    return value


def _generated_case(case_kind, request_seed, board_seed, name, timeout,
                    canary):
    board_seed = _canonical_seed(board_seed, "board seed")
    timeout = validate_timeout(timeout, "timeout")
    if case_kind == "q30":
        request_seed = _canonical_seed(request_seed, "Q30 seed")
        path = ("circuitjs.html?tsjChallenge=led&seed=%s&tsjDebug=true&"
                "tsjVerifyQ30=true&tsjQ30Coordinator=true&tsjQ30Seed=%s" %
                (board_seed, request_seed))
        return {
            "name": name or ("q30-" + request_seed),
            "path": path,
            "stateAttribute": "data-tsj-q30-coordinator-state",
            "expectedState": "PASS:complete",
            "reportAttribute": "data-tsj-q30-coordinator-report",
            "timeoutSeconds": timeout,
        }
    if case_kind == "a07":
        if canary == "negative":
            # Navigation is intentionally never reached for the unsupported
            # method canary, but the positive path remains fully specified.
            expected_state = "PASS:a07"
        else:
            expected_state = "PASS:a07"
        path = ("circuitjs.html?tsjChallenge=led&seed=%s&"
                "tsjVerifyA07=true&tsjDebug=true&running=true" % board_seed)
        return {
            "name": name or ("a07-" + canary),
            "path": path,
            "stateAttribute": "data-tsj-verification",
            "expectedState": expected_state,
            "reportAttribute": "data-tsj-a07-report",
            "timeoutSeconds": timeout,
        }
    raise ValueError("case must be q30 or a07")


def _parse_run_options(argv):
    parser = argparse.ArgumentParser(
        description="10 ms CDP CPU profile diagnostic; output is scratch evidence")
    parser.add_argument("legacy", nargs="*",
                        help="legacy REPO OUTPUT SPEC_JSON positional form")
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--spec", type=Path)
    parser.add_argument("--case", choices=("q30", "a07"))
    parser.add_argument("--seed",
                        help="Q30 request seed as a canonical signed-long")
    parser.add_argument("--board-seed",
                        help="board/challenge seed as a canonical signed-long")
    parser.add_argument("--case-name")
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument("--canary", choices=("none", "positive", "negative"),
                        default="none")
    parser.add_argument("--profiler-negative-canary", action="store_true",
                        help=argparse.SUPPRESS)
    parser.add_argument("--profiler-stop-negative-canary", action="store_true",
                        help="send an unsupported method while recording, then issue real stop")
    parser.add_argument("--require-warm-boundary", action="store_true")
    parser.add_argument("--expected-input-sha256")
    parser.add_argument("--expected-source-sha256")
    parser.add_argument("--expected-web-sha256")
    parser.add_argument("--expected-source-file-count", type=int)
    parser.add_argument("--input-map-sha256",
                        help="source-audit/input-map identity recorded for root binding")
    parser.add_argument("--run-label")
    parser.add_argument("--arm", choices=("on", "control", "canary"),
                        help="measurement arm label recorded for pair binding")
    parser.add_argument("--plan-id")
    parser.add_argument("--pair-id")
    parser.add_argument("--control-label")
    parser.add_argument("--source-revision")
    parser.add_argument("--accepted-lu-revision")
    args = parser.parse_args(argv[1:])

    legacy = list(args.legacy)
    if legacy:
        if len(legacy) != 3 or args.repo or args.output or args.spec:
            parser.error("legacy mode requires exactly REPO OUTPUT SPEC_JSON and no duplicate path options")
        repo, output, spec = map(Path, legacy)
    else:
        if not args.repo or not args.output:
            parser.error("--repo and --output are required")
        repo, output = args.repo, args.output
        spec = args.spec

    negative_canary = args.profiler_negative_canary or args.canary == "negative"
    if args.profiler_negative_canary and args.canary not in ("none", "negative"):
        parser.error("--profiler-negative-canary conflicts with --canary positive")
    stop_negative_canary = args.profiler_stop_negative_canary
    if negative_canary and stop_negative_canary:
        parser.error("start and active-stop canaries must run as separate invocations")
    if args.require_warm_boundary and negative_canary:
        parser.error("a start transport canary cannot require an application warm boundary")
    if spec is None:
        case_kind = args.case or ("a07" if args.canary != "none" else None)
        if case_kind is None:
            parser.error("--case is required when --spec is omitted")
        if not args.board_seed:
            parser.error("--board-seed is required for a generated case")
        if case_kind == "q30" and not args.seed:
            parser.error("--seed is required for a generated Q30 case")
        if case_kind == "a07" and args.seed is not None:
            parser.error("--seed is only valid for generated Q30 cases; use --board-seed for A07")
        generated = _generated_case(case_kind, args.seed, args.board_seed,
                                    args.case_name, args.timeout, args.canary)
        raw_spec = (json.dumps({"cases": [generated]}, ensure_ascii=False,
                               indent=2) + "\n").encode("utf-8")
        spec_path = None
    else:
        if args.case or args.seed or args.board_seed or args.case_name:
            parser.error("--case/seed options cannot be combined with --spec")
        spec_path = spec.expanduser().resolve()
        raw_spec = None
    return {
        "repo": repo.expanduser().resolve(),
        "output": output.expanduser(),
        "specPath": spec_path,
        "rawSpec": raw_spec,
        "negativeCanary": negative_canary,
        "stopNegativeCanary": stop_negative_canary,
        "requireWarmBoundary": args.require_warm_boundary,
        "expectedInputSha256": args.expected_input_sha256,
        "expectedSourceSha256": args.expected_source_sha256,
        "expectedWebSha256": args.expected_web_sha256,
        "expectedSourceFileCount": args.expected_source_file_count,
        "inputMapSha256": args.input_map_sha256,
        "runLabel": args.run_label,
        "arm": args.arm,
        "planId": args.plan_id,
        "pairId": args.pair_id,
        "controlLabel": args.control_label,
        "sourceRevision": args.source_revision,
        "acceptedLuRevision": args.accepted_lu_revision,
    }


def _assert_expected_input_identity(manifest, options):
    expected = {
        "sha256": options.get("expectedInputSha256"),
        "sourceSha256": options.get("expectedSourceSha256"),
        "webSha256": options.get("expectedWebSha256"),
        "sourceFileCount": options.get("expectedSourceFileCount"),
    }
    mismatches = []
    for key, value in expected.items():
        if value is not None and manifest.get(key) != value:
            mismatches.append({"field": key, "expected": value,
                               "observed": manifest.get(key)})
    if mismatches:
        raise RuntimeError("input identity mismatch: " +
                           json.dumps(mismatches, sort_keys=True))


def main(argv):
    try:
        options = _parse_run_options(argv)
        repo = options["repo"]
        output = validate_output(options["output"], repo)
        spec_path = options["specPath"]
        if not repo.is_dir() or not (repo / "war" / "circuitjs.html").is_file():
            raise ValueError("repository war/circuitjs.html is missing")
        if spec_path is None:
            spec_path = output.parent / (output.name + ".generated-spec.json")
            raw_spec = options["rawSpec"]
            spec = json.loads(raw_spec.decode("utf-8"))
            cases = [normalise_case(case, index + 1)
                     for index, case in enumerate(spec["cases"])]
        else:
            if not spec_path.is_file():
                raise ValueError("spec JSON path is not a file")
            spec, raw_spec, cases = load_spec(spec_path)
        if len(cases) != 1:
            raise ValueError("CPU profile candidate requires exactly one case")
    except (OSError, ValueError) as error:
        print("ERROR", str(error), file=sys.stderr)
        return 2

    negative_canary = options["negativeCanary"]

    try:
        output.mkdir()
    except OSError as error:
        print("ERROR unable to create unique output directory: " + str(error), file=sys.stderr)
        return 2
    (output / "spec.json").write_bytes(raw_spec)
    result = {"schema": SCRIPT_SCHEMA, "runner": "cpu_profile_10ms.py",
              "repository": str(repo), "startedUtc": utc_now(), "outcome": "NOT_RUN",
              "cases": [], "caseCount": len(cases), "errors": [],
              "diagnosticMetadata": {
                  "runLabel": options.get("runLabel"),
                  "arm": options.get("arm"),
                  "planId": options.get("planId"),
                  "pairId": options.get("pairId"),
                  "controlLabel": options.get("controlLabel"),
                  "inputMapSha256": options.get("inputMapSha256"),
                  "sourceRevision": options.get("sourceRevision"),
                  "acceptedLuRevision": options.get("acceptedLuRevision"),
                  "expectedInputSha256": options.get("expectedInputSha256"),
                  "expectedSourceSha256": options.get("expectedSourceSha256"),
                  "expectedWebSha256": options.get("expectedWebSha256"),
                  "expectedSourceFileCount": options.get("expectedSourceFileCount"),
                  "interpretation": (
                      "External V8 CPU samples and host/application wall timers are "
                      "separate measurements; no allocation or retained-heap claim."),
              }}
    save_json(output, "run-start.json", result)

    server = None
    server_thread = None
    playwright = None
    context = None
    cdp_session = None
    debugger_enabled = False
    debugger_script_events = {}
    owned = []
    input_before = None
    runner_before = None
    base_url = None
    profile = output / "profile"

    try:
        input_before = capture_input_manifest(repo)
        runner_before = capture_script_identity(repo)
        save_json(output, "input-manifest-before.json", input_before)
        save_json(output, "runner-before.json", runner_before)
        result["inputAudit"] = {"status": "BEFORE_CAPTURED",
                                 "beforeSha256": input_before["sha256"],
                                 "sourceSha256": input_before["sourceSha256"],
                                 "webSha256": input_before["webSha256"],
                                 "fileCount": input_before["fileCount"]}
        _assert_expected_input_identity(input_before, options)

        server = ThreadingHTTPServer(("127.0.0.1", 0),
                                     partial(QuietHandler, directory=str(repo / "war")))
        server_thread = Thread(target=server.serve_forever, daemon=True,
                               name="compiled-attribute-http")
        server_thread.start()
        base_url = "http://127.0.0.1:%d" % server.server_port

        if sync_playwright is None:
            raise RuntimeError("Playwright is not installed on this host")
        playwright = sync_playwright().start()
        context = playwright.chromium.launch_persistent_context(
            str(profile), channel="msedge", headless=True,
            viewport={"width": 1440, "height": 1000},
            args=["--disable-background-timer-throttling",
                  "--disable-renderer-backgrounding"])
        rows = process_rows()
        owned = owned_edge_rows(rows)
        owner = next((row for row in rows if int(row.get("pid", -1)) == os.getpid()), None)
        if owner is None:
            raise RuntimeError("runner process identity was not returned")
        identity = {
            "schema": SCRIPT_SCHEMA,
            "runner": {"pid": owner.get("pid"), "created": owner.get("created"),
                        "executable": owner.get("ExecutablePath")},
            "edgeProcessesBeforeCases": owned,
            "profile": str(profile),
            "port": server.server_port,
            "baseUrl": base_url,
        }
        save_json(output, "identity.json", identity)
        save_json(output, "owned-processes-before.json", owned)
        if not owned:
            raise RuntimeError("no Edge descendant was observed before browser gates")
        page = context.pages[0] if context.pages else context.new_page()
        cdp_session = context.new_cdp_session(page)
        def on_script_parsed(event):
            if isinstance(event, dict) and event.get("scriptId") is not None:
                debugger_script_events[str(event["scriptId"])] = event
        cdp_session.on("Debugger.scriptParsed", on_script_parsed)
        cdp_session.send("Debugger.enable")
        debugger_enabled = True
        result["cpuProfileConfig"] = {
            "samplingIntervalMicroseconds": CPU_PROFILE_SAMPLING_INTERVAL_US,
            "caseCount": 1,
            "scope": "page target only; CPU sampling and passive Debugger source-provenance capture are diagnostic and may perturb timing",
            "stopTargetState": "RUNNING:warm",
            "requireWarmBoundary": options["requireWarmBoundary"],
            "negativeCanary": negative_canary,
            "stopNegativeCanary": options["stopNegativeCanary"],
            "pollIntervalSeconds": POLL_SECONDS,
            "stopDispatchTailRecorded": True,
            "attributionBuckets": list(CPU_PROFILE_BUCKETS),
            "wallTimerSeparate": True,
        }
        result["identity"] = identity
        result["operationStartedUtc"] = utc_now()
        for case in cases:
            receipt = run_case(page, base_url, case, output,
                               cpu_profile_session=cdp_session,
                               cpu_profile_repo=repo,
                               cpu_profile_negative_canary=negative_canary,
                               cpu_profile_stop_negative_canary=options["stopNegativeCanary"],
                               cpu_profile_require_warm_boundary=options["requireWarmBoundary"],
                               cpu_profile_script_events=debugger_script_events)
            result["cases"].append(receipt)
            save_json(output, "progress.json", result)
            print(receipt["outcome"], case["name"],
                  round(receipt["operationSeconds"], 3), flush=True)
        all_pass = all(row["outcome"] == "PASS" for row in result["cases"])
        result["outcome"] = (
            "PASS_CANARY" if all_pass and options["stopNegativeCanary"] else
            "PASS" if all_pass else "FAIL")
        if options["stopNegativeCanary"]:
            result["canary"] = {
                "kind": "active-profile-stop-transport",
                "status": "PASS" if all_pass else "FAIL",
                "requiresRealStopAfterUnsupportedMethod": True,
            }
    except ExpectedProfilerStartCanary as error:
        result["outcome"] = "PASS_CANARY"
        result["canary"] = {
            "kind": "unsupported-profiler-start-transport",
            "status": "PASS",
            "requiresCleanup": True,
            "expectedError": str(error),
        }
        result["errors"].append({"phase": "expected-start-canary",
                                 "message": str(error), "expected": True})
        print("EXPECTED_CANARY", str(error), flush=True)
    except BaseException as error:
        result["outcome"] = "FAIL"
        save_error(result, "operation", error)
        print(traceback.format_exc(), file=sys.stderr, flush=True)
    finally:
        audit_started = time.monotonic()
        try:
            input_after = capture_input_manifest(repo)
            runner_after = capture_script_identity(repo)
            save_json(output, "input-manifest-after.json", input_after)
            save_json(output, "runner-after.json", runner_after)
            unchanged = (input_before is not None and
                         input_before["sha256"] == input_after["sha256"] and
                         runner_before is not None and
                         runner_before["sha256"] == runner_after["sha256"])
            result["inputAudit"] = {
                "status": "PASS" if unchanged else "FAIL",
                "beforeSha256": input_before["sha256"] if input_before else None,
                "afterSha256": input_after["sha256"],
                "sourceSha256Before": input_before["sourceSha256"] if input_before else None,
                "sourceSha256After": input_after["sourceSha256"],
                "webSha256Before": input_before["webSha256"] if input_before else None,
                "webSha256After": input_after["webSha256"],
                "runnerBeforeSha256": runner_before["sha256"] if runner_before else None,
                "runnerAfterSha256": runner_after["sha256"],
                "fileCountBefore": input_before["fileCount"] if input_before else None,
                "fileCountAfter": input_after["fileCount"],
                "seconds": time.monotonic() - audit_started,
            }
            if (not unchanged and
                    result["outcome"] in ("PASS", "PASS_CANARY")):
                result["outcome"] = "FAIL_INPUT_MUTATION"
        except BaseException as error:
            result["inputAudit"] = {"status": "FAIL",
                                     "seconds": time.monotonic() - audit_started}
            save_error(result, "input-after", error)
            if result["outcome"] in ("PASS", "PASS_CANARY"):
                result["outcome"] = "FAIL_INPUT_AUDIT"

        cleanup_started = time.monotonic()
        cleanup_errors = []
        try:
            if cdp_session is not None:
                if debugger_enabled:
                    try:
                        cdp_session.send("Debugger.disable")
                    except BaseException as error:
                        cleanup_errors.append({"phase": "debugger-disable",
                                               "message": str(error)})
                try:
                    cdp_session.detach()
                except BaseException as error:
                    cleanup_errors.append({"phase": "cdp-detach", "message": str(error)})
            if context is not None:
                try:
                    rows = process_rows()
                    owned = list({(row.get("pid"), row.get("created")): row
                                  for row in owned + owned_edge_rows(rows)}.values())
                    save_json(output, "owned-processes-before-close.json", owned)
                except BaseException as error:
                    cleanup_errors.append({"phase": "process-snapshot", "message": str(error)})
                try:
                    context.close()
                except BaseException as error:
                    cleanup_errors.append({"phase": "context-close", "message": str(error)})
            if playwright is not None:
                try:
                    playwright.stop()
                except BaseException as error:
                    cleanup_errors.append({"phase": "playwright-stop", "message": str(error)})
        finally:
            if server is not None:
                try:
                    server.shutdown()
                    server.server_close()
                except BaseException as error:
                    cleanup_errors.append({"phase": "server-shutdown", "message": str(error)})
            if server_thread is not None:
                server_thread.join(timeout=5)

        survivors = []
        saved_ids = {(row.get("pid"), row.get("created")) for row in owned}
        for _ in range(20):
            try:
                survivors = [row for row in process_rows()
                             if (row.get("pid"), row.get("created")) in saved_ids]
            except BaseException as error:
                cleanup_errors.append({"phase": "survivor-query", "message": str(error)})
                survivors = [{"error": str(error)}]
            if not survivors:
                break
            time.sleep(0.25)
        server_stopped = server_thread is None or not server_thread.is_alive()
        cleanup_ok = not cleanup_errors and not survivors and server_stopped
        result["cleanup"] = {
            "status": "PASS" if cleanup_ok else "FAIL",
            "seconds": time.monotonic() - cleanup_started,
            "serverStopped": server_stopped,
            "ownedSurvivors": survivors,
            "errors": cleanup_errors,
        }
        if not cleanup_ok:
            result["outcome"] = "FAIL_CLEANUP"
        result["finishedUtc"] = utc_now()
        save_json(output, "result.json", result)
        print("FINISHED", result["outcome"], "cases", len(result["cases"]), flush=True)

    return 0 if result["outcome"] in ("PASS", "PASS_CANARY") else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))


