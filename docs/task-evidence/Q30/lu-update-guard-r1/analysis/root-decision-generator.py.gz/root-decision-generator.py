from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
seqraw=(s/'lu-update-guard-r1-sequence-result.json').read_bytes();d=json.loads(seqraw)
assert d['status']=='STOPPED_INCONCLUSIVE_FIRST_PAIR_RULE' and len(d['rows'])==2 and len(d['pairs'])==1 and len(d['notRun'])==6
a,b=[x['cold'] for x in d['rows']]
result={'status':'INCONCLUSIVE_NO_VALIDATED_RUNTIME_BENEFIT','Q30':'BLOCKED_NOT_ACCEPTED','integrated':False,
 'sequenceSha256':sha(seqraw),'controlColdMs':a['elapsedMs'],'candidateColdMs':b['elapsedMs'],
 'candidateMinusControlMs':{k:b[k]-a[k] for k in ['elapsedMs','proofElapsedMs','routingElapsedMs']},
 'parity':'Full original strict reader,43corruptionsperarm and complete non-timing equality PASS. Owned cleanup PASS.',
 'notRun':d['notRun'],'continuation':'The predeclared first-pair minimum1percent cold AND proof reduction was not met. This is a focused-trial resource rule, not a changed production acceptance threshold.',
 'compiledMechanism':'All5 GWT factors put the existing failure helper behind the same inline two-bound finite predicate; both scaling callsites and all numerical validation remain. Mechanism does not prove savings.',
 'decision':'Retain evidence; do not integrate.82ms cold and25ms proof regressions are noise-scale, not proof of a population regression. Do not run remaining6focusedrows or finalacceptance merely to seek a favorable result.',
 'limits':'Private seed10014 size40 only. Both rows exceed90000ms; no normal/corpus/scale acceptance or mutablegraph/proofcache reuse.'}
out=s/'lu-update-guard-r1-root-decision.json';assert not out.exists();out.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'status':result['status'],'sha256':sha(out.read_bytes()),'delta':result['candidateMinusControlMs']}))
