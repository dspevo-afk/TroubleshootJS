# `requireFiniteStamp` CPU context census

This is a read-only census of the completed
`cpu-10ms-r1-02-profile-10014` run for Q30 seed `10014`.  No host, browser,
build, test, or agent was launched.  The raw profile is 902,402 bytes with
SHA-256
`829e1a8ef12c856761d83a3bbf404f867e98d8b555bb223aaed752e12d1aa142`.  The
exact decoded source payload is
`b10cd75edabbfd0954b3e96eecad14c15c56285454b5725db13318eb630daa5c`, and the
validated symbol-map artifact is
`99a7c9a7e85070aee5dabe44a4621ea489f40c5e259a861d8e8397fdb2e58018`.

## Direct samples and disjoint nearest callers

`com.lushprojects.circuitjs1.client.CirSim::requireFiniteStamp`
(`CirSim.java:3211`) has 192 directly sampled frames totaling 1,963,913 us
(1.963913 s) of paired `timeDeltas`.  Each sample was assigned once to its
nearest proven mapped parent in the raw profile tree:

| Nearest proven mapped parent | Direct samples | Direct self delta |
| --- | ---: | ---: |
| `CirSim::lu_factorAfterInputScan` (`CirSim.java:8075`) | 167 | 1.716487 s |
| `CirSim::$stampMatrix` (`CirSim.java:3188`) | 25 | 0.247426 s |
| `CirSim::$stampRightSide` | 0 | 0 s |
| Other/no proven mapped parent | 0 | 0 s |

The two rows sum exactly to the direct total.  The LU row is nested in
`lu_factorNonlinearOwned` and then `runCircuitOwned`; those enclosing frames are
context and are not extra time.  The 25 `stampMatrix` samples similarly include
the component `doStep` callers above it.  No `stampRightSide` nearest-parent
samples were observed for this callee.

## What the source position does and does not show

The source map proves the callee at line 3211 and the LU parent at line 8075,
but the CPU profile does not preserve the caller instruction or Java call-site
line.  `lu_factorAfterInputScan` has three source call sites for this guard:
the scale-factor check at line 8131, lower-row scaling at line 8138, and the
upper-row inner update at line 8159.  The 1.716487 s LU-context total cannot be
partitioned among those sites from this profile.  In particular, it must not be
called inner-update self time or treated as the amount removable by a one-site
inner-update trial.  `stampMatrix` also calls the guard at lines 3190, 3197,
and 3207, so its 0.247426 s cannot be split between the input, mapped
right-side, and accumulated-matrix checks here either.

Therefore sampled source position does **not** distinguish LU inner-update work
from LU scaling checks in this run.  The separate source-only finite-guard trial
may target the line-8159 inner-update call, but its compile and acceptance gates
have not run and this census supplies no savings claim for the full helper.

The result is a context ranking only: 87.4% of the direct guard samples are
under the LU helper and 12.6% under `stampMatrix`.  It is not wall-time,
allocation, heap, causality, or optimization evidence; the profile interval is
dynamic around the nominal 10 ms setting and profiler overhead is not isolated.
