from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
repo=Path('<REPO_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
for n in ['lu-update-guard-r1-native6.json','lu-update-guard-r1-gwt5.json','lu-update-guard-r1-canaries-summary.json']:
    d=json.loads((s/n).read_bytes());assert d['status']=='PASS' and d['exitCode']==0
assert json.loads((s/'lu-update-guard-r2-compiled-inspection/result.json').read_bytes())['status']=='PASS_COMPILED_GUARD_SHAPE_ONLY'
assert 'three negative corruption canaries' in (s/'lu-update-guard-r1-a07-reader.log').read_text()
canary=json.loads((s/'lu-update-guard-r1-canaries/result.json').read_bytes())
assert canary['outcome']=='PASS' and canary['cleanup']['status']=='PASS'
cpuplan=json.loads((s/'cpu-profile-10ms-r1-measurement-plan.json').read_bytes())
rows=[('control','10014',40),('candidate','10014',40),('candidate','10014',40),('control','10014',40),
      ('candidate','7',37),('control','7',37),('control','10387',20),('candidate','10387',20)]
plan={'schema':1,'status':'PREDECLARED','purpose':'PRIVATE_ONE_SITE_LU_UPDATE_GUARD_TRIAL','productionAcceptance':False,
 'sourceAuditSha256':sha((s/'lu-update-guard-r1-preparation/source-audit.json').read_bytes()),
 'source':{'control':'scratch/pivot-lower-fusion-r2-preparation/candidate','candidate':'lu-update-guard-r1-preparation/candidate'},
 'runtime':{'control':{'sha256':cpuplan['runtimeSha256'],'fileCount':cpuplan['runtimeFiles']},
            'candidate':{'sha256':canary['inputAudit']['beforeSha256'],'fileCount':canary['inputAudit']['fileCountBefore']}},
 'sequence':[{'label':'lu-update-guard-r1-%02d-%s-%s'%(i+1,arm,seed),'arm':arm,'seed':seed,'packages':size} for i,(arm,seed,size) in enumerate(rows)],
 'continuationAfterFirstPair':'Continue only with full parity and at least1percent reductions in both cold total and proof time. Otherwise retain focused evidence as inconclusive/rejected and mark remaining6rows NOT_RUN. This is an experiment resource rule, not an acceptance threshold change.',
 'continuationAfterRepeatedPair':'Both forty-package paired cold/proof gains must remain positive; minimum cold gain must exceed the larger within-arm cold range. Otherwise stop before smaller-scale checks. Passing this rule is bounded repeated-seed evidence only.',
 'requirements':['New owned browser every row; original private cold cache protocol, complete reports/proofs and strict negatives.',
  'No profile query or clocks. All consumed source/build inputs unchanged before and after each row.',
  'Preserve numerical predicates/failure text/arithmetic order/pivots/settling/physical/replay/work/cache/cleanup.',
  'No final matrix until normal cold margin and full scale gates pass. No production acceptance from these private rows.'],
 'interpretation':'One source call-site changes dispatch shape; CPU places1.716487sampled seconds of guard self work underLU but cannot isolate inner updates from scaling. No predicted savings. Fresh matched controls and reverse-order repeat required for attribution.',
 'limits':{'normalMaxJobMillis':90000,'maxJobSteps':640,'maxUnitMillis':5000}}
planpath=s/'lu-update-guard-r1-measurement-plan.json';assert not planpath.exists()
planpath.write_bytes((json.dumps(plan,indent=2)+'\n').encode())
files=['lu-update-guard-r1-measurement-plan.json','lu-update-guard-r1-preparation/source-audit.json','run_timing.py',
 'validate_current_q30_timing_pair.py','lu-update-guard-r1-native6.json','lu-update-guard-r1-gwt5.json',
 'lu-update-guard-r1-canaries/result.json','lu-update-guard-r1-canaries-summary.json','lu-update-guard-r1-a07-reader.log',
 'lu-update-guard-r2-compiled-inspection/result.json','scratch/lu-finite-guard-cpu-context.md']
repo_files=['tests/browser/compiled_attribute_acceptance.py','docs/task-evidence/Q30/scale-plan-4/check_coordinator.py','docs/task-evidence/Q30/scale-plan-4/check_d01.py']
def entries(root,paths):return [{'path':p,'sha256':sha((root/p).read_bytes())} for p in paths]
binding={'status':'FROZEN_READY_FOR_FOCUSED_TRIAL','driverSha256':sha((s/'run_lu_update_guard_r1_sequence_root.py').read_bytes()),
 'files':entries(s,files),'repoFiles':entries(repo,repo_files),'scope':'Private matched cold experiment only, no production acceptance.'}
out=s/'lu-update-guard-r1-execution-binding.json';assert not out.exists();out.write_bytes((json.dumps(binding,indent=2)+'\n').encode())
print(json.dumps({'planSha256':sha(planpath.read_bytes()),'bindingSha256':sha(out.read_bytes()),'driverSha256':binding['driverSha256']}))
