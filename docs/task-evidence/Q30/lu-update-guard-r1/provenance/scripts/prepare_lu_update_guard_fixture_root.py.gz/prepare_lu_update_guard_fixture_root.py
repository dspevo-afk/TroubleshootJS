from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
base=s/'scratch/pivot-lower-fusion-r2-preparation'
auditraw=(base/'source-audit.json').read_bytes()
assert sha(auditraw)=='0d27e176dc46afb4db91316570f4674e52b51ce2b462c64f6b6a37b98cbec197'
records=json.loads(auditraw)['armInputs']['candidate'];assert len(records)==1340
control=base/'candidate'
path='src/com/lushprojects/circuitjs1/client/CirSim.java'
before=(control/path).read_bytes()
raw=(s/'scratch/lu-update-guard-r1-draft/CirSim.java').read_bytes()
assert sha(before)=='c0b9d9bc7ff72d0e5021500c331e40dfcd03974ee3517c39d757d05302b1cfc3'
assert sha(raw)=='5ac82d6eb62c0f32fb7525039ea1a41d91fc198998bf4664f306aeb42e0bdb75'
needle=b'                        double value = row[j] - factor * pivotRow[j];'
prefix,tail=before.split(needle)
old=b'requireFiniteStamp(value);';new=b'if (!SolverExecutionBoundary.finite(value)) requireFiniteStamp(value);'
assert raw==prefix+needle+tail.replace(old,new,1)
prep=s/'lu-update-guard-r1-preparation';assert not prep.exists()
candidate=prep/'candidate';candidate.mkdir(parents=True)
for e in records:
    original=(control/e['path']).read_bytes()
    assert (len(original),sha(original))==(e['bytes'],e['sha256']),e['path']
    to=candidate/e['path'];to.parent.mkdir(parents=True,exist_ok=True)
    to.write_bytes(raw if e['path']==path else original)
inputs=[]
for e in records:
    payload=(candidate/e['path']).read_bytes()
    inputs.append({'path':e['path'],'bytes':len(payload),'sha256':sha(payload)})
changed=[a['path'] for a,b in zip(inputs,records) if a!=b]
assert changed==[path]
receipt={'status':'SOURCE_ONLY_PREPARED_NOT_VALIDATED','baselineAuditSha256':sha(auditraw),
 'candidateSource':str(candidate),'controlSource':str(control),'changedInputs':changed,
 'generatedWarCopied':False,'armInputs':{'control':records,'candidate':inputs}}
(prep/'source-audit.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({'sourceAuditSha256':sha((prep/'source-audit.json').read_bytes()),'candidateInputs':len(inputs),'changedInputs':changed}))
