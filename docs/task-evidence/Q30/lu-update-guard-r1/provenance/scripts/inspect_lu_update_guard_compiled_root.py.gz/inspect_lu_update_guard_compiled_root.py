from pathlib import Path
import csv,hashlib,importlib.util,json,re
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
path=s/'cpu-profile-10ms-r1-draft/cpu_profile_10ms.py'
assert sha(path.read_bytes())=='1197d7f81653361a91f30ae561fc3e928f96446b6d658c6625e317bb3573c43b'
spec=importlib.util.spec_from_file_location('cpu_decoder_only',path)
decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
root=s/'lu-update-guard-r1-preparation/candidate'
out=s/'lu-update-guard-r2-compiled-inspection';assert not out.exists();out.mkdir()
rows=[]
for file in sorted((root/'war/WEB-INF/deploy/circuitjs1/symbolMaps').glob('*.symbolMap')):
    strong=file.stem
    with file.open(encoding='utf8',newline='') as stream:
        symbols=[r for r in csv.DictReader((l for l in stream if not l.startswith('#')),fieldnames=decoder.GWT_SYMBOL_FIELDS)
          if r['className']=='com.lushprojects.circuitjs1.client.CirSim' and r['memberName'] in ['lu_factorAfterInputScan','requireFiniteStamp']]
    names={n:next(x['jsName'] for x in symbols if x['memberName']==n) for n in ['lu_factorAfterInputScan','requireFiniteStamp']}
    assert len(symbols)==2
    evidence,cache,payload=decoder._read_gwt_download_payload(root,strong)
    code=payload.decode();start=code.index('function '+names['lu_factorAfterInputScan']+'(')
    end=code.index('\nfunction ',start);body=code[start:end]
    (out/(strong+'-lu-factor.js')).write_bytes(body.encode())
    # Bind the exact generated statement for root inspection; do not execute JS.
    calls=list(re.finditer(re.escape(names['requireFiniteStamp'])+r'\(',body))
    contexts=[body[max(0,m.start()-100):m.start()+65] for m in calls]
    guard=re.search(r'([A-Za-z_$][\w$]*)>=([A-Za-z_$][\w$]*)&&\1<=([A-Za-z_$][\w$]*)\|\|'+re.escape(names['requireFiniteStamp'])+r'\(\1\);',body)
    assert len(calls)==3 and guard and guard.start()<calls[-1].start()<guard.end()
    constants={name:re.search(r'\b'+re.escape(name)+r'=(-?\d+(?:\.\d+)?E[+-]?\d+)(?=[,;])',code).group(1) for name in guard.group(2,3)}
    assert [float(constants[n]) for n in guard.group(2,3)]==[-1.7976931348623157E308,1.7976931348623157E308]
    rows.append({'strongName':strong,'symbols':names,'bundle':evidence,'symbolMapSha256':sha(file.read_bytes()),
       'factorBodySha256':sha(body.encode()),'callContexts':contexts,'guardStatement':guard.group(),'guardConstants':constants,'hotGuardObserved':True})
assert len(rows)==5
result={'status':'PASS_COMPILED_GUARD_SHAPE_ONLY','rows':rows,
 'interpretation':'Five exact generated factors retain two unconditional scaling guard calls; third update guard has inline two-bound finite predicate before the same failure helper. This is compiled mechanism evidence, not runtime savings.'}
(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result))
