# LU update guard r1: source-only draft

This directory is an isolated, source-only candidate derived byte-for-byte from the accepted lower-index-fusion source. The base `CirSim.java` SHA-256 is `c0b9d9bc7ff72d0e5021500c331e40dfcd03974ee3517c39d757d05302b1cfc3`. The candidate changes exactly one statement at the `lu_factorAfterInputScan` innermost update (source line 8159):

```java
if (!SolverExecutionBoundary.finite(value)) requireFiniteStamp(value);
```

The arithmetic expression, evaluation order, row write, scaling path, pivot logic, and all surrounding loops are unchanged. No other `requireFiniteStamp` call is changed.

The intended mechanism is GWT code shape: finite values take the existing pure `SolverExecutionBoundary.finite` predicate and avoid the hot `requireFiniteStamp` helper call; nonfinite values enter the existing helper, which retains the established `NUMERICAL_FAILURE` type and `Nonfinite CircuitJS matrix stamp` message. The helper repeats the same predicate on that cold failure path. This is a bounded hypothesis, not a claimed speedup. The root must inspect the compiled `gVb` output and stop the trial if the per-update helper call is not removed or inlined.

The prior gzip review artifact is preserved as `exact-diff.pre-root-newline-review.patch.gz` with SHA-256 `0b1ecb736aca686a7f648b503cd8319cade0171ebd0d72aad5e38cedd2b7f852`. `exact-diff.patch.gz` was regenerated with Python `difflib` over `splitlines()` values and LF-only diff output; its new SHA-256 is `208044e4ced416453e0e5d8a09ee13faa3ec3de1c3ded66860a8c6117124a491`. Source bytes were not normalized or changed.

For JVM and GWT, the equivalence obligation is exact. `finite` is the existing pure predicate, so finite values and NaN/positive infinity/negative infinity take the same accept/reject branches as before. The computed `value` is unchanged and is still checked before `row[j]` is written. The trial does not skip validation, reorder arithmetic, alter the later-row `>=` pivot tie, or change `LuFactorizationWorkspace.lowerRows` row aliases, swap reconciliation, compaction, or cleanup. It does not touch scaling checks, `lu_solve`, matrix reuse, settling, budgets, seeds, or the solver contract.

The useful focused native oracle already exists: `LuFactorizationChecks` compares against independent `originalFactor`/`originalSolve`. The root should reuse its late-swap, tied-pivot, underflow-zero, nonfinite/overflow, and workspace-reuse/cleanup cases without adding implementation-mirroring assertions. No oracle, build, GWT compile, host, browser, test, or profile was run for this draft.
