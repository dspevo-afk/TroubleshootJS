from __future__ import print_function

import argparse
import difflib
import hashlib
import json
import os
import shutil
import sys

BASE_ROUTER_SHA256 = "c728dd8a1e2c164e366019db76050c4ec32281b7112f0e71f38769710c77e1d9"
ROUTER_REL = os.path.join("src", "com", "lushprojects", "circuitjs1", "client", "PcbNetRouter.java")
TEST_REL = os.path.join("tests", "contracts", "PcbNetRouterDistanceFieldContractTest.java")

REPLACEMENT = """        private int[] distanceField(boolean[] goals) {
            return manhattanDistanceField(gridWidth, gridHeight, goals);
        }

        private static int[] manhattanDistanceField(int width, int height, boolean[] goals) {
            long cellCount = (long) width * (long) height;
            if (width < 1 || height < 1 || cellCount > PcbRoutingWork.MAX_GRID_CELLS)
                throw new Rejected(Reason.GRID_LIMIT, "ROUTING_GRID_BUDGET", null);
            int cells = (int) cellCount;
            if (goals == null || goals.length != cells)
                throw new IllegalArgumentException("Invalid routing goal field");

            int[] distance = new int[cells];
            boolean hasGoal = false;
            for (int key = 0; key < cells; key++) {
                if (goals[key]) {
                    distance[key] = 0;
                    hasGoal = true;
                } else {
                    distance[key] = Integer.MAX_VALUE;
                }
            }
            if (!hasGoal) throw new Rejected("ORPHAN_TREE");

            // Forward row-major relaxation propagates goals from west and north.
            for (int y = 0; y < height; y++) {
                int row = y * width;
                for (int x = 0; x < width; x++) {
                    int key = row + x;
                    int best = distance[key];
                    if (x > 0) {
                        int west = distance[key - 1];
                        if (west != Integer.MAX_VALUE && west + 1 < best) best = west + 1;
                    }
                    if (y > 0) {
                        int north = distance[key - width];
                        if (north != Integer.MAX_VALUE && north + 1 < best) best = north + 1;
                    }
                    distance[key] = best;
                }
            }

            // Reverse row-major relaxation propagates goals from east and south.
            for (int y = height - 1; y >= 0; y--) {
                int row = y * width;
                for (int x = width - 1; x >= 0; x--) {
                    int key = row + x;
                    int best = distance[key];
                    if (x + 1 < width) {
                        int east = distance[key + 1];
                        if (east != Integer.MAX_VALUE && east + 1 < best) best = east + 1;
                    }
                    if (y + 1 < height) {
                        int south = distance[key + width];
                        if (south != Integer.MAX_VALUE && south + 1 < best) best = south + 1;
                    }
                    distance[key] = best;
                }
            }
            return distance;
        }

"""

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def lf_text(data):
    return data.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")

def write(path, data):
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "wb") as stream:
        stream.write(data)

def patch_file(rel, old, new, is_new=False):
    a_name = "/dev/null" if is_new else "a/" + rel.replace(os.sep, "/")
    b_name = "b/" + rel.replace(os.sep, "/")
    before = [] if is_new else lf_text(old).splitlines(True)
    after = lf_text(new).splitlines(True)
    return list(difflib.unified_diff(before, after, fromfile=a_name, tofile=b_name, n=3))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=os.path.dirname(os.path.abspath(__file__)))
    args = parser.parse_args()
    root = os.path.abspath(args.root)
    baseline = os.path.join(root, "baseline", ROUTER_REL)
    candidate = os.path.join(root, "candidate", ROUTER_REL)
    test_template = os.path.join(root, "templates", os.path.basename(TEST_REL))
    candidate_test = os.path.join(root, "candidate", TEST_REL)

    with open(baseline, "rb") as stream:
        original = stream.read()
    if sha256(original) != BASE_ROUTER_SHA256:
        raise SystemExit("Frozen baseline SHA256 mismatch: " + sha256(original))
    with open(test_template, "rb") as stream:
        test_bytes = stream.read()

    nl = b"\r\n" if b"\r\n" in original else b"\n"
    if nl == b"\r\n" and original.replace(b"\r\n", b"").find(b"\n") >= 0:
        raise SystemExit("Mixed line endings in frozen baseline")
    start_marker = b"        private int[] distanceField(boolean[] goals) {"
    end_marker = b"        private boolean isLegalMove("
    start = original.find(start_marker)
    end = original.find(end_marker, start + len(start_marker))
    if start < 0 or end < 0:
        raise SystemExit("Could not locate the frozen distanceField method boundaries")
    old_block = original[start:end]
    replacement = REPLACEMENT.replace("\n", nl.decode("ascii")).encode("utf-8")
    updated = original[:start] + replacement + original[end:]
    if updated.count(start_marker) != 1:
        raise SystemExit("Expected exactly one distanceField wrapper after replacement")

    write(candidate, updated)
    write(candidate_test, test_bytes)

    router_rel = ROUTER_REL.replace(os.sep, "/")
    test_rel = TEST_REL.replace(os.sep, "/")
    diff = []
    diff.extend(["diff --git a/" + router_rel + " b/" + router_rel + "\n"])
    diff.extend(patch_file(router_rel, original, updated))
    diff.extend(["diff --git a/" + test_rel + " b/" + test_rel + "\n"])
    diff.extend(patch_file(test_rel, b"", test_bytes, True))
    patch_bytes = "".join(diff).encode("utf-8")
    patch_path = os.path.join(root, "route-distance-transform.patch")
    write(patch_path, patch_bytes)

    manifest = {
        "scope": "isolated source prototype only; no build or gate executed",
        "baselineRouterSha256": sha256(original),
        "candidateRouterSha256": sha256(updated),
        "testTemplateSha256": sha256(test_bytes),
        "candidateTestSha256": sha256(test_bytes),
        "patchSha256": sha256(patch_bytes),
        "routerLineEndingsPreserved": nl == b"\r\n" and b"\r\n" in updated,
        "changedProductionPaths": [router_rel],
        "addedContractPaths": [test_rel],
        "methodReplacement": {
            "startMarker": start_marker.decode("ascii"),
            "endMarker": end_marker.decode("ascii"),
            "oldBlockSha256": sha256(old_block),
            "newBlockSha256": sha256(replacement)
        },
        "algorithm": "two full grid passes; west/north forward, east/south reverse; goal cells initialized to zero"
    }
    write(os.path.join(root, "source-manifest.json"),
          (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8"))
    inventory_entries = []
    inventory_name = "sha256-manifest.json"
    for directory, subdirs, files in os.walk(root):
        subdirs.sort()
        for filename in sorted(files):
            full_path = os.path.join(directory, filename)
            relative = os.path.relpath(full_path, root).replace(os.sep, "/")
            if relative == inventory_name:
                continue
            with open(full_path, "rb") as stream:
                stored = stream.read()
            inventory_entries.append({
                "path": relative,
                "bytes": len(stored),
                "sha256": sha256(stored)
            })
    inventory = {
        "scope": "all stored files below this draft directory except this inventory",
        "entries": inventory_entries
    }
    write(os.path.join(root, inventory_name),
          (json.dumps(inventory, indent=2, sort_keys=True) + "\n").encode("utf-8"))
    print(json.dumps(manifest, sort_keys=True))

if __name__ == "__main__":
    main()