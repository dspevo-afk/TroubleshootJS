from pathlib import Path
import hashlib,json,subprocess,sys,time
s=Path(__file__).resolve().parent
repo=Path('<PRIVATE_USER>/.codex/worktrees/q30-multirail-qualification/TroubleshootJS')
sha=lambda b:hashlib.sha256(b).hexdigest()
prep=Path((s/'route-distance-transform-source-pair-path.txt').read_text().strip())
audit_raw=(prep/'source-audit.json').read_bytes();assert sha(audit_raw)=='4193d7f6a304320c3db90798cf8a77178054d407e8629678808875e3f6720702';audit=json.loads(audit_raw)
plan_raw=(s/'route-transform-measurement-plan.json').read_bytes();assert sha(plan_raw)=='3c5a98af36925d9002fb81c57a08b09dec731e634c195af0136e60b7a04654da';plan=json.loads(plan_raw)
gate_raw=(s/'route-transform-r1-gates.json').read_bytes();gate=json.loads(gate_raw)
assert gate['status']=='FOCUSED_GATES_PASS_NOT_ACCEPTANCE' and gate['sourceAuditSha256']==sha(audit_raw) and gate['planSha256']==sha(plan_raw)
assert gate['controlEvidenceReuse']['status']=='PASS' and len(gate['steps'])==4 and all(r['exitCode']==0 for r in gate['steps'])
assert sha(gate_raw)=='725fc173a2819ed510e9329d591bbae7be1bd6ca9999705201b168993c3619b2'
assert sha((s/'route-transform-r1-canaries/result.json').read_bytes())=='1f99ce52a942e2105c54623106cbd78c684b6f3ac61852b3c6105491b355ac32'
EXPECTED_RUNTIME_INPUTS={'control': {'beforeSha256': '53f869e8164f6b8edc3b75ba1e6a299a984de5c88829b60b04a9ca59e76787a9', 'sourceSha256Before': 'cb257f2158d02ece1fb0a3f7ac7386ec9a14e43100be1ad337d2e344aae0828e', 'webSha256Before': 'e7377863185fc8208cb356474b39d14c9a82a35f5470bd7824d68113e1c03961', 'runnerBeforeSha256': '1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4', 'fileCountBefore': 1525}, 'candidate': {'beforeSha256': 'b305135c9817a8f0d6c9adc4fe0d74a60a330878090f76a01071eee4c406865e', 'sourceSha256Before': 'c331f4469be0298422ac288a0798cc5eef80a13f3851a2069d67b52ecf29fcae', 'webSha256Before': '2facacabeb80d506ebca846f2799318babb760a46c7ac7fdeac3c4348b22739e', 'runnerBeforeSha256': '1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4', 'fileCountBefore': 1525}}
assert sha((s/'scratch/route-distance-transform-independent-review.md').read_bytes())=='98473270eb9c2edf03c70561f514da00b78bd1dab90909f3804301cb466b1f5c'
assert sha((s/'run_timing.py').read_bytes())=='a7ef67c63397a28c1781b40746507fc0fa129f030742b8c6201350f099a9765f'
assert sha((s/'validate_current_q30_timing_pair.py').read_bytes())=='67430d7c56d872d115a7c38732bf60101cff52e8bf40f7af075213debc8e7e3b'
hostpath=repo/'tests/browser/compiled_attribute_acceptance.py'
assert sha(hostpath.read_bytes())=='1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4'
sequence=plan['sequence'];assert len(sequence)==8
result={'status':'RUNNING','planSha256':sha(plan_raw),'sourceAuditSha256':sha(audit_raw),'gateSha256':sha(gate_raw),'driverSha256':sha(Path(__file__).read_bytes()),'rows':[],'pairs':[],'notRun':[r['label'] for r in sequence]}
out=s/'route-transform-sequence-result.json';assert not out.exists()
identities={}
def save():out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def unchanged():
 for arm in ('control','candidate'):
  source=Path(audit[arm+'Source'])
  for e in audit['armInputs'][arm]:
   b=(source/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],(arm,e['path'])
 assert sha(hostpath.read_bytes())=='1bb267655c97e35f2869925ae91d92a56c708256305e4bfb10106a172d2748a4'
def hostcheck(row,summary):
 folder=s/row['label'];host=json.loads((folder/'result.json').read_bytes())
 assert host['outcome']=='PASS' and host['errors']==[] and host['inputAudit']['status']=='PASS'
 cleanup=host['cleanup'];assert cleanup['status']=='PASS' and cleanup['serverStopped'] and not cleanup['errors'] and not cleanup['ownedSurvivors']
 assert len(host['cases'])==1
 case=host['cases'][0]
 assert case['outcome']=='PASS' and case['terminalReached'] and case['stateMatch'] and case['reportMatch'] and case['reportJsonValid'] and not case['timedOut'] and not case['navigationError']
 for key in ('pageErrors','httpErrors','consoleErrors','attributeReadErrors','listenerCleanupErrors'):assert case[key]==[]
 raw=(folder/case['reportFile']).read_bytes();assert sha(raw)==case['reportSha256']
 d=json.loads(raw);assert d['seed']==row['seed'] and d['requestedSeed']==row['seed']
 for phase in ('cold','warm'):
  assert summary[phase]['cleanupComplete'] and summary[phase]['profileKeys']==[]
 identity={key:host['inputAudit'][key] for key in ('beforeSha256','sourceSha256Before','webSha256Before','runnerBeforeSha256','fileCountBefore')}
 assert identity==EXPECTED_RUNTIME_INPUTS[row['arm']], 'timing row differs from its accepted/tested compiled runtime'
 if row['arm'] in identities:assert identity==identities[row['arm']]
 else:identities[row['arm']]=identity
 return {'inputIdentity':identity,'reportSha256':sha(raw),'cleanup':cleanup}
save()
try:
 for index,row in enumerate(sequence):
  unchanged();label=row['label']
  assert not (s/label).exists() and not (s/(label+'-summary.json')).exists() and not (s/(label+'-spec.json')).exists()
  print('START '+label,flush=True)
  p=subprocess.run([sys.executable,'-B',str(s/'run_timing.py'),str(repo),str(s),audit[row['arm']+'Source'],label,row['seed']],capture_output=True,text=True)
  assert p.returncode==0,p.stdout+p.stderr
  summary=json.loads((s/(label+'-summary.json')).read_bytes());assert summary['exitCode']==0
  details=hostcheck(row,summary);unchanged()
  record={**row,'summary':summary,**details};result['rows'].append(record);result['notRun'].remove(label);save()
  print(json.dumps({'label':label,'cold':summary['cold'],'hostSeconds':summary['hostMonotonicSeconds'],'cleanupSeconds':details['cleanup']['seconds']}),flush=True)
  if index%2==1:
   a,b=result['rows'][-2:];assert a['seed']==b['seed'];tag='route-transform-pair-'+str(index//2+1)
   command=[sys.executable,'-B',str(s/'validate_current_q30_timing_pair.py'),str(s),str(repo),a['label'],b['label'],row['seed'],'--tag',tag]
   began=time.monotonic();v=subprocess.run(command,capture_output=True,text=True)
   (s/(tag+'-validation.log')).write_text(v.stdout+v.stderr,encoding='utf-8')
   assert v.returncode==0,v.stderr
   validation=json.loads(v.stdout);assert validation['status']=='PASS'
   result['pairs'].append({'seed':row['seed'],'labels':[a['label'],b['label']],'status':'PASS','validatorElapsedSeconds':time.monotonic()-began,'validationSha256':sha(v.stdout.encode('utf-8'))});save()
   if index==1:
    cold={r['arm']:r['summary']['cold'] for r in result['rows']}
    total_ratio=cold['candidate']['elapsedMs']/cold['control']['elapsedMs']
    route_ratio=cold['candidate']['routingElapsedMs']/cold['control']['routingElapsedMs']
    if total_ratio>=1.02 or route_ratio>=0.98:
     result['status']='REJECTED_FIRST_PAIR_COLD_REGRESSION' if total_ratio>=1.02 else 'INCONCLUSIVE_FIRST_PAIR_ROUTING_GAIN_BELOW_TWO_PERCENT'
     result['earlyStopColdRatio']=total_ratio;result['earlyStopRoutingRatio']=route_ratio;save();print(result['status'],flush=True);sys.exit(0)

 result['status']='FOCUSED_PAIRS_PASS_PENDING_ROOT_ACCEPTANCE';save();print(result['status'],flush=True)
except BaseException as error:
 if isinstance(error,SystemExit) and error.code==0:raise
 result['status']='STOPPED_FAILURE';result['failure']=str(error);save();raise
