package com.lushprojects.circuitjs1.client;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

/** Exact parity contract for the routing distance-field transform prototype. */
public final class PcbNetRouterDistanceFieldContractTest {
    private static int assertions;
    private static final Method TRANSFORM = findTransform();

    private static void require(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }

    private static Method findTransform() {
        try {
            Method method = PcbNetRouter.Router.class.getDeclaredMethod(
                "manhattanDistanceField", int.class, int.class, boolean[].class);
            method.setAccessible(true);
            return method;
        } catch (Exception error) {
            throw new AssertionError("distance transform seam is present", error);
        }
    }

    private static int[] transform(int width, int height, boolean[] goals) throws Exception {
        try {
            return (int[]) TRANSFORM.invoke(null, Integer.valueOf(width), Integer.valueOf(height), goals);
        } catch (InvocationTargetException error) {
            Throwable cause = error.getCause();
            if (cause instanceof Exception) throw (Exception) cause;
            if (cause instanceof Error) throw (Error) cause;
            throw error;
        }
    }

    private static void verify(int width, int height, boolean[] goals, String label) throws Exception {
        boolean[] original = goals.clone();
        int[] actual = transform(width, height, goals);
        int[] expected = queueBfs(width, height, goals);
        require(Arrays.equals(expected, actual), label + " equals independent queue-BFS distances");
        require(Arrays.equals(original, goals), label + " leaves goal mask unchanged");
    }

    // Kept as an independent test oracle: multi-source queue relaxation, not a
    // scan-order transform or a call into production code.
    private static int[] queueBfs(int width, int height, boolean[] goals) {
        int[] distance = new int[goals.length];
        int[] queue = new int[goals.length];
        int head = 0;
        int tail = 0;
        for (int key = 0; key < goals.length; key++) {
            distance[key] = Integer.MAX_VALUE;
            if (goals[key]) {
                distance[key] = 0;
                queue[tail++] = key;
            }
        }
        if (tail == 0) throw new AssertionError("oracle requires at least one goal");
        while (head < tail) {
            int key = queue[head++];
            int x = key % width;
            int y = key / width;
            if (x > 0) tail = relax(key - 1, key, distance, queue, tail);
            if (x + 1 < width) tail = relax(key + 1, key, distance, queue, tail);
            if (y > 0) tail = relax(key - width, key, distance, queue, tail);
            if (y + 1 < height) tail = relax(key + width, key, distance, queue, tail);
        }
        return distance;
    }

    private static int relax(int next, int from, int[] distance, int[] queue, int tail) {
        if (distance[next] == Integer.MAX_VALUE) {
            distance[next] = distance[from] + 1;
            queue[tail++] = next;
        }
        return tail;
    }

    private static void smallAndDegenerateRectangles() throws Exception {
        int[][] shapes = new int[][] {
            {1, 1}, {1, 17}, {19, 1}, {2, 2}, {2, 11}, {11, 2},
            {3, 8}, {8, 3}, {13, 9}
        };
        for (int s = 0; s < shapes.length; s++) {
            int width = shapes[s][0];
            int height = shapes[s][1];
            int cells = width * height;
            for (int goal = 0; goal < cells; goal++) {
                boolean[] mask = new boolean[cells];
                mask[goal] = true;
                verify(width, height, mask, "single goal " + width + "x" + height + "@" + goal);
            }

            boolean[] all = new boolean[cells];
            Arrays.fill(all, true);
            verify(width, height, all, "all goals " + width + "x" + height);
        }
    }

    private static void arbitraryGoalMasks() throws Exception {
        int[][] shapes = new int[][] {{4, 7}, {9, 5}, {16, 12}};
        long state = 0x6d2b79f5L;
        for (int s = 0; s < shapes.length; s++) {
            int width = shapes[s][0];
            int height = shapes[s][1];
            int cells = width * height;
            for (int sample = 0; sample < 32; sample++) {
                boolean[] mask = new boolean[cells];
                for (int i = 0; i < cells; i++) {
                    state = state * 6364136223846793005L + 1442695040888963407L;
                    mask[i] = (state >>> 61) == 0;
                }
                mask[(sample * 17) % cells] = true;
                verify(width, height, mask, "deterministic arbitrary mask " + width + "x" + height + "#" + sample);
            }
        }
    }

    private static void maximumPracticalDimensions() throws Exception {
        int width = 1000;
        int height = 700;
        boolean[] goals = new boolean[width * height];
        goals[0] = true;
        goals[width - 1] = true;
        goals[(height / 2) * width + width / 2] = true;
        goals[goals.length - 1] = true;
        verify(width, height, goals, "maximum accepted 700000-cell rectangle");

        int[] longFieldGoals = new int[] {0, 349999, 699999};
        boolean[] line = new boolean[700000];
        for (int i = 0; i < longFieldGoals.length; i++) line[longFieldGoals[i]] = true;
        verify(1, line.length, line, "maximum one-column degenerate rectangle");
    }

    private static void typedNoGoalAndInvalidInputs() throws Exception {
        try {
            transform(4, 3, new boolean[12]);
            throw new AssertionError("empty goal mask is rejected");
        } catch (PcbNetRouter.Rejected rejected) {
            require(rejected.reason == PcbNetRouter.Reason.NO_PATH, "empty goal keeps typed no-path reason");
            require("ORPHAN_TREE".equals(rejected.getMessage()), "empty goal keeps orphan diagnostic");
        }
        expectGridLimit(0, 1, new boolean[0]);
        expectGridLimit(1000, 701, new boolean[700001]);
        try {
            transform(3, 2, new boolean[5]);
            throw new AssertionError("wrong-sized mask is rejected");
        } catch (IllegalArgumentException expected) {
            require(expected.getMessage() != null, "wrong-sized mask has a clear argument rejection");
        }
        try {
            transform(1, 1, null);
            throw new AssertionError("null mask is rejected");
        } catch (IllegalArgumentException expected) {
            require(expected.getMessage() != null, "null mask has a clear argument rejection");
        }
    }

    private static void expectGridLimit(int width, int height, boolean[] goals) throws Exception {
        try {
            transform(width, height, goals);
            throw new AssertionError("invalid grid dimensions are rejected");
        } catch (PcbNetRouter.Rejected rejected) {
            require(rejected.reason == PcbNetRouter.Reason.GRID_LIMIT, "invalid grid retains typed grid rejection");
            require("ROUTING_GRID_BUDGET".equals(rejected.getMessage()), "invalid grid retains budget diagnostic");
        }
    }

    private static void wrapperPreservesObserverAndWorkSemantics() throws Exception {
        final int[] observerChecks = new int[1];
        Rectangle outline = new Rectangle(0, 0, 140, 100);
        PcbNetRouter.Router router = new PcbNetRouter.Router(
            new PcbBoardLayout(400, 300, outline, new Rectangle(180, 20, 150, 200)),
            new TroubleshootBoard("distance-field-contract"), outline, 0,
            new SeededPcbLayoutGenerator.AttemptObserver() {
                public void check(int attempt) { observerChecks[0]++; }
            });
        PcbRoutingWork.Statistics before = router.work.snapshot();
        Method wrapper = PcbNetRouter.Router.class.getDeclaredMethod("distanceField", boolean[].class);
        wrapper.setAccessible(true);
        boolean[] goals = new boolean[13 * 9];
        goals[0] = true;
        wrapper.invoke(router, (Object) goals);
        PcbRoutingWork.Statistics after = router.work.snapshot();
        require(observerChecks[0] == 0, "distance-field preparation adds no cancellation polling");
        require(before.toCanonical().equals(after.toCanonical()), "distance-field preparation adds no routing work units");
    }

    public static void main(String[] args) throws Exception {
        smallAndDegenerateRectangles();
        arbitraryGoalMasks();
        maximumPracticalDimensions();
        typedNoGoalAndInvalidInputs();
        wrapperPreservesObserverAndWorkSemantics();
        System.out.println("PASS: PcbNetRouterDistanceFieldContractTest assertions=" + assertions);
    }
}
