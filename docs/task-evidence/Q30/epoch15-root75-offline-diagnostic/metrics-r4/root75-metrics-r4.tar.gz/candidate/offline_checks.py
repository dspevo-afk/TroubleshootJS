"""Synthetic offline contracts for the root75 metrics-only diagnostic.

Fixtures exercise the Python owners without launching a browser, native process,
application case, or CPU sampler. All generated reports are synthetic.
"""
import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest
from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch

import instrumented_host
import renderer_capture
import run_one_diagnostic as launcher


HERE = Path(__file__).resolve().parent
HOST_PATH = HERE / "headful_attribute_host.py"
FIXTURE_ROOT = Path(tempfile.mkdtemp(prefix="q30-root75-metrics-offline-"))
ROOT = FIXTURE_ROOT  # Kept for the unchanged bounded verifier's receipt destination.
URL = "http://127.0.0.1:12345/" + launcher.PATH
STATE = "SCREEN_DONE:synthetic-fixture"
ATTRIBUTE = "data-tsj-q30-normal-state"
REPORT_ATTRIBUTE = "data-tsj-q30-normal-report"


def metric_response(timestamp=100.0, thread=2.0, script_duration=None):
    if script_duration is None:
        script_duration = thread / 3
    return {"metrics": [
        {"name": "Timestamp", "value": timestamp},
        {"name": "ThreadTime", "value": thread},
        {"name": "TaskDuration", "value": thread / 2},
        {"name": "ScriptDuration", "value": script_duration},
    ]}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def owned_dir(test_case, label):
    path = FIXTURE_ROOT / (test_case._testMethodName + "-" + label)
    path.mkdir(parents=True, exist_ok=False)
    return path


def assert_metrics_only(test_case, session):
    methods = [method for method, _ in session.calls]
    test_case.assertFalse(any(name.startswith(("Tracing.", "IO.")) for name in methods), methods)
    test_case.assertEqual(session.listeners, {})


class MetricsSession:
    """Synthetic subset of the CDP session API consumed by this candidate."""

    def __init__(self, fault=None, observer=None):
        self.fault = fault
        self.observer = observer
        self.calls = []
        self.listeners = {}
        self.metric_reads = 0
        self.target_reads = 0
        self.frame_tree_reads = 0
        self.frame_id = "frame" if observer is not None else "fixed"
        self.loader_id = "loader"
        self.target_id = "wrong-frame" if fault == "target-frame" else self.frame_id
        self.target_url = "elsewhere" if fault == "target-url" else URL
        self.browser_context_id = "context"
        self.page = getattr(observer, "page", None)

    async def send(self, method, params):
        self.calls.append((method, params))
        if method == "Browser.getVersion":
            return {"protocolVersion": "fixture", "product": "fixture", "jsVersion": "fixture"}
        if method == "Target.getTargetInfo":
            self.target_reads += 1
            target_id, context_id = self.target_id, self.browser_context_id
            if self.fault == "target-after-change" and self.target_reads > 1:
                target_id = "successor-frame"
            if self.fault == "context-after-change" and self.target_reads > 1:
                context_id = "successor-context"
            return {"targetInfo": {"targetId": target_id, "type": "page",
                                   "url": self.target_url, "browserContextId": context_id}}
        if method == "Performance.enable":
            if params != {"timeDomain": "threadTicks"}:
                raise AssertionError("capture must request the threadTicks time domain")
            if self.fault == "enable-error":
                raise RuntimeError("synthetic threadTicks enable failure")
            return {}
        if method == "Performance.getMetrics":
            self.metric_reads += 1
            if self.fault == "route-frame-change" and self.metric_reads == 1:
                self.frame_id = "successor-frame"
            elif self.fault == "route-loader-change" and self.metric_reads == 1:
                self.loader_id = "successor-loader"
            elif self.fault == "route-generation-change" and self.metric_reads == 1:
                self.observer.navigation_epoch += 1
            elif self.fault == "route-url-change" and self.metric_reads == 1:
                self.page.url = URL + "#successor"
            elif self.fault == "final-scope-loader-change" and self.metric_reads == 2:
                self.loader_id = "successor-loader"
            if self.fault == "baseline-timeout" and self.metric_reads == 1:
                await asyncio.sleep(.40)
            if self.fault == "final-timeout" and self.metric_reads == 2:
                await asyncio.sleep(.40)
            if self.fault == "baseline-malformed" and self.metric_reads == 1:
                return {"metrics": []}
            if self.fault == "final-malformed" and self.metric_reads == 2:
                return {"metrics": [{"name": "Timestamp", "value": 101.0}]}
            if self.fault == "final-regression" and self.metric_reads == 2:
                return metric_response(101.0, 1.0)
            if self.fault == "extreme-duration-delta":
                return (metric_response(100.0, 2.0, -1e308) if self.metric_reads == 1 else
                        metric_response(101.0, 2.25, 1e308))
            return metric_response(100.0, 2.0) if self.metric_reads == 1 else metric_response(101.0, 2.25)
        if method == "Page.getFrameTree":
            self.frame_tree_reads += 1
            if self.fault == "boundary-loader-change" and self.frame_tree_reads == 3:
                self.loader_id = "successor-loader"
            return {"frameTree": {"frame": {"id": self.frame_id, "loaderId": self.loader_id,
                                             "url": URL}}}
        if method == "DOM.getDocument":
            return {"root": {"nodeId": 2, "backendNodeId": 2, "documentURL": URL,
                "children": [{"nodeName": "HTML", "nodeId": 4, "backendNodeId": 4,
                    "attributes": [ATTRIBUTE, STATE]}]}}
        if method == "Performance.disable":
            if self.fault == "disable-error":
                raise RuntimeError("synthetic disable cleanup failure")
            return {}
        raise AssertionError("unexpected synthetic CDP method: " + method)

    async def detach(self):
        self.calls.append(("detach", {}))


class RecycledFrontendSession(MetricsSession):
    """Synthetic CDP session whose frontend IDs change while backend scope stays fixed."""

    def __init__(self, page=None, *, observer=None, fault=None, report=None):
        super().__init__(fault, observer)
        self.page = page or getattr(observer, "page", None)
        self.frame_id = self.target_id = "frame"
        self.target_url = URL
        self.listeners = {}
        self.document_reads = 0
        self.last_document_id = self.last_html_id = None
        self.report = report

    def on(self, event, handler):
        self.listeners.setdefault(event, []).append(handler)

    def remove_listener(self, event, handler):
        handlers = self.listeners.get(event, [])
        if handler in handlers:
            handlers.remove(handler)
        if not handlers:
            self.listeners.pop(event, None)

    def emit(self, event, value):
        for handler in tuple(self.listeners.get(event, ())):
            handler(value)

    async def send(self, method, params=None):
        params = params or {}
        if method in ("Page.enable", "DOM.enable"):
            self.calls.append((method, params))
            return {}
        if method == "Page.getFrameTree":
            result = await super().send(method, params)
            frame = result["frameTree"]["frame"]
            if self.fault == "frame":
                frame["id"] = "successor-frame"
            elif self.fault == "loader":
                frame["loaderId"] = "successor-loader"
            return result
        if method == "DOM.getDocument":
            self.calls.append((method, params))
            self.document_reads += 1
            document_id = 2 + 10 * self.document_reads
            html_id = document_id + 2
            self.last_document_id, self.last_html_id = document_id, html_id
            document_backend, html_backend = ((20, 40) if self.fault == "backend" else (2, 4))
            if self.page is not None and self.page.navigated and self.document_reads == 3:
                state = "PREPARED:synthetic"
            elif self.page is not None:
                state = self.page.attributes.get(ATTRIBUTE, "ATTACHED:synthetic")
            else:
                state = "PREPARED:synthetic"
            attributes = [ATTRIBUTE, state]
            report = self.page.attributes.get(REPORT_ATTRIBUTE) if self.page is not None else None
            if report is not None:
                attributes.extend((REPORT_ATTRIBUTE, report))
            children = [] if self.fault == "missing-html" else [{
                "nodeName": "HTML", "nodeId": html_id, "backendNodeId": html_backend,
                "attributes": attributes}]
            return {"root": {"nodeName": "#document", "nodeId": document_id,
                "backendNodeId": document_backend, "documentURL": self.target_url,
                "children": children}}
        result = await super().send(method, params)
        if method == "Performance.getMetrics" and self.metric_reads == 1 and self.observer is not None:
            if self.fault == "version":
                self.emit("DOM.documentUpdated", {})
            elif self.fault == "session":
                self.emit("close", {})
            elif self.fault == "navigation":
                self.observer.navigation_epoch += 1
            elif self.fault == "attachment":
                self.observer.script_attachment["generation"] += 1
        return result


class SyntheticRoute:
    def __init__(self, page, *, publish_events=False):
        self.page = page
        self.publish_events = publish_events
        self.actions = []
        self.request = types.SimpleNamespace(frame=page.main_frame, resource_type="script")
        observer = getattr(page, "observer", None)
        self.old_html_id = getattr(observer, "html_id", None)
        self.refreshed_html_id = None
        self.count_after_stale = self.count_after_fresh = None
        self.cached_state_after_binding = None
        self.report_present_at_route_entry = None
        self.report_after_terminal = None

    async def continue_(self):
        self.actions.append("continue")
        if not self.publish_events:
            return
        observer, session = self.page.observer, self.page.session
        self.report_present_at_route_entry = REPORT_ATTRIBUTE in self.page.attributes
        if self.old_html_id is None:
            self.old_html_id = session.last_html_id - 10
        self.refreshed_html_id = session.last_html_id
        self.cached_state_after_binding = observer.state
        session.emit("DOM.attributeModified", {"nodeId": self.old_html_id,
            "name": ATTRIBUTE, "value": "RUNNING:stale"})
        self.count_after_stale = observer.event_count
        self.page.attributes[ATTRIBUTE] = "RUNNING:synthetic"
        session.emit("DOM.attributeModified", {"nodeId": self.refreshed_html_id,
            "name": ATTRIBUTE, "value": "RUNNING:synthetic"})
        if self.page.report is not None:
            self.page.attributes[REPORT_ATTRIBUTE] = self.page.report
        self.page.attributes[ATTRIBUTE] = STATE
        self.report_after_terminal = self.page.attributes.get(REPORT_ATTRIBUTE)
        session.emit("DOM.attributeModified", {"nodeId": self.refreshed_html_id,
            "name": ATTRIBUTE, "value": STATE})
        self.count_after_fresh = observer.event_count
        session.emit("DOM.attributeModified", {"nodeId": self.old_html_id,
            "name": ATTRIBUTE, "value": "SCREEN_DONE:stale"})

    async def abort(self):
        self.actions.append("abort")


class SyntheticPage:
    """Small fake Playwright surface; it does not start a browser or server."""

    def __init__(self, report=None):
        self.url = "about:blank"
        self.main_frame = object()
        self.navigated = False
        self.attributes = {ATTRIBUTE: "ATTACHED:synthetic"}
        self.report = report
        self.listeners = {}
        self.observer = None
        self.route_handler = None
        self.route_instance = None
        self.session = RecycledFrontendSession(self, report=report)

        class Context:
            async def new_cdp_session(_context, _page):
                return self.session
        self.context = Context()

    async def route(self, _pattern, handler):
        self.route_handler = handler
        self.observer = handler.__self__

    async def unroute(self, _pattern, _handler):
        return None

    def on(self, event, handler):
        self.listeners.setdefault(event, []).append(handler)

    def remove_listener(self, event, handler):
        handlers = self.listeners.get(event, [])
        if handler in handlers:
            handlers.remove(handler)
        if not handlers:
            self.listeners.pop(event, None)

    async def goto(self, url, **_kwargs):
        self.url, self.session.target_url, self.navigated = url, url, True
        self.session.emit("Page.frameNavigated", {"frame": {"id": "frame", "url": url}})
        await self.observer.html_ready.wait()
        self.route_instance = SyntheticRoute(self, publish_events=True)
        await self.route_handler(self.route_instance)
        return types.SimpleNamespace(status=200, url=url, status_text="OK")

    def locator(self, _selector):
        page = self
        class Locator:
            async def get_attribute(_locator, attribute, timeout=None):
                return page.attributes.get(attribute)
        return Locator()


class MetricValidationChecks(unittest.TestCase):
    def test_metric_values_accepts_finite_required_rows_and_rejects_bad_shape(self):
        parsed = renderer_capture.metric_values(metric_response())
        self.assertEqual(parsed["Timestamp"], 100.0)
        invalid = [
            None, {"metrics": []},
            {"metrics": [{"name": "Timestamp", "value": 1}]},
            {"metrics": [{"name": "Timestamp", "value": 1},
                         {"name": "Timestamp", "value": 2}]},
            metric_response(thread=True), metric_response(thread=float("nan")),
            metric_response(thread=-1.0),
            {"metrics": [{"name": "x" * 257, "value": 1},
                         {"name": "Timestamp", "value": 1},
                         {"name": "ThreadTime", "value": 1},
                         {"name": "TaskDuration", "value": 1}]},
            {"metrics": [{"name": "Timestamp", "value": 1},
                         {"name": "ThreadTime", "value": 1},
                         {"name": "TaskDuration", "value": 1}] * 43},
        ]
        for response in invalid:
            with self.subTest(response=response):
                with self.assertRaises(ValueError):
                    renderer_capture.metric_values(response)

    def test_metric_delta_requires_advancing_clock_and_nonregressing_values(self):
        before = renderer_capture.metric_values(metric_response())
        with self.assertRaisesRegex(ValueError, "did not advance"):
            renderer_capture.metric_delta(before, before)
        with self.assertRaisesRegex(ValueError, "ThreadTime moved backward"):
            renderer_capture.metric_delta(before, renderer_capture.metric_values(metric_response(101.0, 1.0)))
        extreme_before = renderer_capture.metric_values(metric_response(script_duration=-1e308))
        extreme_after = renderer_capture.metric_values(metric_response(101.0, 2.25, 1e308))
        with self.assertRaisesRegex(ValueError, "ScriptDuration delta not finite"):
            renderer_capture.metric_delta(extreme_before, extreme_after)
        delta = renderer_capture.metric_delta(before, renderer_capture.metric_values(metric_response(101.0, 2.25)))
        self.assertEqual(delta["TimestampSeconds"], 1.0)
        self.assertEqual(delta["ThreadTimeSeconds"], .25)

    def test_production_and_parent_budget_constants_remain_frozen(self):
        self.assertEqual((renderer_capture.CAPTURE_SETUP_SECONDS, renderer_capture.CAPTURE_FINISH_SECONDS,
                          renderer_capture.CAPTURE_CLEANUP_SECONDS), (5.0, 5.0, 1.5))
        self.assertEqual(launcher.LIMITS, {"jobMillis": 90000, "sharedWork": 640,
                                           "activeOperationMillis": 5000})
        self.assertEqual((launcher.OUTER_MS, launcher.CLEANUP_MS, launcher.FINAL_RESERVE_MS,
                          launcher.CONTROLLER_MS, launcher.WINDOW_SECONDS),
                         (180000, 15000, 20000, 220000, 240))


class RendererCaptureChecks(unittest.IsolatedAsyncioTestCase):
    async def run_capture(self, fault=None, *, binding=None):
        root = owned_dir(self, fault or "positive")
        session = MetricsSession(fault)
        item = renderer_capture.RendererCapture(session, root,
            binding=binding or {"pageUrl": URL, "terminalScopeVerified": True})
        with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_FINISH_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
            await item.start(time.monotonic() + 2.0)
            item.binding["terminalScopeVerified"] = True
            result = await item.finish()
        return result, session, root, item

    async def test_cpu_measured_positive_is_metrics_only(self):
        result, session, root, _ = await self.run_capture()
        self.assertEqual(result["status"], "CPU_MEASURED")
        self.assertFalse(result["qualification"])
        self.assertTrue(result["diagnosticOnly"])
        self.assertEqual(result["metricDelta"]["ThreadTimeSeconds"], .25)
        self.assertEqual(result["tracing"], "NOT_ATTEMPTED_METRICS_ONLY")
        self.assertEqual(json.loads((root / "renderer-capture.json").read_text())["status"], "CPU_MEASURED")
        assert_metrics_only(self, session)

    async def test_setup_and_final_metric_failures_are_optional_cpu_unavailable(self):
        faults = ("enable-error", "baseline-malformed", "baseline-timeout",
                  "final-malformed", "final-timeout", "final-regression",
                  "extreme-duration-delta")
        for fault in faults:
            with self.subTest(fault=fault):
                result, session, _, item = await self.run_capture(fault)
                self.assertEqual(result["status"], "CPU_UNAVAILABLE")
                self.assertIsNone(result["metricDelta"])
                self.assertEqual(result["cleanup"]["status"], "PASS")
                self.assertTrue(result["errors"])
                self.assertEqual([row["method"] for row in result["commandClocks"]].count(
                    "Performance.disable"), 1)
                self.assertTrue(item.started)
                assert_metrics_only(self, session)

    async def test_final_target_or_context_identity_change_is_fatal(self):
        for fault in ("target-after-change", "context-after-change"):
            with self.subTest(fault=fault):
                root = owned_dir(self, fault)
                session = MetricsSession(fault)
                item = renderer_capture.RendererCapture(session, root, binding={"pageUrl": URL})
                with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
                     patch.object(renderer_capture, "CAPTURE_FINISH_SECONDS", .25), \
                     patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
                    await item.start(time.monotonic() + 2.0)
                    item.binding["terminalScopeVerified"] = True
                    result = await item.finish()
                self.assertEqual(result["status"], "FAIL_CAPTURE")
                self.assertIsNone(result["metricDelta"])
                self.assertTrue(result["fatalErrors"])
                assert_metrics_only(self, session)

    async def test_initial_target_identity_change_is_rejected_before_enable(self):
        root = owned_dir(self, "target-before-enable")
        session = MetricsSession("target-frame")
        item = renderer_capture.RendererCapture(session, root, binding={
            "pageUrl": URL, "attachedDocument": {"frameId": "frame"}})
        with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
            with self.assertRaises(renderer_capture.CaptureIdentityError):
                await item.start(time.monotonic() + 2.0)
        self.assertIsNone(item.deltas)
        self.assertNotIn("Performance.enable", [method for method, _ in session.calls])
        assert_metrics_only(self, session)

    async def test_disable_cleanup_failure_is_strict_capture_failure(self):
        result, session, _, _ = await self.run_capture("disable-error")
        self.assertEqual(result["status"], "FAIL_CAPTURE")
        self.assertEqual(result["cleanup"]["status"], "FAIL")
        self.assertFalse(result["cleanup"]["performanceDisabled"])
        self.assertEqual(result["metricDelta"]["ThreadTimeSeconds"], .25)
        self.assertEqual(result["cleanup"]["errors"][0]["phase"], "Performance.disable")
        self.assertIn("synthetic disable cleanup failure", result["cleanup"]["errors"][0]["message"])
        assert_metrics_only(self, session)


class PinnedRouteScopeChecks(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.root = owned_dir(self, "route-fixtures")

    async def make_observer(self, name, fault=None):
        root = self.root / name
        root.mkdir()
        host = instrumented_host.imported(HOST_PATH, "root75_offline_host_" + name,
                                          instrumented_host.HOST_SHA)
        captures = instrumented_host.install(host, root)

        class Page:
            def __init__(self):
                self.url = URL
                self.main_frame = object()
            async def unroute(self, pattern, handler):
                return None

        page = Page()
        item = host.HtmlAttributeObserver(page, URL, ATTRIBUTE, time.monotonic() + 3.0, [])
        item.session = MetricsSession(fault, item)
        item.navigation_epoch = 1
        item.document_scope = {"frameId": "frame", "loaderId": "loader", "pageUrl": URL,
                               "documentBackend": 2, "htmlBackend": 4}
        item.document_id = item.document_backend = 2
        item.html_id = item.html_backend = 4
        item.state = STATE
        item.html_ready.set()

        class Route:
            def __init__(self):
                self.request = type("Request", (), {"frame": page.main_frame,
                    "resource_type": "script"})()
                self.actions = []
            async def continue_(self):
                self.actions.append("continue")
            async def abort(self):
                self.actions.append("abort")

        return host, item, Route(), captures, root

    async def test_pinned_route_scope_terminal_check_and_cleanup(self):
        _, item, route, captures, root = await self.make_observer("positive")
        await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["continue"])
        self.assertEqual(item.script_attachment["generation"], 1)
        await item.verify_terminal_scope(dict(item.document_scope), 1, STATE, 0)
        self.assertTrue(item.terminal_verified)
        await item.close()
        self.assertEqual(item.errors, [])
        self.assertFalse(item.route_tasks)
        receipt = json.loads((root / "renderer-capture.json").read_text())
        self.assertEqual(receipt["status"], "CPU_MEASURED")
        self.assertEqual(captures[0].binding["terminalScope"]["generationAfter"], 1)
        methods = [method for method, _ in item.session.calls]
        self.assertLess(methods.index("Performance.disable"), methods.index("detach"))
        assert_metrics_only(self, item.session)

    async def test_optional_metric_errors_continue_original_route_once(self):
        faults = ("enable-error", "baseline-malformed", "baseline-timeout",
                  "final-malformed", "final-timeout", "final-regression",
                  "extreme-duration-delta")
        with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_FINISH_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
            for index, fault in enumerate(faults):
                with self.subTest(fault=fault):
                    _, item, route, _, root = await self.make_observer("optional-" + str(index), fault)
                    await item.hold_compiled_script(route)
                    self.assertEqual(route.actions, ["continue"])
                    await item.verify_terminal_scope(dict(item.document_scope), 1, STATE, 0)
                    await item.close()
                    self.assertEqual(route.actions, ["continue"])
                    self.assertFalse(item.route_tasks)
                    self.assertEqual(item.errors, [])
                    receipt = json.loads((root / "renderer-capture.json").read_text())
                    self.assertEqual(receipt["status"], "CPU_UNAVAILABLE")
                    self.assertEqual(receipt["cleanup"]["status"], "PASS")
                    assert_metrics_only(self, item.session)

    async def test_target_frame_loader_generation_and_url_mismatches_abort_once(self):
        faults = ("target-frame", "target-url", "route-frame-change", "route-loader-change",
                  "route-generation-change", "route-url-change")
        for index, fault in enumerate(faults):
            with self.subTest(fault=fault):
                _, item, route, _, root = await self.make_observer("identity-" + str(index), fault)
                await item.hold_compiled_script(route)
                self.assertEqual(route.actions, ["abort"])
                self.assertFalse(item.route_tasks)
                await item.close()
                receipt = json.loads((root / "renderer-capture.json").read_text())
                self.assertEqual(receipt["status"], "FAIL_CAPTURE")
                self.assertIsNone(receipt["metricDelta"])
                assert_metrics_only(self, item.session)

    async def test_original_owner_aborts_once_on_attachment_drift_deadline_or_cancel(self):
        for index, drift in enumerate(("frame", "loader", "generation", "url")):
            with self.subTest(drift=drift):
                _, item, route, captures, _ = await self.make_observer("owner-drift-" + str(index))
                item.html_ready.clear()
                task = asyncio.create_task(item.hold_compiled_script(route))
                await asyncio.sleep(0)
                if drift == "frame":
                    item.document_scope = {**item.document_scope, "frameId": "successor-frame"}
                elif drift == "loader":
                    item.document_scope = {**item.document_scope, "loaderId": "successor-loader"}
                elif drift == "generation":
                    item.navigation_epoch += 1
                else:
                    item.page.url = URL + "#successor"
                item.html_ready.set()
                await task
                self.assertEqual(route.actions, ["abort"])
                self.assertFalse(item.route_tasks)
                self.assertEqual(captures, [])
                await item.close()

        _, item, route, captures, _ = await self.make_observer("expired-route")
        item.deadline = time.monotonic() - 1.0
        item.html_ready.clear()
        await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["abort"])
        self.assertFalse(item.route_tasks)
        self.assertEqual(captures, [])
        await item.close()

        _, item, route, captures, _ = await self.make_observer("cancel-route")
        item.html_ready.clear()
        task = asyncio.create_task(item.hold_compiled_script(route))
        await asyncio.sleep(0)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual(route.actions, ["abort"])
        self.assertFalse(item.route_tasks)
        self.assertEqual(captures, [])
        await item.close()

    async def test_expired_observer_uses_verified_boundary_scope_without_terminal_claim(self):
        _, item, route, captures, root = await self.make_observer("timeout-boundary")
        await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["continue"])
        item.deadline = time.monotonic() - 1.0
        with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_FINISH_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
            await item.close()
        receipt = json.loads((root / "renderer-capture.json").read_text())
        self.assertFalse(receipt["binding"]["terminalScopeVerified"])
        self.assertEqual(receipt["binding"]["boundaryKind"], "OBSERVER_TIMEOUT")
        self.assertTrue(receipt["binding"]["boundaryScopeVerified"])
        self.assertEqual(receipt["binding"]["boundaryScope"]["generation"], 1)
        self.assertEqual(receipt["status"], "CPU_MEASURED")
        self.assertEqual(receipt["cleanup"]["status"], "PASS")
        self.assertEqual(route.actions, ["continue"])
        self.assertEqual(item.errors, [])
        self.assertEqual(captures[0].binding["boundaryScope"]["loaderId"], "loader")
        assert_metrics_only(self, item.session)

    async def test_timeout_boundary_scope_drift_is_fatal_and_unverified(self):
        _, item, route, _, root = await self.make_observer("timeout-boundary-drift", "boundary-loader-change")
        await item.hold_compiled_script(route)
        item.deadline = time.monotonic() - 1.0
        with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_FINISH_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
            await item.close()
        receipt = json.loads((root / "renderer-capture.json").read_text())
        self.assertFalse(receipt["binding"]["terminalScopeVerified"])
        self.assertFalse(receipt["binding"]["boundaryScopeVerified"])
        self.assertEqual(receipt["status"], "FAIL_CAPTURE")
        self.assertTrue(receipt["fatalErrors"])
        self.assertEqual(route.actions, ["continue"])
        self.assertTrue(any(row["phase"] == "renderer-diagnostic-capture" for row in item.errors))
        assert_metrics_only(self, item.session)

    async def test_final_counter_sample_rechecks_exact_loader_scope(self):
        _, item, route, _, root = await self.make_observer("final-metric-scope", "final-scope-loader-change")
        await item.hold_compiled_script(route)
        await item.verify_terminal_scope(dict(item.document_scope), 1, STATE, 0)
        await item.close()
        receipt = json.loads((root / "renderer-capture.json").read_text())
        self.assertEqual(route.actions, ["continue"])
        self.assertEqual(receipt["status"], "FAIL_CAPTURE")
        self.assertIsNone(receipt["metricDelta"])
        self.assertTrue(receipt["fatalErrors"])
        self.assertFalse(receipt["binding"].get("finalMetricScopeVerified", False))
        self.assertEqual(receipt["cleanup"]["status"], "PASS")
        assert_metrics_only(self, item.session)


class RendererAdapterRebindChecks(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.root = owned_dir(self, "frontend-id-rebind")

    def direct_route_fixture(self, name, fault):
        output = self.root / name
        output.mkdir()
        host = instrumented_host.imported(HOST_PATH, "root75_rebind_host_" + name,
                                          instrumented_host.HOST_SHA)
        captures = instrumented_host.install(host, output)
        page = SyntheticPage()
        page.url = URL
        page.navigated = True
        item = host.HtmlAttributeObserver(page, URL, ATTRIBUTE, time.monotonic() + 3.0, [])
        session = RecycledFrontendSession(page, observer=item, fault=fault)
        page.session, page.observer = session, item
        item.session = session
        item.navigation_epoch = 1
        item.document_scope = {"frameId": "frame", "loaderId": "loader", "pageUrl": URL,
                               "documentBackend": 2, "htmlBackend": 4}
        item.document_id = item.document_backend = 2
        item.html_id = item.html_backend = 4
        item.state = "ATTACHED:synthetic"
        item.html_ready.set()
        for event, handler in (("Page.frameNavigated", item.frame_navigated),
                               ("DOM.documentUpdated", item.document_updated),
                               ("close", item.session_closed)):
            session.on(event, handler)
            item.listeners.append((event, handler))
        return host, page, item, SyntheticRoute(page), captures, output

    async def run_owner_case(self, name, report):
        output = self.root / name
        output.mkdir()
        host = instrumented_host.imported(HOST_PATH, "root75_owner_host_" + name,
                                          instrumented_host.HOST_SHA)
        captures = instrumented_host.install(host, output)
        page = SyntheticPage(report)
        case = {"index": 1, "name": "cold-75", "slug": "001-cold-75",
            "path": launcher.PATH, "stateAttribute": ATTRIBUTE, "expectedState": None,
            "expectedPrefix": "SCREEN_DONE", "terminalPrefixes": ["SCREEN_DONE"],
            "timeoutSeconds": 150.0, "reportAttribute": REPORT_ATTRIBUTE}
        receipt = await host.run_case(page, "http://127.0.0.1:12345", case, output)
        return receipt, page, captures, output

    async def test_actual_owner_rebinds_recycled_ids_and_preserves_nonpass_report(self):
        report_raw = '{ "rootSeed":"75", "applicationOutcome":"FAIL", "terminalStage":"SCREEN_DONE" }'
        receipt, page, captures, output = await self.run_owner_case("owner-nonpass-report", report_raw)
        route = page.route_instance
        self.assertEqual(route.actions, ["continue"])
        self.assertFalse(route.report_present_at_route_entry)
        self.assertEqual(route.report_after_terminal, report_raw)
        self.assertNotEqual(route.old_html_id, route.refreshed_html_id)
        self.assertEqual(route.cached_state_after_binding, "PREPARED:synthetic")
        self.assertEqual(route.count_after_stale, 0)
        self.assertEqual(route.count_after_fresh, 2)
        self.assertEqual(page.observer.html_id, route.refreshed_html_id)
        self.assertEqual(receipt["outcome"], "PASS")
        self.assertEqual(receipt["observedState"], STATE)
        self.assertTrue(receipt["reportJsonValid"])
        self.assertTrue(receipt["observation"]["terminalScopeVerified"])
        scope = receipt["observation"]["scopeIdentity"]
        self.assertTrue(scope["scriptAttachmentMatchesTerminalScope"])
        self.assertEqual(scope["documentBackendBefore"], 2)
        self.assertEqual(scope["documentBackendAfter"], 2)
        self.assertEqual(scope["htmlBackendBefore"], 4)
        self.assertEqual(scope["htmlBackendAfter"], 4)
        report_path = output / "cases/001-cold-75.report.json"
        self.assertEqual(report_path.read_bytes(), report_raw.encode("utf-8"))
        self.assertEqual(receipt["reportSha256"], hashlib.sha256(report_raw.encode("utf-8")).hexdigest())
        self.assertEqual(json.loads(report_path.read_text(encoding="utf-8"))["applicationOutcome"], "FAIL")
        self.assertEqual(captures[0].binding["terminalScope"], scope)
        assert_metrics_only(self, page.session)

    async def test_actual_owner_reports_missing_report_without_conflating_terminal_state(self):
        receipt, page, _, _ = await self.run_owner_case("owner-missing-report", None)
        self.assertEqual(page.route_instance.actions, ["continue"])
        self.assertTrue(receipt["terminalReached"])
        self.assertFalse(receipt["timedOut"])
        self.assertEqual(receipt["observedState"], STATE)
        self.assertEqual(receipt["outcome"], "FAIL")
        self.assertFalse(receipt["reportObserved"])
        self.assertIsNone(receipt["reportJsonValid"])
        self.assertFalse(receipt["reportMatch"])
        self.assertIsNone(receipt["reportSha256"])
        self.assertTrue(receipt["observation"]["terminalScopeVerified"])
        self.assertEqual(receipt["observerErrors"], [])
        assert_metrics_only(self, page.session)

    async def test_adapter_identity_and_epoch_guards_abort_once_before_release(self):
        faults = ("version", "session", "navigation", "attachment", "backend",
                  "frame", "loader", "missing-html")
        with patch.object(renderer_capture, "CAPTURE_SETUP_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_FINISH_SECONDS", .25), \
             patch.object(renderer_capture, "CAPTURE_CLEANUP_SECONDS", .10):
            for fault in faults:
                with self.subTest(fault=fault):
                    _, _, item, route, _, _ = self.direct_route_fixture("guard-" + fault, fault)
                    await item.hold_compiled_script(route)
                    self.assertEqual(route.actions, ["abort"])
                    self.assertFalse(item.route_tasks)
                    self.assertTrue(item.capture.fatal_errors)
                    await item.close()
                    result = json.loads((item.capture.root / "renderer-capture.json").read_text())
                    self.assertEqual(result["status"], "FAIL_CAPTURE")
                    self.assertEqual(result["cleanup"]["status"], "PASS")
                    assert_metrics_only(self, item.session)


def host_receipt(outcome="PASS"):
    return {"outcome": outcome, "errors": [], "inputAudit": {"status": "PASS"},
        "cleanup": {"status": "PASS", "serverStopped": True, "ownedSurvivors": [], "errors": []}}


def capture_receipt(status="CPU_UNAVAILABLE", cleanup="PASS", **binding):
    return {"status": status, "cleanup": {"status": cleanup},
            "rendererCapability": "unknown", "binding": binding}


def waited(exit_code=0):
    return {"reason": None, "exitCode": exit_code,
            "cleanup": {"cleanupVerified": True, "drainsComplete": True}}


def good_drains():
    return [{"overflow": False, "errors": [], "readerAlive": False, "streamClosed": True}]


def clean_timeout_host():
    case = {"outcome": "TIMEOUT", "timedOut": True, "terminalReached": False,
        "navigationError": None, "case": {"path": launcher.PATH, "timeoutSeconds": 150},
        "pageErrors": [], "httpErrors": [], "consoleErrors": [], "observerErrors": [],
        "listenerCleanupErrors": [],
        "attributeReadErrors": [
            {"type": "DeadlineExpired", "attribute": "data-tsj-q30-normal-state"},
            {"type": "DeadlineExpired", "attribute": "data-tsj-q30-normal-report"}]}
    host = host_receipt("FAIL")
    host["cases"] = [case]
    return host


class StatusChecks(unittest.TestCase):
    def test_completed_status_accepts_cpu_unavailable_for_app_pass_and_nonpass(self):
        capture = capture_receipt()
        status = launcher.completed_status(host_receipt(), capture, waited(), good_drains(),
                                           {"status": "APP_PASS"})
        self.assertEqual(status, "DIAGNOSTIC_COMPLETE")
        status = launcher.completed_status(host_receipt(), capture, waited(), good_drains(),
                                           {"status": "APP_NONPASS"})
        self.assertEqual(status, "DIAGNOSTIC_COMPLETE_APP_NONPASS")

    def test_completed_status_requires_capture_host_input_and_process_cleanup(self):
        host, capture = host_receipt(), capture_receipt()
        self.assertEqual(launcher.completed_status(host, capture, waited(), good_drains(),
                         {"status": "APP_PASS"}), "DIAGNOSTIC_COMPLETE")
        broken_capture = capture_receipt(cleanup="FAIL")
        self.assertEqual(launcher.completed_status(host, broken_capture, waited(), good_drains(),
                         {"status": "APP_PASS"}), "DIAGNOSTIC_FAIL")
        broken_host = host_receipt()
        broken_host["cleanup"]["errors"] = ["synthetic cleanup failure"]
        self.assertEqual(launcher.completed_status(broken_host, capture, waited(), good_drains(),
                         {"status": "APP_PASS"}), "DIAGNOSTIC_FAIL")
        reported_host_error = host_receipt()
        reported_host_error["errors"] = ["synthetic observation failure"]
        self.assertEqual(launcher.completed_status(reported_host_error, capture, waited(), good_drains(),
                         {"status": "APP_PASS"}), "DIAGNOSTIC_FAIL")
        broken_inputs = host_receipt()
        broken_inputs["inputAudit"]["status"] = "FAIL"
        self.assertEqual(launcher.completed_status(broken_inputs, capture, waited(), good_drains(),
                         {"status": "APP_PASS"}), "DIAGNOSTIC_FAIL")
        self.assertEqual(launcher.completed_status(host, capture, waited(1), good_drains(),
                         {"status": "APP_PASS"}), "DIAGNOSTIC_FAIL")
        self.assertEqual(launcher.completed_status(host, capture, waited(),
                         [{"overflow": True, "errors": [], "readerAlive": False, "streamClosed": True}],
                         {"status": "APP_PASS"}), "DIAGNOSTIC_FAIL")

    def test_clean_timeout_without_report_is_classified_and_bad_boundary_is_rejected(self):
        capture = capture_receipt(boundaryKind="OBSERVER_TIMEOUT", boundaryScopeVerified=True)
        status = launcher.completed_status(clean_timeout_host(), capture, waited(1), good_drains(),
                                           {"status": "REPORT_UNAVAILABLE"})
        self.assertEqual(status, "DIAGNOSTIC_OBSERVER_TIMEOUT_REPORT_UNAVAILABLE")
        failed_scope = capture_receipt(boundaryKind="OBSERVER_TIMEOUT", boundaryScopeVerified=False)
        status = launcher.completed_status(clean_timeout_host(), failed_scope, waited(1), good_drains(),
                                           {"status": "REPORT_UNAVAILABLE"})
        self.assertEqual(status, "DIAGNOSTIC_FAIL")
        host = clean_timeout_host()
        host["cases"][0]["observerErrors"] = ["synthetic observer failure"]
        status = launcher.completed_status(host, capture, waited(1), good_drains(),
                                           {"status": "APP_NONPASS"})
        self.assertEqual(status, "DIAGNOSTIC_FAIL")

    def test_controller_status_accepts_cpu_unavailable_app_nonpass_and_clean_timeout(self):
        summary = {"status": "DIAGNOSTIC_COMPLETE_APP_NONPASS",
                   "inputBindingUnchanged": True, "errors": [],
                   "rendererCapture": "CPU_UNAVAILABLE", "captureCleanup": "PASS"}
        self.assertEqual(launcher.controller_status(waited(1), summary),
                         "CONTROLLER_COMPLETE_APP_NONPASS_DIAGNOSTIC_ONLY")
        timeout = {**summary, "status": "DIAGNOSTIC_OBSERVER_TIMEOUT_REPORT_UNAVAILABLE"}
        self.assertEqual(launcher.controller_status(waited(1), timeout),
                         "CONTROLLER_COMPLETE_OBSERVER_TIMEOUT_REPORT_UNAVAILABLE")

    def test_controller_status_fails_on_timeout_missing_receipt_inputs_or_cleanup(self):
        good = {"status": "DIAGNOSTIC_COMPLETE", "inputBindingUnchanged": True,
                "errors": [], "rendererCapture": "CPU_UNAVAILABLE", "captureCleanup": "PASS"}
        self.assertEqual(launcher.controller_status(waited(), good),
                         "CONTROLLER_COMPLETE_DIAGNOSTIC_ONLY")
        self.assertEqual(launcher.controller_status(waited(), None),
                         "CONTROLLER_COMPLETE_WORKER_FAILURE")
        self.assertEqual(launcher.controller_status(waited(), {**good, "inputBindingUnchanged": False}),
                         "CONTROLLER_COMPLETE_WORKER_FAILURE")
        self.assertEqual(launcher.controller_status(waited(), {**good, "errors": ["synthetic"]}),
                         "CONTROLLER_COMPLETE_WORKER_FAILURE")
        self.assertEqual(launcher.controller_status(waited(), {**good, "captureCleanup": "FAIL"}),
                         "CONTROLLER_COMPLETE_WORKER_FAILURE")
        failed = {"reason": "outer deadline", "exitCode": 1,
                  "cleanup": {"cleanupVerified": True, "drainsComplete": True}}
        self.assertEqual(launcher.controller_status(failed, good), "FAIL_CONTROLLER")


class GrantAndFinalizationChecks(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 4, 6, 0, 0, tzinfo=timezone.utc)
        self.digest = "f" * 64
        self.grant = {"schema": 1, "parentReference": "synthetic-fixture",
            "windowGranted": True, "quietDesktopConfirmed": True,
            "candidateManifestSha256": self.digest, "windowStartUtc": "2026-10-04T06:00:00Z",
            "windowEndUtc": "2026-10-04T06:04:00Z", "maximumCases": 1,
            "qualification": False, "limits": dict(launcher.LIMITS)}

    def test_grant_positive_and_fail_closed_contracts(self):
        self.assertEqual(launcher.validate_grant(self.grant, self.digest, self.now),
                         self.now + timedelta(seconds=240))
        bad_grants = []
        for key, value in (("windowGranted", False), ("quietDesktopConfirmed", False),
                           ("qualification", True), ("maximumCases", 2)):
            bad_grants.append({**self.grant, key: value})
        bad_grants.append({**self.grant, "limits": {**launcher.LIMITS, "jobMillis": 90001}})
        for grant in bad_grants:
            with self.subTest(grant=grant):
                with self.assertRaises(ValueError):
                    launcher.validate_grant(grant, self.digest, self.now)
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, "a" * 64, self.now)
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now + timedelta(seconds=240))
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now + timedelta(seconds=26))

    def test_launch_without_grant_refuses_before_audit(self):
        with patch.object(launcher, "audit", side_effect=AssertionError("must refuse first")):
            with self.assertRaisesRegex(ValueError, "parent grant"):
                launcher.main(["--repo", "unused", "--pointer", "unused", "--matched-helper", "unused",
                    "--runner", "unused", "--r4-original", "unused", "--launch"])

    def test_strict_json_deadline_duplicate_nonfinite_and_size_checks(self):
        root = owned_dir(self, "strict-json")
        with self.assertRaisesRegex(ValueError, "reserve exhausted"):
            launcher.strict_json(root / "absent.json", time.monotonic_ns() - 1)
        duplicate = root / "duplicate.json"
        duplicate.write_bytes(b'{"x":1,"x":2}')
        with self.assertRaisesRegex(ValueError, "duplicate JSON"):
            launcher.strict_json(duplicate)
        nonfinite = root / "nonfinite.json"
        nonfinite.write_bytes(b'{"x":NaN}')
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            launcher.strict_json(nonfinite)
        oversized = root / "oversized.json"
        with oversized.open("xb") as output:
            output.truncate(launcher.MAX_JSON_BYTES + 1)
        with self.assertRaisesRegex(ValueError, "bounded regular"):
            launcher.strict_json(oversized)

    def test_host_budget_keeps_deadline_and_cleanup_reserves(self):
        self.assertEqual(launcher.host_budget(220000000000, 10000000000), 174000)
        self.assertEqual(launcher.host_budget(220000000000, 0), 180000)
        with self.assertRaisesRegex(ValueError, "insufficient controller"):
            launcher.host_budget(220000000000, 120000000000)


class FakeDrain:
    def __init__(self):
        self.count = 128
        self.overflow = types.SimpleNamespace(is_set=lambda: False)
        self.errors = []
        self.thread = types.SimpleNamespace(is_alive=lambda: False)
        self.streamClosed = True


class FakeReader:
    def __init__(self, app_status):
        self.app_status = app_status

    @staticmethod
    def pairs(rows):
        result = {}
        for key, value in rows:
            if key in result:
                raise ValueError("duplicate synthetic JSON key")
            result[key] = value
        return result

    @staticmethod
    def bad_constant(value):
        raise ValueError("nonfinite synthetic JSON constant: " + value)

    def evaluate(self, report, raw, plan, plan_raw, *, acceptance_path):
        return {"status": self.app_status, "applicationOutcome": report.get("applicationOutcome"),
                "syntheticFixture": True}


class FakeKernel:
    @staticmethod
    def CloseHandle(_handle):
        return True


class FakeRunner:
    def __init__(self, scenario, report, created_roots):
        self.scenario = scenario
        self.report = report
        self.created_roots = created_roots
        self.wait_calls = []

    @staticmethod
    def _api():
        return FakeKernel()

    def _spawn(self, _kernel, _config, argv, root):
        output = Path(argv[argv.index("--output") + 1])
        output.mkdir()
        child = {"pid": 475, "creationTicks": 1, "image": "synthetic-fixture-only",
                 "commandSha256": "a" * 64, "resumeNs": time.monotonic_ns(),
                 "drains": [FakeDrain()], "job": None, "thread": None, "proc": None,
                 "argv": argv, "root": root, "output": output}
        self.created_roots.append(root)
        return child

    def _wait(self, _kernel, child, timeout_ms):
        self.wait_calls.append(timeout_ms)
        output = child["output"]
        if self.scenario not in ("missing-report", "observer-timeout-report-unavailable"):
            report_path = output / "cases/001-cold-75.report.json"
            if self.scenario == "malformed-report":
                report_path.parent.mkdir(parents=True, exist_ok=True)
                report_path.write_text("{malformed fixture JSON", encoding="utf-8")
            else:
                write_json(report_path, self.report)
        if self.scenario == "observer-timeout-report-unavailable":
            host = clean_timeout_host()
        elif self.scenario != "missing-host":
            host = host_receipt()
        if self.scenario != "missing-host":
            write_json(output / "result.json", host)
        if self.scenario not in ("missing-host", "missing-capture"):
            binding = ({"boundaryKind": "OBSERVER_TIMEOUT", "boundaryScopeVerified": True}
                       if self.scenario == "observer-timeout-report-unavailable" else {})
            write_json(output / "renderer-capture.json",
                       {"status": "CPU_UNAVAILABLE", "cleanup": {"status": "PASS"},
                        "binding": binding})
        exit_code = 1 if self.scenario == "observer-timeout-report-unavailable" else 0
        return {"reason": None, "exitCode": exit_code,
                "cleanup": {"cleanupVerified": True, "drainsComplete": True}}


class LauncherLaunchChecks(unittest.TestCase):
    def run_fake_launch(self, scenario):
        root = owned_dir(self, scenario)
        synthetic_here = root / "candidate"
        synthetic_here.mkdir()
        repo = root / "repo"
        repo.mkdir()
        runner_dir = root / "runner"
        runner_dir.mkdir()
        runner_path = runner_dir / "maintained_runner.py"
        runner_path.write_text("# synthetic import boundary\n", encoding="utf-8")
        receipts_path = runner_dir / "receipts.py"
        receipts_path.write_text("# synthetic receipt import binding\n", encoding="utf-8")
        receipts_module = types.ModuleType("receipts")
        receipts_module.__file__ = str(receipts_path)
        host_python = root / "python.exe"
        host_python.write_bytes(b"synthetic fixture path; never executed")
        deps = root / "deps"
        (deps / "playwright").mkdir(parents=True)
        (deps / "greenlet").mkdir()
        app = root / "prepared-app"
        app.mkdir()
        plan, acceptance, grant_path = root / "plan.json", root / "acceptance.json", root / "grant.json"
        if scenario != "missing-plan":
            write_json(plan, {"synthetic": True})
        write_json(acceptance, {"synthetic": True})
        write_json(grant_path, {
            "schema": 1, "parentReference": "synthetic-offline-fixture",
            "windowGranted": True, "quietDesktopConfirmed": True,
            "candidateManifestSha256": "f" * 64,
            "windowStartUtc": "2026-10-04T06:00:00Z",
            "windowEndUtc": "2026-10-04T06:04:00Z",
            "maximumCases": 1, "qualification": False,
            "limits": dict(launcher.LIMITS)})
        app_outcome = "FAIL" if scenario == "app-nonpass" else "PASS"
        report = {"rootSeed": "75", "applicationOutcome": app_outcome, "terminalStage": "SCREEN_DONE",
                  "generationElapsedMs": 1234.5, "workUnits": 640,
                  "stages": [{"name": "generation", "elapsedMs": 1200.0}],
                  "attempts": [{"number": 1, "outcome": "PASS"}]}
        before = {"candidateManifestSha256": "f" * 64,
                  "dependencies": {"reader": "synthetic-reader-pin"},
                  "operationElapsedMs": 1.0, "phaseClocks": []}
        after_template = {**before, "operationElapsedMs": 2.0,
                          "phaseClocks": [{"phase": "synthetic-final-audit"}]}
        created_roots = []
        runner = FakeRunner(scenario, report, created_roots)
        reader = FakeReader("APP_NONPASS" if scenario == "app-nonpass" else "APP_PASS")

        def fake_imported(path, _name, _expected):
            return reader if Path(path).name == "q30_scale_reader.py" else runner

        def fake_audit(_args, _deadline=None):
            return dict(after_template), {"synthetic": True}

        def fake_mkdtemp(prefix):
            path = synthetic_here / (prefix.strip("-") + "-owned")
            path.mkdir()
            return str(path)

        args = types.SimpleNamespace(repo=repo, pointer=root / "pointer.json",
            matched_helper=root / "matched.py", runner=runner_path, r4_original=root / "r4.py",
            grant_json=grant_path, host_python=host_python, deps=deps,
            controller_deadline_ns=time.monotonic_ns() + 240_000_000_000)
        variant = {"app": app, "paths": {"plan": plan, "acceptance": acceptance}}
        old_sys_path = list(sys.path)
        try:
            with patch.object(launcher, "HERE", synthetic_here), \
                 patch.object(launcher, "imported", side_effect=fake_imported), \
                 patch.object(launcher, "audit", side_effect=fake_audit), \
                 patch.object(launcher, "validate_grant", return_value=None), \
                 patch.object(launcher.sys, "platform", "win32"), \
                 patch.dict(sys.modules, {"receipts": receipts_module}), \
                 patch.object(launcher.tempfile, "mkdtemp", side_effect=fake_mkdtemp), \
                 redirect_stdout(StringIO()):
                status_code = launcher.launch(args, before, variant)
        finally:
            sys.path[:] = old_sys_path
        self.assertEqual(len(created_roots), 1)
        result_path = Path(created_roots[0]) / "diagnostic-result.json"
        return status_code, json.loads(result_path.read_text(encoding="utf-8")), runner

    def test_fake_launch_preserves_app_report_with_optional_cpu_unavailable(self):
        code, result, runner = self.run_fake_launch("complete")
        self.assertEqual(code, 0)
        self.assertEqual(result["status"], "DIAGNOSTIC_COMPLETE")
        self.assertEqual(result["rendererCapture"], "CPU_UNAVAILABLE")
        self.assertEqual(result["captureCleanup"], "PASS")
        self.assertTrue(result["inputBindingUnchanged"])
        self.assertEqual(result["applicationAudit"]["status"], "APP_PASS")
        self.assertEqual(result["phaseWallTimes"]["source"], "UNCHANGED_APP_REPORT")
        self.assertEqual(result["phaseWallTimes"]["rootSeed"], "75")
        self.assertEqual(result["phaseWallTimes"]["generationElapsedMs"], 1234.5)
        self.assertTrue(result["appReportSha256"])
        self.assertEqual(len(runner.wait_calls), 1)
        self.assertEqual(runner.wait_calls[0], launcher.OUTER_MS)

    def test_fake_launch_keeps_app_nonpass_separate_from_host_pass_and_optional_cpu(self):
        code, result, _ = self.run_fake_launch("app-nonpass")
        self.assertEqual(code, 1)
        self.assertEqual(result["status"], "DIAGNOSTIC_COMPLETE_APP_NONPASS")
        self.assertEqual(result["applicationAudit"]["status"], "APP_NONPASS")
        self.assertEqual(result["applicationAudit"]["applicationOutcome"], "FAIL")
        self.assertEqual(result["hostObservation"]["outcome"], "PASS")
        self.assertEqual(result["rendererCapture"], "CPU_UNAVAILABLE")
        self.assertEqual(result["captureCleanup"], "PASS")
        self.assertEqual(result["phaseWallTimes"]["applicationOutcome"], "FAIL")
        self.assertTrue(result["appReportSha256"])
        self.assertTrue(result["inputBindingUnchanged"])
        self.assertEqual(result["errors"], [])

    def test_missing_host_or_capture_receipt_keeps_app_report_and_phase_rows(self):
        for scenario in ("missing-host", "missing-capture"):
            with self.subTest(scenario=scenario):
                code, result, _ = self.run_fake_launch(scenario)
                self.assertEqual(code, 1)
                self.assertEqual(result["status"], "DIAGNOSTIC_FAIL")
                self.assertTrue(result["errors"])
                self.assertTrue(result["inputBindingUnchanged"])
                self.assertEqual(result["applicationAudit"]["status"], "APP_PASS")
                self.assertEqual(result["phaseWallTimes"]["source"], "UNCHANGED_APP_REPORT")
                self.assertEqual(result["phaseWallTimes"]["rootSeed"], "75")
                self.assertTrue(result["appReportSha256"])
                self.assertEqual(result["rendererCapture"], "NOT_RUN")
                self.assertEqual(result["captureCleanup"], "NOT_RUN")
                if scenario == "missing-capture":
                    self.assertEqual(result["hostObservation"]["outcome"], "PASS")
                else:
                    self.assertIsNone(result.get("hostObservation"))

    def test_missing_app_report_survives_clean_timeout_classification(self):
        code, result, _ = self.run_fake_launch("observer-timeout-report-unavailable")
        self.assertEqual(code, 1)
        self.assertEqual(result["status"], "DIAGNOSTIC_OBSERVER_TIMEOUT_REPORT_UNAVAILABLE")
        self.assertEqual(result["applicationAudit"]["status"], "REPORT_UNAVAILABLE")
        self.assertIsNone(result["phaseWallTimes"])
        self.assertEqual(result["rendererCapture"], "CPU_UNAVAILABLE")
        self.assertEqual(result["captureCleanup"], "PASS")
        self.assertEqual(result["hostObservation"]["outcome"], "FAIL")
        self.assertEqual(result["errors"], [])
        self.assertTrue(result["inputBindingUnchanged"])
        controller = launcher.controller_status(result["operation"], result)
        self.assertEqual(controller, "CONTROLLER_COMPLETE_OBSERVER_TIMEOUT_REPORT_UNAVAILABLE")

    def test_missing_plan_and_malformed_app_report_are_report_audit_failures(self):
        for scenario in ("missing-plan", "malformed-report"):
            with self.subTest(scenario=scenario):
                code, result, _ = self.run_fake_launch(scenario)
                self.assertEqual(code, 1)
                self.assertEqual(result["status"], "DIAGNOSTIC_FAIL")
                self.assertEqual(result["applicationAudit"]["status"], "FAIL_REPORT_AUDIT")
                self.assertNotEqual(result["applicationAudit"]["status"], "REPORT_UNAVAILABLE")
                self.assertEqual(result["rendererCapture"], "CPU_UNAVAILABLE")
                self.assertEqual(result["captureCleanup"], "PASS")
                self.assertTrue(result["errors"])
                self.assertIsNone(result["phaseWallTimes"])
                self.assertTrue(result["inputBindingUnchanged"])


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {"schema": 1, "status": "PASS_SYNTHETIC_ONLY" if result.wasSuccessful() else "FAIL",
        "qualification": False, "browserLaunched": False, "q30CasesLaunched": 0,
        "nativeCpuSamples": 0, "tests": result.testsRun, "failures": len(result.failures),
        "errors": len(result.errors), "skipped": len(result.skipped), "fixtureRoot": str(FIXTURE_ROOT)}
    (FIXTURE_ROOT / "offline-result.json").write_text(json.dumps(receipt, indent=2) + "\n",
                                                        encoding="utf-8")
    print(json.dumps(receipt, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
