"""New synthetic capture/grant fixtures only. No browser/native CPU/sample launch."""
import asyncio
import base64
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import renderer_capture as capture
import run_one_diagnostic as launcher
import instrumented_host as wrapper

ROOT = Path(tempfile.mkdtemp(prefix="q30-root75-offline-fixtures-"))
URL = "http://127.0.0.1:12345/" + launcher.PATH


def metrics(timestamp=100.0, thread=2.0):
    return {"metrics": [{"name": "Timestamp", "value": timestamp},
        {"name": "ThreadTime", "value": thread}, {"name": "TaskDuration", "value": thread / 2},
        {"name": "ScriptDuration", "value": thread / 3}]}


class Session:
    def __init__(self, fault=None):
        self.fault = fault
        self.listeners = {}
        self.calls = []
        self.metric_reads = self.target_reads = self.chunk_reads = 0
        self.trace = b'{"traceEvents":[{"name":"fixture","ts":1}]}'

    def on(self, event, handler):
        self.listeners[event] = handler

    def remove_listener(self, event, handler):
        if self.fault == "listener-close":
            raise RuntimeError("listener failed")
        assert self.listeners.pop(event) == handler

    async def send(self, method, params):
        self.calls.append((method, params))
        if method == "Page.getFrameTree":
            return {"frameTree": {"frame": {"id": "frame", "loaderId": "loader", "url": URL}}}
        if method == "DOM.getDocument":
            return {"root": {"nodeId": 2, "backendNodeId": 2, "documentURL": URL,
                "children": [{"nodeName": "HTML", "nodeId": 4,
                    "backendNodeId": 5 if self.fault == "scope-change" else 4,
                    "attributes": ["data-tsj-q30-normal-state", "SCREEN_DONE:fixture"]}]}}
        if method == "Browser.getVersion":
            return {"protocolVersion": "fixture", "product": "fixture", "jsVersion": "fixture"}
        if method == "Target.getTargetInfo":
            self.target_reads += 1
            return {"targetInfo": {"targetId": "other" if self.fault == "target-change" and
                self.target_reads > 1 else "fixed", "type": "page",
                "url": "other" if self.fault == "target-url" else URL}}
        if method == "Tracing.getCategories":
            return {"categories": [] if self.fault == "categories" else list(capture.CATEGORIES)}
        if method == "Performance.enable":
            assert params == {"timeDomain": "threadTicks"}
            if self.fault == "enable":
                raise RuntimeError("thread time unsupported")
        if method == "Performance.getMetrics":
            self.metric_reads += 1
            if self.metric_reads == 1:
                return metrics()
            if self.fault == "metric-timeout":
                await asyncio.sleep(.2)
            if self.fault == "regression":
                return metrics(101.0, 1.0)
            if self.fault == "missing-metric":
                return {"metrics": []}
            return metrics(101.0, 2.25)
        if method == "Tracing.start":
            assert params["traceConfig"]["traceBufferSizeInKb"] == 16384
            assert params["traceConfig"]["recordMode"] == "recordUntilFull"
            assert params["traceConfig"]["enableSampling"] is False
            assert params["traceConfig"]["enableSystrace"] is False
            if self.fault == "start":
                raise RuntimeError("trace start uncertain")
            if self.fault == "buffer":
                self.listeners["Tracing.bufferUsage"]({"percentFull": 1.0})
        if method == "Tracing.end":
            if self.fault == "end":
                raise RuntimeError("trace end failed")
            if self.fault == "completion-timeout":
                return {}
            row = {"dataLossOccurred": self.fault == "loss", "stream": "fixture-stream",
                   "traceFormat": "json", "streamCompression": "none"}
            if self.fault == "no-stream":
                row.pop("stream")
            if self.fault == "missing-loss":
                row.pop("dataLossOccurred")
            if self.fault == "format":
                row["traceFormat"] = "proto"
            if self.fault == "compression":
                row["streamCompression"] = "gzip"
            self.listeners["Tracing.tracingComplete"](row)
            if self.fault == "duplicate-completion":
                self.listeners["Tracing.tracingComplete"](row)
        if method == "IO.read":
            self.chunk_reads += 1
            if self.fault == "stream-timeout":
                await asyncio.sleep(.2)
            if self.fault == "read":
                raise RuntimeError("stream read failed")
            if self.fault == "base64":
                return {"data": "!!!", "eof": True, "base64Encoded": True}
            if self.fault == "oversize":
                return {"data": "x" * (capture.READ_BYTES + 1), "eof": True}
            if self.fault == "no-progress":
                return {"data": "", "eof": False}
            if self.fault == "empty":
                return {"data": "", "eof": True}
            if self.fault == "flags":
                return {"data": "x", "eof": 1}
            if self.fault == "no-eof":
                return {"data": "x" * capture.READ_BYTES, "eof": False}
            if self.chunk_reads == 1:
                return {"data": self.trace[:20].decode(), "eof": False}
            return {"data": base64.b64encode(self.trace[20:]).decode(), "base64Encoded": True, "eof": True}
        if method == "IO.close" and self.fault == "close":
            raise RuntimeError("stream close failed")
        if method == "Performance.disable" and self.fault == "disable":
            raise RuntimeError("disable failed")
        return {}

    async def detach(self):
        self.calls.append(("detach", {}))


class CaptureChecks(unittest.IsolatedAsyncioTestCase):
    async def execute(self, fault=None, *, terminal=True):
        root = ROOT / self._testMethodName
        root.mkdir()
        session = Session(fault)
        item = capture.RendererCapture(session, root, binding={"pageUrl": URL,
            "terminalScopeVerified": terminal})
        try:
            await item.start(time.monotonic() + 1)
        except Exception as error:
            item.error("setup", error)
        # Three 50ms cleanup opportunities avoid using 10ms subdeadlines on the
        # selected Windows event loop. The .2s fake stall still MUST exceed the
        # .15s operation budget; cleanup commands and the elapsed cap stay required.
        with patch.object(capture, "CAPTURE_FINISH_SECONDS", .3), \
             patch.object(capture, "CAPTURE_CLEANUP_SECONDS", .15), \
             patch.object(capture, "MAX_TRACE_BYTES", 2 * capture.READ_BYTES):
            result = await item.finish()
        self.assertFalse(result["qualification"])
        self.assertEqual(result["traceContentAudit"], "NOT_RUN")
        self.assertEqual(item.listeners, [])
        self.assertLess(result["finishElapsedMs"], 500)
        if fault:
            self.assertEqual(result["status"], "FAIL_CAPTURE")
            self.assertTrue(result["errors"])
        return result, session, root, item

    async def test_positive(self):
        result, session, root, item = await self.execute()
        self.assertEqual(result["status"], "PASS_CAPTURE_ONLY")
        self.assertEqual(result["metricDelta"]["TimestampSeconds"], 1.0)
        self.assertEqual(result["metricDelta"]["ThreadTimeSeconds"], .25)
        self.assertEqual((root / "renderer-trace.json").read_bytes(), session.trace)
        self.assertEqual(result["traceBytes"], len(session.trace))
        methods = [row[0] for row in session.calls]
        self.assertLess(methods.index("IO.close"), methods.index("Performance.disable"))
        self.assertIsNone(await item.finish())
        self.assertEqual(methods.count("Tracing.end"), 1)

    async def test_unsealed_terminal(self):
        result, _, _, _ = await self.execute(terminal=False)
        self.assertEqual(result["status"], "FAIL_CAPTURE")
        self.assertIn("stable attachment", result["errors"][0]["message"])


def add_capture_negative(fault):
    async def check(self):
        result, session, _, _ = await self.execute(fault)
        if fault not in ("target-url", "categories", "enable"):
            self.assertIn("Tracing.end", [row[0] for row in session.calls])
        if fault == "completion-timeout":
            self.assertLess(result["finishElapsedMs"], 500)
        if fault in ("metric-timeout", "stream-timeout"):
            methods = [row[0] for row in session.calls]
            self.assertIn("IO.close", methods)
            self.assertIn("Performance.disable", methods)
    setattr(CaptureChecks, "test_" + fault.replace("-", "_"), check)


for FAULT in ("target-change", "target-url", "categories", "enable", "start", "buffer", "regression",
              "missing-metric", "end", "loss", "missing-loss", "no-stream", "format", "compression",
              "duplicate-completion", "read", "base64", "oversize", "no-progress", "empty", "flags",
              "no-eof", "close", "disable", "listener-close", "completion-timeout"):
    add_capture_negative(FAULT)
for FAULT in ("metric-timeout", "stream-timeout"):
    add_capture_negative(FAULT)


class CategoryChecks(unittest.TestCase):
    # Independent required contract and primary-source group fixtures, rather
    # than deriving expected membership from the implementation under test.
    required = ["devtools.timeline", "v8", "v8.execute", "toplevel", "disabled-by-default-v8.gc"]
    grouped = ["devtools.timeline,v8", "v8.execute,toplevel", "disabled-by-default-v8.gc"]

    def test_exact_preserves_order_duplicates(self):
        values = ["unrelated", "v8", "devtools.timeline", "v8.execute", "toplevel",
                  "disabled-by-default-v8.gc", "v8"]
        row = capture.category_preflight({"categories": values})
        self.assertEqual(row["status"], "REQUIREMENTS_ENUMERATED")
        self.assertEqual(row["requiredCategories"], self.required)
        self.assertEqual(row["returnedCategories"], values)
        self.assertTrue(row["returnedEvidenceComplete"])
        self.assertEqual(row["missingRequirements"], [])
        self.assertTrue(all(item["matchKind"] == "EXACT" for item in row["matches"]))

    def test_explicit_comma_groups(self):
        row = capture.category_preflight({"categories": self.grouped})
        self.assertEqual(row["status"], "REQUIREMENTS_ENUMERATED")
        self.assertEqual(row["returnedCategories"], self.grouped)
        self.assertEqual([item["returnedEntryIndex"] for item in row["matches"]], [0, 0, 1, 1, 2])
        self.assertEqual(row["matches"][0]["matchKind"], "GROUP_ATOM")

    def test_each_requirement_stays_required(self):
        for required in self.required:
            with self.subTest(required=required):
                values = [value for value in self.required if value != required]
                row = capture.category_preflight({"categories": values})
                self.assertEqual(row["status"], "MISSING_REQUIREMENTS")
                self.assertEqual(row["missingRequirements"], [required])
                self.assertEqual(row["returnedCategories"], values)

    def test_no_alias_case_substring_or_wildcard_support(self):
        values = ["DEVTOOLS.TIMELINE", "v8*", "v8.execute.more", "toplevel.flow",
                  "disabled-by-default-v8.gc_extra"]
        row = capture.category_preflight({"categories": values})
        self.assertEqual(row["status"], "MISSING_REQUIREMENTS")
        self.assertEqual(row["missingRequirements"], self.required)

    def test_no_whitespace_normalization(self):
        row = capture.category_preflight({"categories": ["devtools.timeline, v8",
            "v8.execute,toplevel", "disabled-by-default-v8.gc"]})
        self.assertEqual(row["missingRequirements"], ["v8"])

    def test_empty_list_explains_all_missing(self):
        row = capture.category_preflight({"categories": []})
        self.assertEqual(row["missingRequirements"], self.required)
        self.assertEqual(row["returnedCategories"], [])
        self.assertTrue(row["returnedEvidenceComplete"])

    def test_malformed_response_is_unknown_membership(self):
        for response in (None, [], {}, {"categories": None}, {"categories": "v8"},
                         {"categories": [1]}, {"categories": [True]}):
            with self.subTest(response=response):
                row = capture.category_preflight(response)
                self.assertEqual(row["status"], "INVALID_RESPONSE")
                self.assertIsNone(row["missingRequirements"])
                self.assertFalse(row["returnedEvidenceComplete"])
                self.assertTrue(row["errors"])

    def test_empty_group_retains_response_but_refuses_membership(self):
        values = self.required + ["a,,b"]
        row = capture.category_preflight({"categories": values})
        self.assertEqual(row["status"], "INVALID_RESPONSE")
        self.assertEqual(row["returnedCategories"], values)
        self.assertIsNone(row["missingRequirements"])

    def test_category_bounds(self):
        cases = [["x"] * 4097, ["x" * 1025], ["x" * 1024] * 257,
                 ["\u00e9" * 513]]
        for values in cases:
            with self.subTest(count=len(values)):
                row = capture.category_preflight({"categories": values})
                self.assertEqual(row["status"], "INVALID_RESPONSE")
                self.assertFalse(row["returnedEvidenceComplete"])
                self.assertIsNone(row["missingRequirements"])

    def test_invalid_utf8_is_explained(self):
        row = capture.category_preflight({"categories": ["\ud800"]})
        self.assertEqual(row["status"], "INVALID_RESPONSE")
        self.assertIn("not valid UTF-8", row["errors"][0])


class CategoryLifecycleChecks(unittest.IsolatedAsyncioTestCase):
    async def test_missing_saved_before_fail_closed(self):
        class MissingGC(Session):
            async def send(self, method, params):
                if method == "Tracing.getCategories":
                    self.calls.append((method, params))
                    return {"categories": ["devtools.timeline", "v8", "v8.execute", "toplevel"]}
                return await super().send(method, params)
        root = ROOT / self._testMethodName
        root.mkdir()
        session = MissingGC()
        item = capture.RendererCapture(session, root, binding={"pageUrl": URL})
        with self.assertRaisesRegex(ValueError, "MISSING_REQUIREMENTS: disabled-by-default-v8.gc"):
            await item.start(time.monotonic() + 1)
        receipt = json.loads((root / "renderer-category-preflight.json").read_text())
        self.assertEqual(receipt["categoryPreflight"]["returnedCategories"],
                         ["devtools.timeline", "v8", "v8.execute", "toplevel"])
        self.assertEqual(receipt["categoryPreflight"]["missingRequirements"], ["disabled-by-default-v8.gc"])
        self.assertNotIn("Performance.enable", [row[0] for row in session.calls])
        self.assertNotIn("Tracing.start", [row[0] for row in session.calls])
        result = await item.finish()
        self.assertEqual(result["status"], "FAIL_CAPTURE")
        self.assertEqual(result["categoryPreflight"], receipt["categoryPreflight"])
        self.assertEqual(session.listeners, {})

    async def test_group_acceptance_keeps_filters_and_content_unknown(self):
        class Groups(Session):
            async def send(self, method, params):
                if method == "Tracing.getCategories":
                    self.calls.append((method, params))
                    return {"categories": ["devtools.timeline,v8", "v8.execute,toplevel",
                                           "disabled-by-default-v8.gc"]}
                return await super().send(method, params)
        root = ROOT / self._testMethodName
        root.mkdir()
        session = Groups()
        item = capture.RendererCapture(session, root, binding={"pageUrl": URL, "terminalScopeVerified": True})
        await item.start(time.monotonic() + 1)
        start = next(params for method, params in session.calls if method == "Tracing.start")
        self.assertEqual(start["traceConfig"]["includedCategories"], CategoryChecks.required)
        result = await item.finish()
        self.assertEqual(result["status"], "PASS_CAPTURE_ONLY")
        self.assertEqual(result["traceContentAudit"], "NOT_RUN")
        self.assertEqual(result["categoryPreflight"]["status"], "REQUIREMENTS_ENUMERATED")
        self.assertEqual(session.listeners, {})

    async def test_existing_category_receipt_not_overwritten(self):
        root = ROOT / self._testMethodName
        root.mkdir()
        receipt = root / "renderer-category-preflight.json"
        receipt.write_text("preserved fixture")
        session = Session()
        item = capture.RendererCapture(session, root, binding={"pageUrl": URL})
        with self.assertRaises(FileExistsError):
            await item.start(time.monotonic() + 1)
        self.assertEqual(receipt.read_text(), "preserved fixture")
        self.assertNotIn("Performance.enable", [row[0] for row in session.calls])
        await item.finish()
        self.assertEqual(session.listeners, {})


class MetricChecks(unittest.TestCase):
    def test_missing(self):
        with self.assertRaises(ValueError):
            capture.metric_values({"metrics": []})

    def test_duplicate(self):
        row = metrics()
        row["metrics"].append(row["metrics"][0])
        with self.assertRaises(ValueError):
            capture.metric_values(row)

    def test_bool(self):
        row = metrics(thread=True)
        with self.assertRaises(ValueError):
            capture.metric_values(row)

    def test_nan(self):
        with self.assertRaises(ValueError):
            capture.metric_values(metrics(thread=float("nan")))

    def test_no_clock_progress(self):
        value = capture.metric_values(metrics())
        with self.assertRaises(ValueError):
            capture.metric_delta(value, value)

    def test_no_zero_substitution(self):
        row = metrics()
        row["metrics"] = [item for item in row["metrics"] if item["name"] != "ThreadTime"]
        with self.assertRaises(ValueError):
            capture.metric_values(row)


class RouteChecks(unittest.IsolatedAsyncioTestCase):
    async def make(self, fault=None):
        root = ROOT / self._testMethodName
        root.mkdir()
        host = wrapper.imported(Path(__file__).parent / "headful_attribute_host.py",
                                "root75_fixture_actual_r4_owner", wrapper.HOST_SHA)
        wrapper.install(host, root)
        class Page:
            url = URL
            main_frame = object()
            async def unroute(self, pattern, handler):
                pass
        page = Page()
        item = host.HtmlAttributeObserver(page, URL, "data-tsj-q30-normal-state",
                                          time.monotonic() + 2, [])
        item.session = Session(fault)
        item.navigation_epoch = 1
        item.document_scope = {"frameId": "frame", "loaderId": "loader", "pageUrl": URL,
                               "documentBackend": 2, "htmlBackend": 4}
        item.document_id = item.document_backend = 2
        item.html_id = item.html_backend = 4
        item.html_ready.set()
        class Request:
            frame = page.main_frame
            resource_type = "script"
        class Route:
            request = Request()
            def __init__(self):
                self.actions = []
            async def continue_(self):
                self.actions.append("continue")
            async def abort(self):
                self.actions.append("abort")
                if fault == "abort-failure":
                    raise RuntimeError("original abort failure")
        return item, Route(), root

    async def test_original_owner_positive(self):
        item, route, root = await self.make()
        await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["continue"])
        self.assertTrue(item.capture.started)
        await item.verify_terminal_scope(dict(item.document_scope), 1, "SCREEN_DONE:fixture", 0)
        self.assertTrue(item.terminal_verified)
        await item.close()
        self.assertEqual(item.errors, [])
        self.assertEqual(json.loads((root / "renderer-capture.json").read_text())["status"],
                         "PASS_CAPTURE_ONLY")
        methods = [row[0] for row in item.session.calls]
        self.assertLess(methods.index("Performance.disable"), methods.index("detach"))
        self.assertFalse(item.route_tasks)

    async def test_setup_failure_releases_original_route(self):
        item, route, _ = await self.make("categories")
        await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["abort"])
        self.assertEqual(item.errors[0]["phase"], "compiled-script-attachment")
        await item.close()
        self.assertFalse(item.route_tasks)

    async def test_setup_scope_change_releases_original_route(self):
        item, route, _ = await self.make("scope-change")
        await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["abort"])
        self.assertIn("crossed held-script", item.errors[0]["message"])
        await item.close()

    async def test_setup_cancellation_releases_original_route(self):
        item, route, _ = await self.make()
        entered = asyncio.Event()
        async def pending(*args):
            entered.set()
            await asyncio.Event().wait()
        with patch.object(capture.RendererCapture, "start", pending):
            task = asyncio.create_task(item.hold_compiled_script(route))
            await entered.wait()
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        self.assertEqual(route.actions, ["abort"])
        await item.close()
        self.assertFalse(item.route_tasks)

    async def test_failed_original_abort_recorded_once(self):
        item, route, _ = await self.make("abort-failure")
        with patch.object(capture.RendererCapture, "start", side_effect=RuntimeError("setup failure")):
            await item.hold_compiled_script(route)
        self.assertEqual(route.actions, ["abort"])
        self.assertIn("diagnostic-setup-route-abort", [row["phase"] for row in item.errors])
        await item.close()


class GrantChecks(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 4, 6, 0, 0, tzinfo=timezone.utc)
        self.digest = "f" * 64
        self.grant = {"schema": 1, "parentReference": "synthetic-fixture", "windowGranted": True,
            "quietDesktopConfirmed": True, "candidateManifestSha256": self.digest,
            "windowStartUtc": "2026-10-04T06:00:00Z", "windowEndUtc": "2026-10-04T06:04:00Z",
            "maximumCases": 1, "qualification": False, "limits": dict(launcher.LIMITS)}

    def test_positive_validation_only(self):
        self.assertEqual(launcher.validate_grant(self.grant, self.digest, self.now),
                         self.now + timedelta(seconds=240))

    def test_missing_launch_grant_refused_before_audit(self):
        with patch.object(launcher, "audit", side_effect=AssertionError("must not audit/import")):
            with self.assertRaisesRegex(ValueError, "parent grant"):
                launcher.main(["--repo", "unused", "--pointer", "unused", "--matched-helper", "unused",
                    "--runner", "unused", "--r4-original", "unused", "--launch"])

    def test_expired(self):
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now + timedelta(seconds=240))

    def test_insufficient_cleanup_reserve(self):
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now + timedelta(seconds=26))

    def test_candidate_mismatch(self):
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, "a" * 64, self.now)

    def test_multiple_cases(self):
        self.grant["maximumCases"] = 2
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now)

    def test_no_window_grant(self):
        self.grant["windowGranted"] = False
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now)

    def test_not_quiet(self):
        self.grant["quietDesktopConfirmed"] = False
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now)

    def test_budget_change(self):
        self.grant["limits"]["jobMillis"] = 90001
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now)

    def test_qualification(self):
        self.grant["qualification"] = True
        with self.assertRaises(ValueError):
            launcher.validate_grant(self.grant, self.digest, self.now)


class FinalizationChecks(unittest.TestCase):
    def test_expired_budget_before_file_read(self):
        with self.assertRaisesRegex(ValueError, "reserve exhausted"):
            launcher.strict_json(ROOT / "absent.json", time.monotonic_ns() - 1)

    def test_oversized_file_before_parse(self):
        path = ROOT / "oversized-sparse-fixture.json"
        with path.open("xb") as output:
            output.truncate(launcher.MAX_JSON_BYTES + 1)
        with self.assertRaisesRegex(ValueError, "bounded regular"):
            launcher.strict_json(path)

    def test_duplicate_json_rejection(self):
        path = ROOT / "duplicate-fixture.json"
        path.write_bytes(b'{"x":1,"x":2}')
        with self.assertRaisesRegex(ValueError, "duplicate JSON"):
            launcher.strict_json(path)

    def test_nonfinite_json_rejection(self):
        path = ROOT / "nonfinite-fixture.json"
        path.write_bytes(b'{"x":NaN}')
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            launcher.strict_json(path)

    def test_hard_outer_scope(self):
        self.assertEqual(launcher.CONTROLLER_MS, 220000)
        self.assertLessEqual(launcher.CONTROLLER_MS + launcher.CLEANUP_MS,
                             launcher.WINDOW_SECONDS * 1000)

    def test_host_budget_clamps_slow_preflight(self):
        self.assertEqual(launcher.host_budget(220000000000, 10000000000), 174000)
        self.assertEqual(launcher.host_budget(220000000000, 0), 180000)

    def test_host_budget_refuses_late_start(self):
        with self.assertRaisesRegex(ValueError, "insufficient controller"):
            launcher.host_budget(220000000000, 120000000000)

    def test_complete_app_nonpass_not_controller_failure(self):
        waited = {"reason": None, "exitCode": 1,
                  "cleanup": {"cleanupVerified": True, "drainsComplete": True}}
        summary = {"status": "DIAGNOSTIC_CAPTURE_COMPLETE_APP_NONPASS", "inputBindingUnchanged": True,
                   "errors": [], "rendererCapture": "PASS_CAPTURE_ONLY"}
        self.assertEqual(launcher.controller_status(waited, summary),
                         "CONTROLLER_COMPLETE_APP_NONPASS_DIAGNOSTIC_ONLY")
        summary["inputBindingUnchanged"] = False
        self.assertEqual(launcher.controller_status(waited, summary), "CONTROLLER_COMPLETE_WORKER_FAILURE")

    def test_controller_timeout_is_failure(self):
        waited = {"reason": "outer deadline", "exitCode": 1,
                  "cleanup": {"cleanupVerified": True, "drainsComplete": True}}
        self.assertEqual(launcher.controller_status(waited, None), "FAIL_CONTROLLER")

    def test_controller_missing_summary_is_worker_failure(self):
        waited = {"reason": None, "exitCode": 1,
                  "cleanup": {"cleanupVerified": True, "drainsComplete": True}}
        self.assertEqual(launcher.controller_status(waited, None), "CONTROLLER_COMPLETE_WORKER_FAILURE")

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {"schema": 1, "status": "PASS_SYNTHETIC_ONLY" if result.wasSuccessful() else "FAIL",
        "qualification": False, "browserLaunched": False, "q30CasesLaunched": 0,
        "nativeCpuSamples": 0, "tests": result.testsRun, "failures": len(result.failures),
        "errors": len(result.errors), "skipped": len(result.skipped), "fixtureRoot": str(ROOT)}
    (ROOT / "offline-result.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
