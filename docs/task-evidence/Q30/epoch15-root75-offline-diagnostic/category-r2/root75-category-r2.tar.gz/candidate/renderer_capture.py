"""Bounded diagnostic CDP capture. No app/controller calls or qualification claim."""
import asyncio
import base64
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import time

CATEGORIES = ("devtools.timeline", "v8", "v8.execute", "toplevel",
              "disabled-by-default-v8.gc")
TRACE_BUFFER_KIB = 16384
MAX_TRACE_BYTES = 24 * 1024 * 1024
READ_BYTES = 64 * 1024
CAPTURE_SETUP_SECONDS = 5.0
CAPTURE_FINISH_SECONDS = 5.0
CAPTURE_CLEANUP_SECONDS = 1.5
MAX_CATEGORY_ENTRIES = 4096
MAX_CATEGORY_ENTRY_BYTES = 1024
MAX_CATEGORY_BYTES = 256 * 1024


def need(condition, message):
    if not condition:
        raise ValueError(message)


def category_preflight(response):
    """Match literal category atoms, including explicitly advertised groups."""
    row = {"status": "INVALID_RESPONSE", "requiredCategories": list(CATEGORIES),
           "returnedCategories": None, "returnedEvidenceComplete": False,
           "missingRequirements": None, "matches": [], "errors": []}
    categories = response.get("categories") if type(response) is dict else None
    row["returnedType"] = type(categories).__name__
    if type(response) is not dict or "categories" not in response or type(categories) is not list:
        row["errors"].append("Tracing.getCategories must return categories as an array of strings")
        return row
    row["returnedCount"] = len(categories)
    if len(categories) > MAX_CATEGORY_ENTRIES:
        row["errors"].append("category entry count exceeds explicit bound")
        return row
    size = 0
    for index, value in enumerate(categories):
        if type(value) is not str:
            row["errors"].append("category entry %d is not a string" % index)
            return row
        try:
            encoded = value.encode("utf-8")
        except UnicodeEncodeError:
            row["errors"].append("category entry %d is not valid UTF-8" % index)
            return row
        size += len(encoded)
        if len(encoded) > MAX_CATEGORY_ENTRY_BYTES or size > MAX_CATEGORY_BYTES:
            row["errors"].append("category byte bound exceeded at entry %d" % index)
            return row
    # Preserve original order/duplicates/spelling before any membership decision.
    row["returnedCategories"] = list(categories)
    row["returnedEvidenceComplete"] = True
    row["returnedUtf8Bytes"] = size
    row["returnedCategoriesJsonSha256"] = hashlib.sha256(
        json.dumps(categories, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()
    atoms = [value.split(",") for value in categories]
    if any(not token for group in atoms for token in group):
        row["errors"].append("empty category/group atom; requirement membership unknown")
        return row
    missing = []
    for required in CATEGORIES:
        witness = next((index for index, group in enumerate(atoms) if required in group), None)
        if witness is None:
            missing.append(required)
        else:
            row["matches"].append({"requiredCategory": required, "returnedEntryIndex": witness,
                                   "matchKind": "EXACT" if categories[witness] == required else "GROUP_ATOM"})
    row["missingRequirements"] = missing
    row["status"] = "MISSING_REQUIREMENTS" if missing else "REQUIREMENTS_ENUMERATED"
    return row


def metric_values(response):
    rows = response.get("metrics")
    need(type(rows) is list and len(rows) <= 128, "metrics missing or unbounded")
    values = {}
    for row in rows:
        name, value = row.get("name"), row.get("value")
        need(type(name) is str and name and name not in values, "metric name missing or repeated")
        need(type(value) in (int, float) and math.isfinite(value), "metric not finite")
        values[name] = value
    need(all(key in values for key in ("Timestamp", "ThreadTime", "TaskDuration")),
         "required wall/thread/task metrics missing")
    need(all(values[key] >= 0 for key in ("Timestamp", "ThreadTime", "TaskDuration")),
         "required metrics negative")
    return values


def metric_delta(before, after):
    delta = {}
    for key in ("Timestamp", "ThreadTime", "TaskDuration", "ScriptDuration",
                "V8CompileDuration", "DevToolsCommandDuration"):
        if key in before and key in after:
            need(after[key] >= before[key], key + " moved backward")
            delta[key + "Seconds"] = after[key] - before[key]
    need(delta["TimestampSeconds"] > 0, "metric wall clock did not advance")
    # This is renderer main-thread running time, not solver-only CPU. Do not
    # interpret wall minus CPU as scheduler-ready time or a preemption proof.
    return delta


class RendererCapture:
    def __init__(self, session, root, *, binding):
        self.session, self.root = session, Path(root)
        self.binding = dict(binding)
        self.errors, self.calls, self.buffer_rows = [], [], []
        self.before = self.after = self.deltas = self.version = None
        self.target_before = self.target_after = None
        self.categories = {"status": "NOT_RUN", "requiredCategories": list(CATEGORIES),
                           "returnedCategories": None, "returnedEvidenceComplete": False,
                           "missingRequirements": None}
        self.trace_attempted = self.performance_attempted = False
        self.started = self.finished = False
        self.trace_complete = asyncio.Event()
        self.completion = None
        self.stream = None
        self.bytes = 0
        self.digest = hashlib.sha256()
        self.listeners = []
        self.clocks = []
        self.deadline = 0
        self.buffer_overflow = False

    def error(self, phase, error):
        self.errors.append({"phase": phase, "type": type(error).__name__, "message": str(error)})

    async def send(self, method, params=None):
        remaining = self.deadline - time.monotonic()
        need(remaining > 0, "shared capture deadline expired before " + method)
        before = time.monotonic_ns()
        try:
            return await asyncio.wait_for(self.session.send(method, params or {}), remaining)
        finally:
            # Stream reads can be numerous; preserve their total byte count,
            # while keeping command timing receipts bounded.
            if method != "IO.read" or len(self.calls) < 32:
                self.calls.append({"method": method, "beforeNs": before,
                                   "afterNs": time.monotonic_ns()})

    def complete(self, row):
        if self.completion is not None:
            self.error("Tracing.tracingComplete", ValueError("duplicate completion"))
        else:
            self.completion = dict(row)
            self.stream = row.get("stream")
        self.trace_complete.set()

    def buffer_usage(self, row):
        if len(self.buffer_rows) < 256:
            self.buffer_rows.append(dict(row))
        else:
            self.buffer_overflow = True
        value = row.get("percentFull", row.get("value"))
        if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value < 1:
            self.buffer_overflow = True

    async def marker(self, label):
        row = {"id": "q30-root75-" + label, "beforeNs": time.monotonic_ns(),
               "utc": datetime.now(timezone.utc).isoformat(timespec="microseconds")}
        await self.send("Tracing.recordClockSyncMarker", {"syncId": row["id"]})
        row["afterNs"] = time.monotonic_ns()
        self.clocks.append(row)

    async def start(self, deadline):
        need(not self.started and not self.trace_attempted, "capture start repeated")
        self.deadline = min(deadline, time.monotonic() + CAPTURE_SETUP_SECONDS)
        for event, handler in (("Tracing.tracingComplete", self.complete),
                               ("Tracing.bufferUsage", self.buffer_usage)):
            self.session.on(event, handler)
            self.listeners.append((event, handler))
        self.version = await self.send("Browser.getVersion")
        self.target_before = (await self.send("Target.getTargetInfo")).get("targetInfo")
        need(type(self.target_before) is dict and self.target_before.get("type") == "page" and
             type(self.target_before.get("targetId")) is str and self.target_before["targetId"] and
             self.target_before.get("url") == self.binding["pageUrl"], "target lacks exact page binding")
        self.categories["status"] = "COMMAND_NOT_COMPLETED"
        self.categories = category_preflight(await self.send("Tracing.getCategories"))
        # Persist before rejecting or starting any instrument domain. Even a
        # later capture/cleanup failure must not erase the category response.
        with (self.root / "renderer-category-preflight.json").open("x", encoding="utf-8") as output:
            json.dump({"schema": 1, "qualification": False, "browserProtocol": self.version,
                       "target": self.target_before, "categoryPreflight": self.categories,
                       "traceContentAudit": "NOT_RUN"}, output, indent=2, allow_nan=False)
            output.write("\n")
        need(self.categories["status"] == "REQUIREMENTS_ENUMERATED",
             "trace category preflight " + self.categories["status"] + ": " +
             (", ".join(self.categories["missingRequirements"] or []) or
              "; ".join(self.categories.get("errors", []))))
        self.performance_attempted = True
        await self.send("Performance.enable", {"timeDomain": "threadTicks"})
        self.before = metric_values(await self.send("Performance.getMetrics"))
        self.trace_attempted = True
        await self.send("Tracing.start", {"transferMode": "ReturnAsStream",
            "streamFormat": "json", "streamCompression": "none",
            "bufferUsageReportingInterval": 1000,
            "traceConfig": {"recordMode": "recordUntilFull",
                "traceBufferSizeInKb": TRACE_BUFFER_KIB,
                "enableSampling": False, "enableSystrace": False,
                "includedCategories": list(CATEGORIES)}})
        await self.marker("before-script-release")
        self.started = True

    async def finish(self):
        if self.finished:
            return
        self.finished = True
        finish_deadline = time.monotonic() + CAPTURE_FINISH_SECONDS
        self.deadline = finish_deadline - CAPTURE_CLEANUP_SECONDS
        finish_start = time.monotonic_ns()
        eof = False
        end_attempted = False
        try:
            if self.started:
                self.target_after = (await self.send("Target.getTargetInfo")).get("targetInfo")
                need(type(self.target_after) is dict and all(self.target_after.get(key) ==
                     self.target_before.get(key) for key in ("targetId", "type", "url", "browserContextId")),
                     "capture crossed its target identity")
                need(self.binding.get("terminalScopeVerified") is True,
                     "terminal lacks stable attachment scope")
                self.after = metric_values(await self.send("Performance.getMetrics"))
                self.deltas = metric_delta(self.before, self.after)
                await self.marker("after-terminal-or-error")
        except (Exception, asyncio.CancelledError) as error:
            self.error("final-metrics", error)
        try:
            if self.trace_attempted:
                need(self.deadline > time.monotonic(), "read budget exhausted before Tracing.end")
                end_attempted = True
                await self.send("Tracing.end")
                remaining = self.deadline - time.monotonic()
                need(remaining > 0, "capture deadline before trace completion")
                await asyncio.wait_for(self.trace_complete.wait(), remaining)
                row = self.completion
                need(row.get("dataLossOccurred") is False, "trace data loss or missing loss flag")
                need(type(self.stream) is str and self.stream, "trace completion missing stream")
                need(row.get("traceFormat", "json") == "json" and
                     row.get("streamCompression", "none") == "none", "trace format changed")
                need(not self.buffer_overflow, "trace buffer full or buffer observations invalid")
                with (self.root / "renderer-trace.json").open("xb") as output:
                    for _ in range(MAX_TRACE_BYTES // READ_BYTES + 1):
                        chunk = await self.send("IO.read", {"handle": self.stream, "size": READ_BYTES})
                        text = chunk.get("data")
                        need(type(text) is str, "trace chunk data missing")
                        encoded = chunk.get("base64Encoded", False)
                        need(type(encoded) is bool and type(chunk.get("eof")) is bool,
                             "trace chunk flags invalid")
                        need(len(text) <= (((READ_BYTES + 2) // 3) * 4 if encoded else READ_BYTES),
                             "trace chunk encoded length exceeds bound")
                        data = base64.b64decode(text, validate=True) if encoded else text.encode("utf-8")
                        need(len(data) <= READ_BYTES and self.bytes + len(data) <= MAX_TRACE_BYTES,
                             "trace stream exceeds explicit byte bound")
                        need(data or chunk["eof"], "trace stream made no progress")
                        output.write(data)
                        self.digest.update(data)
                        self.bytes += len(data)
                        if chunk["eof"]:
                            eof = True
                            break
                    need(eof, "trace stream did not reach EOF within bound")
                    need(self.bytes > 0, "trace stream empty")
        except (Exception, asyncio.CancelledError) as error:
            self.error("trace-finish", error)
        finally:
            # Reserve distinct bounded opportunities for end, stream close and
            # domain disable even if a read or final metric consumes its budget.
            self.deadline = finish_deadline - 2 * CAPTURE_CLEANUP_SECONDS / 3
            if self.trace_attempted and not end_attempted:
                try:
                    await self.send("Tracing.end")
                    remaining = self.deadline - time.monotonic()
                    need(remaining > 0, "cleanup end completion budget exhausted")
                    await asyncio.wait_for(self.trace_complete.wait(), remaining)
                except (Exception, asyncio.CancelledError) as error:
                    self.error("cleanup-Tracing.end", error)
            self.deadline = finish_deadline - CAPTURE_CLEANUP_SECONDS / 3
            if self.stream:
                try:
                    await self.send("IO.close", {"handle": self.stream})
                except (Exception, asyncio.CancelledError) as error:
                    self.error("IO.close", error)
            self.deadline = finish_deadline
            if self.performance_attempted:
                try:
                    await self.send("Performance.disable")
                except (Exception, asyncio.CancelledError) as error:
                    self.error("Performance.disable", error)
            for event, handler in self.listeners:
                try:
                    self.session.remove_listener(event, handler)
                except Exception as error:
                    self.error("capture-listener-cleanup", error)
            self.listeners.clear()
        result = {"schema": 1, "status": "PASS_CAPTURE_ONLY" if self.started and eof and
                  self.deltas is not None and not self.errors else "FAIL_CAPTURE",
            "qualification": False, "diagnosticOnly": True, "binding": self.binding,
            "browserProtocol": self.version, "timeDomain": "threadTicks",
            "categoryPreflight": self.categories,
            "targetBefore": self.target_before, "targetAfter": self.target_after,
            "metricsBefore": self.before, "metricsAfter": self.after, "metricDelta": self.deltas,
            "clockMarkers": self.clocks, "commandClocks": self.calls, "traceCompletion": self.completion,
            "bufferUsage": self.buffer_rows, "traceBytes": self.bytes,
            "traceSha256": self.digest.hexdigest() if self.bytes else None, "traceEOF": eof,
            "traceContentAudit": "NOT_RUN",
            "errors": self.errors, "finishElapsedMs": (time.monotonic_ns() - finish_start) / 1e6,
            "bounds": {"traceBufferKiB": TRACE_BUFFER_KIB, "traceFileBytes": MAX_TRACE_BYTES,
                       "categoryEntries": MAX_CATEGORY_ENTRIES, "categoryEntryBytes": MAX_CATEGORY_ENTRY_BYTES,
                       "categoryTotalBytes": MAX_CATEGORY_BYTES,
                       "setupSeconds": CAPTURE_SETUP_SECONDS, "finishSeconds": CAPTURE_FINISH_SECONDS},
            "limits": ["Instrumentation overhead is unknown until selected Edge path is tested.",
                "ThreadTime is renderer main-thread running time including GC/host work, not solver-only CPU.",
                "Wall minus thread time does not identify scheduler-ready time or establish preemption.",
                "Trace GC/task coverage, renderer thread identity and marker mapping require post-run audit.",
                "No per-proof-item or HEALTHY-slice labels exist in this unchanged normal-mode artifact."]}
        with (self.root / "renderer-capture.json").open("x", encoding="utf-8") as output:
            json.dump(result, output, indent=2, allow_nan=False)
            output.write("\n")
        return result
