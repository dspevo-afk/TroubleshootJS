"""Bounded optional renderer CPU metrics; app/qualification outcome is independent."""
import asyncio
import json
import math
from pathlib import Path
import time

CAPTURE_SETUP_SECONDS = 5.0
CAPTURE_FINISH_SECONDS = 5.0
CAPTURE_CLEANUP_SECONDS = 1.5


def need(condition, message):
    if not condition:
        raise ValueError(message)


class CaptureIdentityError(ValueError):
    pass


def metric_values(response):
    need(type(response) is dict, "metrics response is not an object")
    rows = response.get("metrics")
    need(type(rows) is list and len(rows) <= 128, "metrics missing or unbounded")
    values = {}
    for row in rows:
        need(type(row) is dict, "metric row is not an object")
        name, value = row.get("name"), row.get("value")
        need(type(name) is str and 0 < len(name) <= 256 and name not in values,
             "metric name missing, repeated or unbounded")
        need(type(value) in (int, float) and math.isfinite(value), "metric not finite")
        values[name] = value
    need(all(key in values for key in ("Timestamp", "ThreadTime", "TaskDuration")),
         "required wall/thread/task metrics missing")
    need(all(values[key] >= 0 for key in ("Timestamp", "ThreadTime", "TaskDuration")),
         "required metrics negative")
    return values


def metric_delta(before, after):
    delta = {}
    for key in ("Timestamp", "ThreadTime", "TaskDuration", "ScriptDuration",
                "V8CompileDuration", "DevToolsCommandDuration"):
        if key in before and key in after:
            need(after[key] >= before[key], key + " moved backward")
            delta[key + "Seconds"] = after[key] - before[key]
            need(math.isfinite(delta[key + "Seconds"]), key + " delta not finite")
    need(delta["TimestampSeconds"] > 0, "metric wall clock did not advance")
    return delta


class RendererCapture:
    def __init__(self, session, root, *, binding):
        self.session, self.root = session, Path(root)
        self.binding = dict(binding)
        self.errors, self.fatal_errors, self.cleanup_errors, self.calls = [], [], [], []
        self.before = self.after = self.deltas = self.version = None
        self.target_before = self.target_after = None
        self.performance_attempted = self.performance_disabled = False
        self.started = self.finished = self.setup_attempted = False
        self.deadline = 0
        self.setup_elapsed_ms = None

    def error(self, phase, error):
        self.fatal_errors.append({"phase": phase, "type": type(error).__name__, "message": str(error)})

    def unavailable(self, phase, error):
        self.errors.append({"phase": phase, "type": type(error).__name__, "message": str(error)})
        self.deltas = None

    async def send(self, method, params=None):
        remaining = self.deadline - time.monotonic()
        need(remaining > 0, "optional metric slot expired before " + method)
        before = time.monotonic_ns()
        try:
            return await asyncio.wait_for(self.session.send(method, params or {}), remaining)
        finally:
            self.calls.append({"method": method, "beforeNs": before, "afterNs": time.monotonic_ns()})

    def target(self, row, *, previous=None):
        attachment = self.binding.get("attachedDocument", {})
        valid = (type(row) is dict and row.get("type") == "page" and
                 type(row.get("targetId")) is str and bool(row["targetId"]) and
                 row.get("url") == self.binding["pageUrl"] and
                 (not attachment.get("frameId") or row["targetId"] == attachment["frameId"]))
        if previous is not None:
            valid = valid and all(row.get(key) == previous.get(key)
                for key in ("targetId", "type", "url", "browserContextId"))
        if not valid:
            raise CaptureIdentityError("capture crossed its exact page/frame target identity")
        return row

    async def disable(self):
        if not self.performance_attempted or self.performance_disabled:
            return
        try:
            await self.send("Performance.disable")
            self.performance_disabled = True
        except asyncio.CancelledError:
            raise
        except Exception as error:
            self.cleanup_errors.append({"phase": "Performance.disable", "type": type(error).__name__,
                                        "message": str(error)})

    async def start(self, deadline):
        if self.setup_attempted or time.monotonic() >= deadline:
            raise CaptureIdentityError("repeated capture or enclosing route deadline expired")
        self.setup_attempted = True
        began = time.monotonic_ns()
        finish_setup = min(deadline, time.monotonic() + CAPTURE_SETUP_SECONDS)
        self.deadline = finish_setup - CAPTURE_CLEANUP_SECONDS
        phase = "setup-browser-version"
        try:
            self.version = await self.send("Browser.getVersion")
            phase = "setup-target"
            self.target_before = self.target((await self.send("Target.getTargetInfo")).get("targetInfo"))
            phase = "Performance.enable"
            self.performance_attempted = True
            await self.send("Performance.enable", {"timeDomain": "threadTicks"})
            phase = "baseline-metrics"
            self.before = metric_values(await self.send("Performance.getMetrics"))
        except (CaptureIdentityError, asyncio.CancelledError):
            raise
        except Exception as error:
            self.unavailable(phase, error)
            # Optional setup failures get bounded cleanup before app release.
            # The enclosing route/parent job deadlines remain authoritative.
            self.deadline = finish_setup
            await self.disable()
        finally:
            self.setup_elapsed_ms = (time.monotonic_ns() - began) / 1e6
        if time.monotonic() >= deadline:
            raise CaptureIdentityError("enclosing route deadline expired after optional metrics")
        self.started = True

    async def finish(self, deadline=None, verify_scope=None):
        if self.finished:
            return
        self.finished = True
        began = time.monotonic_ns()
        finish_deadline = min(deadline, time.monotonic() + CAPTURE_FINISH_SECONDS) if deadline is not None else time.monotonic() + CAPTURE_FINISH_SECONDS
        self.deadline = finish_deadline - CAPTURE_CLEANUP_SECONDS
        try:
            terminal = self.binding.get("terminalScopeVerified") is True
            timeout_boundary = (self.binding.get("boundaryScopeVerified") is True and
                                self.binding.get("boundaryKind") == "OBSERVER_TIMEOUT")
            if not terminal and not timeout_boundary:
                raise CaptureIdentityError("final boundary lacks stable attachment scope")
            if self.started and self.before is not None and not self.errors:
                self.target_after = self.target((await self.send("Target.getTargetInfo")).get("targetInfo"),
                                                previous=self.target_before)
                self.after = metric_values(await self.send("Performance.getMetrics"))
                self.deltas = metric_delta(self.before, self.after)
                if verify_scope is not None:
                    try:
                        self.binding["finalMetricScope"] = await verify_scope(self.deadline)
                        self.binding["finalMetricScopeVerified"] = True
                    except asyncio.CancelledError:
                        raise
                    except Exception as error:
                        raise CaptureIdentityError("final metric attachment scope: " + str(error)) from error
        except CaptureIdentityError as error:
            self.error("final-scope", error)
            self.deltas = None
        except asyncio.CancelledError as error:
            self.error("final-cancellation", error)
            self.deltas = None
        except Exception as error:
            self.unavailable("final-metrics", error)
        finally:
            self.deadline = finish_deadline
            try:
                await self.disable()
            except asyncio.CancelledError as error:
                self.cleanup_errors.append({"phase": "Performance.disable-cancellation",
                                            "type": type(error).__name__, "message": str(error)})
        cleanup = {"status": "FAIL" if self.cleanup_errors else "PASS",
                   "performanceEnableAttempted": self.performance_attempted,
                   "performanceDisabled": self.performance_disabled if self.performance_attempted else None,
                   "errors": self.cleanup_errors}
        status = "CPU_MEASURED" if self.started and self.deltas is not None and not self.errors else "CPU_UNAVAILABLE"
        if self.fatal_errors or cleanup["status"] != "PASS":
            status = "FAIL_CAPTURE"
        result = {"schema": 2, "status": status, "qualification": False, "diagnosticOnly": True,
            "binding": self.binding, "browserProtocol": self.version, "timeDomain": "threadTicks",
            "tracing": "NOT_ATTEMPTED_METRICS_ONLY", "targetBefore": self.target_before,
            "targetAfter": self.target_after, "metricsBefore": self.before, "metricsAfter": self.after,
            "metricDelta": self.deltas, "commandClocks": self.calls,
            "errors": self.errors, "fatalErrors": self.fatal_errors, "cleanup": cleanup,
            "setupElapsedMs": self.setup_elapsed_ms, "finishElapsedMs": (time.monotonic_ns() - began) / 1e6,
            "bounds": {"setupSeconds": CAPTURE_SETUP_SECONDS, "finishSeconds": CAPTURE_FINISH_SECONDS,
                       "cleanupReserveSeconds": CAPTURE_CLEANUP_SECONDS, "metricRows": 128, "metricNameChars": 256},
            "limits": ["Optional metric unavailability does not abort a safely owned app run.",
                "ThreadTime is aggregate renderer main-thread running time including GC/DOM/host work, not solver-only CPU.",
                "Wall minus thread time does not establish preemption; no GC or per-stage CPU attribution.",
                "App phase wall times come only from the unchanged terminal report; instrumentation overhead is unknown."]}
        with (self.root / "renderer-capture.json").open("x", encoding="utf-8") as output:
            json.dump(result, output, indent=2, allow_nan=False)
            output.write("\n")
        return result
