"""One root75 diagnostic using pinned r4 attachment owner; never qualification."""
import argparse
import asyncio
import hashlib
import importlib.util
import importlib.metadata
import json
from pathlib import Path
import sys
import time

from renderer_capture import RendererCapture, CAPTURE_FINISH_SECONDS, CAPTURE_CLEANUP_SECONDS

R4_SHA = "146101ab19500b06e8d0cb56bde32d90f8439c87b245099c8e1c569b07df85cd"
HOST_SHA = "669c9d1bcd5b221b970809ae17545c86ef79b67edf904ec25df12c26badec5be"
ROOT75_PATH = "circuitjs.html?lang=en&tsjNormalMode=cold&tsjNormalSeed=75"


def imported(path, name, expected):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError("pinned source changed: " + path.name)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def install(host, output):
    base_observer, base_case = host.HtmlAttributeObserver, host.run_case
    captures = []

    class DiagnosticObserver(base_observer):
        async def hold_compiled_script(self, route):
            observer = self
            class InstrumentedRoute:
                request = route.request
                async def abort(self):
                    await route.abort()
                async def continue_(self):
                    observer.capture = RendererCapture(observer.session, output,
                        binding={"rootSeed": "75", "pageUrl": observer.url,
                                 "attachedDocument": dict(observer.script_attachment),
                                 "r4OriginalHostSha256": R4_SHA, "derivedHeadfulHostSha256": HOST_SHA})
                    captures.append(observer.capture)
                    # Runs only after r4 has established the exact held main-frame
                    # script attachment. No app job has started at this point.
                    try:
                        attachment = observer.script_attachment
                        if not isinstance(attachment, dict):
                            raise ValueError("held-script attachment is missing")
                        attachment = dict(attachment)
                        await observer.capture.start(observer.deadline)
                        # A frame read does not discard the owner's frontend DOM
                        # bindings. Let its existing version-fenced acquisition
                        # finish; a frontend refresh is not a new loader/document.
                        frame = (await asyncio.wait_for(observer.session.send("Page.getFrameTree", {}),
                            observer.timeout()))["frameTree"]["frame"]
                        await asyncio.wait_for(observer.html_ready.wait(), observer.timeout())
                        scope = observer.document_scope
                        scope_keys = ("frameId", "loaderId", "pageUrl", "documentBackend", "htmlBackend")
                        checks = {
                            "live-session": not observer.closed and not observer.session_lost,
                            "held-attachment": observer.script_attachment == attachment,
                            "navigation": observer.navigation_epoch == attachment.get("generation"),
                            "main-frame": not frame.get("parentId") and frame.get("id") == attachment.get("frameId"),
                            "loader": frame.get("loaderId") == attachment.get("loaderId"),
                            "page-url": frame.get("url", "") + frame.get("urlFragment", "") == observer.page.url == observer.url == attachment.get("pageUrl"),
                            "owner-ready": observer.html_ready.is_set() and not any(not task.done() for task in observer.tasks),
                            "owner-errors": not observer.errors,
                            "owner-scope": isinstance(scope, dict) and scope == {key: attachment.get(key) for key in scope_keys},
                            "frontend-nodes": type(observer.document_id) is int and type(observer.html_id) is int,
                            "backend-nodes": type(observer.document_backend) is int and type(observer.html_backend) is int and
                                observer.document_backend == attachment.get("documentBackend") and observer.html_backend == attachment.get("htmlBackend"),
                        }
                        observer.capture.binding["setupGuard"] = {"checks": checks,
                            "domAcquisitionEpoch": observer.version, "navigationEpoch": observer.navigation_epoch,
                            "documentNode": observer.document_id, "htmlNode": observer.html_id,
                            "ownerScope": dict(scope) if isinstance(scope, dict) else None,
                            "frame": {key: frame.get(key) for key in ("id", "loaderId", "url", "urlFragment", "parentId")}}
                        rejected = [name for name, accepted in checks.items() if not accepted]
                        if rejected:
                            raise ValueError("diagnostic held-script guard rejected: " + ", ".join(rejected))
                        # No await/query/rebind between this synchronous proof
                        # and invoking the original route's continuation below.
                    except (Exception, asyncio.CancelledError) as setup_error:
                        observer.capture.error("setup-or-scope", setup_error)
                        # The r4 owner has marked its proxy continue action as
                        # started. The proxy must release the ORIGINAL route on
                        # setup failure, as the owner's abort guard cannot retry.
                        try:
                            await asyncio.wait_for(route.abort(), observer.timeout())
                        except (Exception, asyncio.CancelledError) as error:
                            observer.failure("diagnostic-setup-route-abort", error)
                        raise
                    await route.continue_()
            await super().hold_compiled_script(InstrumentedRoute())

        async def close(self):
            try:
                if getattr(self, "capture", None) is not None:
                    finish_deadline = time.monotonic() + CAPTURE_FINISH_SECONDS
                    self.capture.binding["terminalScopeVerified"] = self.terminal_verified
                    self.capture.binding["terminalScope"] = getattr(self, "scope_identity", None)
                    async def final_scope(deadline):
                        original_deadline = self.deadline
                        try:
                            self.deadline = deadline
                            _, _, scope = await self.read_document_scope()
                            attachment = self.script_attachment
                            if (self.closed or self.session_lost or
                                self.navigation_epoch != attachment["generation"] or
                                any(attachment.get(key) != value for key, value in scope.items())):
                                raise ValueError("final boundary crossed its compiled-script attachment")
                            return {**scope, "generation": self.navigation_epoch}
                        finally:
                            self.deadline = original_deadline
                    if not self.terminal_verified and self.capture.started and time.monotonic() >= self.deadline:
                        self.capture.binding["boundaryKind"] = "OBSERVER_TIMEOUT"
                        self.capture.binding["boundaryScopeVerified"] = False
                        try:
                            # Closing read only: the observation is already over.
                            # Reuse the exact r4 scope parser within the SAME final
                            # capture budget; never extend app/route observation.
                            scope = await final_scope(finish_deadline - CAPTURE_CLEANUP_SECONDS)
                            self.capture.binding["boundaryScope"] = scope
                            self.capture.binding["boundaryScopeVerified"] = True
                        except (Exception, asyncio.CancelledError) as error:
                            self.capture.error("timeout-boundary-scope", error)
                    result = await self.capture.finish(finish_deadline, final_scope)
                    if result is None or result["status"] not in ("CPU_MEASURED", "CPU_UNAVAILABLE") or \
                       result["cleanup"]["status"] != "PASS":
                        self.failure("renderer-diagnostic-capture", RuntimeError("capture incomplete"))
            finally:
                await super().close()

    async def run_case(page, base_url, case, case_output):
        if case["path"] != ROOT75_PATH or case["timeoutSeconds"] != 150.0:
            raise ValueError("diagnostic requires exactly frozen root75/150s host observation")
        receipt = await base_case(page, base_url, case, case_output)
        receipt["diagnosticOnly"] = True
        receipt["qualification"] = False
        return receipt

    host.HtmlAttributeObserver = DiagnosticObserver
    host.run_case = run_case
    return captures


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--derived-host", type=Path, required=True)
    parser.add_argument("--app", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--deps", type=Path, required=True)
    args = parser.parse_args()
    if list(sys.version_info[:3]) != [3, 13, 14]:
        raise ValueError("physical host Python version changed")
    for package in ("playwright", "greenlet"):
        origin = Path(importlib.util.find_spec(package).origin).resolve(strict=True)
        if args.deps.resolve(strict=True) not in origin.parents:
            raise ValueError("host dependency loaded outside task-local root")
    if importlib.metadata.version("playwright") != "1.63.0" or \
       importlib.metadata.version("greenlet") != "3.5.6":
        raise ValueError("task-local host dependency versions changed")
    host = imported(args.derived_host, "root75_derived_headful_host", HOST_SHA)
    _, _, cases = host.load_spec(args.spec)
    if len(cases) != 1 or cases[0]["path"] != ROOT75_PATH:
        raise ValueError("only one root75 case is allowed")
    install(host, args.output)
    code = await host.main([str(args.derived_host), str(args.app), str(args.output), str(args.spec)])
    return code


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
