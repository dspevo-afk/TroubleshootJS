$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'q30_utc_duration.ps1')
$q30DurationCases = @(
    @('actual-r4', '2026-10-04T13:29:30.9255187Z', '2026-10-04T13:29:31.4534931Z', 0.5279744),
    @('same-positive-offset', '2026-10-04T17:29:30.9255187+04:00', '2026-10-04T13:29:31.4534931Z', 0.5279744),
    @('same-negative-offset', '2026-10-04T09:29:30.9255187-04:00', '2026-10-04T13:29:31.4534931Z', 0.5279744),
    @('midnight', '2026-10-03T23:59:59.5000000Z', '2026-10-04T00:00:00.2500000Z', 0.75),
    @('negative', '2026-10-04T13:29:31.4534931Z', '2026-10-04T13:29:30.9255187Z', -0.5279744)
)
$q30DurationResults = @()
foreach ($q30DurationCase in $q30DurationCases) {
    $q30DurationActual = Get-Q30UtcElapsedSeconds -StartedUtc $q30DurationCase[1] -FinishedUtc $q30DurationCase[2]
    if ([Math]::Abs($q30DurationActual - $q30DurationCase[3]) -gt 0.00000005) { throw ('Duration mismatch: ' + $q30DurationCase[0]) }
    $q30DurationResults += [ordered]@{ case=$q30DurationCase[0]; actualSeconds=$q30DurationActual; expectedSeconds=$q30DurationCase[3] }
}
$q30DurationReceipt = [ordered]@{ schema=1; status='PASS_TIMEZONE_DURATION_ONLY'; qualification=$false;
    tests=$q30DurationCases.Count; checkedUtc=[DateTime]::UtcNow.ToString('o');
    testsUsedActualSelectedPowerShell=$true; browserLaunched=$false; rawReleaseReceiptChanged=$false;
    selectedLocalTimezone=[TimeZoneInfo]::Local.Id; cases=$q30DurationResults }
$q30DurationOutput = Join-Path $PSScriptRoot 'q30-utc-duration-result.json'
if (Test-Path -LiteralPath $q30DurationOutput) { throw 'Preserve prior test receipt' }
$q30DurationReceipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $q30DurationOutput -Encoding utf8
$q30DurationReceipt | ConvertTo-Json -Depth 6
