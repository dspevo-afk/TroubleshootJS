"""One root75 diagnostic using pinned r4 attachment owner; never qualification."""
import argparse
import asyncio
import hashlib
import importlib.util
import importlib.metadata
import json
from pathlib import Path
import sys

from renderer_capture import RendererCapture

R4_SHA = "146101ab19500b06e8d0cb56bde32d90f8439c87b245099c8e1c569b07df85cd"
HOST_SHA = "669c9d1bcd5b221b970809ae17545c86ef79b67edf904ec25df12c26badec5be"
ROOT75_PATH = "circuitjs.html?lang=en&tsjNormalMode=cold&tsjNormalSeed=75"


def imported(path, name, expected):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError("pinned source changed: " + path.name)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def install(host, output):
    base_observer, base_case = host.HtmlAttributeObserver, host.run_case
    captures = []

    class DiagnosticObserver(base_observer):
        async def hold_compiled_script(self, route):
            observer = self
            class InstrumentedRoute:
                request = route.request
                async def abort(self):
                    await route.abort()
                async def continue_(self):
                    observer.capture = RendererCapture(observer.session, output,
                        binding={"rootSeed": "75", "pageUrl": observer.url,
                                 "attachedDocument": dict(observer.script_attachment),
                                 "r4OriginalHostSha256": R4_SHA, "derivedHeadfulHostSha256": HOST_SHA})
                    captures.append(observer.capture)
                    # Runs only after r4 has established the exact held main-frame
                    # script attachment. No app job has started at this point.
                    try:
                        await observer.capture.start(observer.deadline)
                        _, _, scope = await observer.read_document_scope()
                        attachment = observer.script_attachment
                        if (observer.closed or observer.navigation_epoch != attachment["generation"] or
                            any(attachment.get(key) != value for key, value in scope.items())):
                            raise ValueError("diagnostic setup crossed held-script attachment")
                    except (Exception, asyncio.CancelledError) as setup_error:
                        observer.capture.error("setup-or-scope", setup_error)
                        # The r4 owner has marked its proxy continue action as
                        # started. The proxy must release the ORIGINAL route on
                        # setup failure, as the owner's abort guard cannot retry.
                        try:
                            await asyncio.wait_for(route.abort(), observer.timeout())
                        except (Exception, asyncio.CancelledError) as error:
                            observer.failure("diagnostic-setup-route-abort", error)
                        raise
                    await route.continue_()
            await super().hold_compiled_script(InstrumentedRoute())

        async def close(self):
            try:
                if getattr(self, "capture", None) is not None:
                    self.capture.binding["terminalScopeVerified"] = self.terminal_verified
                    self.capture.binding["terminalScope"] = getattr(self, "scope_identity", None)
                    result = await self.capture.finish()
                    if result is None or result["status"] != "PASS_CAPTURE_ONLY":
                        self.failure("renderer-diagnostic-capture", RuntimeError("capture incomplete"))
            finally:
                await super().close()

    async def run_case(page, base_url, case, case_output):
        if case["path"] != ROOT75_PATH or case["timeoutSeconds"] != 150.0:
            raise ValueError("diagnostic requires exactly frozen root75/150s host observation")
        receipt = await base_case(page, base_url, case, case_output)
        receipt["diagnosticOnly"] = True
        receipt["qualification"] = False
        return receipt

    host.HtmlAttributeObserver = DiagnosticObserver
    host.run_case = run_case
    return captures


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--derived-host", type=Path, required=True)
    parser.add_argument("--app", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--deps", type=Path, required=True)
    args = parser.parse_args()
    if list(sys.version_info[:3]) != [3, 13, 14]:
        raise ValueError("physical host Python version changed")
    for package in ("playwright", "greenlet"):
        origin = Path(importlib.util.find_spec(package).origin).resolve(strict=True)
        if args.deps.resolve(strict=True) not in origin.parents:
            raise ValueError("host dependency loaded outside task-local root")
    if importlib.metadata.version("playwright") != "1.63.0" or \
       importlib.metadata.version("greenlet") != "3.5.6":
        raise ValueError("task-local host dependency versions changed")
    host = imported(args.derived_host, "root75_derived_headful_host", HOST_SHA)
    _, _, cases = host.load_spec(args.spec)
    if len(cases) != 1 or cases[0]["path"] != ROOT75_PATH:
        raise ValueError("only one root75 case is allowed")
    install(host, args.output)
    code = await host.main([str(args.derived_host), str(args.app), str(args.output), str(args.spec)])
    return code


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
