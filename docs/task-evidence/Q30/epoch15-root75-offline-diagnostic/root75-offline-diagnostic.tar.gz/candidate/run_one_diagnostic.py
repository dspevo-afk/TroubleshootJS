"""Audit-only by default. A fresh parent grant is required for one diagnostic launch."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import time
import uuid

HERE = Path(__file__).resolve().parent
R4_SHA = "146101ab19500b06e8d0cb56bde32d90f8439c87b245099c8e1c569b07df85cd"
MATCHED_SHA = "68a5257bac66c667a7adbe50a7eb25049e5f795aa9f93be8bc62e982edb6ffce"
RUNNER_SHA = "19931855b98aeb358f16dcbd94b6c69d81a221191bed2f07697a3ccdcffff5e6"
RECEIPTS_SHA = "5d0865564e39a33a679a7fe5adda0e3ba2c539ce5740034e0a495135619ab0a8"
CANARY_RECEIPT_SHA = "2faa3de7aaade5ce583f547d703f3318af2ebb1af7338843ad3734e9b0a709e2"
LIMITS = {"jobMillis": 90000, "sharedWork": 640, "activeOperationMillis": 5000}
OUTER_MS, CLEANUP_MS, FINAL_RESERVE_MS, WINDOW_SECONDS = 180000, 15000, 20000, 240
CONTROLLER_MS = 220000
MAX_JSON_BYTES = 4 * 1024 * 1024
SPAWN_RESERVE_MS = 1000
PATH = "circuitjs.html?lang=en&tsjNormalMode=cold&tsjNormalSeed=75"


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


def check_deadline(deadline):
    need(deadline is None or time.monotonic_ns() < deadline, "finalization reserve exhausted")


def regular_bounded(path, maximum=MAX_JSON_BYTES, deadline=None):
    check_deadline(deadline)
    info = path.stat()
    need(not path.is_symlink() and not getattr(info, "st_file_attributes", 0) & 0x400 and
         stat.S_ISREG(info.st_mode) and 0 < info.st_size <= maximum,
         "input is not a bounded regular file: " + path.name)
    check_deadline(deadline)


def strict_json(path, deadline=None):
    raw = read_bounded(path, deadline)
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def constant(_):
        raise ValueError("nonfinite JSON constant")
    result = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=pairs,
                        parse_constant=constant)
    check_deadline(deadline)
    return result


def read_bounded(path, deadline=None):
    regular_bounded(path, deadline=deadline)
    with path.open("rb") as source:
        raw = source.read(MAX_JSON_BYTES + 1)
    need(0 < len(raw) <= MAX_JSON_BYTES, "JSON grew beyond byte bound")
    check_deadline(deadline)
    return raw


def reader_json(reader, path, deadline):
    raw = read_bounded(path, deadline)
    obj = json.loads(raw.decode("utf-8"), object_pairs_hook=reader.pairs, parse_constant=reader.bad_constant)
    need(type(obj) is dict, "app/plan JSON object missing")
    check_deadline(deadline)
    return obj, raw


def imported(path, name, expected):
    need(sha(path) == expected, "pinned source changed: " + path.name)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write(path, value):
    with path.open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write("\n")


def parse_utc(text):
    need(type(text) is str and text.endswith("Z"), "grant requires explicit UTC Z times")
    return datetime.fromisoformat(text.replace("Z", "+00:00"))


def host_budget(controller_deadline_ns, now_ns):
    need(type(controller_deadline_ns) is int, "owned controller deadline missing")
    available = (controller_deadline_ns - now_ns) // 1000000 - CLEANUP_MS - FINAL_RESERVE_MS - SPAWN_RESERVE_MS
    need(available >= 105000, "insufficient controller time for root75 and cleanup/finalization")
    return min(OUTER_MS, available)


def controller_status(waited, summary):
    if waited["reason"] is not None or not waited["cleanup"]["cleanupVerified"] or \
       not waited["cleanup"]["drainsComplete"]:
        return "FAIL_CONTROLLER"
    valid = type(summary) is dict and summary.get("inputBindingUnchanged") is True and \
        summary.get("errors") == [] and summary.get("rendererCapture") == "PASS_CAPTURE_ONLY"
    if valid and waited["exitCode"] == 0 and summary.get("status") == "DIAGNOSTIC_CAPTURE_COMPLETE":
        return "CONTROLLER_COMPLETE_DIAGNOSTIC_ONLY"
    if valid and waited["exitCode"] == 1 and summary.get("status") == "DIAGNOSTIC_CAPTURE_COMPLETE_APP_NONPASS":
        return "CONTROLLER_COMPLETE_APP_NONPASS_DIAGNOSTIC_ONLY"
    return "CONTROLLER_COMPLETE_WORKER_FAILURE"


def validate_grant(grant, manifest_sha, now):
    need(type(grant) is dict and set(grant) == {"schema", "parentReference", "windowGranted",
        "quietDesktopConfirmed", "candidateManifestSha256", "windowStartUtc", "windowEndUtc",
        "maximumCases", "qualification", "limits"}, "grant fields differ")
    need(grant["schema"] == 1 and grant["windowGranted"] is True and
         grant["quietDesktopConfirmed"] is True and grant["qualification"] is False,
         "no explicit quiet-window grant")
    need(type(grant["parentReference"]) is str and 0 < len(grant["parentReference"]) <= 128,
         "parent coordination reference missing")
    need(grant["candidateManifestSha256"] == manifest_sha and
         type(grant["maximumCases"]) is int and grant["maximumCases"] == 1 and
         grant["limits"] == LIMITS, "grant candidate/case/budget binding differs")
    start, end = parse_utc(grant["windowStartUtc"]), parse_utc(grant["windowEndUtc"])
    need((end - start).total_seconds() == WINDOW_SECONDS and start <= now < end,
         "grant not in fresh exact 240-second window")
    need((end - now).total_seconds() * 1000 >= OUTER_MS + CLEANUP_MS + FINAL_RESERVE_MS,
         "insufficient operation/cleanup/finalization reserve")
    return end


def audit(args, deadline=None):
    t0 = time.monotonic_ns()
    phases = []
    def phase(name):
        check_deadline(deadline)
        row = {"phase": name, "elapsedMs": (time.monotonic_ns() - t0) / 1e6}
        phases.append(row)
        print(json.dumps({"offlineInputAudit": row}), file=sys.stderr, flush=True)
    phase("candidate-pins")
    manifest_path = HERE / "candidate-manifest.json"
    manifest = strict_json(manifest_path)
    need(manifest["qualification"] is False and manifest["autoRun"] is False and
         manifest["maximumCases"] == 1 and manifest["limits"] == LIMITS,
         "candidate scope changed")
    for name, row in manifest["sourcePins"].items():
        need(Path(name).name == name and name.endswith(".py"), "nonlocal candidate filename")
        path = HERE / name
        need(path.stat().st_size == row["size"] and sha(path) == row["sha256"],
             "candidate source changed: " + name)
    need(sha(args.r4_original) == R4_SHA, "passed r4 original changed")
    old = ('            str(profile), channel="msedge", headless=True,\n'
           '            viewport={"width": 1440, "height": 1000},\n'
           '            args=["--disable-background-timer-throttling",\n'
           '                  "--disable-renderer-backgrounding"])')
    new = ('            str(profile), channel="msedge", headless=False,\n'
           '            viewport={"width": 1440, "height": 1000})')
    original = args.r4_original.read_text(encoding="utf-8-sig")
    derived = (HERE / "headful_attribute_host.py").read_text(encoding="utf-8-sig")
    need(original.count(old) == 1 and original.replace(old, new) == derived,
         "derived host differs beyond the reviewed launch clause")
    receipt = args.repo / "docs/task-evidence/Q30/epoch15-offline-attachment-r4/actual-edge-result.json"
    need(sha(receipt) == CANARY_RECEIPT_SHA and strict_json(receipt)["status"] ==
         "PASS_FIVE_FIXTURE_CANARY_ONLY", "passed attachment receipt changed")
    phase("frozen-input-loader")
    pointer = strict_json(args.pointer, deadline)
    preparation = Path(pointer["taskRoot"])
    for path in (preparation / "isolated/source-snapshot.json", preparation / "isolated/prepare-receipt.json",
                 preparation / "scale-plan.json", preparation / "acceptance-plan.json"):
        regular_bounded(path, deadline=deadline)
    matched = imported(args.matched_helper, "root75_matched_input_loader", MATCHED_SHA)
    variant = matched.load_variant("current", args.pointer.resolve(strict=True))
    need(variant["plan"]["limits"] == LIMITS and variant["rootRow"]["seed"] == "75",
         "root75 current plan mismatch")
    phase("repository-1354-inventory")
    repo_state = matched.inventory(args.repo, variant["snapshot"]["files"], True)
    phase("prepared-app-inventory")
    app_state = matched.app_state(variant)
    phase("prepared-app-complete-manifest")
    derived_host = imported(HERE / "headful_attribute_host.py", "root75_input_manifest_owner",
                            manifest["sourcePins"]["headful_attribute_host.py"]["sha256"])
    actual_app = derived_host.capture_input_manifest(variant["app"])
    expected_app = variant["plan"]["preparedInputIdentity"]
    for actual_key, expected_key in (("sha256", "combinedSha256"), ("sourceSha256", "sourceSha256"),
        ("webSha256", "webSha256"), ("fileCount", "fileCount"),
        ("sourceFileCount", "sourceFileCount"), ("webFileCount", "webFileCount")):
        need(actual_app[actual_key] == expected_app[expected_key], "prepared app identity differs: " + actual_key)
    phase("external-owner-pins")
    need(sha(args.runner) == RUNNER_SHA, "maintained cleanup runner changed")
    need(sha(args.runner.parent / "receipts.py") == RECEIPTS_SHA, "runner receipt dependency changed")
    reader = args.repo / "tests/qualification/q30-scale-acceptance/q30_scale_reader.py"
    reader_base = args.repo / "tests/qualification/q30-normal-screen/q30_screen_reader.py"
    reader_freeze = args.repo / "tests/qualification/q30-scale-acceptance/freeze_plan.py"
    report = {"schema": 1, "status": "PASS_OFFLINE_INPUT_AUDIT", "qualification": False,
        "browserLaunched": False, "q30CasesLaunched": 0,
        "candidateManifestSha256": sha(manifest_path), "sourceIdentity": variant["pointer"]["sourceIdentity"],
        "baseHead": variant["pointer"]["baseHead"],
        "repositoryInputs": {"fileCount": len(repo_state), "mapSha256": json_sha(repo_state)},
        "preparedApp": {"stateSha256": json_sha(app_state),
            "inputIdentity": {key: actual_app[key] for key in
                ("sha256", "sourceSha256", "webSha256", "fileCount", "sourceFileCount", "webFileCount")}},
        "passedCanaryReceiptSha256": CANARY_RECEIPT_SHA,
        "sourcePins": manifest["sourcePins"],
        "dependencies": {"maintainedRunner": sha(args.runner), "inputLoader": sha(args.matched_helper),
            "runnerReceipts": RECEIPTS_SHA,
            "reader": sha(reader), "readerBase": sha(reader_base), "readerFreeze": sha(reader_freeze),
            "pointer": sha(args.pointer), **{key: sha(path) for key, path in variant["paths"].items()}},
        "phaseClocks": phases, "operationElapsedMs": (time.monotonic_ns() - t0) / 1e6}
    check_deadline(deadline)
    return report, variant


def controlled_launch(args):
    """Hard outer job bounds worker audit/reader I/O as well as the nested host."""
    manifest_path = HERE / "candidate-manifest.json"
    manifest, grant = strict_json(manifest_path), strict_json(args.grant_json)
    end = validate_grant(grant, sha(manifest_path), datetime.now(timezone.utc))
    need((end - datetime.now(timezone.utc)).total_seconds() * 1000 >= CONTROLLER_MS + CLEANUP_MS,
         "insufficient controller/cleanup reserve")
    for name, row in manifest["sourcePins"].items():
        need(Path(name).name == name and sha(HERE / name) == row["sha256"], "controller source pin changed")
    need(sha(args.runner.parent / "receipts.py") == RECEIPTS_SHA, "controller receipts changed")
    sys.path.insert(0, str(args.runner.parent.resolve(strict=True)))
    runner = imported(args.runner, "root75_outer_controller_runner", RUNNER_SHA)
    need(Path(sys.modules["receipts"].__file__).resolve(strict=True) ==
         (args.runner.parent / "receipts.py").resolve(strict=True), "controller receipts import escaped")
    executable = args.host_python.resolve(strict=True)
    root = Path(tempfile.mkdtemp(prefix="q30-root75-diagnostic-controller-"))
    argv = [str(executable), "-B", str(HERE / "run_one_diagnostic.py"), "--launch", "--owned-worker"]
    controller_deadline_ns = time.monotonic_ns() + CONTROLLER_MS * 1000000
    argv.extend(["--controller-deadline-ns", str(controller_deadline_ns)])
    for name in ("repo", "pointer", "matched_helper", "runner", "r4_original", "grant_json", "host_python", "deps"):
        argv.extend(["--" + name.replace("_", "-"), str(getattr(args, name).resolve(strict=True))])
    k, child, waited = runner._api(), None, None
    result = {"schema": 1, "status": "FAIL_CONTROLLER", "qualification": False,
        "outerTimeoutMs": CONTROLLER_MS, "cleanupLimitMs": CLEANUP_MS,
        "candidateManifestSha256": sha(manifest_path), "windowEndUtc": grant["windowEndUtc"],
        "workerMonotonicDeadlineNs": controller_deadline_ns,
        "taskRoot": str(root), "errors": []}
    try:
        validate_grant(grant, sha(manifest_path), datetime.now(timezone.utc))
        child = runner._spawn(k, {"executable": executable}, argv, root)
        result["process"] = {"pid": child["pid"], "creationFileTimeTicks": child["creationTicks"],
            "executable": child["image"], "commandSha256": child["commandSha256"],
            "resumeMonotonicNs": child["resumeNs"]}
        write(root / "launch.json", {**result, "status": "RUNNING"})
        waited = runner._wait(k, child, CONTROLLER_MS)
        result["operation"] = waited
        try:
            result["workerSummary"] = strict_json(root / "stdout.log")
        except Exception as error:
            result["workerSummary"] = None
            result["workerSummaryError"] = type(error).__name__ + ": " + str(error)
        result["status"] = controller_status(waited, result["workerSummary"])
    except BaseException as error:
        result["errors"].append(type(error).__name__ + ": " + str(error))
        if child is not None and waited is None:
            try:
                result["emergencyCleanup"] = runner._wait(k, child, 0)
            except BaseException as cleanup_error:
                result["errors"].append("controller emergency cleanup: " + repr(cleanup_error))
    finally:
        if child is not None:
            for key in ("job", "thread", "proc"):
                if child.get(key) and not k.CloseHandle(child[key]):
                    result["errors"].append("controller CloseHandle failed: " + key)
                child[key] = None
        if result["errors"]:
            result["status"] = "FAIL_CONTROLLER"
        write(root / "controller-result.json", result)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "CONTROLLER_COMPLETE_DIAGNOSTIC_ONLY" else 1


def launch(args, before, variant):
    need(args.grant_json is not None, "launch requires a new parent grant file")
    grant = strict_json(args.grant_json)
    validate_grant(grant, before["candidateManifestSha256"], datetime.now(timezone.utc))
    host_cap_ms = host_budget(args.controller_deadline_ns, time.monotonic_ns())
    need(sys.platform == "win32", "selected Windows host required")
    executable = args.host_python.resolve(strict=True)
    need(executable.is_absolute() and executable.is_file(), "physical Python executable missing")
    deps = args.deps.resolve(strict=True)
    need((deps / "playwright").is_dir() and (deps / "greenlet").is_dir(), "task-local deps missing")
    # The marker is exclusive and candidate/grant-bound. Repeating this helper
    # with the same grant cannot launch a second case.
    marker = HERE / ("launch-used-" + sha(args.grant_json) + ".json")
    write(marker, {"status": "ONE_DIAGNOSTIC_LAUNCH_RESERVED", "qualification": False,
                   "parentReference": grant["parentReference"], "grantSha256": sha(args.grant_json),
                   "candidateManifestSha256": before["candidateManifestSha256"]})
    sys.path.insert(0, str(args.runner.parent.resolve(strict=True)))
    runner = imported(args.runner, "root75_maintained_runner", RUNNER_SHA)
    need(Path(sys.modules["receipts"].__file__).resolve(strict=True) ==
         (args.runner.parent / "receipts.py").resolve(strict=True), "runner receipt import escaped owner")
    root = Path(tempfile.mkdtemp(prefix="q30-root75-renderer-diagnostic-"))
    write(root / "input-audit-before.json", before)
    spec = root / "host-spec.json"
    write(spec, {"cases": [{"name": "cold-75", "path": PATH,
        "stateAttribute": "data-tsj-q30-normal-state", "reportAttribute": "data-tsj-q30-normal-report",
        "expectedPrefix": "SCREEN_DONE", "terminalPrefixes": ["SCREEN_DONE"], "timeoutSeconds": 150}]})
    output = root / "host-output"
    argv = [str(executable), "-B", str(HERE / "instrumented_host.py"),
            "--derived-host", str(HERE / "headful_attribute_host.py"),
            "--app", str(variant["app"]), "--output", str(output), "--spec", str(spec), "--deps", str(deps)]
    result = {"schema": 1, "status": "DIAGNOSTIC_FAIL", "qualification": False,
        "diagnosticOnly": True, "rootSeed": "75", "maximumCases": 1, "limits": LIMITS,
        "maximumInnerHostCapMs": OUTER_MS, "controllerMonotonicDeadlineNs": args.controller_deadline_ns,
        "taskRoot": str(root), "parentReference": grant["parentReference"],
        "windowEndUtc": grant["windowEndUtc"], "candidateManifestSha256": before["candidateManifestSha256"],
        "errors": [], "applicationAudit": "NOT_RUN", "rendererCapture": "NOT_RUN"}
    k, child, waited = runner._api(), None, None
    environment = {key: os.environ.get(key) for key in ("PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "PYTHONIOENCODING")}
    try:
        os.environ.update(PYTHONPATH=str(deps), PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
        validate_grant(grant, before["candidateManifestSha256"], datetime.now(timezone.utc))
        host_cap_ms = host_budget(args.controller_deadline_ns, time.monotonic_ns())
        result["innerHostCapMs"] = host_cap_ms
        child = runner._spawn(k, {"executable": executable}, argv, root)
        result["ownedProcess"] = {"pid": child["pid"], "creationFileTimeTicks": child["creationTicks"],
            "executable": child["image"], "commandSha256": child["commandSha256"],
            "resumeMonotonicNs": child["resumeNs"]}
        write(root / "launch.json", {**result, "status": "RUNNING"})
        waited = runner._wait(k, child, host_cap_ms)
        result["operation"] = waited
        result["drains"] = [{"bytes": d.count, "overflow": d.overflow.is_set(), "errors": d.errors,
            "readerAlive": d.thread.is_alive(), "streamClosed": d.streamClosed} for d in child["drains"]]
        final_started_ns = time.monotonic_ns()
        final_deadline = final_started_ns + FINAL_RESERVE_MS * 1000000
        host = strict_json(output / "result.json", final_deadline)
        capture = strict_json(output / "renderer-capture.json", final_deadline)
        result["hostObservation"] = {key: host.get(key) for key in ("outcome", "cleanup", "errors", "inputAudit")}
        result["rendererCapture"] = capture["status"]
        # The modified diagnostic host is deliberately excluded from acceptance
        # host auditing. The unchanged maintained reader audits the app alone.
        reader_path = args.repo / "tests/qualification/q30-scale-acceptance/q30_scale_reader.py"
        reader = imported(reader_path, "root75_diagnostic_app_reader", before["dependencies"]["reader"])
        report_path = output / "cases/001-cold-75.report.json"
        regular_bounded(report_path, deadline=final_deadline)
        regular_bounded(variant["paths"]["plan"], deadline=final_deadline)
        regular_bounded(variant["paths"]["acceptance"], deadline=final_deadline)
        report, raw = reader_json(reader, report_path, final_deadline)
        plan, plan_raw = reader_json(reader, variant["paths"]["plan"], final_deadline)
        app_audit = reader.evaluate(report, raw, plan, plan_raw, acceptance_path=variant["paths"]["acceptance"])
        check_deadline(final_deadline)
        result["applicationAudit"] = app_audit
        result["appReportSha256"] = hashlib.sha256(raw).hexdigest()
        clean = waited["cleanup"]
        valid = (waited["reason"] is None and waited["exitCode"] == 0 and clean["cleanupVerified"] and
            clean["drainsComplete"] and all(not d["overflow"] and not d["errors"] and
            not d["readerAlive"] and d["streamClosed"] for d in result["drains"]) and
            host["outcome"] == "PASS" and host["errors"] == [] and host["inputAudit"]["status"] == "PASS" and
            host["cleanup"]["status"] == "PASS" and host["cleanup"]["serverStopped"] is True and
            host["cleanup"]["ownedSurvivors"] == [] and host["cleanup"]["errors"] == [] and
            capture["status"] == "PASS_CAPTURE_ONLY")
        if valid:
            result["status"] = "DIAGNOSTIC_CAPTURE_COMPLETE" if app_audit["status"] == "APP_PASS" else \
                "DIAGNOSTIC_CAPTURE_COMPLETE_APP_NONPASS"
    except BaseException as error:
        result["errors"].append(type(error).__name__ + ": " + str(error))
        if child is not None and waited is None:
            try:
                result["emergencyCleanup"] = runner._wait(k, child, 0)
            except BaseException as cleanup_error:
                result["errors"].append("emergency cleanup: " + repr(cleanup_error))
    finally:
        if child is not None:
            for key in ("job", "thread", "proc"):
                if child.get(key) and not k.CloseHandle(child[key]):
                    result["errors"].append("CloseHandle failed: " + key)
                child[key] = None
        for key, old in environment.items():
            if old is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = old
        try:
            if "final_started_ns" not in locals():
                final_started_ns = time.monotonic_ns()
                final_deadline = final_started_ns + FINAL_RESERVE_MS * 1000000
            after, _ = audit(args, final_deadline)
            after.pop("operationElapsedMs")
            after.pop("phaseClocks")
            stable_before = {key: value for key, value in before.items()
                             if key not in ("operationElapsedMs", "phaseClocks")}
            result["inputBindingUnchanged"] = after == stable_before
            write(root / "input-audit-after.json", after)
            if not result["inputBindingUnchanged"]:
                result["errors"].append("input binding changed")
        except Exception as error:
            result["inputBindingUnchanged"] = False
            result["errors"].append("final input audit: " + repr(error))
        result["finalization"] = {"budgetMs": FINAL_RESERVE_MS,
            "elapsedMs": (time.monotonic_ns() - final_started_ns) / 1e6,
            "deadlineExceeded": time.monotonic_ns() >= final_deadline,
            "method": "cooperative phase/file checks plus hard220s owned outer controller for blocked I/O"}
        if result["finalization"]["deadlineExceeded"]:
            result["errors"].append("finalization reserve exhausted")
        if result["errors"]:
            result["status"] = "DIAGNOSTIC_FAIL"
        write(root / "diagnostic-result.json", result)
    print(json.dumps({key: result.get(key) for key in
                     ("status", "taskRoot", "rendererCapture", "inputBindingUnchanged", "errors")}, indent=2))
    return 0 if result["status"] == "DIAGNOSTIC_CAPTURE_COMPLETE" else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "pointer", "matched-helper", "runner", "r4-original"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--launch", action="store_true")
    parser.add_argument("--grant-json", type=Path)
    parser.add_argument("--host-python", type=Path)
    parser.add_argument("--deps", type=Path)
    parser.add_argument("--owned-worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--controller-deadline-ns", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    # Refuse a launch without the grant before input imports, native APIs,
    # environment mutations, temp directories or processes are created.
    if args.launch:
        need(args.grant_json is not None and args.host_python is not None and args.deps is not None,
             "launch requires parent grant, physical Python and task-local deps")
        validate_grant(strict_json(args.grant_json), sha(HERE / "candidate-manifest.json"),
                       datetime.now(timezone.utc))
        if not args.owned_worker:
            return controlled_launch(args)
    before, variant = audit(args)
    if not args.launch:
        print(json.dumps(before, indent=2, allow_nan=False))
        return 0
    return launch(args, before, variant)


if __name__ == "__main__":
    sys.exit(main())
