"""Serial, bounded offline fixtures and current-input audit; no live launch."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import time
import unittest

import offline_checks
import run_one_diagnostic as launcher

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "pointer", "matched-helper", "runner", "r4-original"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    start = time.monotonic_ns()
    manifest = launcher.strict_json(HERE / "candidate-manifest.json")
    before = {name: launcher.sha(HERE / name) for name in manifest["sourcePins"]}
    for name, row in manifest["sourcePins"].items():
        launcher.need(before[name] == row["sha256"], "unfrozen source: " + name)
        ast.parse((HERE / name).read_text(encoding="utf-8-sig"), filename=name)
    suite = unittest.defaultTestLoader.loadTestsFromModule(offline_checks)
    tested = unittest.TextTestRunner(verbosity=2).run(suite)
    audit = None
    errors = []
    if tested.wasSuccessful():
        try:
            audit, _ = launcher.audit(args, start + 25000000000)
        except Exception as error:
            errors.append(type(error).__name__ + ": " + str(error))
    after = {name: launcher.sha(HERE / name) for name in manifest["sourcePins"]}
    receipt = {"schema": 1, "status": "PASS_OFFLINE_ONLY" if tested.wasSuccessful() and audit and
        not errors and before == after else "FAIL", "qualification": False,
        "browserLaunched": False, "q30CasesLaunched": 0, "nativeCpuSamples": 0,
        "tests": tested.testsRun, "failures": len(tested.failures), "errors": errors,
        "testErrors": len(tested.errors), "skipped": len(tested.skipped),
        "sourcePins": before, "sourceUnchanged": before == after,
        "candidateManifestSha256": launcher.sha(HERE / "candidate-manifest.json"),
        "inputAudit": audit, "fixtureRoot": str(offline_checks.ROOT),
        "elapsedMs": (time.monotonic_ns() - start) / 1e6}
    launcher.write(offline_checks.ROOT / "final-offline-result.json", receipt)
    print(json.dumps(receipt, indent=2, allow_nan=False))
    return 0 if receipt["status"] == "PASS_OFFLINE_ONLY" else 1


if __name__ == "__main__":
    raise SystemExit(main())
