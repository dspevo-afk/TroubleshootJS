"""Strict original-cohort sequence; stop and preserve every nonpass."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser=argparse.ArgumentParser()
for name in ['repo','prepared','plan','acceptance','output']:
    parser.add_argument(name,type=Path)
parser.add_argument('--start',type=int,default=0)
parser.add_argument('--count',type=int)
parser.add_argument('--host-python',type=Path,required=True)
args=parser.parse_args()
assert not args.output.exists()
plan=json.loads(args.plan.read_text())
raw_acceptance=args.acceptance.read_bytes()
acceptance=json.loads(raw_acceptance)
bundled=json.loads((args.repo/'tests/qualification/q30-scale-acceptance/acceptance-plan.json').read_text())
snapshot=json.loads((args.prepared/'source-snapshot.json').read_text())
assert snapshot['baseHead']==acceptance['baseHead']==plan['baseHead']
assert snapshot['sourceIdentity']==plan['sourceIdentity']
assert json.dumps({k:v for k,v in acceptance.items() if k!='baseHead'},sort_keys=True)==json.dumps({k:v for k,v in bundled.items() if k!='baseHead'},sort_keys=True)
assert plan['acceptancePlanSha256']==hashlib.sha256(raw_acceptance).hexdigest()
assert plan['coldOrder']==acceptance['coldOrder']==bundled['coldOrder']
assert len(plan['coldOrder'])==77 and len(set(plan['coldOrder']))==77
assert 0 <= args.start < 77 and args.count is not None and 0 < args.count <= 77-args.start
assert plan['limits']=={'jobMillis':90000,'sharedWork':640,'activeOperationMillis':5000}
args.output.mkdir()
order=plan['coldOrder']
chosen=order[args.start:args.start+args.count if args.count is not None else None]
record={'schema':1,'startedUtc':datetime.now(timezone.utc).isoformat(),'state':'RUNNING','pid':os.getpid(),
        'executable':sys.executable,'plan':str(args.plan),'acceptancePlanSha256':plan['acceptancePlanSha256'],
        'planRootCount':77,'selectedRoots':chosen,'collectionPolicy':'Stop on every nonpass; never substitute or waive a root','rows':[]}
def save(): (args.output/'sequence.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for index,seed in enumerate(chosen,args.start+1):
    slug=f'{index:03d}-seed{seed}'
    destination=args.output/slug
    spec={'cases':[{'name':'cold-'+seed,'path':'circuitjs.html?lang=en&tsjNormalMode=cold&tsjNormalSeed='+seed,
                   'stateAttribute':'data-tsj-q30-normal-state','reportAttribute':'data-tsj-q30-normal-report',
                   'expectedPrefix':'SCREEN_DONE','terminalPrefixes':['SCREEN_DONE'],'timeoutSeconds':150}]}
    spec_path=args.output/(slug+'-spec.json')
    spec_path.write_text(json.dumps(spec,indent=2)+'\n')
    row={'index':index,'rootSeed':seed,'startedUtc':datetime.now(timezone.utc).isoformat(),'status':'RUNNING'}
    record['rows'].append(row)
    save()
    print('START',index,seed,flush=True)
    started=time.monotonic()
    with (args.output/(slug+'-host.log')).open('w') as log:
        host=subprocess.run([str(args.host_python),'-B',str(args.prepared/'host/normal_screen_host.py'),str(args.prepared/'app'),
                             str(destination),str(spec_path)],stdout=log,stderr=subprocess.STDOUT)
    row['hostExitCode']=host.returncode
    row['hostSeconds']=round(time.monotonic()-started,3)
    report=destination/'cases'/('001-cold-'+seed+'.report.json')
    command=[sys.executable,str(args.repo/'tests/qualification/q30-scale-acceptance/q30_scale_reader.py'),
             '--report',str(report),'--plan',str(args.plan),'--host-record',str(destination/'result.json'),
             '--acceptance-plan',str(args.acceptance)]
    read=subprocess.run(command,capture_output=True,text=True)
    (args.output/(slug+'-reader.json')).write_text(read.stdout)
    (args.output/(slug+'-reader.stderr.txt')).write_text(read.stderr)
    row['readerExitCode']=read.returncode
    try:
        checked=json.loads(read.stdout)
        row.update({'status':checked['status'],'applicationOutcome':checked.get('app',{}).get('applicationOutcome'),
                    'metrics':checked.get('app',{}).get('metrics'),'hostStatus':(checked.get('host') or {}).get('status')})
        if checked.get('app',{}).get('errors'): row['readerErrors']=checked['app']['errors']
        host_record=json.loads((destination/'result.json').read_text())
        row['cleanup']=host_record.get('cleanup')
    except Exception as error:
        row.update({'status':'READ_ERROR','error':str(error)})
    row['finishedUtc']=datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps(row),flush=True)
    if host.returncode!=0 or read.returncode!=0 or row['status']!='APP_PASS' or row['hostStatus']!='HOST_PASS':
        record['state']='STOPPED_NONPASS'
        break
else:
    record['state']='COMPLETED'
record['finishedUtc']=datetime.now(timezone.utc).isoformat()
save()
raise SystemExit(0 if record['state']=='COMPLETED' else 1)
