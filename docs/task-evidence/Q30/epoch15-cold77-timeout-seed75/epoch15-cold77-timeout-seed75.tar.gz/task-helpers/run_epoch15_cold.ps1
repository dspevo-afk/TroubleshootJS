param([ValidateSet('cold-pilot','cold-rest')][string]$Batch='cold-pilot')
$ErrorActionPreference='Stop'
$workspace=$PSScriptRoot
$repo='$REPO'
$binding=Get-Content -LiteralPath (Join-Path $workspace 'epoch15-task-pointer.json') -Raw | ConvertFrom-Json
$integration=Get-Content -LiteralPath (Join-Path $workspace 'integration-pointer.json') -Raw | ConvertFrom-Json
if($binding.taskRoot -ne $integration.taskRoot -or $binding.baseHead -ne $integration.baseHead){throw 'Epoch15 task pointer differs from integrated candidate'}
$task=$binding.taskRoot
$snapshot=Get-Content -LiteralPath (Join-Path $task 'isolated\source-snapshot.json') -Raw | ConvertFrom-Json
if($snapshot.sourceIdentity -ne $binding.sourceIdentity -or $snapshot.baseHead -ne $binding.baseHead -or $snapshot.files.Count -ne 1354){throw 'Prepared source identity/base/count differs'}
foreach($row in $snapshot.files){if((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $repo $row.path)).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Consumed source changed: '+$row.path)}}
$planPath=Join-Path $task 'scale-plan.json'
$acceptance=Join-Path $task 'acceptance-plan.json'
if((Get-FileHash -Algorithm SHA256 -LiteralPath $acceptance).Hash.ToLowerInvariant() -ne $binding.continuedPlanSha256){throw 'Acceptance bytes changed'}
$plan=Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
if($plan.sourceIdentity -ne $binding.sourceIdentity -or $plan.cases.Count -ne 77 -or $plan.coldOrder.Count -ne 77){throw 'Frozen plan binding differs'}
$canaries=Get-Content -LiteralPath (Join-Path $task 'compiled-canaries-py313-stage-result.json') -Raw | ConvertFrom-Json
if($canaries.status -ne 'PASS'){throw 'Compiled canaries/export not passing'}
$output=Join-Path $task $Batch
$result=Join-Path $task ($Batch+'-result.json')
$log=Join-Path $task ($Batch+'.log')
$ownership=Join-Path $task ($Batch+'-ownership.json')
if((Test-Path -LiteralPath $output) -or (Test-Path -LiteralPath $result) -or (Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $ownership)){throw 'Preserve existing cold evidence'}
if($Batch -eq 'cold-rest'){
    $pilot=Get-Content -LiteralPath (Join-Path $task 'cold-pilot\sequence.json') -Raw | ConvertFrom-Json
    if($pilot.state -ne 'COMPLETED' -or $pilot.rows.Count -ne 3){throw 'Three-case pilot not complete'}
    foreach($row in $pilot.rows){if($row.status -ne 'APP_PASS' -or $row.hostStatus -ne 'HOST_PASS' -or $row.hostExitCode -ne 0 -or $row.readerExitCode -ne 0){throw 'Pilot nonpass'}}
}
$self=Get-CimInstance Win32_Process -Filter ('ProcessId='+$PID)
@{schema=1;pid=$PID;createdUtc=$self.CreationDate.ToUniversalTime().ToString('o');executable=$self.ExecutablePath;command=$self.CommandLine;taskRoot=$task;batch=$Batch;head=$binding.baseHead;sourceIdentity=$binding.sourceIdentity} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ownership
$python='$USER_HOME\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$env:PYTHONPATH='$OS_TEMP\q30-finish-0fa2512465\deps'
$env:PYTHONDONTWRITEBYTECODE='1'
$started=[DateTime]::UtcNow
$timer=[Diagnostics.Stopwatch]::StartNew()
$start=if($Batch -eq 'cold-pilot'){0}else{3}
$count=if($Batch -eq 'cold-pilot'){3}else{74}
try{& $python -B -u (Join-Path $workspace 'run_epoch15_cold_sequence.py') $repo (Join-Path $task 'isolated') $planPath $acceptance $output --start $start --count $count --host-python 'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_3.13.3824.0_x64__qbz5n2kfra8p0\python3.13.exe' *> $log; $code=$LASTEXITCODE}
catch{$_ | Out-String | Add-Content -LiteralPath $log; $code=1}
$timer.Stop()
$sequence=if(Test-Path -LiteralPath (Join-Path $output 'sequence.json')){Get-Content -LiteralPath (Join-Path $output 'sequence.json') -Raw | ConvertFrom-Json}else{$null}
$complete=$null -ne $sequence -and $sequence.state -eq 'COMPLETED' -and $sequence.rows.Count -eq $count
@{schema=1;head=$binding.baseHead;sourceIdentity=$binding.sourceIdentity;batch=$Batch;startedUtc=$started.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');elapsedSeconds=$timer.Elapsed.TotalSeconds;exitCode=$code;status=if($code -eq 0 -and $complete){'COMMAND_PASS_PENDING_RECEIPT_REVIEW'}else{'FAIL'};complete=$complete;firstIndex=($start+1);count=$count;acceptancePlanSha256=$binding.continuedPlanSha256;frozenPlanSha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $planPath).Hash.ToLowerInvariant();cleanupElapsedSeconds='Per-case host records'} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $result
Get-Content -LiteralPath $log -Tail 3
if($code -eq 0 -and -not $complete){exit 1}
exit $code
