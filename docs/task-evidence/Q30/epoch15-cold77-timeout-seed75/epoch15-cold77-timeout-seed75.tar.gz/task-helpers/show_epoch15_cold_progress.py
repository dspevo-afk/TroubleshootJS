"""Read the existing cold sequence; never launch or alter qualification work."""
import json
from datetime import datetime, timezone
from pathlib import Path

workspace = Path(__file__).resolve().parent
pointer = json.loads((workspace / 'epoch15-task-pointer.json').read_text(encoding='utf-8'))
task = Path(pointer['taskRoot'])
def read_sequence(path):
    return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {'state': 'NOT_STARTED', 'rows': []}

pilot = read_sequence(task / 'cold-pilot/sequence.json')
rest = read_sequence(task / 'cold-rest/sequence.json')
rows = pilot['rows'] + rest['rows']
passed = [row for row in rows if row['status'] == 'APP_PASS']
record = {
    'observedUtc': datetime.now(timezone.utc).isoformat(),
    'state': rest['state'] if rest['state'] != 'NOT_STARTED' else pilot['state'],
    'passed': len(passed),
    'total': 77,
    'maxElapsedMs': max((row['metrics']['elapsedMs'] for row in passed), default=None),
    'minHeadroomMs': min((row['metrics']['headroomMs'] for row in passed), default=None),
    'failures': [row for row in rows if row['status'] not in {'APP_PASS', 'RUNNING'}],
    'current': [row for row in rows if row['status'] == 'RUNNING'],
    'lastCompleted': passed[-1:]}
for batch in ('cold-pilot', 'cold-rest'):
    stage = task / (batch + '-result.json')
    if stage.exists():
        record[batch + 'StageResult'] = json.loads(stage.read_text(encoding='utf-8-sig'))
record['lastCompleted'] = [
    {'rootSeed': row['rootSeed'], 'elapsedMs': row['metrics']['elapsedMs'],
     'cleanupStatus': row['cleanup']['status']}
    for row in record['lastCompleted']]
print(json.dumps(record))
