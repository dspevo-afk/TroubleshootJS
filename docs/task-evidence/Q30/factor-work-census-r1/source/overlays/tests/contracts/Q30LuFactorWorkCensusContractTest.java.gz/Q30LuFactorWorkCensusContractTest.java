package com.lushprojects.circuitjs1.client;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

/** Native oracle and cadence contract for the selected-factor work census. */
public final class Q30LuFactorWorkCensusContractTest {
    private static final String PROFILE =
        "com.lushprojects.circuitjs1.client.CirSim$LuRepetitionProfile";
    private static final String WORKSPACE =
        "com.lushprojects.circuitjs1.client.CirSim$LuFactorizationWorkspace";
    private static int assertions;

    public static void main(String[] args) throws Exception {
        System.out.println("PASS: Q30 factor work-census contracts assertions=" + run());
    }

    public static int run() throws Exception {
        assertions = 0;
        Object profile = newProfile();
        Object workspace = newWorkspace();

        // Seven ordinary timer-selected calls followed by the eighth census call.
        for (int i = 1; i <= 7; i++)
            require(invokeProfiledFactor(new double[][] {{4}}, 1, new int[1],
                    workspace, profile), "unselected 1x1 factor failed");
        require(intValue(profile, "workCensusSelectedCalls") == 0,
                "census selected before the eighth timer-selected factor");
        require(invokeProfiledFactor(new double[][] {{4}}, 1, new int[1],
                workspace, profile), "eighth 1x1 factor failed");
        require(intValue(profile, "workCensusSelectedCalls") == 1 &&
                intValue(profile, "workCensusCompletedCalls") == 1,
                "eighth timer-selected factor was not one completed census scope");
        Object sizeOne = sizeCounts(profile, 1);
        require(numberValue(sizeOne, "factorAttempts") == 1 &&
                numberValue(sizeOne, "factorCompletions") == 1 &&
                numberValue(sizeOne, "pivots") == 1 &&
                numberValue(sizeOne, "pivotSearchCandidates") == 1 &&
                numberValue(sizeOne, "referenceClearCalls") == 1 &&
                numberValue(sizeOne, "workspaceClearCalls") == 1,
                "1x1 census did not count the exact scope and cleanup work");

        // A zero-row preflight is still an attempted selected factor and cleans.
        for (int i = 9; i <= 15; i++)
            require(invokeProfiledFactor(new double[][] {{4}}, 1, new int[1],
                    workspace, profile), "cadence filler factor failed");
        require(!invokeProfiledFactor(new double[][] {{0}}, 1, new int[1],
                workspace, profile), "selected zero row unexpectedly factored");
        sizeOne = sizeCounts(profile, 1);
        require(numberValue(sizeOne, "factorAttempts") == 2 &&
                numberValue(sizeOne, "matrixInputSamples") == 2 &&
                numberValue(sizeOne, "factorCompletions") == 1 &&
                numberValue(sizeOne, "factorFailures") == 1 &&
                numberValue(sizeOne, "preflightCompletions") == 2 &&
                numberValue(sizeOne, "preflightZeroRowRejections") == 1 &&
                numberValue(sizeOne, "factorBodiesEntered") == 1,
                "zero-row attempt was not conserved separately from entered LU bodies");
        require(workspaceClear(workspace), "zero-row census retained workspace state");

        // Compare counted factor arithmetic against the independent retained oracle.
        fillToNextCensus(profile, workspace);
        double[][] sparse = {{4, 1, 2}, {0, 3, 1}, {0, 0, 2}};
        compareWithOriginal(sparse, profile, workspace);
        fillToNextCensus(profile, workspace);
        double[][] dense = {{1, 2, 3}, {4, 5, 6}, {7, 8, 10}};
        compareWithOriginal(dense, profile, workspace);
        Object sizeThree = sizeCounts(profile, 3);
        require(numberValue(sizeThree, "factorAttempts") == 2 &&
                numberValue(sizeThree, "matrixInputSamples") == 2 &&
                numberValue(sizeThree, "factorCompletions") == 2 &&
                numberValue(sizeThree, "pivots") == 6 &&
                numberValue(sizeThree, "pivotSearchCandidates") == 12,
                "dimension aggregate lost successful factor work");
        require(numberValue(sizeThree, "pivotsWithNoLowerRows") > 0 &&
                numberValue(sizeThree, "upperProbesWithNoLowerRows") > 0 &&
                numberValue(sizeThree, "upperNonzerosWithNoLowerRows") > 0 &&
                numberValue(sizeThree, "rankOneUpdatesCompleted") > 0 &&
                numberValue(sizeThree, "pivotSwaps") > 0,
                "sparse opportunity or dense update/swap work was not captured");

        // Selected malformed scope must be counted failed and clear its references.
        for (int i = 0; i < 7; i++)
            require(invokeProfiledFactor(new double[][] {{2}}, 1, new int[1],
                    workspace, profile), "malformed-scope cadence filler failed");
        boolean threw = false;
        try {
            invokeProfiledFactor(new double[][] {{1, 0}, {}}, 2, new int[2],
                    workspace, profile);
        } catch (ArrayIndexOutOfBoundsException expected) {
            threw = true;
        }
        require(threw, "selected malformed factor did not preserve its failure");
        Object sizeTwo = sizeCounts(profile, 2);
        require(numberValue(sizeTwo, "factorAttempts") == 1 &&
                numberValue(sizeTwo, "factorFailures") == 1 &&
                numberValue(sizeTwo, "factorCompletions") == 0,
                "throwing sampled factor was not counted as a failed attempt");
        require(workspaceClear(workspace), "throwing census retained workspace state");

        // A late numerical throw occurs after one lower reference is stored.
        // Compare with the uncounted owned helper and verify cleanup/counters.
        for (int i = 0; i < 7; i++)
            require(invokeProfiledFactor(new double[][] {{2}}, 1, new int[1],
                    workspace, profile), "late-failure cadence filler failed");
        double[][] overflow = {{1, Double.MAX_VALUE}, {1, -Double.MAX_VALUE}};
        double[][] expected = copy(overflow), actual = copy(overflow);
        int[] expectedPivots = new int[2], actualPivots = new int[2];
        SolverExecutionBoundary.Failure expectedFailure = null, actualFailure = null;
        try { invokeOwnedFactor(expected, 2, expectedPivots); }
        catch (SolverExecutionBoundary.Failure failure) { expectedFailure = failure; }
        try { invokeProfiledFactor(actual, 2, actualPivots, workspace, profile); }
        catch (SolverExecutionBoundary.Failure failure) { actualFailure = failure; }
        require(expectedFailure != null && actualFailure != null &&
                expectedFailure.outcome == SolverExecutionBoundary.Outcome.NUMERICAL_FAILURE &&
                actualFailure.outcome == expectedFailure.outcome,
                "late counted factor failure differs from uncounted owned outcome");
        for (int i = 0; i < 2; i++) {
            require(expectedPivots[i] == actualPivots[i], "late failure pivot differs");
            for (int j = 0; j < 2; j++)
                require(Double.doubleToLongBits(expected[i][j]) ==
                        Double.doubleToLongBits(actual[i][j]), "late failure matrix differs");
        }
        sizeTwo = sizeCounts(profile, 2);
        require(numberValue(sizeTwo, "factorAttempts") == 2 &&
                numberValue(sizeTwo, "matrixInputSamples") == 2 &&
                numberValue(sizeTwo, "factorFailures") == 2 &&
                numberValue(sizeTwo, "lowerNonzeroFactors") == 1 &&
                numberValue(sizeTwo, "rankOneUpdateAttempts") == 1 &&
                numberValue(sizeTwo, "rankOneUpdatesCompleted") == 0 &&
                numberValue(sizeTwo, "lowerRowReferencesCleared") == 1,
                "late numerical failure did not conserve partial work and reference cleanup");
        require(workspaceClear(workspace), "late numerical failure retained workspace state");
        require(intValue(profile, "workCensusSelectedCalls") == 6 &&
                intValue(profile, "workCensusCompletedCalls") == 3 &&
                intValue(profile, "workCensusFailedCalls") == 3,
                "selected attempt totals do not conserve completed and failed samples");
        return assertions;
    }

    private static void fillToNextCensus(Object profile, Object workspace) throws Exception {
        while (intValue(profile, "luFactorTimingAttempts") % 8 != 7)
            require(invokeProfiledFactor(new double[][] {{3}}, 1, new int[1],
                    workspace, profile), "cadence alignment factor failed");
    }

    private static void compareWithOriginal(double[][] input, Object profile, Object workspace)
            throws Exception {
        int n = input.length;
        double[][] expected = copy(input), actual = copy(input);
        int[] expectedPivots = new int[n], actualPivots = new int[n];
        boolean expectedOk = originalFactor(expected, n, expectedPivots);
        boolean actualOk = invokeProfiledFactor(actual, n, actualPivots, workspace, profile);
        require(expectedOk && actualOk, "oracle/counting factor success differs");
        for (int i = 0; i < n; i++) {
            require(expectedPivots[i] == actualPivots[i], "pivot differs from retained oracle");
            for (int j = 0; j < n; j++)
                require(Double.doubleToLongBits(expected[i][j]) ==
                        Double.doubleToLongBits(actual[i][j]),
                        "factor differs from retained oracle at " + i + "," + j);
        }
        require(workspaceClear(workspace), "successful census retained workspace state");
    }

    private static boolean originalFactor(double[][] matrix, int n, int[] pivots)
            throws Exception {
        Method method = LuFactorizationChecks.class.getDeclaredMethod("originalFactor",
                double[][].class, Integer.TYPE, int[].class);
        method.setAccessible(true);
        return ((Boolean) invoke(method, null, matrix, Integer.valueOf(n), pivots)).booleanValue();
    }

    private static boolean invokeOwnedFactor(double[][] matrix, int n, int[] pivots)
            throws Exception {
        Class<?> workspaceType = Class.forName(WORKSPACE);
        Method method = CirSim.class.getDeclaredMethod("lu_factorNonlinearOwned",
                double[][].class, Integer.TYPE, int[].class, workspaceType);
        method.setAccessible(true);
        try {
            return ((Boolean) invoke(method, null, matrix, Integer.valueOf(n), pivots,
                    newWorkspace())).booleanValue();
        } catch (RuntimeException | Error failure) {
            throw failure;
        }
    }

    private static Object newProfile() throws Exception {
        Class<?> type = Class.forName(PROFILE);
        Constructor<?> constructor = type.getDeclaredConstructor(String.class);
        constructor.setAccessible(true);
        return constructor.newInstance("factor-work-census");
    }

    private static Object newWorkspace() throws Exception {
        Class<?> type = Class.forName(WORKSPACE);
        Constructor<?> constructor = type.getDeclaredConstructor();
        constructor.setAccessible(true);
        return constructor.newInstance();
    }

    private static boolean invokeProfiledFactor(double[][] matrix, int n, int[] pivots,
            Object workspace, Object profile) throws Exception {
        Class<?> workspaceType = Class.forName(WORKSPACE);
        Class<?> profileType = Class.forName(PROFILE);
        Method method = CirSim.class.getDeclaredMethod("lu_factorNonlinearProfiled",
                double[][].class, Integer.TYPE, int[].class, workspaceType, profileType);
        method.setAccessible(true);
        try {
            return ((Boolean) invoke(method, null, matrix, Integer.valueOf(n), pivots,
                    workspace, profile)).booleanValue();
        } catch (RuntimeException | Error failure) {
            throw failure;
        }
    }

    private static Object invoke(Method method, Object receiver, Object... args)
            throws Exception {
        try {
            return method.invoke(receiver, args);
        } catch (InvocationTargetException wrapped) {
            Throwable cause = wrapped.getCause();
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            if (cause instanceof Error) throw (Error) cause;
            throw wrapped;
        }
    }

    @SuppressWarnings("unchecked")
    private static Object sizeCounts(Object profile, int size) throws Exception {
        Field field = profile.getClass().getDeclaredField("workCensusBySize");
        field.setAccessible(true);
        Object result = ((Map<Integer, Object>) field.get(profile)).get(Integer.valueOf(size));
        if (result == null) throw new AssertionError("missing size group " + size);
        return result;
    }

    private static int intValue(Object object, String name) throws Exception {
        Field field = object.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.getInt(object);
    }

    private static double numberValue(Object object, String name) throws Exception {
        Field field = object.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.getDouble(object);
    }

    private static boolean workspaceClear(Object workspace) throws Exception {
        Method counts = workspace.getClass().getDeclaredMethod("allCountsZeroForChecks");
        Method refs = workspace.getClass().getDeclaredMethod("allRowReferencesNullForChecks");
        counts.setAccessible(true);
        refs.setAccessible(true);
        return ((Boolean) counts.invoke(workspace)).booleanValue() &&
                ((Boolean) refs.invoke(workspace)).booleanValue();
    }

    private static double[][] copy(double[][] matrix) {
        double[][] result = new double[matrix.length][matrix.length];
        for (int i = 0; i < matrix.length; i++)
            System.arraycopy(matrix[i], 0, result[i], 0, matrix.length);
        return result;
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private Q30LuFactorWorkCensusContractTest() { }
}
