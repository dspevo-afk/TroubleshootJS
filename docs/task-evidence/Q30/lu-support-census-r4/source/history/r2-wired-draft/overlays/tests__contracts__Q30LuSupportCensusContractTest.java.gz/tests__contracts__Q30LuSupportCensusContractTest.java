package com.lushprojects.circuitjs1.client;

/**
 * Native-only oracle for the unregistered support-census collector draft.
 *
 * <p>The fixtures below describe support graphs directly.  They do not call
 * GWT JSON, JSNI, CircuitJS, or a second LU implementation.</p>
 */
public final class Q30LuSupportCensusContractTest {
    private static int assertions;

    public static void main(String[] args) {
        System.out.println("PASS: Q30 LU support-census contracts assertions=" + run());
    }

    public static int run() {
        assertions = 0;
        checkAsymmetricGraphAndReplay();
        checkStableExactReplay();
        checkDuplicateCapture();
        checkDefaultCadence();
        checkLargerOriginalPrefix();
        checkFailedAndMalformedScopes();
        checkZeroRiskAndUnknownObservation();
        checkColdWarmIsolation();
        checkTraceAndScopeCompleteness();
        return assertions;
    }

    private static void checkAsymmetricGraphAndReplay() {
        Q30LuSupportCensus census = new Q30LuSupportCensus("cold", 8);
        census.declareZeroPivotObservationAvailable();
        double[][] original = asymmetricOriginal();
        double[][] current = asymmetricCurrent(original);
        for (int i = 0; i < 7; i++)
            check(census.beginFactor(5) == null, "ordinary factor unexpectedly selected");
        Q30LuSupportCensus.SampleToken token = census.beginFactor(5);
        check(token != null, "eighth eligible factor was not selected");
        census.recordPreFactor(token, current, original, 5);
        census.finishFactor(token, true, new int[] { 0, 1, 3, 3, 4 });
        Q30LuSupportCensus.Report report = census.freeze();

        check(report.valid && report.frozen && report.selectionInterval == 8,
                "asymmetric report did not freeze validly or retain its cadence");
        check(report.eligibleFactorCalls == 8 && report.selectedFactorCalls == 1 &&
                report.completedFactorCalls == 1 && report.failedFactorCalls == 0,
                "selection/completion totals changed");
        check(report.samples.length == 1, "asymmetric sample was not retained");
        Q30LuSupportCensus.Sample sample = report.samples[0];
        check(sample.snapshot.cellReads == 125,
                "scan matrix-cell read count is not five n-squared reads");
        check(sample.snapshot.supportAdded == 2 && sample.snapshot.supportRemoved == 0 &&
                sample.snapshot.supportUnchanged == 7 &&
                sample.snapshot.valueDifferences == 2 &&
                sample.snapshot.signedZeroDifferences == 0 &&
                sample.snapshot.currentCrossOriginalEdges == 1,
                "support/value difference census is incorrect");

        check(sample.snapshot.originalGraph.edges == 7 &&
                sample.snapshot.currentGraph.edges == 9,
                "support edge totals are incorrect");
        check(sample.snapshot.originalGraph.components.length == 3 &&
                sample.snapshot.currentGraph.components.length == 2,
                "component count did not reflect the added cross edge");
        component(sample.snapshot.originalGraph, new int[] { 0, 2 },
                new int[] { 1, 4 }, 3, "original A");
        component(sample.snapshot.originalGraph, new int[] { 1, 4 },
                new int[] { 0, 3 }, 3, "original B");
        component(sample.snapshot.originalGraph, new int[] { 3 },
                new int[] { 2 }, 1, "original C");
        component(sample.snapshot.currentGraph, new int[] { 0, 1, 2, 4 },
                new int[] { 0, 1, 3, 4 }, 8, "current merged A/B");
        component(sample.snapshot.currentGraph, new int[] { 3 },
                new int[] { 2 }, 1, "current C");

        Q30LuSupportCensus.Opportunity opportunity = sample.opportunity;
        check(opportunity.fullPivotCandidates == 15 &&
                opportunity.fullLowerCandidates == 10 &&
                opportunity.fullUpperCandidates == 10,
                "global five-by-five candidate counts are incorrect");
        check(opportunity.localPivotCandidates == 11 &&
                opportunity.localLowerCandidates == 7 &&
                opportunity.localUpperCandidates == 6,
                "row-swap replay candidate counts are incorrect");
        check(opportunity.replayComplete && !opportunity.exact &&
                !opportunity.crossGroupPivot && !opportunity.zeroPivotRisk &&
                !opportunity.nonfiniteSupportData &&
                !opportunity.stableOriginalComponents &&
                !opportunity.initialOrderOnly &&
                opportunity.zeroPivotObservationAvailable &&
                opportunity.zeroPivotFallbacks == 0,
                "support drift was presented as exact evidence");

        // Mutating the returned graph cannot mutate the retained profile.
        Q30LuSupportCensus.Component returned = component(sample.snapshot.currentGraph,
                new int[] { 0, 1, 2, 4 }, new int[] { 0, 1, 3, 4 }, 8,
                "returned merged A/B");
        int retainedFirstRow = returned.rows[0];
        returned.rows[0] = 99;
        Q30LuSupportCensus.Report duplicate = census.freeze();
        Q30LuSupportCensus.Component retained = component(
                duplicate.samples[0].snapshot.currentGraph,
                new int[] { 0, 1, 2, 4 }, new int[] { 0, 1, 3, 4 }, 8,
                "retained merged A/B after alias mutation");
        check(!duplicate.valid && duplicate.lifecycleErrors == 1,
                "duplicate freeze was not rejected as a lifecycle error");
        check(retained.rows[0] == retainedFirstRow,
                "returned component storage aliases retained profile state");
    }

    private static void checkStableExactReplay() {
        Q30LuSupportCensus census = new Q30LuSupportCensus("stable", 8);
        census.declareZeroPivotObservationAvailable();
        double[][] original = new double[4][4];
        original[0][0] = 2;
        original[0][1] = 3;
        original[1][0] = 5;
        original[1][1] = 7;
        original[2][2] = 11;
        original[2][3] = 13;
        original[3][2] = 17;
        original[3][3] = 19;
        double[][] current = copy(original);
        current[0][1] = 29;
        current[3][2] = 31;
        for (int i = 0; i < 7; i++) check(census.beginFactor(4) == null,
                "stable fixture filler was selected");
        Q30LuSupportCensus.SampleToken token = census.beginFactor(4);
        census.recordPreFactor(token, current, original, 4);
        census.finishFactor(token, true, new int[] { 1, 1, 3, 3 });
        Q30LuSupportCensus.Report report = census.freeze();
        Q30LuSupportCensus.Opportunity opportunity = report.samples[0].opportunity;
        check(report.valid && report.completeCapture &&
                opportunity.replayComplete && opportunity.exact &&
                !opportunity.initialOrderOnly &&
                opportunity.stableOriginalComponents &&
                report.failedFactorCalls == 0,
                "stable successful replay was not separated from drift evidence");
    }

    private static void checkDuplicateCapture() {
        Q30LuSupportCensus census = new Q30LuSupportCensus("duplicate-capture", 8);
        double[][] matrix = {{ 2, 0 }, { 0, 3 }};
        for (int i = 0; i < 7; i++) check(census.beginFactor(2) == null,
                "duplicate-capture filler was selected");
        Q30LuSupportCensus.SampleToken token = census.beginFactor(2);
        census.recordPreFactor(token, matrix, matrix, 2);
        census.recordPreFactor(token, matrix, matrix, 2);
        census.finishFactor(token, true, new int[] { 0, 1 });
        Q30LuSupportCensus.Report report = census.freeze();
        check(!report.valid && report.lifecycleErrors == 1 && report.samples.length == 0,
                "duplicate pre-factor capture was silently accepted");
    }

    private static void checkDefaultCadence() {
        Q30LuSupportCensus census = new Q30LuSupportCensus("default-cadence");
        for (int i = 0; i < Q30LuSupportCensus.DEFAULT_SELECTION_INTERVAL - 1; i++)
            check(census.beginFactor(1) == null, "default cadence selected early");
        Q30LuSupportCensus.SampleToken token = census.beginFactor(1);
        check(token != null, "default 4096 cadence did not select its boundary");
        double[][] matrix = {{ 1 }};
        census.recordPreFactor(token, matrix, matrix, 1);
        census.finishFactor(token, true, new int[] { 0 });
        Q30LuSupportCensus.Report report = census.freeze();
        check(report.selectionInterval == Q30LuSupportCensus.DEFAULT_SELECTION_INTERVAL &&
                report.eligibleFactorCalls == Q30LuSupportCensus.DEFAULT_SELECTION_INTERVAL &&
                report.selectedFactorCalls == 1,
                "default cadence totals were not reconstructed exactly");
    }

    private static void checkLargerOriginalPrefix() {
        Q30LuSupportCensus census = new Q30LuSupportCensus("active-prefix", 8);
        census.declareZeroPivotObservationAvailable();
        double[][] current = {{ 2, 0 }, { 0, 3 }};
        double[][] original = new double[4][4];
        original[0][0] = 2;
        original[1][1] = 3;
        original[3][3] = 91;
        original[0][3] = 97;
        for (int i = 0; i < 7; i++) check(census.beginFactor(2) == null,
                "active-prefix filler was selected");
        Q30LuSupportCensus.SampleToken token = census.beginFactor(2);
        census.recordPreFactor(token, current, original, 2);
        census.finishFactor(token, true, new int[] { 0, 1 });
        Q30LuSupportCensus.Report report = census.freeze();
        check(report.valid && report.samples.length == 1 &&
                report.samples[0].snapshot.originalGraph.edges == 2 &&
                report.samples[0].snapshot.stableOriginalComponents,
                "larger original allocation tail was not ignored safely");

        Q30LuSupportCensus shortPrefix = new Q30LuSupportCensus("short-prefix", 8);
        for (int i = 0; i < 7; i++) check(shortPrefix.beginFactor(2) == null,
                "short-prefix filler was selected");
        Q30LuSupportCensus.SampleToken shortToken = shortPrefix.beginFactor(2);
        shortPrefix.recordPreFactor(shortToken, current, new double[][] {{ 1 }}, 2);
        shortPrefix.finishFactor(shortToken, true, new int[] { 0, 1 });
        Q30LuSupportCensus.Report shortReport = shortPrefix.freeze();
        check(!shortReport.valid && shortReport.scanErrors == 1 &&
                shortReport.samples.length == 0,
                "too-short active matrix prefix was not rejected");
    }

    private static void checkFailedAndMalformedScopes() {
        Q30LuSupportCensus failed = new Q30LuSupportCensus("failed", 8);
        failed.declareZeroPivotObservationAvailable();
        double[][] dense = {{ 2, 3 }, { 5, 7 }};
        for (int i = 0; i < 7; i++) check(failed.beginFactor(2) == null,
                "failed fixture filler was selected");
        Q30LuSupportCensus.SampleToken failedToken = failed.beginFactor(2);
        failed.recordPreFactor(failedToken, dense, dense, 2);
        failed.finishFactor(failedToken, false, new int[] { 1 });
        Q30LuSupportCensus.Report failedReport = failed.freeze();
        check(failedReport.eligibleFactorCalls == 8 &&
                failedReport.selectedFactorCalls == 1 &&
                failedReport.completedFactorCalls == 0 &&
                failedReport.failedFactorCalls == 1,
                "failed factor was not counted separately");
        check(failedReport.samples.length == 1 &&
                !failedReport.samples[0].factorSucceeded,
                "failed sample was discarded instead of retained as bounded data");
        check(!failedReport.completeCapture &&
                !failedReport.samples[0].opportunity.replayComplete &&
                !failedReport.samples[0].opportunity.exact &&
                failedReport.samples[0].opportunity.initialOrderOnly &&
                failedReport.samples[0].opportunity.zeroPivotObservationAvailable &&
                failedReport.samples[0].opportunity.fullPivotCandidates == 3 &&
                failedReport.samples[0].opportunity.fullLowerCandidates == 1 &&
                failedReport.samples[0].opportunity.fullUpperCandidates == 1,
                "failed sample did not retain explicit initial-order-only flags");

        Q30LuSupportCensus malformed = new Q30LuSupportCensus("malformed", 8);
        malformed.declareZeroPivotObservationAvailable();
        for (int i = 0; i < 7; i++) check(malformed.beginFactor(1) == null,
                "malformed fixture filler was selected");
        Q30LuSupportCensus.SampleToken malformedToken = malformed.beginFactor(1);
        malformed.recordPreFactor(malformedToken, new double[][] {{ }},
                new double[][] {{ 1 }}, 1);
        malformed.recordPreFactor(malformedToken, new double[][] {{ }},
                new double[][] {{ 1 }}, 1);
        malformed.finishFactor(malformedToken, true, new int[] { 0 });
        malformed.finishFactor(malformedToken, true, new int[] { 0 });
        Q30LuSupportCensus.Report malformedReport = malformed.freeze();
        check(!malformedReport.valid && malformedReport.scanErrors == 1 &&
                malformedReport.completedFactorCalls == 1 &&
                malformedReport.samples.length == 0 && malformedReport.lifecycleErrors == 2,
                "malformed diagnostic shape was not isolated from physical completion");

        Q30LuSupportCensus invalidReplay = new Q30LuSupportCensus("invalid-replay", 8);
        invalidReplay.declareZeroPivotObservationAvailable();
        for (int i = 0; i < 7; i++) check(invalidReplay.beginFactor(2) == null,
                "invalid-replay fixture filler was selected");
        Q30LuSupportCensus.SampleToken invalidToken = invalidReplay.beginFactor(2);
        invalidReplay.recordPreFactor(invalidToken, dense, dense, 2);
        invalidReplay.finishFactor(invalidToken, true, new int[] { 0, 2 });
        Q30LuSupportCensus.Report invalidReport = invalidReplay.freeze();
        check(!invalidReport.completeCapture &&
                !invalidReport.samples[0].opportunity.replayComplete &&
                !invalidReport.samples[0].opportunity.exact,
                "invalid pivot replay was presented as complete");

        Q30LuSupportCensus missingScan = new Q30LuSupportCensus("missing-scan", 8);
        for (int i = 0; i < 7; i++) check(missingScan.beginFactor(1) == null,
                "missing-scan fixture filler was selected");
        Q30LuSupportCensus.SampleToken missingToken = missingScan.beginFactor(1);
        missingScan.finishFactor(missingToken, true, new int[] { 0 });
        Q30LuSupportCensus.Report missingReport = missingScan.freeze();
        check(!missingReport.valid && missingReport.scanErrors == 1 &&
                missingReport.samples.length == 0,
                "selected factor without a pre-factor capture was accepted");

        // Late calls after freeze remain invalid and cannot reopen the profile.
        check(malformed.beginFactor(1) == null,
                "frozen profile accepted a late factor");
        Q30LuSupportCensus.Report late = malformed.freeze();
        check(!late.valid && late.lifecycleErrors == 4,
                "duplicate capture/finish, late factor, and duplicate freeze were not recorded");
    }

    private static void checkZeroRiskAndUnknownObservation() {
        Q30LuSupportCensus risk = new Q30LuSupportCensus("risk", 8);
        double[][] sparse = {{ 1e-18, 0, 0 }, { 0, 5, 0 }, { 0, 0, 0 }};
        for (int i = 0; i < 7; i++) check(risk.beginFactor(3) == null,
                "zero-risk fixture filler was selected");
        Q30LuSupportCensus.SampleToken riskToken = risk.beginFactor(3);
        risk.recordPreFactor(riskToken, sparse, sparse, 3);
        risk.recordPostFactorZeroRisk(riskToken, sparse, 3);
        risk.finishFactor(riskToken, true, new int[] { 0, 1, 2 });
        Q30LuSupportCensus.Report riskReport = risk.freeze();
        Q30LuSupportCensus.Opportunity riskOpportunity = riskReport.samples[0].opportunity;
        check(!riskOpportunity.exact && riskOpportunity.crossGroupPivot &&
                riskOpportunity.zeroPivotRisk &&
                riskOpportunity.postFactorZeroRisk &&
                riskOpportunity.postFactorSentinelHits == 1 &&
                riskOpportunity.zeroPivotFallbacks == 0 &&
                !riskOpportunity.zeroPivotObservationAvailable,
                "isolated row/column and sentinel risk were not rejected conservatively");

        Q30LuSupportCensus unknown = new Q30LuSupportCensus("unknown", 8);
        for (int i = 0; i < 7; i++) check(unknown.beginFactor(1) == null,
                "unknown-observation filler was selected");
        Q30LuSupportCensus.SampleToken token = unknown.beginFactor(1);
        unknown.recordPreFactor(token, new double[][] {{ 1 }}, new double[][] {{ 1 }}, 1);
        unknown.finishFactor(token, true, new int[] { 0 });
        Q30LuSupportCensus.Report unknownReport = unknown.freeze();
        check(unknownReport.valid && !unknownReport.zeroPivotObservationAvailable &&
                !unknownReport.samples[0].opportunity.exact,
                "missing zero-pivot observation was presented as exact");

        Q30LuSupportCensus nonfinite = new Q30LuSupportCensus("nonfinite", 8);
        nonfinite.declareZeroPivotObservationAvailable();
        for (int i = 0; i < 7; i++) check(nonfinite.beginFactor(1) == null,
                "nonfinite fixture filler was selected");
        Q30LuSupportCensus.SampleToken nonfiniteToken = nonfinite.beginFactor(1);
        double[][] nan = {{ Double.NaN }};
        nonfinite.recordPreFactor(nonfiniteToken, nan, nan, 1);
        nonfinite.finishFactor(nonfiniteToken, true, new int[] { 0 });
        Q30LuSupportCensus.Report nonfiniteReport = nonfinite.freeze();
        check(!nonfiniteReport.valid &&
                nonfiniteReport.samples[0].snapshot.currentGraph.nonfiniteEntries == 1 &&
                nonfiniteReport.samples[0].snapshot.originalGraph.nonfiniteEntries == 1 &&
                nonfiniteReport.samples[0].opportunity.nonfiniteSupportData &&
                !nonfiniteReport.samples[0].opportunity.exact,
                "nonfinite support was not retained and rejected for exact use");
    }


    private static void checkTraceAndScopeCompleteness() {
        double[][] matrix = {{0,1,2},{1,0,0},{0,2,3}};
        Q30LuSupportCensus census = new Q30LuSupportCensus("trace", 1);
        Q30LuSupportCensus.SampleToken token = census.beginFactor(3);
        census.recordPreFactor(token, matrix, matrix, 3);
        int[] pivots = {1,2,2,999};
        census.finishFactor(token, true, pivots);
        pivots[0] = 0;
        Q30LuSupportCensus.Report report = census.freeze(true);
        check(report.scopeComplete && report.completeCapture &&
                report.samples[0].ipvtTraceComplete, "successful trace capture incomplete");
        check(report.samples[0].ipvtPrefix.length == 3 &&
                report.samples[0].ipvtPrefix[0] == 1, "pivot prefix not defensively bounded");
        check(!report.samples[0].opportunity.exact, "capture incorrectly implies exactness");
        Q30LuSupportCensus lost = new Q30LuSupportCensus("lost-scope", 1);
        Q30LuSupportCensus.SampleToken lostToken = lost.beginFactor(1);
        lost.recordPreFactor(lostToken, new double[][]{{1}}, new double[][]{{1}}, 1);
        lost.finishFactor(lostToken, true, new int[]{0});
        Q30LuSupportCensus.Report truncated = lost.freeze(false);
        check(truncated.valid && !truncated.scopeComplete && !truncated.completeCapture,
                "active/lost owner capture was presented as complete");
        Q30LuSupportCensus drift = new Q30LuSupportCensus("internal-drift", 1);
        Q30LuSupportCensus.SampleToken driftToken = drift.beginFactor(2);
        drift.recordPreFactor(driftToken, new double[][]{{1,1},{1,1}},
                new double[][]{{1,1},{1,0}}, 2);
        drift.finishFactor(driftToken, true, new int[]{1,1});
        Q30LuSupportCensus.Report changed = drift.freeze();
        check(changed.samples[0].snapshot.stableOriginalComponents &&
                changed.samples[0].snapshot.supportAdded == 1 &&
                changed.samples[0].snapshot.supportRemoved == 0,
                "internal support drift hidden by stable components");
        check(!changed.samples[0].opportunity.exact, "unknown fallback presented as exact");
    }

    private static void checkColdWarmIsolation() {
        Q30LuSupportCensus cold = new Q30LuSupportCensus("cold", 8);
        cold.declareZeroPivotObservationAvailable();
        for (int i = 0; i < 7; i++) cold.beginFactor(1);
        Q30LuSupportCensus.SampleToken token = cold.beginFactor(1);
        cold.recordPreFactor(token, new double[][] {{ 1 }}, new double[][] {{ 1 }}, 1);
        cold.finishFactor(token, true, new int[] { 0 });
        Q30LuSupportCensus.Report coldReport = cold.freeze();

        Q30LuSupportCensus warm = new Q30LuSupportCensus("warm", 8);
        warm.declareZeroPivotObservationAvailable();
        Q30LuSupportCensus.Report warmReport = warm.freeze();
        check(coldReport.samples.length == 1 && coldReport.selectedFactorCalls == 1,
                "cold report lost its own selected sample");
        check(warmReport.valid && warmReport.eligibleFactorCalls == 0 &&
                warmReport.selectedFactorCalls == 0 && warmReport.samples.length == 0,
                "warm report inherited cold census state");
    }

    private static double[][] asymmetricOriginal() {
        double[][] result = new double[5][5];
        result[0][1] = 2;
        result[2][1] = 3;
        result[2][4] = 5;
        result[1][0] = 7;
        result[4][0] = 11;
        result[4][3] = 13;
        result[3][2] = 17;
        return result;
    }

    private static double[][] asymmetricCurrent(double[][] original) {
        double[][] result = copy(original);
        result[2][0] = 19;
        result[1][3] = 23;
        return result;
    }

    private static Q30LuSupportCensus.Component component(
            Q30LuSupportCensus.Graph graph, int[] rows, int[] columns,
            long edges, String label) {
        for (int i = 0; i < graph.components.length; i++) {
            Q30LuSupportCensus.Component candidate = graph.components[i];
            if (same(candidate.rows, rows) && same(candidate.columns, columns)) {
                check(candidate.edges == edges, label + " edge count changed");
                return candidate;
            }
        }
        throw new AssertionError(label + " component missing");
    }

    private static boolean same(int[] actual, int[] expected) {
        if (actual.length != expected.length) return false;
        for (int i = 0; i < actual.length; i++)
            if (actual[i] != expected[i]) return false;
        return true;
    }

    private static double[][] copy(double[][] source) {
        double[][] result = new double[source.length][];
        for (int i = 0; i < source.length; i++) result[i] = source[i].clone();
        return result;
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        assertions++;
    }

    private Q30LuSupportCensusContractTest() { }
}
