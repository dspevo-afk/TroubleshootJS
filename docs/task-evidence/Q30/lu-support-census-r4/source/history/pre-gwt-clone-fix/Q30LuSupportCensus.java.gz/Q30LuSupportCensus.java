package com.lushprojects.circuitjs1.client;

import java.util.Vector;

/**
 * Bounded, count-only support census for the private Q30 LU probe.
 *
 * <p>This class never changes a matrix and has no simulator or graph owner.
 * One verifier-owned instance is used for one cold or warm run and is frozen
 * before its value-only report is published.</p>
 */
final class Q30LuSupportCensus {
    static final int DEFAULT_SELECTION_INTERVAL = 4096;
    static final int MAX_SELECTED_SAMPLES = 256;
    static final int MAX_MATRIX_SIZE = 512;

    private final String phase;
    private final int selectionInterval;
    private boolean frozen;
    private boolean valid = true;
    private boolean zeroPivotObservationAvailable;
    /* Hot dispatch state stays primitive and bounded; long totals update only
     * at a selected boundary or when the frozen report is assembled. */
    private int selectionOrdinal;
    private long selectionBatches;
    private long selectedFactorCalls;
    private long completedFactorCalls;
    private long failedFactorCalls;
    private long droppedSampleRecords;
    private long scanErrors;
    private long diagnosticErrors;
    private long scanCellReads;
    private long lifecycleErrors;
    private long counterOverflow;
    private SampleToken active;
    private final Vector<Sample> samples = new Vector<Sample>();

    Q30LuSupportCensus(String phase) {
        this(phase, DEFAULT_SELECTION_INTERVAL);
    }

    Q30LuSupportCensus(String phase, int selectionInterval) {
        if (phase == null || phase.length() == 0)
            throw new IllegalArgumentException("missing support-census phase");
        if (selectionInterval <= 0)
            throw new IllegalArgumentException("invalid support-census selection interval");
        this.phase = phase;
        this.selectionInterval = selectionInterval;
    }

    /** Declares that the selected LU fallback branch has a count-only hook. */
    void declareZeroPivotObservationAvailable() {
        if (frozen) {
            late("zero-pivot observation declared after freeze");
            return;
        }
        zeroPivotObservationAvailable = true;
    }

    /**
     * Counts every eligible owned factor call.  A null result means ordinary
     * unselected work; a token still needs finishFactor() on every selected
     * call, including a record-cap drop.
     */
    SampleToken beginFactor(int matrixSize) {
        if (frozen) {
            late("factor selection after freeze");
            return null;
        }
        if (selectionOrdinal != selectionInterval - 1) {
            selectionOrdinal++;
            return null;
        }
        selectionOrdinal = 0;
        selectionBatches = add(selectionBatches, 1);
        if (active != null) {
            lifecycle("selected factor began while another sample was open");
            return null;
        }
        selectedFactorCalls = add(selectedFactorCalls, 1);
        SampleToken token = new SampleToken(selectedFactorCalls, matrixSize);
        if (samples.size() >= MAX_SELECTED_SAMPLES) {
            droppedSampleRecords = add(droppedSampleRecords, 1);
            valid = false;
            token.dropped = true;
        }
        active = token;
        return token;
    }

    /** Captures the pre-factor matrix values; this method never calls a clock. */
    void recordPreFactor(SampleToken token, double[][] current, double[][] original,
            int matrixSize) {
        if (!isActive(token)) return;
        if (token.dropped) return;
        if (token.preFactorCaptured) {
            token.scanError = true;
            lifecycle("duplicate pre-factor capture");
            return;
        }
        token.preFactorCaptured = true;
        if (matrixSize != token.matrixSize || matrixSize < 0 || matrixSize > MAX_MATRIX_SIZE) {
            token.scanError = true;
            scanErrors = add(scanErrors, 1);
            valid = false;
            return;
        }
        try {
            token.snapshot = scan(current, original, matrixSize);
            scanCellReads = add(scanCellReads, token.snapshot.cellReads);
            if (token.snapshot.currentGraph.nonfiniteEntries != 0 ||
                    token.snapshot.originalGraph.nonfiniteEntries != 0)
                valid = false;
            token.opportunity = Opportunity.initial(token.snapshot.currentGraph,
                token.snapshot.stableOriginalComponents);
        } catch (RuntimeException invalidShape) {
            token.scanError = true;
            scanErrors = add(scanErrors, 1);
            valid = false;
        }
    }

    /** Records an instrumentation failure without changing the physical LU. */
    void recordDiagnosticFailure(SampleToken token) {
        if (token != null) token.scanError = true;
        diagnosticErrors = add(diagnosticErrors, 1);
        valid = false;
    }

    /** Count-only hook at the existing zero-pivot fallback branch. */
    void recordZeroPivotFallback(SampleToken token) {
        if (!isActive(token)) return;
        if (!zeroPivotObservationAvailable) {
            valid = false;
            return;
        }
        token.zeroPivotFallbacks = add(token.zeroPivotFallbacks, 1);
    }

    /**
     * Conservative post-factor sentinel check. It records a risk only; it is
     * never reported as an observed fallback branch. A legitimate pivot equal
     * to the sentinel is therefore a safe false positive.
     */
    void recordPostFactorZeroRisk(SampleToken token, double[][] factored,
            int matrixSize) {
        if (!isActive(token)) return;
        if (matrixSize != token.matrixSize || matrixSize < 0 ||
                matrixSize > MAX_MATRIX_SIZE) {
            token.scanError = true;
            scanErrors = add(scanErrors, 1);
            valid = false;
            return;
        }
        try {
            requireSquare(factored, matrixSize, "factored");
            for (int k = 0; k < matrixSize; k++) {
                if (factored[k][k] == 1e-18) {
                    token.postFactorZeroRisk = true;
                    token.postFactorSentinelHits = add(token.postFactorSentinelHits, 1);
                }
            }
        } catch (Throwable invalidShape) {
            token.scanError = true;
            scanErrors = add(scanErrors, 1);
            valid = false;
        }
    }

    /** Completes a selected sample around the unchanged original LU call. */
    void finishFactor(SampleToken token, boolean succeeded, int[] ipvt) {
        if (token != null && token.finished) {
            lifecycle("selected factor finished twice");
            return;
        }
        if (!isActive(token)) return;
        token.finished = true;
        int[] ipvtPrefix = null;
        boolean ipvtTraceComplete = false;
        if (succeeded && !token.dropped && !token.scanError) {
            ipvtPrefix = copyIpvtPrefix(ipvt, token.matrixSize);
            ipvtTraceComplete = ipvtPrefix != null &&
                ipvtPrefix.length == token.matrixSize;
        }
        if (succeeded) completedFactorCalls = add(completedFactorCalls, 1);
        else failedFactorCalls = add(failedFactorCalls, 1);
        if (!token.dropped && token.snapshot == null && !token.scanError) {
            scanErrors = add(scanErrors, 1);
            valid = false;
            token.scanError = true;
        }
        if (!token.dropped && token.snapshot != null && !token.scanError) {
            token.opportunity = succeeded
                ? Opportunity.replay(token.snapshot.currentGraph, token.opportunity,
                    ipvtTraceComplete ? ipvtPrefix : null,
                    zeroPivotObservationAvailable, token.zeroPivotFallbacks,
                    token.postFactorZeroRisk, token.postFactorSentinelHits)
                : token.opportunity.asIncomplete(zeroPivotObservationAvailable,
                    token.zeroPivotFallbacks, token.postFactorZeroRisk,
                    token.postFactorSentinelHits);
            samples.add(new Sample(token.ordinal, token.matrixSize, token.snapshot,
                token.opportunity, succeeded, token.zeroPivotFallbacks,
                token.postFactorSentinelHits, ipvtPrefix, ipvtTraceComplete));
        }
        active = null;
    }

    /** Freezes value state; all returned arrays are defensive copies. */
    Report freeze() { return freeze(true); }

    /** An active/lost owner may be cleared, but its capture is incomplete. */
    Report freeze(boolean scopeComplete) {
        if (active != null) {
            lifecycle("freeze with an open selected factor");
            active = null;
        }
        if (frozen) {
            lifecycle("duplicate freeze");
        }
        frozen = true;
        long eligibleFactorCalls = multiply(selectionBatches, selectionInterval);
        eligibleFactorCalls = add(eligibleFactorCalls, selectionOrdinal);
        Sample[] copy = new Sample[samples.size()];
        boolean tracesComplete = true;
        for (int i = 0; i < samples.size(); i++) {
            copy[i] = samples.get(i).copy();
            tracesComplete &= copy[i].factorSucceeded && copy[i].ipvtTraceComplete &&
                copy[i].opportunity.replayComplete;
        }
        boolean completeCapture = scopeComplete && tracesComplete && valid && lifecycleErrors == 0 &&
            counterOverflow == 0 && diagnosticErrors == 0 && selectedFactorCalls > 0 &&
            failedFactorCalls == 0 && droppedSampleRecords == 0 && scanErrors == 0 &&
            selectedFactorCalls == completedFactorCalls &&
            selectedFactorCalls == samples.size();
        return new Report(phase, selectionInterval,
            valid && lifecycleErrors == 0 && counterOverflow == 0,
            frozen, scopeComplete, completeCapture, zeroPivotObservationAvailable,
            eligibleFactorCalls, selectedFactorCalls, completedFactorCalls,
            failedFactorCalls, droppedSampleRecords, scanErrors, diagnosticErrors,
            scanCellReads, lifecycleErrors, counterOverflow, copy);
    }

    private boolean isActive(SampleToken token) {
        if (token == null || active != token || token.finished || frozen) {
            lifecycle("late or foreign support-census operation");
            return false;
        }
        return true;
    }

    private void late(String message) {
        lifecycleErrors = add(lifecycleErrors, 1);
        valid = false;
    }

    private void lifecycle(String message) {
        lifecycleErrors = add(lifecycleErrors, 1);
        valid = false;
    }

    private long add(long left, long right) {
        if (right > 0 && left > Long.MAX_VALUE - right) {
            counterOverflow = Long.MAX_VALUE;
            valid = false;
            return Long.MAX_VALUE;
        }
        if (right < 0 && left < Long.MIN_VALUE - right) {
            counterOverflow = Long.MAX_VALUE;
            valid = false;
            return Long.MIN_VALUE;
        }
        return left + right;
    }

    private long multiply(long left, long right) {
        if (left < 0 || right < 0 ||
                (left != 0 && right > Long.MAX_VALUE / left)) {
            counterOverflow = Long.MAX_VALUE;
            valid = false;
            return Long.MAX_VALUE;
        }
        return left * right;
    }

    private static SampleSnapshot scan(double[][] current, double[][] original, int n) {
        requireSquare(current, n, "current");
        requireSquare(original, n, "original");
        UnionFind currentUf = new UnionFind(2 * n);
        UnionFind originalUf = new UnionFind(2 * n);
        long currentEdges = 0, originalEdges = 0;
        long currentNonfinite = 0, originalNonfinite = 0;
        long added = 0, removed = 0, unchanged = 0, valueDifferences = 0;
        long signedZeroDifferences = 0;
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                double now = current[r][c];
                double before = original[r][c];
                boolean nowEdge = now != 0.0;
                boolean beforeEdge = before != 0.0;
                if (nowEdge) {
                    currentUf.union(r, n + c);
                    currentEdges++;
                    if (!finite(now)) currentNonfinite++;
                }
                if (beforeEdge) {
                    originalUf.union(r, n + c);
                    originalEdges++;
                    if (!finite(before)) originalNonfinite++;
                }
                if (nowEdge && beforeEdge) unchanged++;
                else if (nowEdge) added++;
                else if (beforeEdge) removed++;
                // GWT 2.7 emulates doubleToLongBits, so this is explicitly a
                // canonical value-bit difference metric (NaN payloads merge).
                if (Double.doubleToLongBits(now) !=
                        Double.doubleToLongBits(before)) {
                    valueDifferences++;
                    if (now == 0.0 && before == 0.0) signedZeroDifferences++;
                }
            }
        }
        Graph currentGraph = Graph.from(currentUf, current, n, currentEdges,
            currentNonfinite);
        Graph originalGraph = Graph.from(originalUf, original, n, originalEdges,
            originalNonfinite);
        long crossOriginal = 0;
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                if (current[r][c] != 0.0 &&
                        originalGraph.rowComponent[r] != originalGraph.columnComponent[c])
                    crossOriginal++;
            }
        }
        boolean stableOriginalComponents = samePartition(currentGraph, originalGraph);
        // The combined pass reads one current and one original cell, the two
        // graph passes read one matrix cell each, and the cross-component pass
        // reads one current cell: five matrix-cell reads per pair. This is an
        // operation-count diagnostic only; no clock is read inside it.
        long cells = ((long) n * (long) n) * 5L;
        return new SampleSnapshot(n, currentGraph, originalGraph, cells, added, removed,
            unchanged, valueDifferences, signedZeroDifferences, crossOriginal,
            stableOriginalComponents);
    }

    /** True only when current and original row/column partitions are identical. */
    private static boolean samePartition(Graph current, Graph original) {
        if (current.matrixSize != original.matrixSize) return false;
        int currentCount = current.components.length;
        int originalCount = original.components.length;
        int[] originalForCurrent = new int[currentCount];
        int[] currentForOriginal = new int[originalCount];
        for (int i = 0; i < currentCount; i++) originalForCurrent[i] = -1;
        for (int i = 0; i < originalCount; i++) currentForOriginal[i] = -1;
        int n = current.matrixSize;
        for (int vertex = 0; vertex < 2 * n; vertex++) {
            int currentId = vertex < n ? current.rowComponent[vertex] :
                current.columnComponent[vertex - n];
            int originalId = vertex < n ? original.rowComponent[vertex] :
                original.columnComponent[vertex - n];
            if (originalForCurrent[currentId] == -1)
                originalForCurrent[currentId] = originalId;
            else if (originalForCurrent[currentId] != originalId)
                return false;
            if (currentForOriginal[originalId] == -1)
                currentForOriginal[originalId] = currentId;
            else if (currentForOriginal[originalId] != currentId)
                return false;
        }
        return true;
    }

    /** Validates only the active n-by-n prefix; inactive allocation tails are ignored. */
    private static void requireSquare(double[][] matrix, int n, String name) {
        if (matrix == null || matrix.length < n)
            throw new IllegalArgumentException(name + " matrix shape");
        for (int i = 0; i < n; i++)
            if (matrix[i] == null || matrix[i].length < n)
                throw new IllegalArgumentException(name + " matrix row shape");
    }

    private static int[] copyIpvtPrefix(int[] ipvt, int n) {
        if (ipvt == null) return null;
        int length = Math.min(ipvt.length, n);
        int[] result = new int[length];
        System.arraycopy(ipvt, 0, result, 0, length);
        return result;
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    static final class SampleToken {
        final long ordinal;
        final int matrixSize;
        boolean dropped;
        boolean scanError;
        boolean preFactorCaptured;
        boolean finished;
        long zeroPivotFallbacks;
        boolean postFactorZeroRisk;
        long postFactorSentinelHits;
        SampleSnapshot snapshot;
        Opportunity opportunity;

        private SampleToken(long ordinal, int matrixSize) {
            this.ordinal = ordinal;
            this.matrixSize = matrixSize;
        }
    }

    static final class Report {
        final String phase;
        final int selectionInterval;
        final boolean valid;
        final boolean frozen;
        final boolean zeroPivotObservationAvailable;
        final long eligibleFactorCalls, selectedFactorCalls, completedFactorCalls;
        final long failedFactorCalls, droppedSampleRecords, scanErrors;
        final long diagnosticErrors, scanCellReads, lifecycleErrors, counterOverflow;
        final boolean scopeComplete, completeCapture;
        final Sample[] samples;

        private Report(String phase, int selectionInterval, boolean valid, boolean frozen,
                boolean scopeComplete, boolean completeCapture, boolean zeroPivotObservationAvailable,
                long eligibleFactorCalls,
                long selectedFactorCalls, long completedFactorCalls,
                long failedFactorCalls, long droppedSampleRecords, long scanErrors,
                long diagnosticErrors, long scanCellReads, long lifecycleErrors,
                long counterOverflow,
                Sample[] samples) {
            this.phase = phase;
            this.selectionInterval = selectionInterval;
            this.valid = valid;
            this.frozen = frozen;
            this.scopeComplete = scopeComplete;
            this.completeCapture = completeCapture;
            this.zeroPivotObservationAvailable = zeroPivotObservationAvailable;
            this.eligibleFactorCalls = eligibleFactorCalls;
            this.selectedFactorCalls = selectedFactorCalls;
            this.completedFactorCalls = completedFactorCalls;
            this.failedFactorCalls = failedFactorCalls;
            this.droppedSampleRecords = droppedSampleRecords;
            this.scanErrors = scanErrors;
            this.diagnosticErrors = diagnosticErrors;
            this.scanCellReads = scanCellReads;
            this.lifecycleErrors = lifecycleErrors;
            this.counterOverflow = counterOverflow;
            this.samples = copySamples(samples);
        }

        private static Sample[] copySamples(Sample[] source) {
            Sample[] result = new Sample[source.length];
            for (int i = 0; i < source.length; i++) result[i] = source[i].copy();
            return result;
        }
    }

    static final class Sample {
        final long ordinal;
        final int matrixSize;
        final SampleSnapshot snapshot;
        final Opportunity opportunity;
        final boolean factorSucceeded;
        final long zeroPivotFallbacks;
        final long postFactorSentinelHits;
        final int[] ipvtPrefix;
        final boolean ipvtTraceComplete;

        private Sample(long ordinal, int matrixSize, SampleSnapshot snapshot,
                Opportunity opportunity, boolean factorSucceeded,
                long zeroPivotFallbacks, long postFactorSentinelHits,
                int[] ipvtPrefix, boolean ipvtTraceComplete) {
            this.ordinal = ordinal;
            this.matrixSize = matrixSize;
            this.snapshot = snapshot;
            this.opportunity = opportunity;
            this.factorSucceeded = factorSucceeded;
            this.zeroPivotFallbacks = zeroPivotFallbacks;
            this.postFactorSentinelHits = postFactorSentinelHits;
            this.ipvtPrefix = ipvtPrefix == null ? new int[0] : ipvtPrefix.clone();
            this.ipvtTraceComplete = ipvtTraceComplete;
        }

        private Sample copy() {
            return new Sample(ordinal, matrixSize, snapshot.copy(), opportunity.copy(),
                factorSucceeded, zeroPivotFallbacks, postFactorSentinelHits,
                ipvtPrefix, ipvtTraceComplete);
        }
    }

    static final class SampleSnapshot {
        final int matrixSize;
        final Graph currentGraph, originalGraph;
        final long cellReads;
        final long supportAdded, supportRemoved, supportUnchanged;
        final long valueDifferences, signedZeroDifferences;
        final long currentCrossOriginalEdges;
        final boolean stableOriginalComponents;

        private SampleSnapshot(int matrixSize, Graph currentGraph, Graph originalGraph,
                long cellReads, long supportAdded, long supportRemoved,
                long supportUnchanged, long valueDifferences,
                long signedZeroDifferences, long currentCrossOriginalEdges,
                boolean stableOriginalComponents) {
            this.matrixSize = matrixSize;
            this.currentGraph = currentGraph;
            this.originalGraph = originalGraph;
            this.cellReads = cellReads;
            this.supportAdded = supportAdded;
            this.supportRemoved = supportRemoved;
            this.supportUnchanged = supportUnchanged;
            this.valueDifferences = valueDifferences;
            this.signedZeroDifferences = signedZeroDifferences;
            this.currentCrossOriginalEdges = currentCrossOriginalEdges;
            this.stableOriginalComponents = stableOriginalComponents;
        }

        private SampleSnapshot copy() {
            return new SampleSnapshot(matrixSize, currentGraph.copy(), originalGraph.copy(),
                cellReads, supportAdded, supportRemoved, supportUnchanged,
                valueDifferences, signedZeroDifferences, currentCrossOriginalEdges,
                stableOriginalComponents);
        }
    }

    static final class Graph {
        final int matrixSize;
        final int[] rowComponent, columnComponent;
        final Component[] components;
        final long edges, nonfiniteEntries;

        private Graph(int matrixSize, int[] rowComponent, int[] columnComponent,
                Component[] components, long edges, long nonfiniteEntries) {
            this.matrixSize = matrixSize;
            this.rowComponent = rowComponent;
            this.columnComponent = columnComponent;
            this.components = components;
            this.edges = edges;
            this.nonfiniteEntries = nonfiniteEntries;
        }

        private static Graph from(UnionFind uf, double[][] matrix, int n,
                long edges, long nonfiniteEntries) {
            int[] roots = new int[2 * n];
            int[] ids = new int[2 * n];
            for (int i = 0; i < ids.length; i++) ids[i] = -1;
            int componentCount = 0;
            for (int i = 0; i < roots.length; i++) {
                roots[i] = uf.find(i);
                if (ids[roots[i]] < 0) ids[roots[i]] = componentCount++;
            }
            int[] rowCounts = new int[componentCount];
            int[] columnCounts = new int[componentCount];
            for (int i = 0; i < n; i++) rowCounts[ids[roots[i]]]++;
            for (int i = 0; i < n; i++) columnCounts[ids[roots[n + i]]]++;
            long[] edgeCounts = new long[componentCount];
            for (int r = 0; r < n; r++)
                for (int c = 0; c < n; c++)
                    if (matrix[r][c] != 0.0)
                        edgeCounts[ids[roots[r]]]++;
            Component[] components = new Component[componentCount];
            for (int id = 0; id < componentCount; id++)
                components[id] = new Component(id, rowCounts[id], columnCounts[id],
                    edgeCounts[id]);
            int[] rowOffsets = new int[componentCount];
            int[] columnOffsets = new int[componentCount];
            for (int r = 0; r < n; r++) {
                int id = ids[roots[r]];
                components[id].rows[rowOffsets[id]++] = r;
            }
            for (int c = 0; c < n; c++) {
                int id = ids[roots[n + c]];
                components[id].columns[columnOffsets[id]++] = c;
            }
            int[] rowComponent = new int[n];
            int[] columnComponent = new int[n];
            for (int r = 0; r < n; r++) rowComponent[r] = ids[roots[r]];
            for (int c = 0; c < n; c++) columnComponent[c] = ids[roots[n + c]];
            return new Graph(n, rowComponent, columnComponent, components, edges,
                nonfiniteEntries);
        }

        private Graph copy() {
            Component[] componentCopy = new Component[components.length];
            for (int i = 0; i < components.length; i++) componentCopy[i] = components[i].copy();
            return new Graph(matrixSize, rowComponent.clone(), columnComponent.clone(),
                componentCopy, edges, nonfiniteEntries);
        }
    }

    static final class Component {
        final int id;
        final int[] rows, columns;
        final long edges;

        private Component(int id, int rowCount, int columnCount, long edges) {
            this.id = id;
            this.rows = new int[rowCount];
            this.columns = new int[columnCount];
            this.edges = edges;
        }

        private Component copy() {
            Component result = new Component(id, rows.length, columns.length, edges);
            System.arraycopy(rows, 0, result.rows, 0, rows.length);
            System.arraycopy(columns, 0, result.columns, 0, columns.length);
            return result;
        }
    }

    static final class Opportunity {
        final long fullPivotCandidates, localPivotCandidates;
        final long fullLowerCandidates, localLowerCandidates;
        final long fullUpperCandidates, localUpperCandidates;
        final boolean replayComplete, exact;
        final boolean crossGroupPivot, zeroPivotRisk, nonfiniteSupportData;
        final boolean initialOrderOnly, stableOriginalComponents;
        final boolean zeroPivotObservationAvailable;
        final boolean postFactorZeroRisk;
        final long zeroPivotFallbacks, postFactorSentinelHits;

        private Opportunity(long fullPivotCandidates, long localPivotCandidates,
                long fullLowerCandidates, long localLowerCandidates,
                long fullUpperCandidates, long localUpperCandidates,
                boolean replayComplete, boolean exact, boolean crossGroupPivot,
                boolean zeroPivotRisk, boolean nonfiniteSupportData,
                boolean initialOrderOnly, boolean stableOriginalComponents,
                boolean zeroPivotObservationAvailable, boolean postFactorZeroRisk,
                long zeroPivotFallbacks, long postFactorSentinelHits) {
            this.fullPivotCandidates = fullPivotCandidates;
            this.localPivotCandidates = localPivotCandidates;
            this.fullLowerCandidates = fullLowerCandidates;
            this.localLowerCandidates = localLowerCandidates;
            this.fullUpperCandidates = fullUpperCandidates;
            this.localUpperCandidates = localUpperCandidates;
            this.replayComplete = replayComplete;
            this.exact = exact;
            this.crossGroupPivot = crossGroupPivot;
            this.zeroPivotRisk = zeroPivotRisk;
            this.nonfiniteSupportData = nonfiniteSupportData;
            this.initialOrderOnly = initialOrderOnly;
            this.stableOriginalComponents = stableOriginalComponents;
            this.zeroPivotObservationAvailable = zeroPivotObservationAvailable;
            this.postFactorZeroRisk = postFactorZeroRisk;
            this.zeroPivotFallbacks = zeroPivotFallbacks;
            this.postFactorSentinelHits = postFactorSentinelHits;
        }

        private static Opportunity initial(Graph graph, boolean stableOriginalComponents) {
            long fullPivot = 0, localPivot = 0, fullLower = 0, localLower = 0;
            long fullUpper = 0, localUpper = 0;
            for (int k = 0; k < graph.matrixSize; k++) {
                fullPivot += graph.matrixSize - k;
                fullLower += Math.max(0, graph.matrixSize - k - 1);
                fullUpper += Math.max(0, graph.matrixSize - k - 1);
                int column = graph.columnComponent[k];
                for (int i = k; i < graph.matrixSize; i++) {
                    if (graph.rowComponent[i] == column) localPivot++;
                    if (i > k && graph.rowComponent[i] == column) localLower++;
                }
                for (int j = k + 1; j < graph.matrixSize; j++) {
                    if (graph.rowComponent[k] == graph.columnComponent[j]) localUpper++;
                }
            }
            return new Opportunity(fullPivot, localPivot, fullLower, localLower,
                fullUpper, localUpper, false, false, false, false,
                graph.nonfiniteEntries != 0, true, stableOriginalComponents, false,
                false, 0, 0);
        }

        private static Opportunity replay(Graph graph, Opportunity initial,
                int[] ipvt, boolean zeroObservationAvailable, long zeroFallbacks,
                boolean postFactorZeroRisk, long postFactorSentinelHits) {
            int n = graph.matrixSize;
            if (ipvt == null || ipvt.length < n)
                return initial.asIncomplete(zeroObservationAvailable, zeroFallbacks,
                    postFactorZeroRisk, postFactorSentinelHits);
            int[] rowLabels = graph.rowComponent.clone();
            long localPivot = 0, localLower = 0, localUpper = 0;
            boolean cross = false, zeroRisk = false, complete = true;
            for (int k = 0; k < n; k++) {
                int pivot = ipvt[k];
                if (pivot < k || pivot >= n) {
                    complete = false;
                    break;
                }
                int columnLabel = graph.columnComponent[k];
                int selectedLabel = rowLabels[pivot];
                if (selectedLabel != columnLabel) cross = true;
                long pivotRows = 0;
                for (int i = k; i < n; i++) {
                    if (rowLabels[i] == columnLabel) {
                        localPivot++;
                        pivotRows++;
                    }
                    if (i > k && rowLabels[i] == columnLabel) localLower++;
                }
                if (pivotRows == 0) zeroRisk = true;
                for (int j = k + 1; j < n; j++)
                    if (selectedLabel == graph.columnComponent[j]) localUpper++;
                if (pivot != k) {
                    int swap = rowLabels[k];
                    rowLabels[k] = rowLabels[pivot];
                    rowLabels[pivot] = swap;
                }
            }
            boolean nonfinite = initial.nonfiniteSupportData || graph.nonfiniteEntries != 0;
            boolean exact = complete && !cross && !zeroRisk && !nonfinite &&
                initial.stableOriginalComponents &&
                !postFactorZeroRisk && zeroObservationAvailable && zeroFallbacks == 0;
            return new Opportunity(initial.fullPivotCandidates, localPivot,
                initial.fullLowerCandidates, localLower, initial.fullUpperCandidates,
                localUpper, complete, exact, cross, zeroRisk, nonfinite, !complete,
                initial.stableOriginalComponents,
                zeroObservationAvailable, postFactorZeroRisk, zeroFallbacks,
                postFactorSentinelHits);
        }

        private Opportunity asIncomplete(boolean available, long fallbacks,
                boolean postFactorZeroRisk, long postFactorSentinelHits) {
            return new Opportunity(fullPivotCandidates, localPivotCandidates,
                fullLowerCandidates, localLowerCandidates, fullUpperCandidates,
                localUpperCandidates, false, false, false, false,
                nonfiniteSupportData, true, stableOriginalComponents, available,
                postFactorZeroRisk, fallbacks, postFactorSentinelHits);
        }

        private Opportunity copy() {
            return new Opportunity(fullPivotCandidates, localPivotCandidates,
                fullLowerCandidates, localLowerCandidates, fullUpperCandidates,
                localUpperCandidates, replayComplete, exact, crossGroupPivot,
                zeroPivotRisk, nonfiniteSupportData, initialOrderOnly,
                stableOriginalComponents, zeroPivotObservationAvailable,
                postFactorZeroRisk, zeroPivotFallbacks, postFactorSentinelHits);
        }
    }

    private static final class UnionFind {
        private final int[] parent;
        private final byte[] rank;

        UnionFind(int size) {
            parent = new int[size];
            rank = new byte[size];
            for (int i = 0; i < size; i++) parent[i] = i;
        }

        int find(int value) {
            int root = value;
            while (parent[root] != root) root = parent[root];
            while (parent[value] != value) {
                int next = parent[value];
                parent[value] = root;
                value = next;
            }
            return root;
        }

        void union(int left, int right) {
            int a = find(left), b = find(right);
            if (a == b) return;
            if (rank[a] < rank[b]) parent[a] = b;
            else if (rank[a] > rank[b]) parent[b] = a;
            else {
                parent[b] = a;
                rank[a]++;
            }
        }
    }

}
